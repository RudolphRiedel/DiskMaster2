	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Request modules 			15-Oct-91	*
	*								*
	*								*
	\***************************************************************/

#include "DM.h"

extern UBYTE    Version[];

struct BoolGadget{
	struct Gadget	Gadget;
	struct Border	Border[2];
	SHORT  APairs[6],BPairs[6];
	struct IntuiText IText; 	/* 20 */
	UBYTE  Filler[16];
};

struct StringGadget{
	struct Gadget	Gadget;
	struct Border	Border[2];
	SHORT  APairs[6],BPairs[6];
	struct StringInfo SInfo;	/* 36 */
	struct StringExtend SExt;
};

struct PropGadget{
	struct Gadget	Gadget;
	struct PropInfo PInfo;
	struct Image	PImage;
};

struct EasyStruct AboutData =
    {
    sizeof(struct EasyStruct),
    0,
   Version,
   "     DiskMaster II\n    Copyright � 1991\n  by Greg Cunningham\n\nDevelopment taken over\n      in 1997 by\n     Rudolph Riedel",
    "OK",
};

extern struct GfxBase		*GfxBase;
extern struct IntuitionBase	*IntuitionBase;
extern struct Screen		*Screen,*RScreen;
extern struct MsgPort		*WinPort;
extern struct TextAttr		FuckingTopaz;
extern struct TextFont		*MyTopaz;
extern int	Abort,Use20;
extern UBYTE	UndoBuff[],ScreenTitle[],*ActionArgs[],UserPStr[],PStr[],sbuff[],
		Version[];
extern UWORD	Pens20[];
struct Window	*ReqWin;
struct BoolGadget *BGads[20];

struct NewWindow NewReqWin={
	220,50,0,60,0,1,GADGETUP|VANILLAKEY,
	RMBTRAP|SMART_REFRESH|NOCAREREFRESH|WINDOWDRAG|WINDOWDEPTH|ACTIVATE,
	0,0,0,0,0,0,0,0,0,CUSTOMSCREEN
};

int	GadCount,YPos,XPos,GotPDefs,pitch,quality,LMarg,RMarg,Lpp,lpi,density,
	prNAME,prLINE,Reqing;

UBYTE	/* -deadcode format/diskcopy - dDev[5][6]={"DF0:","DF1:","DF2:","DF3:","    "},dName[4][30], */
	LMs[22]="Left Margin  <<  1>>",
	RMs[22]="Right Margin << 81>>",
	LPs[22]="Lines/Page   << 66>>",
	GDs[22]="Gfx Density  <<  2>>",
	PitchS[3][6]={"Pica ","Elite","Fine "},
	QualS[2][6]={"Draft"," NLQ "},
	LPI[2][6]={"8 LPI","6 LPI"};

void FreeBGads(void);
int OpenReq(void);
void prsetup(void);

void FreeBGads()
{FAST int i;

 for(i=0;i<20;i++){
	if(BGads[i]) FreeMem((UBYTE *)BGads[i],sizeof(struct StringGadget));
	BGads[i]=0;
 }
}

void SetupBorder(struct BoolGadget *bgad,int type)
{FAST struct Gadget *gad=&bgad->Gadget;
 FAST struct Border *bd=&bgad->Border[0];
 FAST SHORT	*pairs=&bgad->APairs[0],*map=(SHORT *)Screen->ViewPort.ColorMap->ColorTable;
 FAST int	pen1=1,pen2=2,t;

 if(!(map[1]&0x888)){pen1=2; pen2=1;}
 if(IntuitionBase->LibNode.lib_Version>34){pen1=Pens20[3]; pen2=Pens20[4];}
 if(type){t=pen1; pen1=pen2; pen2=t;}
 gad->GadgetRender=(APTR)bd;
 bd->FrontPen=pen1; bd->Count=3; bd->XY=pairs;
 pairs[1]=gad->Height-1; pairs[4]=gad->Width-1;
 bd=bd->NextBorder=&bgad->Border[1]; pairs=&bgad->BPairs[0];
 bd->FrontPen=pen2; bd->Count=3; bd->XY=pairs;
 pairs[0]=pairs[5]=1; pairs[1]=pairs[3]=gad->Height; pairs[2]=pairs[4]=gad->Width;
}

struct Gadget *AllocGad(UBYTE *str,int type,int id,int acti)
{FAST struct BoolGadget *bgad;
 FAST struct Gadget	*gad;
 FAST struct IntuiText	*itext;

 if(!(bgad=(struct BoolGadget *)AllocMem(sizeof(struct StringGadget),MEMF_CLEAR|MEMF_PUBLIC))) return(0);
 if(GadCount) BGads[GadCount-1]->Gadget.NextGadget=&bgad->Gadget;
 gad=&bgad->Gadget; gad->GadgetID=id; BGads[GadCount++]=bgad; gad->Height=13;
 gad->Activation=GADGIMMEDIATE|RELVERIFY|acti; gad->TopEdge=YPos;
 if(!type){
	gad->GadgetType=BOOLGADGET;
	itext=gad->GadgetText=&bgad->IText;
	gad->Width=(strlen(str)+1)<<3; itext->IText=str;
	itext->FrontPen=3;
	itext->DrawMode=JAM2;
	itext->ITextFont=&FuckingTopaz;
	gad->LeftEdge=XPos;
	XPos+=(gad->Width+4);
	itext->LeftEdge=5; itext->TopEdge=3;
	SetupBorder(bgad,0);
 }else{
	FAST struct StringGadget *sgad=(struct StringGadget *)bgad;
	FAST struct StringInfo	*si=&sgad->SInfo;

	if(IntuitionBase->LibNode.lib_Version>34) gad->Activation|=0x2000;
	gad->LeftEdge	=9;
	gad->GadgetType =STRGADGET;
	gad->SpecialInfo=(APTR)si;
	si->Buffer	=str;
	si->UndoBuffer	=UndoBuff;
	si->MaxChars	=type;
	si->BufferPos	=strlen(str);
	si->DispPos	=0;
	si->Extension	=&sgad->SExt;
	sgad->SExt.Font =MyTopaz;
	sgad->SExt.Pens[0]=Pens20[2];
	sgad->SExt.Pens[1]=Pens20[7];
	sgad->SExt.ActivePens[0]=Pens20[8];
	sgad->SExt.ActivePens[1]=Pens20[7];
	sgad->SExt.InitialModes=(1<<2);
	gad->Width	=NewReqWin.Width-14;
	SetupBorder(bgad,1);
	sgad->Border[0].LeftEdge=sgad->Border[1].LeftEdge=-3;
	sgad->Border[0].TopEdge=sgad->Border[1].TopEdge=-3;
	gad->Width-=4; gad->Height-=4;
 }
 return(gad);
}

int OpenReq()
{FAST struct RastPort	*rp;
 FAST struct Screen	*scr=Screen;

 if(RScreen) scr=RScreen;
 NewReqWin.LeftEdge=(scr->Width>>1)-(NewReqWin.Width>>1);
 NewReqWin.FirstGadget=0;
 if(BGads[0]) NewReqWin.FirstGadget=&BGads[0]->Gadget;
 NewReqWin.Height=YPos+17; NewReqWin.Screen=scr;
 NewReqWin.TopEdge=(scr->Height>>1)-(NewReqWin.Height>>1);
 if(!(ReqWin=OpenSharedWindow(&NewReqWin))) return(0);
 SetWindowTitles(ReqWin,Version,ScreenTitle);
 rp=ReqWin->RPort; SetFont(rp,MyTopaz);
 SetAPen(rp,1); SetBPen(rp,0); return(1);
}

void About()
{
 if(Use20) EasyRequest(NULL, &AboutData, NULL, NULL);
}

int DMReq(UBYTE *title,UBYTE *yes,UBYTE *no,UBYTE *abort,UBYTE *buf,int max)
{FAST struct RastPort	*rp;
 FAST struct IntuiMessage *msg;
 FAST struct Window	*win;
 FAST struct Gadget	*gad;
 FAST int		wid,id=2,done=0,c;

 if(Reqing){Abort=1; return(0);}
 YPos=Screen->BarHeight+17; XPos=6;
 if(max) YPos+=14;
 GadCount=0;
 if(!no) no="Cancel";
 if(!yes) yes="Continue";
 if(!title) title="NO TITLE!";
 if(!AllocGad(yes,0,1,0)) goto Q;
 if(abort) if(!AllocGad(abort,0,2,0)) goto Q;
 if(!(gad=AllocGad(no,0,0,0))) goto Q;
 gad->LeftEdge=(-8)-gad->Width; gad->Flags=GRELRIGHT;
 wid=(strlen(title)+2)<<3;
 if(wid<XPos) wid=XPos;
 NewReqWin.Width=wid+8;
 if(max){
	if(!(gad=AllocGad(buf,max,1,0))) goto Q;
	gad->TopEdge-=14;
 }
 if(!OpenReq()) return(0);
 rp=ReqWin->RPort; Move(rp,8,Screen->BarHeight+10);
 if(*title) Text(rp,title,strlen(title));

 if(max) ActivateGadget(gad,ReqWin,0);

 Reqing=1;
 while(!done){
	WaitPort(WinPort);
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		win=msg->IDCMPWindow; gad=(struct Gadget *)msg->IAddress;
		if(win==ReqWin){done=1;
			if(msg->Class==VANILLAKEY){
				c=MyToUpper(msg->Code); id=1;
				if(c==0x1b) id=2;
				if(c=='Q'||c=='C'||c=='N') id=0;
			}else id=gad->GadgetID;
		}
		ReplyMsg((struct Message *)msg);
	}
 }
 CloseSharedWindow(ReqWin);
 Reqing=0;
 if(!id&&max) strcpy(buf,UndoBuff);
Q: FreeBGads();
 if(id==2){Abort=1; id=0;}
 return(id);
}


void prsetup()
{
 sprintf(PStr,"\x1B[0m\x1B[0q\x1B[0w\x1B[%ldw\x1B[%ld;%lds\x1B[%ld\"z\x1B[%ldz\x1B[%ldt",
		pitch,LMarg,RMarg,quality+1,lpi,Lpp);
 if(BGads[0]){
	prNAME=(BGads[0]->Gadget.Flags&SELECTED);
	prLINE=(BGads[1]->Gadget.Flags&SELECTED);
 }
}

void PrDefault()
{FAST struct Preferences *prefs;

 if(GotPDefs) return;
 GotPDefs=1;
 if(!(prefs=(struct Preferences *)AllocMem(sizeof(struct Preferences),MEMF_PUBLIC))) return;
 GetPrefs(prefs,sizeof(struct Preferences));
 pitch=prefs->PrintPitch>>8;
 quality=prefs->PrintQuality>>8;
 lpi=1-(prefs->PrintSpacing>>9);
 LMarg=prefs->PrintLeftMargin;
 RMarg=prefs->PrintRightMargin;
 Lpp=prefs->PaperLength;
 density=prefs->PrintDensity;
 FreeMem(prefs,sizeof(struct Preferences));
 switch(pitch){
	case 2: RMarg=LMarg+96; break;
	case 4: RMarg=LMarg+196; break;
	default: RMarg=LMarg+80;
 }
}

void SetStrVal(UBYTE *str,int v)
{
 str+=15; sprintf(str,"%3ld",v); str[3]='>';
}

void SavePDefs(int fh)
{
 if(!GotPDefs) return;
 strcpy(sbuff,"SetPrinter");
 if(prNAME)	strcat(sbuff," HEADER");
 if(prLINE)	strcat(sbuff," NUMBERS");
 if(!pitch)	strcat(sbuff," PICA");
 if(pitch==2)	strcat(sbuff," ELITE");
 if(pitch==4)	strcat(sbuff," FINE");
 if(!quality)	strcat(sbuff," DRAFT");
 else		strcat(sbuff," NLQ");
 sprintf(sbuff,"%s DENSITY %ld LEFT %ld RIGHT %ld LINES %ld LPI %ld\n",sbuff,density,LMarg,RMarg,Lpp,lpi?6:8);
 Write(fh,sbuff,strlen(sbuff));
}

void PrintReq()
{FAST struct IntuiMessage *msg;
 FAST struct Gadget	*gad;
 FAST struct Window	*win;
 FAST UBYTE		*ptr;
 FAST int		done=0,mx,i=1;

 PrDefault(); prNAME=0; prLINE=0;
 while(ActionArgs[i]){
	ptr=ActionArgs[i]; mx=((*ptr)<<16)|((ptr[1])<<8)|ptr[2];
	switch(mx){
		case 0x44454e: i++; density=atoi(ActionArgs[i])&0xF; break;
		case 0x445241: quality=0; break;
		case 0x454c49: pitch=2; RMarg=LMarg+96; break;
		case 0x46494e: pitch=4; RMarg=LMarg+196; break;
		case 0x484541: prNAME=1; break;
		case 0x4e4c51: quality=1; break;
		case 0x4e554d: prLINE=1; break;
		case 0x4c4546: i++; LMarg=atoi(ActionArgs[i]); break;
		case 0x4c494e: i++; Lpp=atoi(ActionArgs[i]); break;
		case 0x4c5049: i++; lpi=(ActionArgs[i][0]=='6'); break;
		case 0x504943: pitch=0; RMarg=LMarg+80; break;
		case 0x524947: i++; RMarg=atoi(ActionArgs[i]); break;
	}
	i++;
 }
 if(!density) density=1;
 if(ActionArgs[1]){prsetup(); return;}
 SetStrVal(LMs,LMarg);
 SetStrVal(RMs,RMarg);
 SetStrVal(LPs,Lpp);
 SetStrVal(GDs,density);

 NewReqWin.Width=236;
 YPos=Screen->BarHeight+4; XPos=6; GadCount=0;
 if(!AllocGad("File Header" ,0,0,TOGGLESELECT)) goto Q;
 if(!AllocGad("Page Numbers",0,1,TOGGLESELECT)) goto Q;
 YPos+=16; XPos=6;
 if(!AllocGad(LMs,0,6,0)) goto Q;
 if(!AllocGad(LPI[lpi],0,3,0)) goto Q;
 YPos+=16; XPos=6;
 if(!AllocGad(RMs,0,7,0)) goto Q;
 if(!AllocGad(PitchS[pitch>>1],0,4,0)) goto Q;
 YPos+=16; XPos=6;
 if(!AllocGad(LPs,0,8,0)) goto Q;
 if(!AllocGad(QualS[quality],0,5,0)) goto Q;
 YPos+=16; XPos=6;
 if(!AllocGad(GDs,0,9,0)) goto Q;
 YPos+=20; XPos=6;
 if(!AllocGad(UserPStr,198,11,0)) goto Q;
 YPos+=16; XPos=6;
 if(!AllocGad("DONE",0,12,0)) goto Q;
 if(!(gad=AllocGad("CANCEL",0,13,0))) goto Q;
 gad->LeftEdge=(-8)-gad->Width; gad->Flags=GRELRIGHT;

 if(!OpenReq()) return;
 SetWindowTitles(ReqWin,"DM II  Printer Setup",ScreenTitle);

 while(!done){
	WaitPort(WinPort);
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		win=msg->IDCMPWindow;
		gad=(struct Gadget *)msg->IAddress; mx=msg->MouseX;
		ReplyMsg((struct Message *)msg);
		if(win==ReqWin) switch(gad->GadgetID){
			case  3: lpi^=1; gad->GadgetText->IText=LPI[lpi]; break;
			case  4: switch(pitch){
					case 0: pitch=2; RMarg=LMarg+96; break;
					case 2: pitch=4; RMarg=LMarg+196; break;
					default: pitch=0; RMarg=LMarg+80;
				 }
				 gad->GadgetText->IText=PitchS[pitch>>1];
				 SetStrVal(RMs,RMarg); break;
			case  5: quality^=1; gad->GadgetText->IText=QualS[quality]; break;
			case  6: if(mx>156&&LMarg<RMarg) LMarg++;
				 else if(mx<133&&mx>116&&LMarg>1) LMarg--;
				 SetStrVal(LMs,LMarg); break;
			case  7: if(mx>156) RMarg++;
				 else if(mx<133&&mx>116&&RMarg>LMarg) RMarg--;
				 SetStrVal(RMs,RMarg); break;
			case  8: if(mx>156) Lpp++;
				 else if(mx<133&&mx>116&&Lpp>0) Lpp--;
				 SetStrVal(LPs,Lpp); break;
			case  9: if(mx>156&&density<7) density++;
				 else if(mx<133&&mx>116&&density>1) density--;
				 SetStrVal(GDs,density); break;
			case 12: prsetup();
			case 13: done=1; break;
		}
		RefreshGadgets(&BGads[2]->Gadget,ReqWin,0);
	}
 }
 CloseSharedWindow(ReqWin);
Q: FreeBGads();
}

/* -deadcode format/diskcopy -

int DoDiskGad(int i)
{FAST struct Gadget	*gad;

 if(!(gad=AllocGad(dDev[i],0,i,TOGGLESELECT))) return(0);
 strcpy(dName[i],"Empty"); YPos+=3;
 if(!(gad=AllocGad(dName[i],30,i+4,0))) return(0);
 gad->LeftEdge=XPos+3; YPos+=13; XPos=6;
}

void FormatReq()
{FAST struct IntuiMessage *msg;
 FAST struct Gadget	*gad;
 FAST struct Window	*win;
 FAST int		i,done=0,aa;

 NewReqWin.Width=268;
 YPos=Screen->BarHeight+4; XPos=6; GadCount=0;
 if(!DoDiskGad(0)) goto Q;
 if(!DoDiskGad(1)) goto Q;
 if(!DoDiskGad(2)) goto Q;
 if(!DoDiskGad(3)) goto Q;

 if(!AllocGad("GO"	,0, 8,0)) goto Q;
 if(!AllocGad("QUICK"	,0, 9,TOGGLESELECT)) goto Q;
 if(!AllocGad("VERIFY"	,0,10,TOGGLESELECT)) goto Q;
 if(!AllocGad("INSTALL" ,0,11,TOGGLESELECT)) goto Q;
 if(!AllocGad("FFS"	,0,12,TOGGLESELECT)) goto Q;
 if(!AllocGad("CANCEL"	,0,13,0)) goto Q;

 NewReqWin.Width=314;

 if(!OpenReq()) return;

 while(!done){
	WaitPort(WinPort);
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		win=msg->IDCMPWindow; gad=(struct Gadget *)msg->IAddress;
		ReplyMsg((struct Message *)msg);
		if(win==ReqWin) switch(gad->GadgetID){
			case 13: Abort=1;
			case  8: done=1; break;
		}
	}
 }
 CloseSharedWindow(ReqWin);
 if(!Abort){
	aa=1;
	for(i=0;i<4;i++)
		if(BGads[i<<1]->Gadget.Flags&SELECTED){
			ActionArgs[aa++]=dDev[i];
			ActionArgs[aa++]=dName[i];
		}
	if(BGads[ 9]->Gadget.Flags&SELECTED) ActionArgs[aa++]="QUICK";
	if(BGads[10]->Gadget.Flags&SELECTED) ActionArgs[aa++]="VERIFY";
	if(BGads[11]->Gadget.Flags&SELECTED) ActionArgs[aa++]="INSTALL";
	if(BGads[12]->Gadget.Flags&SELECTED) ActionArgs[aa]="FFS";
 }
Q: FreeBGads();
}

void DiskCopyReq()
{FAST struct IntuiMessage *msg;
 FAST struct Gadget	*gad;
 FAST struct Window	*win;
 FAST int		i,done=0,dd=0,aa;

 NewReqWin.Width=194;
 YPos=Screen->BarHeight+20; XPos=6; GadCount=0;
 if(!AllocGad(dDev[0],0,0,TOGGLESELECT)) goto Q;
 i=XPos;
 if(!AllocGad(dDev[1],0,1,TOGGLESELECT)) goto Q;
 if(!AllocGad(dDev[2],0,2,TOGGLESELECT)) goto Q;
 if(!AllocGad(dDev[3],0,3,TOGGLESELECT)) goto Q;
 YPos-=16; XPos=i;
 if(!AllocGad("Multi Copy",0,4,TOGGLESELECT)) goto Q;
 XPos=6;
 if(!AllocGad(dDev[0],0,5,0)) goto Q;
 YPos+=32; XPos=6;
 if(!AllocGad("GO",0,12,0)) goto Q;
 if(!(gad=AllocGad("CANCEL",0,13,0))) goto Q;
 gad->LeftEdge=(-8)-gad->Width; gad->Flags=GRELRIGHT;
 if(!OpenReq()) return;
 while(!done){
	WaitPort(WinPort);
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		win=msg->IDCMPWindow; gad=(struct Gadget *)msg->IAddress;
		ReplyMsg((struct Message *)msg);
		if(win==ReqWin) switch(gad->GadgetID){
			case  5: if(++dd>3) dd=0;
				 gad->GadgetText->IText=dDev[dd]; break;
			case 13: Abort=1;
			case 12: done=1; break;
		}
		RefreshGadgets(&BGads[5]->Gadget,ReqWin,0);
	}
 }
 CloseSharedWindow(ReqWin);
 if(!Abort){
	aa=1;
	ActionArgs[aa++]=dDev[dd];
	for(i=0;i<4;i++)
		if(BGads[i]->Gadget.Flags&SELECTED) ActionArgs[aa++]=dDev[i];
	if(BGads[4]->Gadget.Flags&SELECTED) ActionArgs[aa]="MULTI";
 }
Q: FreeBGads();
}
*/