#include	<stdio.h>
#include	<string.h>
#include	<Exec/Types.h>
#include	<Exec/Memory.h>
#include	<Exec/Interrupts.h>
#include	<Devices/TrackDisk.h>
#include	<Devices/Audio.h>
#include	<Devices/Printer.h>
#include	<Intuition/IntuitionBase.h>
#include	<Intuition/sghooks.h>
#include	<Dos/DosExtens.h>
#include	<Dos/DosTags.h>
#include	<Dos/FileHandler.h>
#include	<Dos/ExAll.h>
#include	<Graphics/GfxBase.h>
#include	<Graphics/Text.h>
#include	"GIFF.h"
#include	<WorkBench/Startup.h>
#include	<Rexx/Storage.h>
#include	<workbench/workbench.h>
#include	<Proto/Icon.h>

#include	<Proto/Exec.h>
#include	<Proto/Dos.h>
#include	<Proto/Intuition.h>
#include	<Proto/Graphics.h>
#include	<Proto/RexxSysLib.h>
#include	<Proto/DiskFont.h>

#define FAST		register
#define sFIB		struct FileInfoBlock

#define ACTION(rmp)	(rmp->rm_Action)
#define RESULT1(rmp)	(rmp->rm_Result1)
#define RESULT2(rmp)	(rmp->rm_Result2)

#define DWFLAG_RESORT	1
#define DWFLAG_ADD	2
#define DW_CMD		(1<<2)
#define DWFLAG_RELOAD	(1<<3)
#define DW_SOURCE	(1<<4)
#define DW_DEST 	(1<<5)

struct DirList{
	LONG	size,attr;
	struct DateStamp ds;
	UBYTE	name[32],*cmt;
	BYTE	dir,sel;
};

struct DirWindow{
	struct Window		*Window;
	struct FileInfoBlock	*Fib;
	LONG			DiskFree,DirLock;
	struct DateStamp	PathDate;
	SHORT			Edge,Index,FileCount,Rows,ColsName,ColsCmt,
				BytesPerBlock,MaxFile,Sels,Flags;
	UBYTE			*Ptr,Path[516],Devi[32],Title[60],Pattern[32];
	struct Image		v_img,h_img;
	struct StringInfo	dir_str;
	struct StringExtend	SExt;
	struct PropInfo 	v_prop,h_prop;
	struct Gadget		dir_gad,v_gad,h_gad,up,dn,lf,rt,parent;
	struct DirList		**DirList;
};

struct LhBuffer{
	UBYTE *lh_Src;
	ULONG lh_SrcSize;
	UBYTE *lh_Dst;
	ULONG lh_DstSize;
	UBYTE *lh_Aux;
	ULONG lh_AuxSize,lh_Reserved;
};

int atoi(UBYTE *str);

/* DMWin.c */
void MainTitle(void);
void WinTitle(struct DirWindow *dw);
void ReSize(struct DirWindow *dw);
void SetHoriz(struct DirWindow *dw);
void SetVert(struct DirWindow *dw);
void DoFileFormat(struct DirList *dlp,int colsN,int colsC);
void dis_name(struct DirWindow *dw,int file,int pos);
void rdis_files(struct DirWindow *dw);
void dis_files(struct DirWindow *dw);
void Increment(struct DirWindow *dw,struct Gadget *gad);
void HorSlide(struct DirWindow *dw,struct Gadget *gad);
void ShowDirection(struct DirWindow *dw,int n);
void NewSize(struct DirWindow *dw);
void slide_em(struct DirWindow *dw,struct Gadget *gad);
void sel_file(struct DirWindow *dw,int my);
int  AllocDlp(struct DirWindow *dw);
int  GetNewPath(struct DirWindow *dw);
int  DiskShadow(struct DirWindow *dw,sFIB *fib);
void FreeDirTable(struct DirWindow *dw);
void InitDir(struct DirWindow *dw,int set);
void GetDirEntry(struct DirWindow *dw);
void Fib2Dlp(struct DirList *dlp,sFIB *fib);
void FindNewDirection(struct DirWindow *dw);
void CloseDirWindow(int num);
int  OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi);
struct Window *OpenSharedWindow(struct NewWindow *nw);
void CloseSharedWindow(struct Window *w);
int  SaveWin(struct DirWindow *dw,int fh);
int  SaveScreen(int fh);
int  SaveWindows(int fh);

/* DM.c */
void FreeUserJunk(void);
void SetTitles(void);
struct DirWindow *FindDMWin(struct Window *win);
void DMOpenFont(UBYTE *str);
void DoWindow(void);

/* DMCmd.c */
int CheckAbortKey(void);
void ReSort(void);
void GetHostScreen(UBYTE *str);
UBYTE *SkipWhite(UBYTE *ptr);
void GetParent(UBYTE *path,int root);
void DoStdio(UBYTE *str);
void display(UBYTE *format,UBYTE *arg1);
void SmartRemEntry(UBYTE *name);
void SmartAddEntry(UBYTE *name);
void AddCmd(struct DirWindow *dw,UBYTE *buf);
UBYTE *ParseArgs(UBYTE *buf,struct DirWindow *dw);
void GetCmdFile(struct DirWindow *dw,UBYTE *name,int size);
void ActionCmd(struct DirWindow *dw,UBYTE *buf);
void ExpandPath(UBYTE *path,sFIB *fib);
int GetGlobuff(LONG size);
void FreeGlobuff(void);
struct Screen *MyOpenScreen(int n,int m,UBYTE *);
void AutoFiler(struct DirWindow *dw,UBYTE *name);
void EditCmd(struct DirWindow *dw,int ni);
int CheckDWs(int type);
int DoKeyCmd(struct DirWindow *dw,int c);
void FreeKeyCmds(void);
void FreeAutoCmds(void);
/* void LoadMod(UBYTE *name); -deadcode play- */
int AutoUnpack(UBYTE *name,int type);
void GetDRI(struct Screen *s);

/* DMAsm.a */
void StartTimer(int secs);
void DMSort(struct DirList **dl,int count);
void DMSrtS(struct DirList **dl,int count);
void DMSrtD(struct DirList **dl,int count);
void StampTime(struct DateStamp *ds,UBYTE *str);
void StampDate(struct DateStamp *ds,UBYTE *str,int flags);
void StampProt(UBYTE *str,LONG prot);
void __asm MyStrUpper(FAST __a0 UBYTE *str);
UBYTE MyToUpper(UBYTE);
int DMMatch(UBYTE *,UBYTE *);
int AutoMatch(UBYTE *,UBYTE *,int);
BYTE *__asm UnpackRow(FAST __a0 BYTE *ptr,FAST __a1 BYTE *dest,FAST __d0 int len,FAST __d1 UBYTE comp);
LONG ACheckSignal(void);

/* DMMenus.c */
void AddMenuCmd(UBYTE *);
void DelMenuItem(struct MenuItem *);
void FreeMenus(void);
int WriteSbuff(int);
void SaveConfig(void);

/* DMShow.c */
void DMShow(UBYTE *fil);
void FreeOldPic(void);
void DoPattern(struct Window *w,UBYTE *fil,UBYTE *p);

/* DMRead.c */
void DMRead(UBYTE *file,sFIB *fib);
void CloseRead(void);

/* DMPal.c */
void SetColors(void);
void SetPens(void);
void DoPalette(int code,int x,int y,int class);
void OpenPalette(void);

struct LhBuffer *CreateBuffer(int size);
void DeleteBuffer(struct LhBuffer *lh);
int LhEncode(struct LhBuffer *lh);
int LhDecode(struct LhBuffer *lh);

/* DMReq.c */
void About(void);
int DMReq(UBYTE *title,UBYTE *yes,UBYTE *no,UBYTE *abort,UBYTE *buf,int max);
void SavePDefs(int fh);
void PrintReq(void);
void PrDefault(void);
/* -deadcode format/diskcopy -
void FormatReq(void);
void DiskCopyReq(void);
*/

/* DMDisk.c */
int DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new);
/* -deadcode format/diskcopy -
void MainDiskEntry(void);
*/