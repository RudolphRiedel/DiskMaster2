
	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Menu module						*
	*								*
	\***************************************************************/

#include "DM.h"

extern struct GfxBase		*GfxBase;
extern struct IntuitionBase	*IntuitionBase;
extern struct Screen		*Screen;
extern struct Process		*process;
extern struct MsgPort		*WinPort;
extern struct DirWindow 	*DirWin[],*CmdWin;
extern struct TextAttr		FuckingTopaz;
extern sFIB	Fib;
extern int	Abort,expandflag,RemMenu;
extern UBYTE	sbuff[],ActionBuf[],*ActionArgs[],Strap[],dcPath[];

struct Menu	*DMMenu;
struct IntuiText MText;

USHORT RenderImageData[] =
	{
		0x0000,0x0000,0x0004,0x0000,0x0000,0x0000,0x0001,0x0000,0x0000,0x0000,
		0x0000,0x4000,0x0000,0x0000,0x0000,0x1000,0x0000,0x0000,0x0000,0x0800,
		0x07C6,0x18F0,0x0000,0x0C00,0x07E7,0x3DF8,0x0000,0x0C00,0x07F7,0xFDDC,
		0x0000,0x0C00,0x0777,0xFCDC,0x0000,0x0C00,0x077F,0xFC3C,0x0000,0x0C00,
		0x077F,0x1C78,0x0000,0x0C00,0x07F7,0x1CF0,0x7FF0,0x0C00,0x07F7,0x1DF8,
		0x0000,0x0C00,0x03E3,0x0CFC,0x7E00,0x0C00,0x0000,0x0000,0x0000,0x0C00,
		0x0000,0x001F,0xFFFC,0x0C00,0x0000,0x0000,0x0000,0x0C00,0x0000,0x001F,
		0xFFC0,0x0C00,0x4000,0x0000,0x0000,0x0C00,0x1000,0x0000,0x0000,0x0C00,
		0x0400,0x0000,0x0000,0x0C00,0x01FF,0xFFFF,0xFFFF,0xFC00,0xFFFF,0xFFFF,
		0xFFF8,0x0000,0xD555,0x5555,0x5556,0x0000,0xD555,0x5555,0x5555,0x8000,
		0xDFFF,0xFFFF,0x5555,0x6000,0xD000,0x0001,0x5555,0x5000,0xD7C6,0x18F1,
		0x5555,0x5000,0xD7E7,0x3999,0x5555,0x5000,0xD667,0xF999,0x5555,0x5000,
		0xD676,0xD819,0x7FFF,0x5000,0xD676,0x1831,0x7FFF,0x5000,0xD666,0x1861,
		0x7FFF,0x5000,0xD7E6,0x18C1,0x000F,0x5000,0xD7C6,0x19F9,0x7FFF,0x5000,
		0xD000,0x0001,0x01FF,0x5000,0xDFFF,0xFFFF,0x7FFF,0x5000,0xD555,0x55E0,
		0x0003,0x5000,0xD555,0x55FF,0xFFFF,0x5000,0xD555,0x55E0,0x003F,0x5000,
		0x3555,0x55FF,0xFFFF,0x5000,0x0D55,0x55FF,0xFFFF,0x5000,0x0355,0x5555,
		0x5555,0x5000,0x0000,0x0000,0x0000,0x0000,0x0002,0x47D0,0x0000,0x4500,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,
		0x0000,0x0000
	};

struct Image RenderImage={
	0, 0, 54, 22, 2,
	RenderImageData,
	3, 0,
	NULL
};

struct DiskObject do_dm_config={
	0xE310,
	0x0001,
	{ /* struct Gadget */
		NULL,
		0,0,54,23,
		4,
		1,
		1,
		(APTR)&RenderImage,
		NULL,
		NULL,
		0,
		NULL,
		0,
		NULL
	},
	4,
	"",
	NULL,
	0x80000000,
	0x80000000,
	NULL,
	"",
	0
};

struct MIKludge{
	struct MenuItem item;
	struct IntuiText itext;
	UBYTE text[2];
};


void fixmenu(void)
{
 FAST struct Menu *menu;
 FAST struct MenuItem *item;
 FAST struct IntuiText *it;

 FAST int row, col=0, maxc, scr;
 struct IntuiText itxt;  /* To find width in case of proportional fonts */

    /* Initialize the few elements needed */

 itxt.ITextFont=Screen->Font;
 itxt.NextText=0;

 for(menu=DMMenu;menu;menu=menu->NextMenu){
	FAST short offset;  /* Offset for width; used for position of item
			  relative to it's menu header at end of loop */

	/* Put this menu header into the IntuiText and figure out how
	   wide it is in pixels */
	itxt.IText = menu->MenuName;
	maxc=IntuiTextLength(&itxt);	/* This is now # of pixels */

	/* Find 'average' character size */
	offset=(maxc/strlen(menu->MenuName))<<1;
	menu->Width=maxc+offset;

	row=0;
	for(item=menu->FirstItem;item;item=item->NextItem){
	    it = (struct IntuiText *)item->ItemFill;
	    item->TopEdge=row;
	    if(it){
		it->TopEdge=1;		/* Center in select box */
		it->LeftEdge=offset>>1;
		it->DrawMode=JAM1;	 /* How workbench's menus are... */
	    }

	    /* Figure out how wide this item is */
	    itxt.IText = ((struct IntuiText *)item->ItemFill)->IText;
	    scr=IntuiTextLength(&itxt);  /* This is now # of pixels */
	    if(item->Command) scr+=(COMMWIDTH+8);
	    if(scr>maxc) maxc=scr;

	    /* Figure out how tall the text is */
	    if(Screen->Font) item->Height=Screen->Font->ta_YSize+2;
	    else item->Height=GfxBase->DefaultFont->tf_YSize+2;

	    row+=item->Height;
	}
	maxc+=offset;

	/* Fit the menu onto the screen */
	if((maxc+10)>Screen->Width){   /* Wider than screen! */
	    offset=-col;
	    /* Unfortunately, this won't reduce the menu's width */
	    maxc=Screen->Width-12;
	}else if((offset=Screen->Width-(col+maxc+10))>0) offset=0;

	for(item=menu->FirstItem;item;item=item->NextItem){
		item->Width=maxc;
		item->LeftEdge=offset;
	}

	menu->LeftEdge=col;
	menu->Height=row;
	col+=menu->Width;
    }
}

struct Menu *AddMenu(UBYTE *name)
{FAST struct Menu *menu,*mptr=DMMenu;
 FAST UBYTE	*ptr;
 FAST int	len;

 name=SkipWhite(name); len=strlen(name)+1;
 while(mptr){
	if(!stricmp(name,mptr->MenuName)) return(mptr);
	mptr=mptr->NextMenu;
 }
 if(!(menu=(struct Menu *)AllocMem(sizeof(struct Menu)+len,MEMF_PUBLIC|MEMF_CLEAR)))
	return(0);
 ptr=(UBYTE *)menu+sizeof(struct Menu); menu->MenuName=ptr; strcpy(ptr,name);
 menu->Flags=MENUENABLED;
 if(!DMMenu) DMMenu=menu;
 else{	mptr=DMMenu;
	while(mptr->NextMenu) mptr=mptr->NextMenu;
	mptr->NextMenu=menu;
 }
 return(menu);
}

void AddMenuItem(struct Menu *menu,UBYTE *name,UBYTE key,UBYTE *cmd)
{FAST struct MIKludge	*myitem;
 FAST struct MenuItem	*item,*itemp;
 FAST struct IntuiText	*itext;
 FAST UBYTE		*nameptr,*cmdptr,*ptr;
 FAST int		size,len;

 len=strlen(name); ptr=name+len-1;
 while(*ptr==' '||*ptr==9){*ptr--=0; len--;}
 cmd=SkipWhite(cmd); cmdptr=cmd;
 while(*cmdptr>10){cmdptr++; len++;}
 size=sizeof(struct MIKludge)+len;
 if(!(myitem=(struct MIKludge *)AllocMem(size,MEMF_PUBLIC|MEMF_CLEAR))) return;
 item=&myitem->item; itext=&myitem->itext; nameptr=myitem->text;
 item->ItemFill=(APTR)itext; itext->TopEdge=1;
 itext->IText=nameptr; strcpy(nameptr,name); len=strlen(name)+1;
 item->Command=key;
 item->Flags=ITEMTEXT|ITEMENABLED|HIGHCOMP;
 if(key){item->Flags|=COMMSEQ; item->Width+=(COMMWIDTH+8);}
 nameptr+=len; cmdptr=cmd;
 while(*cmdptr>10) *nameptr++=*cmdptr++;
 itemp=menu->FirstItem;
 if(!itemp) menu->FirstItem=item;
 else{	while(itemp->NextItem) itemp=itemp->NextItem;
	itemp->NextItem=item;
 }
 fixmenu();
}

void menu_on(void)
{FAST int i;

 if(DMMenu) for(i=0;i<255;i++) if(DirWin[i]) SetMenuStrip(DirWin[i]->Window,DMMenu);
}

void menu_off(void)
{FAST int i;

 for(i=0;i<255;i++) if(DirWin[i]) ClearMenuStrip(DirWin[i]->Window);
}

void AddMenuCmd(UBYTE *buf)
{FAST struct Menu *menu;
 FAST UBYTE	*ptr,k;

 if(!buf||*buf==0){
	buf=ActionBuf; *buf=0;
	if(!DMReq("Command template: Menu,Title,A,<command string>",0,0,0,buf,512)) return;
 }
 menu_off();
 ptr=sbuff;
 while(*buf&&*buf!=10&&*buf!=',') *ptr++=*buf++;
 *ptr=0;
 if(!(menu=AddMenu(sbuff))) goto Q;
 if(*buf!=',') goto Q;
 ptr=sbuff; buf++;
 if(*buf==' '||*buf==10) buf++;
 while(*buf&&*buf!=10&&*buf!=',') *ptr++=*buf++;
 if(*buf!=',') goto Q;
 *ptr=0; buf++; k=0; buf=SkipWhite(buf);
 if(*buf&&buf[1]==','){k=*buf; buf+=2;}
 buf=SkipWhite(buf);
 if(*buf) AddMenuItem(menu,sbuff,k,buf);
Q: menu_on();
}

void DelMenu(struct Menu *menu2)
{
 FAST struct Menu *menu,**mpr=&DMMenu;
 FAST int size;
 FAST UBYTE *ptr;

 for(menu=*mpr;menu;menu=*mpr){
	if(menu==menu2){
	    *mpr=menu->NextMenu;
	    size=sizeof(struct Menu);
	    if(ptr=menu2->MenuName) size+=(strlen(ptr)+1);
	    FreeMem(menu2,size);
	    return;
	}
	mpr=&menu->NextMenu;
 }
}

void DelMenuItem(struct MenuItem *item)
{FAST struct Menu *menu;
 FAST struct MenuItem *itemp,**ipr;
 FAST struct IntuiText *itext=(struct IntuiText *)item->ItemFill;
 FAST int	len,size=sizeof(struct MenuItem)+sizeof(struct IntuiText);

 menu_off();
 RemMenu=0;
 for(menu=DMMenu;menu;menu=menu->NextMenu){
	ipr=&menu->FirstItem;
	for(itemp=*ipr;itemp;itemp=*ipr){
		if(itemp==item){
			FAST UBYTE *ptr;
			*ipr=itemp->NextItem;
			if(ptr=itext->IText){
				len=strlen(ptr)+1; size+=len; ptr+=len;
				len=strlen(ptr)+1; size+=len;
			}
			FreeMem(item,size);
			if(!menu->FirstItem) DelMenu(menu);
			fixmenu();
			menu_on(); return;
		}
		ipr = &itemp->NextItem;
	}
 }

 menu_on();
}

void FreeMenus(void)
{FAST struct Menu	*menu=DMMenu,*mtemp;
 FAST struct MenuItem	*item,*itemp;
 FAST struct IntuiText	*itext;
 FAST UBYTE		*ptr;
 FAST int		len,size;

 while(menu){
	item=menu->FirstItem;
	while(item){
		itext=(struct IntuiText *)item->ItemFill;
		size=sizeof(struct MenuItem)+sizeof(struct IntuiText);
		if(ptr=itext->IText){
			len=strlen(ptr)+1; size+=len; ptr+=len;
			len=strlen(ptr)+1; size+=len;
		}
		itemp=item->NextItem; FreeMem(item,size); item=itemp;
	}
	mtemp=menu->NextMenu; size=sizeof(struct Menu);
	if(ptr=menu->MenuName) size+=(strlen(ptr)+1);
	FreeMem(menu,size); menu=mtemp;
 }
 DMMenu=0;
}

int SaveMenus(int fh)
{FAST struct Menu	*menu=DMMenu;
 FAST struct MenuItem	*item;
 FAST struct IntuiText	*itext;
 FAST UBYTE		*ptr,*ptr2,*ptr3,cmd[4],c;

 while(menu){
	item=menu->FirstItem;
	ptr=menu->MenuName;
	while(item){
		itext=(struct IntuiText *)item->ItemFill;
		ptr2=itext->IText; ptr3=ptr2+strlen(ptr2)+1; c=item->Command;
		cmd[0]=cmd[3]=0; cmd[1]=','; cmd[2]=' ';
		if(c) cmd[0]=c;
		sprintf(sbuff,"AddMenu %s, %s, %s%s\n",ptr,ptr2,cmd,ptr3);
		if(WriteSbuff(fh)<=0) return(0);
		item=item->NextItem;
	}
	menu=menu->NextMenu; Write(fh,"\n",1);
 }
 return(1);
}

int WriteSbuff(int fh){return(Write(fh,sbuff,strlen(sbuff)));}

extern UBYTE *_ProgramName;

void SaveConfig()
{FAST UBYTE	*buf=ActionArgs[1];
 FAST int	fh,icon,ef;
 FAST UBYTE	savetype=ActionArgs[0][5];
 FAST struct Library *IconBase=OpenLibrary("icon.library",0);

 icon=(ActionArgs[2]&&!stricmp(ActionArgs[2],"ICON"));
 if(!buf||*buf==0){
	if(savetype!='M') buf=Strap+4;
	else{buf=dcPath; strcpy(dcPath,"RAM:CmdWindow.DM");}
	if(!buf||*buf==0){buf=dcPath; strcpy(buf,"Startup.DM");}
	icon=1;
	if(!DMReq("Enter filename to save",0,0,0,buf,512)) goto Q;
 }
 if(fh=Open(buf,MODE_NEWFILE)){
	if(savetype=='M'&&CmdWin){icon=0; SaveWin(CmdWin,fh);}
	else if(Write(fh,"Reset\n",6)){SaveScreen(fh); SaveMenus(fh); SavePDefs(fh); SaveWindows(fh);}
	Close(fh); SmartAddEntry(buf);
	if(icon){
		strcpy(sbuff,_ProgramName);
		ef=expandflag=1; expandflag=1;
		ExpandPath(sbuff,&Fib);
		expandflag=ef;
		do_dm_config.do_DefaultTool=sbuff;
		PutDiskObject(buf,&do_dm_config);
		sprintf(sbuff,"%s.info",buf);
		SmartAddEntry(sbuff);
	}
 }
Q: CloseLibrary(IconBase);
}

