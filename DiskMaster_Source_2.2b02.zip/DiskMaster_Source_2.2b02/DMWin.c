
	/***************************************************************\
	*			DiskMaster II		2-Sep-92	*
	*	Window module						*
	*								*
	*	Item disp/select, Dirload				*
	*								*
	\***************************************************************/

#include "DM.h"

#define GADREL		GADGIMMEDIATE|RELVERIFY
#define TOPOFFSET	12
#define DLPTR(x)	((struct DeviceList *)BADDR(x))
#define LENGTH(x)	(*(UBYTE *)BADDR(x))
#define STRING(x)	(((char *)BADDR(x))+1)

extern struct GfxBase		*GfxBase;
extern struct IntuitionBase	*IntuitionBase;
extern struct Screen		*Screen,*MyScreen;
extern struct Process		*process;
extern struct MsgPort		*WinPort;
extern struct DateStamp 	setStamp;
extern struct InfoData		InfoData;
extern struct DirWindow 	*DirWin[],*CDWin,*DestWin,*CmdWin;
extern struct DirList		*DClickDir;
extern struct Menu		*DMMenu;
extern struct TextFont		*DMFont,*MyTopaz;
extern struct TextAttr		FuckingTopaz;
extern struct FileInfoBlock	Fib;
extern UWORD	Pens20[];
extern UBYTE	ScreenTitle[],sbuff[],*NextPath,Strap[],PGadStr[],dcPath[],
		*AutoCmdStr[],*KeyCmdStr[];
extern int	KeepGoing,DWNum,lockcount,ChgCmd,DClick,expandflag,Use20,SortType;

int	LastI,DefaultEdge,ColFudge=33,LTotal;
UBYTE	DispFormat[60]="NS T DMY A C",
	TitleFormat[60]="%B/%F %I/%C",
	BarFormat[200]="DiskMaster %V %T %W %D%M%Y C:%C F:%F Total:%P",
	UndoBuff[516],hextab[]="0123456789ABCDEF",BackPattern[512];

WORD	VAHVectHi[]={17,0,  0, 0, 0,10},
	VAHVectLo[]={17,1, 17,10, 1,10},
	HAHVectHi[]={15,0,  0,0, 0,9},
	HAHVectLo[]={15,1, 15,9, 1,9},
	UpArrowVectors[]={-4,4, 0,0, 4,4},
	DownArrowVectors[]={-4,-4, 0,0, 4,-4},
	LeftArrowVectors[]={5,-2, 0,0, 5,2},
	RightArrowVectors[]={-5,-2, 0,0, -5,2};

struct Border
	VAHBorder2	={0,0,1,0,JAM1,3,VAHVectLo,0},
	VAHBorder 	={0,0,2,0,JAM1,3,VAHVectHi,&VAHBorder2},
	InVAHBorder2	={0,0,2,0,JAM1,3,VAHVectLo,0},
	InVAHBorder	={0,0,1,0,JAM1,3,VAHVectHi,&InVAHBorder2},
	HAHBorder2	={0,0,1,0,JAM1,3,HAHVectLo,0},
	HAHBorder 	={0,0,2,0,JAM1,3,HAHVectHi,&HAHBorder2},
	InHAHBorder2	={0,0,2,0,JAM1,3,HAHVectLo,0},
	InHAHBorder	={0,0,1,0,JAM1,3,HAHVectHi,&InHAHBorder2},
	UpArrowBorder	={9,3,1,0,JAM1,3,UpArrowVectors,&VAHBorder},
	DownArrowBorder	={9,7,1,0,JAM1,3,DownArrowVectors,&VAHBorder},
	LeftArrowBorder	={5,4,1,0,JAM1,3,LeftArrowVectors,&HAHBorder},
	RightArrowBorder={11,4,1,0,JAM1,3,RightArrowVectors,&HAHBorder};

struct IntuiText GadSText[4]={
	{1,0,JAM2,2,1,&FuckingTopaz,"S",0},
	{1,0,JAM2,2,1,&FuckingTopaz,"D",0},
	{1,0,JAM2,2,1,&FuckingTopaz,"C",0},
	{1,0,JAM2,2,1,&FuckingTopaz," ",0}
};

USHORT	PPairs[]={0,9, 11,9, 11,0,  11,0, 0,0, 0,9};

struct Border
	PBorder[]={
		{0,0,2,0,JAM1,3,&PPairs[0],&PBorder[1]},
		{0,0,1,0,JAM1,3,&PPairs[6],0},
	};

struct DirWindow DWTemplate={
	0,0,0,0,
	{0},
	0,0,0,0,0,0,0,0,0,0,
	0,"","","","",
	{0},{0},
	{0,(UBYTE *)&UndoBuff,0,512},
	{0},
	{FREEVERT|AUTOKNOB|0x10,0,0,0,0xFFFF},{FREEHORIZ|AUTOKNOB|0x10,0,0,0xFFFF,0},

	{0,  3,11,-23,  9,GRELWIDTH|GADGHCOMP,GADREL,STRGADGET,0,0,0,0,0,0,0},
	{0,-13,10, 10,-61,GRELHEIGHT|GRELRIGHT|GADGHNONE,GADREL|RIGHTBORDER,PROPGADGET,0,0,0,0,0,1,0},
	{0,  4,-7,-57,  6,GRELBOTTOM|GRELWIDTH|GADGHNONE,GADREL|BOTTOMBORDER,PROPGADGET,0,0,0,0,0,2,0},

	{0,-17,-31,18,11,GRELBOTTOM|GRELRIGHT|GADGHIMAGE,GADREL|RIGHTBORDER,BOOLGADGET,(APTR)&UpArrowBorder,(APTR)&InVAHBorder,0,0,0,3,0},
	{0,-17,-20,18,11,GRELBOTTOM|GRELRIGHT|GADGHIMAGE,GADREL|RIGHTBORDER,BOOLGADGET,(APTR)&DownArrowBorder,(APTR)&InVAHBorder,0,0,0,4,0},
	{0,-49, -9,16,10,GRELBOTTOM|GRELRIGHT|GADGHIMAGE,GADREL|BOTTOMBORDER,BOOLGADGET,(APTR)&LeftArrowBorder,(APTR)&InHAHBorder,0,0,0,5,0},
	{0,-33, -9,16,10,GRELBOTTOM|GRELRIGHT|GADGHIMAGE,GADREL|BOTTOMBORDER,BOOLGADGET,(APTR)&RightArrowBorder,(APTR)&InHAHBorder,0,0,0,6,0},
	{0,-14, 10,12,10,GRELRIGHT,GADREL|RIGHTBORDER,BOOLGADGET,(APTR)&PBorder,0,0,0,0,7,0},
	0
};

struct NewWindow
  NewWin={10,30,200,80,0,1,
	CLOSEWINDOW|GADGETDOWN|MOUSEBUTTONS|GADGETUP|NEWSIZE|ACTIVEWINDOW|VANILLAKEY|MENUPICK|DISKINSERTED,
	SMART_REFRESH|NOCAREREFRESH|WINDOWCLOSE|WINDOWDRAG|WINDOWDEPTH|WINDOWSIZING|ACTIVATE,
	0,0,0,0,0,80,70,0xFFFF,0xFFFF,CUSTOMSCREEN
  };

UBYTE *AddTStr(UBYTE *ptr,int i);
int  GZZWidth(struct DirWindow *dw);
struct DeviceList *NDevice(struct DeviceList *t,int type);
void GetDevListType(struct DirWindow *dw,int type);
void GetDevList(struct DirWindow *dw);
void FindRealDev(UBYTE *path,struct MsgPort *mp);
void ExpandPath(UBYTE *path,sFIB *fib);
int  CacheLoad(struct DirWindow *dw);
int  FindPattern(UBYTE *str);
void Separate(struct DirWindow *dw);

void RefreshGadget(struct Gadget *gad,struct Window *win)
{FAST struct Gadget *gad2=gad->NextGadget;

 gad->NextGadget=0; RefreshGadgets(gad,win,0); gad->NextGadget=gad2;
}

UBYTE *AddTStr(UBYTE *ptr,int i)
{UBYTE tbuf[24],*ptr2=tbuf;

 sprintf(tbuf,"%ld",i);
 while(*ptr2) *ptr++=*ptr2++;
 *ptr=0; return(ptr);
}

void MainTitle()
{FAST struct DateStamp *ds=&setStamp;
 FAST UBYTE	*ptr=ScreenTitle,*dptr=BarFormat;
 FAST int	c;

 DateStamp(ds);
 while(c=*dptr++){
	if(c!='%') *ptr++=c;
	else switch(c=MyToUpper(*dptr++)){
		case   0: return;
		case 'C': ptr=AddTStr(ptr,AvailMem(MEMF_CHIP)); break;
		case 'F': ptr=AddTStr(ptr,AvailMem(MEMF_FAST)); break;
		case 'P': ptr=AddTStr(ptr,AvailMem(0)); break;
		case 'T': StampTime(ds,ptr); ptr+=7; break;
		case 'D': StampDate(ds,ptr,1); ptr+=2; break;
		case 'M': StampDate(ds,ptr,2); ptr+=3; break;
		case 'Y': StampDate(ds,ptr,4); ptr+=2; break;
		case 'W': StampDate(ds,ptr,8); ptr+=3; break;

/*Version in Screen-Title*/

		case 'V': *ptr++='2'; *ptr++='.'; *ptr++='2'; *ptr++='b'; *ptr++='2'; break;
		default : *ptr++=c;
	}
 }
 *ptr=0;
}

void WinTitle(struct DirWindow *dw)
{FAST UBYTE	*ptr,*dptr=TitleFormat;
 FAST int	c;

 MainTitle();
 if(!dw) return;
 ReSize(dw); ptr=dw->Title;
 if(dw->FileCount&&dw->DirList[0]->dir>1);
 else while(c=*dptr++){
	if(c!='%') *ptr++=c;
	else switch(c=MyToUpper(*dptr++)){
		case   0: return;
/*Free*/	case 'F': ptr=AddTStr(ptr,dw->DiskFree); break;
/*Count*/	case 'C': ptr=AddTStr(ptr,dw->FileCount); break;
/*Sel */	case 'I': ptr=AddTStr(ptr,dw->Sels); break;
/*BSel*/	case 'B': ptr=AddTStr(ptr,LTotal); break;
		default : *ptr++=c;
	}
 }
 *ptr=0; SetWindowTitles(dw->Window,dw->Title,ScreenTitle);
}

void ReSize(struct DirWindow *dw)
{FAST struct DirList **dl=dw->DirList,*dlp;
 FAST int i,cols,cols1=0,cols2=0,total=0,sels=0;

 for(i=0;i<dw->FileCount;i++){
	dlp=dl[i];
	cols=strlen(dlp->name);
	if(cols>cols1) cols1=cols;
	if(dlp->cmt){
		cols=strlen(dlp->cmt);
		if(cols>cols2) cols2=cols;
	}
	if(dlp->sel){sels++; total+=dlp->size;}
 }
 dw->ColsName=cols1; dw->ColsCmt=cols2; LTotal=total; dw->Sels=sels;
 if(dw->FileCount&&(dw->DirList[0]->dir==2||dw->DirList[0]->dir==3)) dw->ColsCmt=0;
}

int GZZWidth(struct DirWindow *dw)
{
 return(dw->Window->Width-dw->Window->BorderLeft-dw->Window->BorderRight);
}

void SetHoriz(struct DirWindow *dw)
{FAST int	hbody=dw->h_prop.HorizBody,i,j=ColFudge;

 i=GZZWidth(dw)/DMFont->tf_XSize;
 ReSize(dw); dw->h_prop.HorizBody=0xFFFF;
 if(j>(i+1)){
	dw->h_prop.HorizBody=(i<<16)/(j-1);
	dw->Edge=(dw->h_prop.HorizPot*(j-i))>>16;
 }else{dw->Edge=0; dw->h_prop.HorizPot=0;}
 if(j>(i+1)) dw->h_prop.HorizBody=(i<<16)/(j-1);
 if(!dw->Edge) dw->h_prop.HorizPot=0;
 if(hbody!=dw->h_prop.HorizBody) RefreshGadget(&dw->h_gad,dw->Window);
}

void SetVert(struct DirWindow *dw)
{FAST int vbody=dw->v_prop.VertBody;

 dw->v_prop.VertBody=0xFFFF;
 if(dw->FileCount>dw->Rows) dw->v_prop.VertBody=((LONG)(dw->Rows-1)<<16)/(dw->FileCount-1);
 else dw->Index=0;
 if(!dw->Index) dw->v_prop.VertPot=0;
 if(vbody!=dw->v_prop.VertBody) RefreshGadget(&dw->v_gad,dw->Window);
}

void DoFileFormat(struct DirList *dlp,int colsN,int colsC)
{FAST UBYTE	*ptr=sbuff,*dptr=DispFormat,*ptr2,*ptr3;
 FAST int	c;

 setmem(ptr,200,' ');
 while(*dptr) switch(c=MyToUpper(*dptr++)){
	case 'N': sprintf(ptr,"%-31s",dlp->name); ptr[31]=' '; ptr+=colsN; break;
	case 'C': if(dlp->dir==3) break;
		  if(dlp->dir==2){
			ptr3=ptr+2; ptr2=0;
			if(dlp->attr==DLT_DEVICE) ptr2="(DEV)";
			else if(dlp->attr==DLT_VOLUME) ptr2="(VOL)";
			else if(dlp->attr==DLT_DIRECTORY) ptr2="(ASN)";
			colsC=7;
		  }else{ptr2=dlp->cmt; ptr3=ptr;}
		  if(ptr2) while(*ptr2) *ptr3++=*ptr2++;
		  ptr+=colsC; break;
	case 'S': if(dlp->dir>1) break;
		  sprintf(ptr,"%9ld",dlp->size); ptr[9]=' '; ptr+=8;
		  if(dlp->dir&&!dlp->size) *ptr=' ';
		  ptr++; break;
	case 'T': if(dlp->dir<2){StampTime(&dlp->ds,ptr  ); ptr+=7;}	break;
	case 'D': if(dlp->dir<2){StampDate(&dlp->ds,ptr,1); ptr+=2;}	break;
	case 'M': if(dlp->dir<2){StampDate(&dlp->ds,ptr,2); ptr+=3;}	break;
	case 'Y': if(dlp->dir<2){StampDate(&dlp->ds,ptr,4); ptr+=2;}	break;
	case 'W': if(dlp->dir<2){StampDate(&dlp->ds,ptr,8); ptr+=3;}	break;
	case 'A': if(dlp->dir<2){StampProt(ptr,dlp->attr ); ptr+=8;}	break;
	default : if(dlp->dir<2) *ptr++=c;
 }
 ColFudge=(ptr-sbuff)+1;
}

void dis_name(struct DirWindow *dw,int file,int pos)
{FAST struct RastPort *rp=dw->Window->RPort;
 FAST struct DirList **dl=dw->DirList,*dlp=dl[file];
 FAST UBYTE	*ptr=sbuff;
 FAST int	Ap=Pens20[TEXTPEN],Bp=Pens20[BACKGROUNDPEN],cols;

 if(pos>dw->Rows) return;
 setmem(ptr,200,' ');
 if(file>=0&&file<dw->FileCount&&dlp->sel<2){
	DoFileFormat(dlp,dw->ColsName,dw->ColsCmt);
	if(dlp->dir==3){
		Ap=dlp->attr&0xF; Bp=(dlp->attr>>4)&0xF;
		if(dlp->sel){Bp^=0xF; Ap^=0xF;}
	}else{	if(dlp->sel) Bp=3; //Pens20[SHINEPEN];
		if(dlp->dir&&dlp->dir<3) Ap=2; //Pens20[HIGHLIGHTTEXTPEN];
	}
	if(Screen->BitMap.Depth==1){Bp=dlp->sel; Ap=Bp^1;}
	if(Ap==Bp) Bp++;
 }
 SetAPen(rp,Ap); SetBPen(rp,Bp);
 Move(rp,dw->Window->BorderLeft,(pos*DMFont->tf_YSize)+dw->Window->BorderTop+TOPOFFSET+DMFont->tf_Baseline);
 ptr=sbuff+dw->Edge; cols=GZZWidth(dw)/DMFont->tf_XSize; Text(rp,ptr,cols);
}

void rdis_files(struct DirWindow *dw)
{FAST struct RastPort	*rp=dw->Window->RPort;
 FAST int		pos,s,VPot,maxname=dw->Rows-1,w,h=DMFont->tf_YSize,
			top=dw->Window->BorderTop+TOPOFFSET;

 if(dw->FileCount<maxname) return;
 w=GZZWidth(dw); s=dw->Window->BorderLeft;
 while(1){
	VPot=dw->v_prop.VertPot; pos=(VPot*(dw->FileCount-maxname))>>16;
	if(pos==dw->Index) return;
	if(pos>dw->Index&&pos<dw->Index+(maxname>>1)){
		ClipBlit(rp,s,top+h,rp,s,top,w,maxname*h,0xC0);
		dw->Index++; dis_name(dw,dw->Index+maxname,maxname);
	}else if(pos<dw->Index&&pos>dw->Index-(maxname>>1)){
		ClipBlit(rp,s,top,rp,s,top+h,w,maxname*h,0xC0);
		dw->Index--; dis_name(dw,dw->Index,0);
	}else{dw->Index=pos; dis_files(dw);}
 }
}

void dis_files(struct DirWindow *dw)
{FAST int i;

 dw->Rows=(dw->Window->Height-dw->Window->BorderTop-TOPOFFSET-10)/DMFont->tf_YSize;
 dis_name(dw,dw->Index,0); SetHoriz(dw); SetVert(dw);
 for(i=0;i<dw->Rows;i++) dis_name(dw,i+dw->Index,i);
}

void Increment(struct DirWindow *dw,struct Gadget *gad)
{FAST int add,def,ft=0;

 if(dw->FileCount<=dw->Rows) return;
 def=0xFFFF/(dw->FileCount-dw->Rows);
 if(gad->GadgetID==3)	add=-def;
 else			add=def+1;
 do{	if((!dw->Index&&add<0)||(dw->Index>(dw->FileCount-dw->Rows-1)&&add>0)) break;
	def=dw->v_prop.VertPot;
	if(def+add>0xFFFF) add=0xFFFF-def;
	dw->v_prop.VertPot+=add; RefreshGadget(&dw->v_gad,dw->Window);
	rdis_files(dw);
	if(!ft&&gad->Flags>0x80){Delay(12); ft=1;}
 }while(gad->Flags>0x80);
}

void HorSlide(struct DirWindow *dw,struct Gadget *gad)
{FAST int	add,def,cols,clc,ft=0;

 cols=GZZWidth(dw)/DMFont->tf_XSize; clc=(ColFudge-cols-1);
 if(clc<=1) return;
 def=0xFFFF/clc;
 if(gad->GadgetID==5)	add=-def;
 else			add=def+1;
 do{	if((!dw->Edge&&add<0)||(dw->Edge>(clc-1)&&add>0)) break;
	def=dw->h_prop.HorizPot;
	if(def+add>0xFFFF) add=0xFFFF-def;
	dw->h_prop.HorizPot+=add; RefreshGadget(&dw->h_gad,dw->Window);
	dis_files(dw);
	if(!ft){Delay(12); ft=1;}
 }while(gad->Flags>0x80);
}

void ShowDirection(struct DirWindow *dw,int n)
{
 if(dw){
	if(dw->Flags&DW_SOURCE) n=0;
	if(dw->Flags&DW_DEST) n=1;
	if(dw->Flags&DW_CMD) n=2;
	if(n==4){
		n=1;
		if(dw==CDWin) n=0;
	}
	dw->parent.GadgetText=&GadSText[n];
	RefreshGadget(&dw->parent,dw->Window);
 }
}

void NewSize(struct DirWindow *dw)
{FAST struct Window	*win=dw->Window;
 FAST struct RastPort	*rp=win->RPort;
 FAST int tp=dw->v_gad.TopEdge;

 dw->dir_str.BufferPos=0; SetAPen(rp,Pens20[BACKGROUNDPEN]);
 RectFill(rp,win->BorderLeft,tp-1,win->Width-win->BorderRight-1,win->Height-win->BorderBottom-1);
 SetAPen(rp,Pens20[SHINEPEN]); Move(rp,2,tp-2); Draw(rp,win->Width-win->BorderRight-1,tp-2);
 SetAPen(rp,Pens20[SHADOWPEN]); Move(rp,2,tp); Draw(rp,win->Width-win->BorderRight-1,tp);
 ShowDirection(DestWin,1); ShowDirection(CDWin,0);
 dis_files(dw); rdis_files(dw); WinTitle(dw);
}

void slide_em(struct DirWindow *dw,struct Gadget *gad)
{FAST int r=0,id=gad->GadgetID;

 if(id==3||id==4){Increment(dw,gad); return;}
 if(id==5||id==6){HorSlide(dw,gad); return;}
 if(id==2) r=1;
 else if(id!=1) return;
 do{	if(r) dis_files(dw);
	else rdis_files(dw);
 }while(gad->Flags>0x80);
}

void sel_file(struct DirWindow *dw,int my)
{FAST struct DirList **dl=dw->DirList,*dlp;
 FAST struct Message *msg;
 FAST int	i,ni,cm;
 FAST UBYTE	smear=5;
 FAST struct	Window *win=dw->Window;

 cm=(dw->Flags&DW_CMD);
 if(my>(win->Height-win->BorderBottom)) return;
 if(DClick&&!cm&&NextPath!=dw->Path) if(GetNewPath(dw)) return;
 if(!dw->FileCount) return;
 i=(my-win->BorderTop-TOPOFFSET)/DMFont->tf_YSize;
 do{	ni=i+dw->Index;
	if(i<0||i>=dw->Rows||ni>=dw->FileCount) goto SK;
	if(win->MouseX>(win->Width-win->BorderRight)) goto SK;
	dlp=dl[ni];
	if(!dlp) goto SK;
	if(smear==5){dlp->sel^=1; smear=dlp->sel;}
	else if(dlp->sel==smear){Delay(2); goto SK;}
	else dlp->sel=smear;
	if(dlp->dir&&dlp->dir<3){
		if(DClick&&DClickDir==dlp&&!dlp->sel&&LastI==i) if(GetNewPath(dw)) return;
		LastI=i; DClickDir=dlp; NextPath=dw->Path; DClick=0;
	}else DClickDir=0;
	if(!dlp->dir){
		if(LastI==i&&DClick&&!dlp->sel){AutoFiler(dw,dlp->name); smear=4;}
		else LastI=i;
	}
	if(dlp->dir==3){
		dis_name(dw,ni,i);
		if(ChgCmd) EditCmd(dw,ni);
		else ActionCmd(dw,dlp->cmt);
		if(dw!=CmdWin) return;
		dw=CmdWin; dlp->sel=0; smear=4;
	}
	DClick=0; dis_name(dw,ni,ni-dw->Index); LastI=i;
	if(smear==4) return;
SK:	ni=(win->MouseY-win->BorderTop-TOPOFFSET)/DMFont->tf_YSize;
	if(ni>i) i++;
	else if(ni<i) i--;
	if(i>=dw->Rows&&i<dw->FileCount){i--; Increment(dw,&dw->dn);}
	if(i<0&&dw->Index){i++; Increment(dw,&dw->up);}
	WaitTOF();
 }while(!(msg=GetMsg(WinPort)));
 if(msg) ReplyMsg(msg);
 WinTitle(dw);
}

/* --------------------------- DIRECTORY LOAD --------------------------------- */
struct DeviceList *NDevice(struct DeviceList *t,int type)
{FAST struct DeviceNode *dn;

 while(t){
	dn=(struct DeviceNode *)t;
	if(t->dl_Type==type&&dn->dn_Task) return(t);
	t=DLPTR(t->dl_Next);
 }
 return(t);
}

int AllocDlp(struct DirWindow *dw)
{FAST struct DirList **dl=dw->DirList;
 FAST int size;

 if(dw->FileCount>=dw->MaxFile){
	size=dw->MaxFile<<2;
	if(!(dl=(struct DirList **)AllocMem(size+2000,MEMF_PUBLIC|MEMF_CLEAR)))
		return(0);
	movmem(dw->DirList,dl,size); FreeMem(dw->DirList,size);
	dw->DirList=dl; dw->MaxFile+=500;
 }
 return((int)(dl[dw->FileCount]=(struct DirList *)AllocMem(sizeof(struct DirList),MEMF_PUBLIC|MEMF_CLEAR)));
}

void GetDevListType(struct DirWindow *dw,int type)
{FAST struct RootNode	*rn=(struct RootNode *)DOSBase->dl_Root;
 FAST struct DosInfo	*di=(struct DosInfo *)BADDR(rn->rn_Info);
 FAST struct DeviceList *t=NDevice(DLPTR(di->di_DevInfo),type);
 FAST struct DirList	**dl,**sdl=&dw->DirList[dw->FileCount],*dlp;
 FAST struct DeviceNode *dn;
 FAST int		n=0,l;

 while(t){
	if(!AllocDlp(dw)) return;
	dl=dw->DirList; dlp=dl[dw->FileCount++];
	dlp->dir=2; dn=(struct DeviceNode *)t; dlp->attr=type;
	l=LENGTH(dn->dn_Name);
	movmem(STRING(dn->dn_Name),dlp->name,l);
	dlp->name[l++]=':'; dlp->name[l]=0;
	n++; t=NDevice(DLPTR(t->dl_Next),type);
 }
 DMSort(sdl,n);
}

void GetDevList(struct DirWindow *dw)
{
 GetDevListType(dw,DLT_DEVICE); GetDevListType(dw,DLT_VOLUME);
 GetDevListType(dw,DLT_DIRECTORY); dw->Path[0]=0; ReSize(dw); NewSize(dw);
}

void FindRealDev(UBYTE *path,struct MsgPort *mp)
{FAST struct RootNode	*rn=(struct RootNode *)DOSBase->dl_Root;
 FAST struct DosInfo	*di=(struct DosInfo *)BADDR(rn->rn_Info);
 FAST struct DeviceList *t=NDevice(DLPTR(di->di_DevInfo),DLT_DEVICE);
 FAST struct DeviceNode *dn;

 while(t){
	dn=(struct DeviceNode *)t;
	if(dn->dn_Task==mp){strcpy(path,STRING(dn->dn_Name)); strcat(path,":"); return;}
	t=NDevice(DLPTR(t->dl_Next),DLT_DEVICE);
 }
}

int GetNewPath(struct DirWindow *dw)
{FAST UBYTE *ptr,*ptr2;

 if(NextPath&&DClick&&DClickDir){
	if(DestWin&&DestWin!=dw&&LastI>=0)
		{DClickDir->sel=0; dis_name(DestWin,LastI+DestWin->Index,LastI);}
	dw->h_prop.HorizPot=0; dw->v_prop.VertPot=0; LastI=-1;
	dw->Index=0; dw->Edge=DefaultEdge;
	strcpy(dw->Path,NextPath); ptr=dw->Path+strlen(dw->Path)-1;
	ptr2=DClickDir->name;
	if(*ptr&&*(ptr2+strlen(ptr2)-1)!=':'){
		if(*ptr++!=':'){*ptr++='/'; *ptr=0;}
	}else ptr=dw->Path;
	strcpy(ptr,DClickDir->name); DClick=0; DClickDir=0;
	InitDir(dw,0); return(1);
 }
 return(0);
}

void ExpandPath(UBYTE *path,sFIB *fib)
{FAST int lock,curdir,i=0,c;

 if(!path[0]||!expandflag) return;
 lock=Lock(path,ACCESS_READ); path[0]=0;
 if(!lock) return;
 while(lock&&Examine(lock,fib)){
	if(path[0]) strins(path,"/");
	strins(path,fib->fib_FileName); i=strlen(fib->fib_FileName);
	curdir=ParentDir(lock); UnLock(lock); lock=curdir;
 }
 c=path[i]; path[i++]=':';
 if(!c) path[i]=0;
 if(lock) UnLock(lock);
}

int DiskShadow(struct DirWindow *dw,sFIB *fib)
{FAST struct DateStamp *ds1,*ds2;
 FAST struct DeviceNode *dn;
 FAST int lock;

 dw->DiskFree=0;
 if(!dw->Path[0]) return(1);
 if(!(lock=Lock(dw->Path,ACCESS_READ))) return(1);
 Info(lock,&InfoData); dw->BytesPerBlock=InfoData.id_BytesPerBlock;
 dw->DiskFree=(InfoData.id_NumBlocks-InfoData.id_NumBlocksUsed-2)*InfoData.id_BytesPerBlock;
 if(dw->DiskFree<0) dw->DiskFree=0;
 dn=(struct DeviceNode *)BADDR(InfoData.id_VolumeNode);
 FindRealDev(dw->Devi,dn->dn_Task); dw->DirLock=lock;
 if(!Examine(lock,fib)) return(0);
 ds1=&dw->PathDate; ds2=&fib->fib_Date; ds1->ds_Days=ds2->ds_Days;
 ds1->ds_Minute=ds2->ds_Minute; ds1->ds_Tick=ds2->ds_Tick;
 return(1);
}

void FreeDirTable(struct DirWindow *dw)
{FAST struct DirList **dl=dw->DirList;
 FAST int i;

 if(dw->DirLock){UnLock(dw->DirLock); dw->DirLock=0;
	if(lockcount) lockcount--;
 }
 for(i=0;i<dw->FileCount;i++){
	if(dl[i]->cmt) FreeMem(dl[i]->cmt,strlen(dl[i]->cmt)+1);
	FreeMem(dl[i],sizeof(struct DirList));
 }
 dw->FileCount=0;
}

int CacheLoad(struct DirWindow *dw)
{FAST struct DirWindow *dw2;
 FAST struct DirList **dl,**dl2,*dlp,*dlp2;
 FAST UBYTE *ptr;
 FAST int i;

 for(i=0;i<255;i++){
	dw2=DirWin[i];
	if(dw2&&dw!=dw2&&!strcmp(dw->Path,dw2->Path)) break;
 }
 if(i==255||!dw2||!dw2->FileCount) return(0);
 ReSort();
 if(dw2->DirLock||dw2->Flags&DWFLAG_RELOAD){dw->Flags|=DWFLAG_RELOAD; return(0);}
 dl2=dw2->DirList;
 for(i=0;i<dw2->FileCount;i++){
	dlp2=dl2[i];
	if(dw->Pattern[0]) if(!DMMatch(dlp2->name,dw->Pattern)) continue;
	if(!AllocDlp(dw)) return(1);
	dl=dw->DirList; dlp=dl[dw->FileCount++];
	dlp->size=dlp2->size; dlp->attr=dlp2->attr;
	dlp->ds.ds_Days=dlp2->ds.ds_Days; dlp->ds.ds_Minute=dlp2->ds.ds_Minute;
	dlp->ds.ds_Tick=dlp2->ds.ds_Tick; dlp->dir=dlp2->dir;
	movmem(dlp2->name,dlp->name,30); ptr=dlp2->cmt;
	if(ptr&&*ptr) if(dlp->cmt=AllocMem(strlen(ptr)+1,MEMF_PUBLIC|MEMF_CLEAR))
			strcpy(dlp->cmt,ptr);
 }
 switch(SortType){
	case 0: DMSort(dw->DirList,dw->FileCount); break;
	case 1: DMSrtS(dw->DirList,dw->FileCount); break;
	case 2: DMSrtD(dw->DirList,dw->FileCount); break;
 }
 ReSize(dw); NewSize(dw); return(1);
}

int FindPattern(UBYTE *str)
{
 while(*str){
	if(*str=='*'||*str=='?'||*str=='#') return(1);
	str++;
 }
 return(0);
}

void Separate(struct DirWindow *dw)
{FAST UBYTE	*mark,*str=dw->Path;
 FAST int	len=strlen(str);

 while(len){
	if(str[len]==':'){mark=str+len+1; break;}
	if(str[len]=='/'){mark=str+len; *mark=0; mark++; break;}
	len--;
 }
 strcpy(dw->Pattern,mark); *mark=0; MyStrUpper(dw->Pattern);
}

void ExDone(struct DirWindow *dw)
{register struct DirWindow *dw2;
 register int i;

 UnLock(dw->DirLock); dw->DirLock=0;
 FreeMem(dw->Fib,sizeof(sFIB)); dw->Fib=0;
 if(lockcount) lockcount--;
 switch(SortType){
	case 0: DMSort(dw->DirList,dw->FileCount); break;
	case 1: DMSrtS(dw->DirList,dw->FileCount); break;
	case 2: DMSrtD(dw->DirList,dw->FileCount); break;
 }
 ReSize(dw); NewSize(dw);
 for(i=0;i<255;i++){
	dw2=DirWin[i];
	if(dw2&&(dw2->Flags&DWFLAG_RELOAD)&&!strcmp(dw->Path,dw2->Path))
		dw2->Flags&=~DWFLAG_RELOAD;
 }
}

void GetDirEntry(struct DirWindow *dw)
{FAST struct DirList	*dlp;
 FAST sFIB	*fib=dw->Fib;
 FAST int 	i;

 if(!dw) return;
 if((dw->Flags&DWFLAG_RELOAD)&&!dw->DirLock){InitDir(dw,0); return;}
 if(!dw->DirLock||!fib) return;
 i=ExNext(dw->DirLock,fib);
 if(i&&dw->Pattern[0]) if(!DMMatch(fib->fib_FileName,dw->Pattern)) return;
 if(!i||!AllocDlp(dw)){ExDone(dw); return;}
 dlp=dw->DirList[dw->FileCount++]; Fib2Dlp(dlp,fib);
}

void Fib2Dlp(struct DirList *dlp,sFIB *fib)
{FAST UBYTE *ptr;

 dlp->size=fib->fib_Size;
 dlp->attr=fib->fib_Protection;
 dlp->ds.ds_Days=fib->fib_Date.ds_Days;
 dlp->ds.ds_Minute=fib->fib_Date.ds_Minute;
 dlp->ds.ds_Tick=fib->fib_Date.ds_Tick; dlp->dir=0;
 if(fib->fib_DirEntryType>=0) dlp->dir=1;
 movmem(fib->fib_FileName,dlp->name,30); ptr=fib->fib_Comment; dlp->cmt=0;
 if(*ptr) if(dlp->cmt=AllocMem(strlen(ptr)+1,MEMF_PUBLIC|MEMF_CLEAR)) strcpy(dlp->cmt,ptr);
}

int AddAll(struct DirWindow *dw,UBYTE *buf)
{FAST struct DirList	*dlp;
 FAST struct ExAllData	*ed=(struct ExAllData *)buf;
 FAST UBYTE *ptr;

 if(ed->ed_Next==0&&ed->ed_Name==0) return 0;
 while(ed){
	if(!AllocDlp(dw)) return 0;
	dlp=dw->DirList[dw->FileCount++];
	CopyMem(ed->ed_Name,dlp->name,30);
	dlp->size=ed->ed_Size;
	dlp->attr=ed->ed_Prot;
	dlp->ds.ds_Days=ed->ed_Days;
	dlp->ds.ds_Minute=ed->ed_Mins;
	dlp->ds.ds_Tick=ed->ed_Ticks; dlp->dir=0;
	if(ed->ed_Type>=0) dlp->dir=1;
	ptr=ed->ed_Comment;
	dlp->cmt=0;
	if(*ptr) if(dlp->cmt=AllocMem(strlen(ptr)+1,MEMF_PUBLIC|MEMF_CLEAR)) strcpy(dlp->cmt,ptr);
	ed=ed->ed_Next;
 }
 return 1;
}

#define ED_FLAGS ED_NAME|ED_TYPE|ED_SIZE|ED_PROTECTION|ED_DATE|ED_COMMENT

int DoExAll(struct DirWindow *dw)
{register struct ExAllControl *myexall=AllocDosObject(DOS_EXALLCONTROL,0);
 register UBYTE *mybuffer=AllocMem(500*36,MEMF_PUBLIC|MEMF_CLEAR);
 register int r=1;

 if(myexall&&mybuffer){
	while(ExAll(dw->DirLock,(struct ExAllData *)mybuffer,500*36,ED_FLAGS,myexall))
		if(!AddAll(dw,mybuffer)) r=0;
		else r=2;
	if(!AddAll(dw,mybuffer)&&r==1) r=0;
 }
 if(myexall) FreeDosObject(DOS_EXALLCONTROL,myexall);
 if(mybuffer) FreeMem(mybuffer,500*36);
 ExDone(dw);
 return r;
}

void InitDir(struct DirWindow *dw,int set)
{
 FreeDirTable(dw); dw->Flags&=~0xF;
 if(!dw->Fib) if(!(dw->Fib=(sFIB *)AllocMem(sizeof(sFIB),MEMF_PUBLIC))) return;
 dw->Pattern[0]=0;
 if(FindPattern(dw->Path)) Separate(dw);
 ExpandPath(dw->Path,dw->Fib);
 if(!DiskShadow(dw,dw->Fib)) goto Q;
 RefreshGadget(&dw->dir_gad,dw->Window); NewSize(dw);
 if(set){strcpy(Strap+4,dw->Path); goto Q;}
 if(!dw->DirLock){GetDevList(dw); goto D;}
 if(dw->Fib->fib_DirEntryType<0){
	GetCmdFile(dw,dw->Path,dw->Fib->fib_Size); return;
 }else if(!CacheLoad(dw)){
//	if(IntuitionBase->LibNode.lib_Version>34){
//		if(!DoExAll(dw)&&!dw->FileCount){lockcount++; return;}
	lockcount++; return;
 }
Q: if(dw->DirLock){UnLock(dw->DirLock); dw->DirLock=0;}
D: FreeMem(dw->Fib,sizeof(sFIB)); dw->Fib=0;
}

/* --------------------- Open/Close windows -------------------------------- */

void FindNewDirection(struct DirWindow *dw)
{FAST struct DirWindow *dw2;
 FAST int i=0;

 if(dw==CmdWin){
	CmdWin=0;
	if(dw==CDWin) CDWin=0;
	for(i=254;i>=0;i--)
		if(dw2=DirWin[i]){
			if(dw2->Flags&DW_CMD){CmdWin=dw2; DWNum=i; return;}
		}
	return;
 }
 if(dw==DestWin){DestWin=0; i=1;}
 if(dw==CDWin){CDWin=DestWin; i=1;}
 if(i){ for(i=254;i>=0;i--)
		if(dw2=DirWin[i]){
			if(dw2->Flags&DW_CMD){DWNum=i; ShowDirection(dw2,2);}
			else if(CDWin==dw2) DWNum=i;
			else{DestWin=dw2; break;}
		}
	ShowDirection(DestWin,1); ShowDirection(CDWin,0);
 }
}

void CloseDirWindow(int num)
{FAST struct DirWindow *dw=DirWin[num];
 FAST int i;

 if(!dw) return;
 ClearMenuStrip(dw->Window); CloseSharedWindow(dw->Window);
 if(dw->Fib) FreeMem(dw->Fib,sizeof(sFIB));
 FreeDirTable(dw); FreeMem(dw->DirList,dw->MaxFile<<2);
 FreeMem(dw,sizeof(struct DirWindow)); DirWin[num]=0; FindNewDirection(dw);
 for(i=0;i<255;i++) if(DirWin[i]){
	if(!DirWin[DWNum]) DWNum=i;
	process->pr_WindowPtr=(APTR)DirWin[i]->Window; break;
 }
 if(i==255){process->pr_WindowPtr=(APTR)-1; KeepGoing=0;}
}

int OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi)
{FAST struct DirWindow	*dw,*dwt;
 FAST struct DirList	**dlist;
 FAST int dwc=0,maxf=500,w=Screen->Width,h=Screen->Height;

 if(Top <0) Top=0;
 if(Left<0) Left=0;
 if(Wid<=0) Wid=w-Left;
 if(Wid<80) Wid=80;
 if(Hi<= 0) Hi=h-Top;
 if(Hi< 70) Hi=70;

 while((Left+Wid)>w){
	if(Wid>80) Wid--;
	else if(Left) Left--;
 }
 while((Top+Hi)>h){
	if(Hi>70) Hi--;
	else if(Top) Top--;
 }
 NewWin.Screen=Screen;
 NewWin.LeftEdge=Left; NewWin.TopEdge=Top; NewWin.Width=Wid; NewWin.Height=Hi;
 while(DirWin[dwc]) dwc++;
 if(dwc>255) return(0);
 if(Use20) DWTemplate.dir_gad.Activation|=0x2000;
 if(!(dw=(struct DirWindow *)AllocMem(sizeof(struct DirWindow),MEMF_PUBLIC))) return(0);
 if(!(dlist=(struct DirList **)AllocMem(maxf<<2,MEMF_PUBLIC|MEMF_CLEAR))) goto Q1;
 dwt=&DWTemplate; movmem(dwt,dw,sizeof(struct DirWindow));
 NewWin.FirstGadget=(struct Gadget *)&dw->up;
 NewWin.Title=(UBYTE *)&dw->Title;
 dw->up.NextGadget=&dw->dn; dw->dn.NextGadget=&dw->lf; dw->lf.NextGadget=&dw->rt;
 dw->rt.NextGadget=&dw->h_gad; dw->h_gad.NextGadget=&dw->v_gad;
 dw->v_gad.NextGadget=&dw->dir_gad;
 dw->dir_gad.NextGadget=&dw->parent;
 dw->h_gad.GadgetRender=(APTR)&dw->h_img;
 dw->v_gad.GadgetRender=(APTR)&dw->v_img;
 dw->h_gad.SpecialInfo=(APTR)&dw->h_prop;
 dw->v_gad.SpecialInfo=(APTR)&dw->v_prop;
 dw->dir_str.Buffer=(UBYTE *)&dw->Path;
 dw->dir_gad.SpecialInfo=(APTR)&dw->dir_str;
 dw->parent.TopEdge=Screen->BarHeight+1;
 dw->dir_gad.TopEdge=Screen->BarHeight+1;
 dw->v_gad.TopEdge=Screen->BarHeight+12;
 dw->v_gad.Height=(-46)-Screen->BarHeight;
 dw->parent.GadgetText=&GadSText[0];
 dw->dir_str.Extension=&dw->SExt;
 dw->SExt.Font=MyTopaz;
 dw->SExt.Pens[0]=Pens20[TEXTPEN];
 dw->SExt.Pens[1]=Pens20[BACKGROUNDPEN];
 dw->SExt.ActivePens[0]=Pens20[HIGHLIGHTTEXTPEN];
 dw->SExt.ActivePens[1]=Pens20[BACKGROUNDPEN];
 dw->SExt.InitialModes=(1<<2);
 if(!(dw->Window=OpenSharedWindow(&NewWin))) goto Q2;
 dw->dir_gad.LeftEdge=dw->Window->BorderLeft; KeepGoing=1;
 if(DMMenu) SetMenuStrip(dw->Window,DMMenu);
 if(DMFont) SetFont(dw->Window->RPort,DMFont);
 dw->MaxFile=maxf; dw->DirList=dlist; DirWin[DWNum=dwc]=dw;
 process->pr_WindowPtr=(APTR)dw->Window;
 if(!path||stricmp(path,"CMD")){
	ShowDirection(DestWin,3); DestWin=CDWin; CDWin=dw;
	ShowDirection(DestWin,1); ShowDirection(CDWin,0);
 }
 GetNewPath(dw);
 if(!dw->DirLock&&!dw->Path[0]){
	h=0;
	if(path){
		strcpy(dw->Path,path);
		if(!stricmp(path,"CMD")){dw->Flags=DW_CMD; strcpy(dw->Path,dcPath); CmdWin=dw; h=1;}
	}
	InitDir(dw,h);
 }
 return(1);
Q2: FreeMem(dlist,maxf<<2);
Q1: FreeMem(dw,sizeof(struct DirWindow)); return(0);
}

struct Window *OpenSharedWindow(struct NewWindow *nw)
{FAST ULONG	flags=nw->IDCMPFlags;
 struct Window	*w;

 nw->IDCMPFlags=0;
 if(w=OpenWindow(nw))
	if(flags){w->UserPort=WinPort; ModifyIDCMP(w,flags);}
 nw->IDCMPFlags=flags; return(w);
}

void CloseSharedWindow(struct Window *w)
{FAST struct IntuiMessage *msg,*succ;
 FAST struct MsgPort *mp=w->UserPort;

 Forbid(); msg=(struct IntuiMessage *)mp->mp_MsgList.lh_Head;
 while(succ=(struct IntuiMessage *)msg->ExecMessage.mn_Node.ln_Succ){
	if(msg->IDCMPWindow==w)
		{Remove((struct Node *)msg); ReplyMsg((struct Message *)msg);}
	msg=succ;
 }
 w->UserPort=0; ModifyIDCMP(w,0); Permit(); CloseWindow(w);
}

int SaveWin(struct DirWindow *dw,int fh)
{FAST struct Window	*w=dw->Window;
 FAST struct DirList	**dl,*dlp;
 FAST UBYTE		*ptr=dw->Path,*ptr2="\n";
 FAST int		ct=0,j;

 if(dw->Flags&DW_CMD){ct=1; ptr="CMD";}
 if(dw->Flags&DW_SOURCE) ptr2="Lock S\n";
 if(dw->Flags&DW_DEST  ) ptr2="Lock D\n";
 sprintf(sbuff,"OpenWindow %3ld %3ld %3ld %3ld %s\n%s",
	w->LeftEdge,w->TopEdge,w->Width,w->Height,ptr,ptr2);
 if(WriteSbuff(fh)<=0) return(0);
 if(ct){ dl=dw->DirList;
	 for(j=0;j<dw->FileCount;j++){
		dlp=dl[j];
		sprintf(sbuff,"AddCmd %s, %ld%ld, %s\n",
			dlp->name,dlp->attr&0xf,(dlp->attr>>4)&0xf,dlp->cmt);
		if(WriteSbuff(fh)<=0) return(0);
	}
	Write(fh,"\n",1);
 }
 return(1);
}

int SaveScreen(int fh)
{FAST UBYTE	*ptr="";
 FAST UWORD	*colmap;
 FAST int	i,cols;

 if(MyScreen){
	if(MyScreen->ViewPort.Modes&LACE){
		if(MyScreen->Height==GfxBase->NormalDisplayRows)
			ptr=" HALF";
		else	ptr=" LACE";
	}
	colmap=(UWORD *)Pens20;
	sprintf(sbuff,"Pens %ld %ld %ld %ld %ld %ld %ld %ld %ld\n",
		*colmap++,*colmap++,*colmap++,*colmap++,*colmap++,
		*colmap++,*colmap++,*colmap++,*colmap++,*colmap);
	if(WriteSbuff(fh)<=0) return(0);
	sprintf(sbuff,"OpenScreen %ld%s\n",MyScreen->BitMap.Depth,ptr);
	if(WriteSbuff(fh)<=0) return(0);
	if(BackPattern[0]){
		sprintf(sbuff,"BackPattern %s\n",BackPattern);
		if(WriteSbuff(fh)<=0) return(0);
	}
	colmap=(UWORD *)MyScreen->ViewPort.ColorMap->ColorTable;
	cols=1<<MyScreen->BitMap.Depth;
	strcpy(sbuff,"Color "); ptr=sbuff+6;
	for(i=0;i<cols;i++){
		*ptr++=hextab[(colmap[i]>>8)&0xf];
		*ptr++=hextab[(colmap[i]>>4)&0xf];
		*ptr++=hextab[colmap[i]&0xf];
		*ptr++=' ';
	}
	ptr--; *ptr++=10; *ptr=0;
	if(WriteSbuff(fh)<=0) return(0);
 }
 if(DMFont){
	sprintf(sbuff,"Font %s",DMFont->tf_Message.mn_Node.ln_Name,DMFont->tf_YSize);
	sprintf(sbuff+strlen(sbuff)-5,"/%ld\n\n",DMFont->tf_YSize);
	if(WriteSbuff(fh)<=0) return(0);
 }
 return(1);
}

int SaveWindows(int fh)
{FAST struct DirWindow	*dw;
 FAST UBYTE		*ptr;
 FAST int		i;

 sprintf(sbuff,"Button \"%s\"\nSetFormat \"%s\"\nBarFormat \"%s\"\nTitleFormat \"%s\"\n\n",
	PGadStr,DispFormat,BarFormat,TitleFormat);
 if(WriteSbuff(fh)<=0) return(0);

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(dw) if(!SaveWin(dw,fh)) return(0);
 }
 for(i=0;i<255;i++)
	if(ptr=AutoCmdStr[i]){
		sprintf(sbuff,"AddAutoCmd %s\n",ptr);
		if(WriteSbuff(fh)<=0) return(0);
	}
 for(i=0;i<100;i++)
	if(ptr=KeyCmdStr[i]){
		sprintf(sbuff,"AddKeyCmd %s\n",ptr);
		if(WriteSbuff(fh)<=0) return(0);
	}
 if(expandflag) Write(fh,"Expand ON\n",10);
 return(1);
}

