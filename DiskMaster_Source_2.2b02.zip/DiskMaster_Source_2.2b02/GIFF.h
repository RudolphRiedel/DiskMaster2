#ifndef GIFF_H
#define GIFF_H

#define MAKE_ID(a,b,c,d)\
	(((long)(a)<<24)+((long)(b)<<16)+((long)(c)<<8)+(long)(d))

#define FORM	MAKE_ID('F','O','R','M')/* IFF standard format		*/
#define LIST	MAKE_ID('L','I','S','T')/*				*/
#define PROP	MAKE_ID('P','R','O','P')/*				*/

/*-----FORMS------*/
#define ILBM	MAKE_ID('I','L','B','M')/* IFF Picture			*/
#define DMCS	MAKE_ID('D','M','C','S')/* Deluxe Music 		*/
#define SMUS	MAKE_ID('S','M','U','S')/* Simple Music, Sonix, Deluxe	*/
#define ESVX	MAKE_ID('8','S','V','X')/* 8 bit sampled voice		*/
#define ANIM	MAKE_ID('A','N','I','M')/* Cel anim, VScape-3D		*/
#define ACBM	MAKE_ID('A','C','B','M')/* Contiguous bitmap, Basic	*/
#define PROW	MAKE_ID('W','O','R','D')/* WORD-Word processor, ProWrite*/
#define HEAD	MAKE_ID('H','E','A','D')/* Idea processor, Flow 	*/
#define ANBM	MAKE_ID('D','P','P','V')/* Animated bitmap, DVideo	*/
#define SHAK	MAKE_ID('S','H','A','K')/* Shakespeare, embedded ILBMs	*/
#define LWOB	MAKE_ID('L','W','O','B')/* LightWave object		*/

/*-----Chunks-----*/
#define ANHD	MAKE_ID('A','N','H','D')/* ANIM, anim delta header info */
#define BMHD	MAKE_ID('B','M','H','D')/* ILBM, header info		*/
#define CMAP	MAKE_ID('C','M','A','P')/* ILBM, 24 bits/color color map*/
#define BODY	MAKE_ID('B','O','D','Y')/* ILBM & 8SVX, body		*/
#define ABIT	MAKE_ID('A','B','I','T')/* ACBM, body			*/
#define CAMG	MAKE_ID('C','A','M','G')/* ILBM, (LONG)Screen->ViewModes*/
#define CRNG	MAKE_ID('C','R','N','G')/* ILBM, Color Cycle DPaintII	*/
#define CCRT	MAKE_ID('C','C','R','T')/* ILBM, Color Cycle GraphiCrap	*/
#define VHDR	MAKE_ID('V','H','D','R')/* 8SVX, header			*/
#define ATAK	MAKE_ID('A','T','A','K')/* 8SVX, atack			*/
#define RLSE	MAKE_ID('R','L','S','E')/* 8SVX, release		*/
#define CHAN	MAKE_ID('C','H','A','N')/* 8SVX, channel (stereo)	*/
#define SPRT	MAKE_ID('S','P','R','T')/* IBLM, Sprite chunk ?		*/
#define AUTH	MAKE_ID('A','U','T','H')/* Author comment string	*/
#define RGB4	MAKE_ID('R','G','B','4')/* 4 bit R G B pixel info	*/
#define DPPV	MAKE_ID('D','P','P','V')/* perspective Chunk, DPaintII	*/
#define PGTB	MAKE_ID('P','G','T','B')/* ProGram TraceBack diagnostic */
#define COMP	MAKE_ID('C','O','M','P')/* BMHD, Comp=2	modified Huffman*/
#define BHSM	MAKE_ID('B','H','S','M')/* Photon Paint chunk  2 (0004) */
#define BHCP	MAKE_ID('B','H','C','P')/* Photon Paint chunk 62	*/
#define CAT	MAKE_ID('C','A','T',' ')/*				*/
#define CLIP	MAKE_ID('C','L','I','P')/* Clipboard stuff?		*/
#define ARC	MAKE_ID('A','R','C',' ')/* Usenet IFF Archive?		*/
#define SIFR	MAKE_ID('S','I','F','R')/* Unreg. ILBM body decode table*/
#define SHAM	MAKE_ID('S','H','A','M')/* SHAM colormap		*/
#define CTBL	MAKE_ID('C','T','B','L')/* DRES colormap		*/
#define DYCP	MAKE_ID('D','Y','C','P')/* DRES info/ch=8/inc.l,clrs.w	*/
#define DPAN	MAKE_ID('D','P','A','N')/* ILBM, DPaint Anim info	*/

#define PNTS	MAKE_ID('P','N','T','S')/* LightWave points		*/
#define SRFS	MAKE_ID('S','R','F','S')/* LightWave surfaces		*/
#define POLS	MAKE_ID('P','O','L','S')/* LightWave polygons		*/

#define ANFR	MAKE_ID('A','N','F','R')
#define MAHD	MAKE_ID('M','A','H','D')
#define MFHD	MAKE_ID('M','F','H','D')
#define CM16	MAKE_ID('C','M','1','6')
#define GRAB	MAKE_ID('G','R','A','B')
#define ATXT	MAKE_ID('A','T','X','T')
#define PTXT	MAKE_ID('P','T','X','T')
#define DLTA	MAKE_ID('D','L','T','A')

/* CODE, PROG - temporarily reserved */


struct BitMapHeader{	/* BMHD */
	UWORD	w,h;
	WORD	x,y;
	UBYTE	d,Masking,Comp,pad1;
	UWORD	TransparentColor;
	UBYTE	XAspect,YAspect;
	WORD	PageWidth,PageHeight;
};

struct Voice8Header{	/* VHDR */
	ULONG	OneShotHiSamps,repHiSamps,sampsPerHiCycle;
	UWORD	Per;
	UBYTE	ctOctave,Comp;
	LONG	volume;
};

/* Chunk/Size holder */
struct ChunkHeader{LONG type,size,ftype;};

typedef struct{ 	/* CCRT */
	WORD	direction;
	UBYTE	start,end;
	LONG	seconds,microseconds;
	WORD	pad;
 }CcrtChunk;

typedef struct{		/* CRNG */
	WORD	pad1,rate,active;
	UBYTE	low,high;
 }CrngChunk;

typedef struct{ 	/* DEST */
	UBYTE depth,pad1;
	UWORD planePick,planeOnOff,planeMask;
 }DestMerge;

typedef UWORD SpritePrecedence;

typedef struct{ 	/* ANHD */
	UBYTE operation,mask;
	UWORD w,h;
	WORD  x,y;
	ULONG abstime,reltime; /* for timing w.r.t. last frame in jiffies */
	UBYTE interleave,pad0;
	ULONG bits,dsize;
	BYTE  *data,*data2,*data3;
 }AnimationHeader;

typedef struct{ 	/* Personal cycle struct */
	UWORD	nColorRegs,colorMap[256],cycleCnt;
	CrngChunk crngChunks[8];
 }ILBMFrame;

#endif

/******************
ARC  (Arcive form)
AIFF (Apple Audio IFF)
ATXT
BANK (SoundQuest MIDI data-dump)
C100 (Cloanto Italia, private word processing form)
CDAT
CLIP (Clipboard data)
FIGR
FNTR (Raster Font)
FNTV (Vector Font)
FTXT (Formatted text)
GSCR (General-use musical SCoRe)
HEAD (Flow Idea Processor form)
MIDI
MOVI
MSMP
PDEF (Deluxe Print page definition)
PGTB (ProGram TraceBack diagnostic dump image)
PICS (Macintosh picture)
PLBM (Obsolete)
PTXT
RGBX
SAMP (Sound Sample)
SC3D (Sculpt 3-D file)
SHAK (Shakespeare data file)
SYTH (SoundQuest Master Librarian file)
TDDD (Turbo Silver file)
TEXT (unformatted ASCII text)
USCR (Uhura Sound software musical score)
UVOX (Uhura Sound software Macintosh Voice)
VDEO (Deluxe Video file)
WORD (ProWrite data file)

*************************/

