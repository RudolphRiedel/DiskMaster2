	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Disk/packet module					*
	*								*
	\***************************************************************/
#include "DM.h"

extern struct StandardPacket	SPkt;

extern UBYTE	ScreenTitle[],sbuff[],*ActionArgs[];
extern int	Abort,CDelay,Use20;

struct IOExtTD	*TdIO[4];

/* -deadcode format/diskcopy -

ULONG	CmdType[4],*diskbuff,*Datas[160],
	BootCode[13]={
		0x444F5300,0xc0200f19,0x00000370,0x43FA0018,
		0x4EAEFFA0,0x4A80670A,0x20402068,0x00167000,
		0x4E7570FF,0x60FA646F,0x732E6C69,0x62726172,
		0x79000000},
	FFSCode[24]={
		0x444F5301,0xE33D0E72,0x00000370,0x43FA003E,
		0x70254EAE,0xFDD84A80,0x670C2240,0x08E90006,
		0x00224EAE,0xFE6243FA,0x00184EAE,0xFFA04A80,
		0x670A2040,0x20680016,0x70004E75,0x70FF4E75,
		0x646F732E,0x6C696272,0x61727900,0x65787061,
		0x6E73696F,0x6E2E6C69,0x62726172,0x79000000
	};

*/

/* -deadcode format/diskcopy -

UBYTE	*DiskName[4],drive[8]="DF0:";
int	Verify,Quick,Install,Change,Multi,srcDisk,RWmode,Single,FFS,
	TrackSize=11264,NumCyls=22;

int AllocDiskIO(void);
void FreeDiskIO(void);
int CheckWP(void);
int GetNumTracks(void);
void DataStamp(void);
void FormatDisk(void);
void DiskCopy(void);

*/

int DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new)
{FAST struct StandardPacket	*pkt=&SPkt;
 FAST struct Process		*proc=(struct Process *)FindTask(0);
 FAST struct MsgPort		*task,*mport=&proc->pr_MsgPort;
 FAST UBYTE			*ptr=name,*ptr2=sbuff+1;

 if(*dev==0) return(0);
 if(!(task=(struct MsgPort *)DeviceProc(dev))) return(0);
 if(!new){
	if(ptr) while(*ptr&&*ptr!=':') *ptr2++=*ptr++;
	*ptr2=0;
	sprintf(sbuff+52,"Enter new name for %s",dev);
	if(!DMReq(sbuff+52,0,0,0,sbuff+1,30)||!sbuff[1]) return(0);
 }else strcpy(sbuff+1,new);
 sbuff[0]=(UBYTE)strlen(sbuff+1);
 pkt->sp_Pkt.dp_Arg1=((ULONG)(sbuff)>>2);
 pkt->sp_Pkt.dp_Type=ACTION_RENAME_DISK;
 pkt->sp_Msg.mn_Node.ln_Name=(char *)&(pkt->sp_Pkt);
 pkt->sp_Pkt.dp_Link=&(pkt->sp_Msg);
 pkt->sp_Pkt.dp_Port=mport; PutMsg(task,(struct Message *)pkt);
 WaitPort(mport); GetMsg(mport);
 return(pkt->sp_Pkt.dp_Res1);
}

/* -deadcode format/diskcopy -

void DMInhibit(LONG on)
{FAST struct StandardPacket	*pkt=&SPkt;
 FAST struct Process		*proc=(struct Process *)FindTask(0);
 FAST struct MsgPort		*task,*mport=&proc->pr_MsgPort;
 FAST int	i;

 for(i=0;i<4;i++){
   drive[2]=i+'0';
   if(TdIO[i]&&CmdType[i])
	if(task=(struct MsgPort *)DeviceProc(drive)){
		pkt->sp_Pkt.dp_Arg1=on;
		pkt->sp_Pkt.dp_Type=ACTION_INHIBIT;
		pkt->sp_Msg.mn_Node.ln_Name=(char *)&(pkt->sp_Pkt);
		pkt->sp_Pkt.dp_Link=&(pkt->sp_Msg);
		pkt->sp_Pkt.dp_Port=mport; PutMsg(task,(struct Message *)pkt);
		WaitPort(mport); GetMsg(mport);
	}
 }
}

int AllocDiskIO()
{FAST int i;

 for(i=0;i<4;i++){
	if(!(TdIO[i]=(struct IOExtTD *)AllocMem(sizeof(struct IOExtTD),MEMF_CLEAR|MEMF_PUBLIC))) return(0);
	if(!(TdIO[i]->iotd_Req.io_Message.mn_ReplyPort=CreatePort(0,0))) return(0);
	if(OpenDevice(TD_NAME,i,(struct IORequest *)TdIO[i],0)){
		DeletePort(TdIO[i]->iotd_Req.io_Message.mn_ReplyPort);
		FreeMem(TdIO[i],sizeof(struct IOExtTD)); TdIO[i]=0;
	}
 }
 return(1);
}

void FreeDiskIO()
{FAST struct MsgPort *mp;
 FAST int i;

 for(i=0;i<4;i++){
	if(TdIO[i]){
		if(TdIO[i]->iotd_Req.io_Device)
			CloseDevice((struct IORequest *)TdIO[i]);
		mp=TdIO[i]->iotd_Req.io_Message.mn_ReplyPort;
		if(mp) DeletePort(mp);
		FreeMem(TdIO[i],sizeof(struct IOExtTD)); TdIO[i]=0;
	}
	CmdType[i]=0;
 }
 if(diskbuff) FreeMem(diskbuff,TrackSize);
 diskbuff=0;
}

void Motor(int on)
{FAST struct IOExtTD	*ior;
 FAST int		i;

 for(i=0;i<4;i++) if(TdIO[i]&&CmdType[i]==RWmode){
	ior=TdIO[i]; ior->iotd_Req.io_Length=on;
	ior->iotd_Req.io_Command=TD_MOTOR; DoIO((struct IORequest *)ior);
 }
}

void dispR(UBYTE *fmt,int i)
{sprintf(ScreenTitle,fmt,i); SetTitles();}

void WaitDisk(struct IOExtTD *ior,int cn)
{FAST int ch;

 ior->iotd_Req.io_Command=TD_CHANGENUM;
 DoIO((struct IORequest *)ior); ch=ior->iotd_Req.io_Actual+cn;
 while(ch>ior->iotd_Req.io_Actual&&!Abort)
	{Delay(25); DoIO((struct IORequest *)ior); CheckAbortKey();}
}

int CheckWP()
{FAST struct IOExtTD *ior;
 FAST int i,cs;

RETRY:
 for(i=0;i<4;i++) if(TdIO[i]&&CmdType[i]){
	ior=TdIO[i]; cs=CmdType[i];
	if(Abort) return(1);
	if(RWmode==ETD_READ&&Single&&srcDisk!=i) continue;
	ior->iotd_Req.io_Command=TD_CHANGESTATE; DoIO((struct IORequest *)ior);
	if(ior->iotd_Req.io_Actual){dispR("Please insert disk in DF%ld:",i); WaitDisk(ior,1); goto RETRY;}
	ior->iotd_Req.io_Command=TD_PROTSTATUS; DoIO((struct IORequest *)ior);
	if(ior->iotd_Req.io_Actual){
		if(cs==ETD_FORMAT){dispR("Please unprotect DF%ld:",i); WaitDisk(ior,2); goto RETRY;}
	}else if(cs==ETD_READ){dispR("Please write protect DF%ld:",i); WaitDisk(ior,2); goto RETRY;}
 }
 return(0);
}

/*	ULONG	dg_SectorSize;		in bytes
	ULONG	dg_TotalSectors;	total # of sectors on drive
	ULONG	dg_Cylinders;		number of cylinders
	ULONG	dg_CylSectors;		number of sectors/cylinder
	ULONG	dg_Heads;		number of surfaces
	ULONG	dg_TrackSectors;	sectors per track
* / - deadcode nested comment -

int GetNumTracks()
{FAST struct IOExtTD *ior;
 FAST int i,tracks=0,ts=0;
 struct DriveGeometry DG;

 for(i=0;i<4;i++) if(TdIO[i]&&CmdType[i]){
	ior=TdIO[i];
	ior->iotd_Req.io_Command=TD_GETNUMTRACKS; DoIO((struct IORequest *)ior);
	if(tracks&&tracks!=ior->iotd_Req.io_Actual){dispR("Disk size mismatch",0); return(0);}
	else tracks=ior->iotd_Req.io_Actual;
	if(Use20){
		ior->iotd_Req.io_Command=TD_GETGEOMETRY;
		ior->iotd_Req.io_Data=(APTR)&DG;
		DoIO((struct IORequest *)ior);
		TrackSize=DG.dg_SectorSize*DG.dg_TrackSectors*DG.dg_Heads;
		if(ts) if(ts!=TrackSize){dispR("Disk size mismatch",0); return(0);}
		ts=TrackSize;
		BootCode[2]=DG.dg_TotalSectors>>1;
		FFSCode[2]=DG.dg_TotalSectors>>1;
	}
 }
 if(!(diskbuff=AllocMem(TrackSize,MEMF_CHIP|MEMF_PUBLIC))) return(0);
 return(tracks>>1);
}

void DataStamp()
{FAST LONG n=0;
 FAST int  i;

 diskbuff[5]=0;
 DateStamp((struct DateStamp *)&diskbuff[121]);
 for(i=0;i<128;i++) n+=diskbuff[i];
 diskbuff[5]=-n;
}

void DoDiskIO(struct IOExtTD *ior,int t)
{
 ior->iotd_Count=-1;
 ior->iotd_Req.io_Length=TrackSize;
 ior->iotd_Req.io_Data=(APTR)diskbuff;
 ior->iotd_Req.io_Command=ETD_FORMAT;
 ior->iotd_Req.io_Offset=t*TrackSize;
 DoIO((struct IORequest *)ior);
}

void DoVerify(struct IOExtTD *ior,int cyl)
{
 dispR("Verifying  %ld",cyl);
 ior->iotd_Req.io_Length=TrackSize;
 ior->iotd_Req.io_Data=(APTR)diskbuff;
 ior->iotd_Req.io_Command=CMD_READ;
 ior->iotd_Req.io_Offset=cyl*TrackSize;
 DoIO((struct IORequest *)ior);
}

int DoCyl(int cmd,int cyl)
{FAST struct IOExtTD *ior;
 FAST int i,err=0;
 int Pend[4];

 for(i=0;i<4;i++){
	Pend[i]=0;
	if(TdIO[i]) if((CmdType[i]==ETD_FORMAT&&cmd==ETD_FORMAT)||(srcDisk==i&&cmd==ETD_READ)){
		ior=TdIO[i]; ior->iotd_Count=-1;
		ior->iotd_Req.io_Length=TrackSize;
		ior->iotd_Req.io_Data=(APTR)diskbuff;
		ior->iotd_Req.io_Command=cmd;
		ior->iotd_Req.io_Offset=cyl*TrackSize;
		SendIO((struct IORequest *)ior); Pend[i]=1;
	}
 }
 for(i=0;i<4;i++) if(Pend[i]){
	ior=TdIO[i]; Pend[i]=0;
	WaitIO((struct IORequest *)ior);
	err=ior->iotd_Req.io_Error;
	if(!err&&Verify&&cmd==ETD_FORMAT){DoVerify(ior,cyl); err=ior->iotd_Req.io_Error;}
 }
 return(err);
}

int DoRoot(int Tracks)
{FAST struct IOExtTD *ior;
 FAST UBYTE	*ptr,*ptr2;
 FAST int	i,j,err=0,r=Tracks>>1;

 if(!DiskName[0]) DiskName[0]="Empty";
 for(j=0;j<4;j++) if(TdIO[j]&&CmdType[j]==ETD_FORMAT){
	ior=TdIO[j];
	if(Quick){DoVerify(ior,r); err=ior->iotd_Req.io_Error;}
	if(err) break;
	memset((char *)diskbuff,0,1024);
	diskbuff[0]=2; diskbuff[3]=72;
	diskbuff[79]=r*NumCyls+1;
	ptr=((UBYTE *)diskbuff)+432;
	ptr2=DiskName[j];
	if(!ptr2) ptr2=DiskName[0];
	*ptr++=i=strlen(ptr2); movmem(ptr2,ptr,i); diskbuff[127]=1;
	DataStamp(); display("Formatting root",0); DoDiskIO(ior,r);
	err=ior->iotd_Req.io_Error;
	if(err) break;
	if(Verify){DoVerify(ior,r); err=ior->iotd_Req.io_Error;}
	if(err) break;
	memset((char *)diskbuff,0,1024);
 }
 return(err);
}

int DoRootCopy(int cyl)
{FAST int	j,err=0;

 for(j=0;j<4;j++) if(TdIO[j]&&CmdType[j]==ETD_FORMAT){
	if(diskbuff[0]==2&&diskbuff[3]==72) DataStamp();
	DoDiskIO(TdIO[j],cyl);
	if(err=TdIO[j]->iotd_Req.io_Error) break;
 }
 return(err);
}

void FormatDisk()
{FAST int	Tracks,cyl,err;

 DMInhibit(1);
 if(CheckWP()) goto Q1;
 if(!(Tracks=GetNumTracks())) goto Q1;
 Motor(1);
 diskbuff[0]=BootCode[0];
 if(FFS) diskbuff[0]=0x444F5301;
 if(Install){
	if(FFS) movmem((char *)&FFSCode ,(char *)diskbuff,24*4);
	else	movmem((char *)&BootCode,(char *)diskbuff,13*4);
	display("Installing",0);
 }else dispR("Formatting %d",0);
 err=DoCyl(ETD_FORMAT,0); cyl=1;
 if(err){dispR("Format error #%ld",err); goto Q;}
 memset((char *)diskbuff,0,1024);
 if(Quick){ err=DoRoot(Tracks);
	if(err) dispR("Format error #%ld",err);
 }else while(cyl<Tracks){
	CheckAbortKey();
	if(Abort) goto Q;
	dispR("Formatting %ld",cyl);
	if(cyl==Tracks>>1) err=DoRoot(Tracks);
	else err=DoCyl(ETD_FORMAT,cyl);
	if(err){dispR("Format error #%ld",err); goto Q;}
	cyl++;
 }
Q: Motor(0);
Q1: DMInhibit(0);
}

void ChangeDisk(int s)
{FAST struct IOExtTD *ior;
 FAST int	i,a;

 Motor(0); RWmode=s;
 if(srcDisk>=0) CmdType[srcDisk]=s;
 for(i=0;i<4&&!Abort;i++) if(TdIO[i]&&CmdType[i]){
	a=0;
	if(s==ETD_READ){dispR("Insert Source Disk in DF%ld:",i); a=1;}
	else if(i==srcDisk){dispR("Insert Destination Disk in DF%ld:",i); a=1;}
	if(a){ior=TdIO[i]; WaitDisk(ior,2); CheckWP();}
 }
 Motor(1);
}

void DiskCopy()
{FAST int err,cyl,Start,DataN,n,Tracks;

 RWmode=ETD_READ;
 DMInhibit(1);
 if(CheckWP()) goto Q;
 if(!(Tracks=GetNumTracks())) goto Q;
 Motor(1);
 for(cyl=0;cyl<Tracks&&!Abort;cyl++){
	Start=cyl; DataN=0; Change=1;
ReadNx: CheckAbortKey();
	if(Abort) goto GetOut;
	dispR("Reading %ld",cyl); err=DoCyl(ETD_READ,cyl);
	if(err){dispR("Read Error #%ld",err); err=0;}
	if((Single)&&cyl<Tracks){
		if(!Change&&!Abort) ChangeDisk(ETD_READ);
		if(Abort){Multi=0; goto GetOut;}
		Change=1;
		if(Datas[DataN]=(LONG *)AllocMem(TrackSize,MEMF_PUBLIC)){
			CopyMem((char *)diskbuff,(char *)Datas[DataN],TrackSize);
			DataN++; cyl++; goto ReadNx;
		}else Multi=0;
	}
GetOut: if(Single){
		if(!Abort) ChangeDisk(ETD_FORMAT);
OutMulti:	cyl=Start; n=0; Change=0;
WriteNx:	CopyMem((char *)Datas[n],(char *)diskbuff,TrackSize);
		if(!Multi) FreeMem((char *)Datas[n],TrackSize);
		n++; CheckAbortKey();
	}
	if(!Abort){
		dispR("Writing %ld",cyl);
		if(cyl==Tracks>>1) err=DoRootCopy(Tracks>>1);
		else err=DoCyl(ETD_FORMAT,cyl);
	}else if(Multi){Multi=0; goto OutMulti;}
	if(err){dispR("Write Error #%ld",err); Abort=1;}
	if(Single&&n<DataN){cyl++; goto WriteNx;}
	if(Multi) goto GetOut;
 }
 Motor(0);
Q: DMInhibit(0);
}

void PDrives(int dc)
{FAST UBYTE	*ptr;
 FAST int	i=1,n,f=0;

 Verify=Quick=Install=Multi=Single=RWmode=0; RWmode=srcDisk=-1; FFS=0;
 for(n=0;n<4;n++){DiskName[n]=0; CmdType[n]=0;}
 n=0;
 while(ptr=ActionArgs[i++]){
	if(MyToUpper(*ptr)=='D'&&MyToUpper(ptr[1])=='F'){
		n=ptr[2]-'0';
		if(n>=0&&n<=3){
			if(dc){ if(CmdType[n]){Single=1; CmdType[n]=ETD_READ;}
				else if(!f){srcDisk=n; CmdType[n]=ETD_READ;}
				else CmdType[n]=ETD_FORMAT;
			}else	CmdType[n]=ETD_FORMAT;
		}
		f++;
	}else if(!stricmp(ptr,"VERIFY")) Verify=1;
	else if(!stricmp(ptr,"INSTALL")) Install=1;
	else if(!stricmp(ptr,"QUICK")) Quick=1;
	else if(!stricmp(ptr,"MULTI")) Single=Multi=1;
	else if(!stricmp(ptr,"FFS")) FFS=1;
	else DiskName[n]=ptr;
 }
 if(!f) Abort=1;
 if(f==1&&dc) Single=1;
}

void MainDiskEntry()
{FAST int dc=(MyToUpper(ActionArgs[0][0])=='D');

 if(!ActionArgs[1]){
	if(dc) DiskCopyReq();
	else FormatReq();
 }
 AllocDiskIO(); PDrives(dc);
 if(!Abort){
	if(dc) DiskCopy();
	else FormatDisk();
 }
 FreeDiskIO(); CDelay=10;
}

*/