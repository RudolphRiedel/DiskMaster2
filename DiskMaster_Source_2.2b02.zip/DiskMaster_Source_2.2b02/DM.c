
	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Main module						*
	*								*
	*	Startup/Exit, S/D control, MsgPort handler		*
	*								*
	\***************************************************************/
#include "DM.h"

extern void TimerCode();
extern struct Menu	*DMMenu;
extern struct WBStartup *_WBenchMsg;
extern struct Window	*Palette;
extern sFIB		Fib;

extern int	LastI,StdIO;

struct PhonySegList{
	BPTR	psl_NextSeg;
	UWORD	psl_JMP;
	LONG	(*psl_EntryPoint)();
};

struct GfxBase		*GfxBase;
struct IntuitionBase	*IntuitionBase;
struct Library		*RexxSysBase;
struct Screen		*Screen,*MyScreen;
struct Process		*process;
struct MsgPort		*WinPort;
struct DirWindow	*DirWin[255],*CDWin,*DestWin,*CmdWin;
struct DirList		*DClickDir;
struct TextFont 	*DMFont,*MyTopaz;
struct RexxMsg		*WaitRX,*rxMsg;
struct TextAttr 	MAttr,FuckingTopaz={"topaz.font",8,0,0};
struct PhonySegList	MySegList={0,0x4EF9,0};
struct FileHandle	FakeHandle;
static struct Process	*DosTask;
static struct Interrupt TimerInt;
struct Window		*BWindow;

SHORT	fuck; /* ds.l 0 kludge */
LONG	__stack=6000,__priority=0,TimerData[2],DSecs,DMicros;
int	DWNum,KeepGoing=1,lockcount,CDelay,Abort,RexxOutstanding,
	LastY,DOSDone,DClick,rexxErr,Use20,sMod,SortType,RemMenu;
UBYTE	ScreenTitle[256],PGadStr[256],Version[]="DiskMaster V2.2b2",FontName[32]="topaz/8",
	DMname[4]="DM",*__procname=DMname,*NextPath,*rexxStr,sbuff[512],
	Strap[256]="DMS:Startup.DM";

UBYTE	DefStart[]=
	"OpenS\n"
	"AddM Project,Add Command,AddCmd\n"
	"AddM Project,Add Menu Item,AddMenu\n"
	"AddM Project,Add Auto Command,AddAutoCmd\n"
	"AddM Project,Add Key Command,AddKeyCmd\n"
	"AddM Project,Change Command,ChgCmd\n"
	"AddM Project,Display Format,F,SetFormat\n"
	"AddM Project,Palette,Color\n"
	"AddM Project,Printer Setup,SetPrinter\n"
	"AddM Project,Save Config,S,SaveConfig\n"
	"AddM Project,Save Cmd Window,SaveCmdWin\n"
	"AddM Project,Edit S:Startup.DM,S,ScrBack;Extern Ed S:Startup.DM;ScrFront\n"
	"AddM Project,Reconfigure,Batch S:Startup.DM\n"
	"AddM Project,About,About\n"
	"AddM Project,Quit,Q,Confirm \"Are you sure you want to quit?\" Yes No;Quit\n"
	"AddM Tools,Execute Command...,Extern\n"
	"AddM Tools,Change Font,Font\n"
	"AddM Tools,Load Pattern,BackPattern %s P\n"
	"AddM Tools,New Window,N,OpenWindow 240 40 260 120\n"
	"AddM Tools,New Cmd Window,C,OpenWindow 240 40 260 120 CMD;AddCmd\n"
	"AddM Tools,Print Dir,Extern List >PRT: %s\n"
	"AddM Tools,Play Module,Play %s\n"
	"AddM Tools,Run DM Script,Single;Batch %s\n"
	"AddM Tools,Run Selected,Single;External run %s\n"
	"AddM Tools,Swap S<->D,Swap\n"
	"AddM Archives,Lha Add,StdIO \"CON:0/12/640/100/Add Window\";Archive \"Lha <* -r a\";StdIO CLOSE\n"
	"AddM Archives,Arc Add,StdIO \"CON:0/12/640/100/Add Window\";Archive \"Arc <* a\";StdIO CLOSE\n"
	"AddM Archives,Zoo Add,StdIO \"CON:0/12/640/100/Add Window\";Archive \"Zoo <* a\";StdIO CLOSE\n"
	"AddM Archives,Lha Extract,StdIO \"CON:0/12/640/100/Extract Window\";Extern Lha <* x %s;StdIO CLOSE\n"
	"AddM Archives,Lha X >Dest,StdIO \"CON:0/12/640/100/Extract Window\";Extern CD %d \\Lha <* x %s;StdIO CLOSE\n"
	"AddM Archives,Lha X Req,Confirm \"Enter destination path\" Continue Cancel %P;StdIO \"CON:0/12/640/100/Extract Window\";Extern CD %R \\Lha <* x %s;StdIO CLOSE\n"
	"AddM Archives,Arc Extract,StdIO \"CON:0/12/640/100/Extract Window\";Extern Arc <* x %s;StdIO CLOSE\n"
	"AddM Archives,Zoo Extract,StdIO \"CON:0/12/640/100/Extract Window\";Extern Zoo <* x// %s;StdIO CLOSE\n"
	"AddM Archives,Lha List,StdIO \"CON:0/12/640/160/List Window\";Extern Lha v %s;Wait;StdIO CLOSE\n"
	"AddM Archives,Arc List,StdIO \"CON:0/12/640/160/List Window\";Extern Arc v %s;Wait;StdIO CLOSE\n"
	"AddM Archives,Zoo List,StdIO \"CON:0/12/640/160/List Window\";Extern Zoo v %s;Wait;StdIO CLOSE\n"
	"AddM Archives,DM Pack,Pack %s %d\n"
	"AddM Archives,DM Unpack,Unpack %s %d\n"
/* -deadcode format/diskcopy -
	"AddM Disk,Format,Format\n"
	"AddM Disk,DiskCopy,DiskCopy\n"
	"AddM Disk,Format DF0:,Confirm \"Are you sure?\";Format DF0:\n"
	"AddM Disk,Format DF1:,Format DF1: VERIFY \"WorkDisk\"\n"
	"AddM Disk,Clear  DF0:,Format DF0: QUICK INSTALL VERIFY\n"
	"AddM Disk,Copy DF0: DF0:,DiskCopy DF0: DF0:\n"
	"AddM Disk,Copy DF0: DF1:,DiskCopy DF0: DF1:\n"
*/
	"AddM Control,Lock as Source,Lock S\n"
	"AddM Control,Lock as Dest,Lock D\n"
	"AddM Control,UnLock,UnLock\n"
	"AddM Control,UnLock all,UnLock All\n"
	"AddM Control,Expand ON,Expand ON\n"
	"AddM Control,Expand OFF,Expand OFF\n"
	"AddM Control,Sort by Name,SortBy Name\n"
	"AddM Control,Sort by Size,SortBy Size\n"
	"AddM Control,Sort by Date,SortBy Date\n"
/* -deadcode play-
	"AddM Control,Stop Music, Play\n"
*/
	"OpenW 269 11 102 189 CMD\n"
	"AddC Root,10, Root\n"
	"AddC Parent,10,Parent\n"
	"AddC All,30,Select *\n"
	"AddC Clear,30,Deselect *\n"
	"AddC Select,30,Select\n"
	"AddC Exclude,30,DeSelect\n"
	"AddC Copy,20,ReqPattern;Copy %s %d\n"
	"AddC Copy Newer,20,Copy %s %d NEWER\n"
	"AddC Move,20,ReqPattern;Move %s %d\n"
	"AddC Delete,30,ReqPattern;Confirm \"All selected files will be lost.\";Delete %s\n"
	"AddC Rename,20,Recurse OFF;Rename %s\n"
	"AddC Protect,20,Recurse OFF;Protect %s\n"
	"AddC Comment,20,Recurse OFF;Comment %s\n"
	"AddC Find,20,ReqPattern \"Please enter search pattern\";Find %s\n"
	"AddC Read,20,Read %s\n"
	"AddC HexRead,20,Read %s HEX\n"
	"AddC ShowPic,20,ShowPic %s\n"
	"AddC MakeDir,20,MakeDir\n"
	"AddC Print,20,Single;Print %s\n"
	"AddC Size Check,20,UnMark OFF;Check %s\n"
	"OpenW 370 11 272 189\n"
	"OpenW 0 11 272 189\n"

	"AddA FORM????ILBM,ShowPic %s\n"
	"AddA FORM????ACBM,ShowPic %s\n"
	"AddA FORM????8SVX,ShowPic %s\n"
	"AddA FORM????ANIM,ShowPic %s\n"
/* -deadcode play-
	"AddA ,MOD.*,Play %s\n"
*/
	"AddA ??-lh,StdIO \"CON:0/12/640/100/Extract Window\";Extern Lha <* x %s;StdIO CLOSE;Confirm \"Delete Archive?\" Yes No;Delete %s\n"
	"AddA ^Z,StdIO \"CON:0/12/640/100/Extract Window\";Extern Arc <* x %s;StdIO CLOSE;Confirm \"Delete Archive?\" Yes No;Delete %s\n"
	"AddA ZOO ?.?? Archive,StdIO \"CON:0/12/640/100/Extract Window\";Extern Zoo <* x// %s;StdIO CLOSE;Confirm \"Delete Archive?\" Yes No;Delete %s\n"
	"AddA PK  StdIO \"CON:0/12/640/100/DM II\";Extern UnZIP <* %s;StdIO CLOSE;Confirm \"Delete Archive?\" Yes No;Delete %s\n"
	"AddA DMS!,StdIO \"CON:0/12/640/100/DM II\";Extern DMS <* WRITE %s TO DF0: NOPAUSE;StdIO CLOSE;Confirm \"Delete DMS File?\" Yes No;Delete %s\n"
	"AddA TEXT,Read %s\n"
	"AddA DEFAULT,Read %s HEX\n\x0";

void geta4(void);
LONG DosHandler(void);

void FreeUserJunk()
{FAST struct IntuiMessage *msg;
 FAST int i;

 if(Palette) OpenPalette();
 for(i=0;i<255;i++) if(DirWin[i]){
	CloseDirWindow(i); DirWin[i]=0;
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)) ReplyMsg((struct Message *)msg);
 }
 CDWin=DestWin=CmdWin=0;
 FreeMenus(); FreeAutoCmds(); FreeKeyCmds(); DoStdio("CLOSE"); GetHostScreen(0);
 if(MyScreen){
	if(!BWindow->NextWindow){
		CloseWindow(BWindow); BWindow=0; CloseScreen(MyScreen);
		Screen=(struct Screen *)OpenWorkBench(); MyScreen=0;
	}
 }
}

void SetTitles()
{FAST struct DirWindow	*dw;
 FAST UBYTE	*ptr=ScreenTitle;
 FAST int	i;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(dw&&(dw->Window->Flags&WINDOWACTIVE))
		{SetWindowTitles(dw->Window,dw->Title,ptr); break;}
 }
}

void DosWrite(UBYTE *ptr,int len)
{FAST UBYTE	*ptr2;

 while(len>0){
	ptr2=ScreenTitle;
	while(*ptr&&len&&*ptr!=10&&*ptr!=13){*ptr2++=*ptr++; len--;}
	*ptr2=0; ptr++; len--; SetTitles();
 }
}

LONG DosHandler()
{FAST struct FileHandle *fh;
 FAST struct Message	*msg,*mess;
 FAST struct DosPacket	*pkt;
 FAST struct MsgPort	*replyport;

 geta4();
 DosTask=(struct Process *)FindTask(0);
 while(KeepGoing){
	Wait(-1);
	while(msg=GetMsg(&DosTask->pr_MsgPort)){
	  pkt=(struct DosPacket *)msg->mn_Node.ln_Name;
	  switch(pkt->dp_Type){
		case 1005:
		case 1006: fh=(struct FileHandle *)BADDR(pkt->dp_Arg1);
			   fh->fh_Arg1=pkt->dp_Type; fh->fh_Port=(struct MsgPort *)-1;
		case 1007: pkt->dp_Res1=-1; break;
		case  'R':
		case   20: pkt->dp_Res1=0; break;
		case 2002:
		case 2001:
		case 2003:
		case  'W': DosWrite((UBYTE *)pkt->dp_Arg2,pkt->dp_Res1=pkt->dp_Arg3); break;
		default  : pkt->dp_Res2=209; pkt->dp_Res1=0; break;
	  }
	  mess=pkt->dp_Link; replyport=pkt->dp_Port;
	  pkt->dp_Port=&DosTask->pr_MsgPort; mess->mn_Node.ln_Name=(char *)pkt;
	  mess->mn_Node.ln_Succ=0; mess->mn_Node.ln_Pred=0;
	  PutMsg(replyport,mess);
	}
 }
 Forbid(); DOSDone=1; return(0);
}

int BootBatch(UBYTE *ptr)
{FAST struct WBArg	*argptr;
 FAST UBYTE		*ptr2;
 FAST int		lock,i,j=4,inq=0;

 if(*ptr==0){
	argptr=_WBenchMsg->sm_ArgList; argptr++;
	if(_WBenchMsg->sm_NumArgs>1){
		CurrentDir(argptr->wa_Lock); strcpy(Strap+4,argptr->wa_Name);
	}
 }else{ if(*ptr=='"'){inq=1; ptr++;}
	if(inq){while(*ptr!='"') ptr++; *ptr++=0;}
	else while(*ptr!=' ') ptr++;
	while(*ptr==' ') ptr++;
	ptr2=ptr;
	while(*ptr2!='\n') ptr2++;
	*ptr2=0;
	if(*ptr) strcpy(Strap+4,ptr);
 }
 if(!(lock=Lock(Strap+4,ACCESS_READ))){
	if(lock=Lock(Strap+2,ACCESS_READ)){j=2; UnLock(lock);}
	else{	if(*ptr=='"') ActionCmd(0,ptr+1);
		else{ActionCmd(0,DefStart); About();}
		goto Q;
	}
 }else UnLock(lock);
 GetCmdFile(0,Strap+j,0);
Q: if(DirWin[0]){
	i=0;
	while(DirWin[i]){
		if(DirWin[i]->Flags&DW_CMD){CmdWin=DirWin[i]; break;}
		i++;
	}
	return(1);
 }
}

struct DirWindow *FindDMWin(struct Window *win)
{FAST struct DirWindow *olddw=CDWin,*dmw;
 FAST int i;

 for(i=0;i<255;i++){
	if(dmw=DirWin[i]) if(win==dmw->Window){
		if(dmw->Flags&DW_CMD){CmdWin=dmw; DWNum=i; ShowDirection(dmw,2); return(dmw);}
		break;
	}
 }
 if(dmw&&(dmw->Window->Flags&WINDOWACTIVE)){
	DWNum=i; CDWin=dmw;
	if(CDWin!=olddw){
		if(!(olddw->Flags&DW_SOURCE)){ShowDirection(DestWin,3); DestWin=olddw;}
		ShowDirection(DestWin,1); ShowDirection(CDWin,0);
	}
 }
 return(dmw);
}

int do_rexx_cmd(struct RexxMsg *rm)
{FAST int ret=1;

 if(rm->rm_LibBase==(APTR)RexxSysBase){
	rexxErr=0; RESULT1(rm)=0; RESULT2(rm)=0; rxMsg=rm;
	ActionCmd(CmdWin,ARG0(rm)); rxMsg=0;
	if(lockcount&&!WaitRX) WaitRX=rm;
	else{	if(rexxErr) RESULT1(rm)=1;
		else if(rexxStr&&(rm->rm_Action&=RXFF_RESULT))
			RESULT2(rm)=(long)CreateArgstring(rexxStr,strlen(rexxStr));
		ReplyMsg((struct Message *)rm);
	}
 }else if(rm->rm_Node.mn_Node.ln_Type==NT_REPLYMSG){
	DeleteArgstring(rm->rm_Args[0]); DeleteRexxMsg(rm);
	if(RexxOutstanding) RexxOutstanding--;
 }else ret=0;
 return(ret);
}

void DoWindow()
{FAST struct IntuiMessage *msg;
 FAST struct DirWindow	*dw;
 FAST struct IntuiText	*itext;
 FAST struct Window	*win;
 FAST struct Gadget	*gad;
 FAST struct MenuItem	*item;
 FAST int	code,class,mx,my,id,l,w,t,hot;
 FAST UBYTE	*ptr;

 while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
	if(RexxSysBase&&do_rexx_cmd((struct RexxMsg *)msg)) continue;
	code=msg->Code; class=msg->Class; mx=msg->MouseX; my=msg->MouseY;
	if(Palette&&msg->IDCMPWindow==Palette){DoPalette(code,mx,my,class); continue;}
	dw=FindDMWin(msg->IDCMPWindow); DClick=0;
	gad=(struct Gadget *)msg->IAddress; hot=0;
	t=(class==MENUPICK);
	w=(class==MOUSEBUTTONS&&code==SELECTDOWN);
	if(w||t){
		if(DoubleClick(DSecs,DMicros,msg->Seconds,msg->Micros)) DClick=1;
		if(w){DSecs=msg->Seconds; DMicros=msg->Micros;}
	}
	if(t&&dw&&(dw->Window->Flags&WINDOWACTIVE)&&dw==CDWin&&DClickDir&&DClick)
		if((msg->MouseY+4)>LastY&&(msg->MouseY-4)<LastY) hot=1;
	LastY=msg->MouseY; ReplyMsg((struct Message *)msg);
	if(dw) switch(class){
		case DISKINSERTED:	Delay(25); ReSort(); break;
		case NEWSIZE:		NewSize(dw); break;
		case VANILLAKEY:	if(code==0x1b) Abort=1;
					else if(!DoKeyCmd(CmdWin,code))
						if(CDWin){ActivateWindow(CDWin->Window); Delay(10); ActivateGadget(&CDWin->dir_gad,CDWin->Window,0);}
					break;
		case MOUSEBUTTONS:	if(code==SELECTDOWN) sel_file(dw,my);
					break;
		case GADGETDOWN:	slide_em(dw,gad); break;
		case GADGETUP:		id=gad->GadgetID;
					if(id==7&&dw==CDWin) ParseArgs(PGadStr,CmdWin);
					if(!id) InitDir(dw,0);
					break;
		case CLOSEWINDOW:	CloseDirWindow(DWNum); break;
		case MENUPICK:		if(item=ItemAddress(DMMenu,code)){
						if(RemMenu) DelMenuItem(item);
						else{
						 itext=(struct IntuiText *)item->ItemFill;
						 ptr=itext->IText+strlen(itext->IText)+1;
						 ActionCmd(CmdWin,ptr);
						}
						break;
					}
					if(hot){
						win=CDWin->Window;
						l=win->LeftEdge; w=win->Width;
						t=my+win->TopEdge-50;
						OpenDirWindow(0,l,t,w,100);
					}
		default:		break;
	}
 }
}

int CheckDOS(void){return DOSDone;}

void __stdargs __main(char *line)
{FAST struct MsgPort	*mp;
 FAST struct DirWindow	*dw;
 FAST LONG	sig,oldCIS,oldCOS;
 FAST int	i,t,xi=10;
 APTR oldproc;

 process=(struct Process *)FindTask(0); process->pr_WindowPtr=(APTR)-1;
 if(!(IntuitionBase=(struct IntuitionBase *)OpenLibrary("intuition.library",33))) return;
 if(IntuitionBase->LibNode.lib_Version>34) Use20=1;
 if(!(GfxBase=(struct GfxBase *)OpenLibrary("graphics.library",0))) goto Q1;
 RexxSysBase=OpenLibrary(RXSNAME,2);
 DiskfontBase=OpenLibrary("diskfont.library",0);
 while(FindPort(DMname)){
	if(DMname[2]) DMname[2]++;
	else DMname[2]='2';
 }
 if(!(WinPort=CreatePort(DMname,0))) goto Q2;
 Screen=(struct Screen *)OpenWorkBench();
 DMOpenFont("topaz/8"); strcpy(PGadStr,"Parent");
 MyTopaz=OpenFont(&FuckingTopaz);
 MySegList.psl_EntryPoint=DosHandler;
 if(mp=CreateProc("DMHandler",0,(LONG)(&MySegList)>>2,4096)){
	oldproc=process->pr_ConsoleTask;
	process->pr_ConsoleTask=(APTR)mp;
	FakeHandle.fh_Type=mp; FakeHandle.fh_Port=(struct MsgPort *)-1;
	oldCOS=process->pr_COS; oldCIS=process->pr_CIS;
	process->pr_COS=process->pr_CIS=(LONG)(&FakeHandle)>>2;
 }
 if(!BootBatch(line)) goto DIE;
 MainTitle(); SetTitles();
 TimerInt.is_Node.ln_Type=2;
 TimerInt.is_Node.ln_Name="DMTimer";
 TimerInt.is_Data=(APTR)&TimerData;
 TimerData[1]=(LONG)process;
 TimerInt.is_Code=TimerCode;
 AddIntServer(5,&TimerInt);
 DoWindow();
 while(KeepGoing){
	if(lockcount){
		t=0;
		for(i=0;i<255;i++){
			dw=DirWin[i];
			GetDirEntry(dw);
			if(dw&&dw->DirLock) t=1;
		}
		if(!t){ lockcount=0;
			if(WaitRX){ReplyMsg((struct Message *)WaitRX); WaitRX=0;}
		}
		DoWindow(); xi=4;
	}else{	StartTimer(1); sig=Wait((1<<WinPort->mp_SigBit)|1); TimerData[0]=0;
		if(sig!=1){DoWindow(); xi=4;}
		else{	if(!CDelay) CDelay=1;
			else CDelay--;
			if(!CDelay){DClickDir=0; LastI=-1; MainTitle(); SetTitles(); CDelay=1;}
			xi--;
			if(xi<=0){
				xi=4;
				if(!(CDWin->dir_gad.Flags&SELECTED)) ReSort();
			}
		}
	}
 }
 RemIntServer(5,&TimerInt);
DIE:
/* LoadMod(0); -deadcode play-*/
 FreeUserJunk();
 if(mp){
	process->pr_ConsoleTask=oldproc;
	process->pr_COS=oldCOS; process->pr_CIS=oldCIS;
	KeepGoing=0; Signal((struct Task *)DosTask,1);
	while(!CheckDOS());
 }
 DeletePort(WinPort);
 if(MyTopaz) CloseFont(MyTopaz);
 if(DMFont) CloseFont(DMFont);
Q2: if(DiskfontBase) CloseLibrary(DiskfontBase);
    if(RexxSysBase) CloseLibrary(RexxSysBase);
    CloseLibrary((struct Library *)GfxBase);
Q1: CloseLibrary((struct Library *)IntuitionBase);
}

void DMOpenFont(UBYTE *str)
{FAST struct TextFont	*oldfont=DMFont;
 FAST struct TextAttr	*mat=&MAttr;
 FAST int		h=0,i;
 FAST UBYTE		*ptr,*tptr;
 UBYTE			fontemp[32];

 if(!str||*str==0){str=FontName; DMReq("Enter new font descriptor.",0,0,0,FontName,30);}
 if(!FontName[0]) strcpy(FontName,"topaz/8");
 DMFont=0; ptr=str+strlen(str)-1;
 while(ptr>str&&*ptr!='/'&&*ptr!=':') ptr--;
 if(ptr[1]>='0'&&ptr[1]<='9'&&(!ptr[2]||!ptr[3])){
	h=atoi(ptr+1);
	ptr--;
	while(ptr>str&&*ptr!='/'&&*ptr!=':') ptr--;
 }
 if(ptr>str) ptr++;
 tptr=fontemp; str=ptr;
 while(*str&&*str!='/') *tptr++=*str++;
 *tptr=0;
 if(!h||h>40) h=8;
 if(strcmp((tptr-5),".font")) strcpy(tptr,".font");
 mat->ta_Name=fontemp; mat->ta_YSize=h;
 DMFont=OpenFont(mat);
 if(DiskfontBase&&(!DMFont||DMFont->tf_YSize!=h)){
	if(oldfont&&DMFont){CloseFont(oldfont); oldfont=DMFont;}
	DMFont=OpenDiskFont(mat);
 }
 if((DMFont->tf_Flags&FPF_PROPORTIONAL)&&DMFont)
	{display("Font is proportional.",0); CloseFont(DMFont); DMFont=0;}
 if(!DMFont&&oldfont){DMFont=oldfont; oldfont=0;}
 if(oldfont) CloseFont(oldfont);
 for(i=0;i<255;i++)
	if(DirWin[i]){SetFont(DirWin[i]->Window->RPort,DMFont); NewSize(DirWin[i]);}
}

