
	/***************************************************************\
	*	Disk Master 2		   By Greg Cunningham		*
	*				� 1990 Nomad Development	*
	*	ShowPic							*
	*					15-Oct-91		*
	\***************************************************************/

#include "DM.h"
#include <exec/execbase.h>

extern struct ExecBase	*SysBase;
extern struct Screen	*Screen;
extern struct MsgPort	*WinPort;
extern struct Process	*process;

extern LONG	Globuff_size,TimerData[],PackSize;
extern UBYTE	*Globuff,sPath[],sbuff[],*ActionArgs[],*PackBuf,BackPattern[];
extern int	Abort,PrintIt,density;

typedef struct{ 	// ANHD
	UBYTE operation,mask;
	UWORD w,h;
	WORD  x,y;
	ULONG abstime,reltime; // for timing w.r.t. last frame in jiffies
	UBYTE interleave,pad0;
	ULONG bits,dsize;
	BYTE  *data,*Next;
 }AnimHeader;

ILBMFrame		iFrame;
AnimHeader		*Anhd,*AnStart;
struct NewScreen	NSS;
struct Screen		*ShowScreen,*ShowScreen2;
struct Window		*ShowWin,*ShowWin2,*ShowClose,*ShowClose2;
struct IOAudio		*sound[4];
struct BitMap		MyBitMap,MyBitMap2,AnBitMap;
struct BitMapHeader	bmhd;

struct NewWindow
  NewClose={0,0,27,10,0,1,CLOSEWINDOW,
	RMBTRAP|SMART_REFRESH|NOCAREREFRESH|WINDOWCLOSE,
	0,0,0,0,0,0,0,0,0,CUSTOMSCREEN},
  NewShow={0,0,0,0,0,0,VANILLAKEY|MOUSEBUTTONS,
	RMBTRAP|BACKDROP|BORDERLESS|ACTIVATE,
	0,0,0,0,0,0,0,0,0,CUSTOMSCREEN
  };

LONG	cyClocks[8],cyRates[8],ViewModes;
int	CycleOn,Toggle,AnCnt;
USHORT	cyMap[256],cyMap2[16];
UBYTE	*PackPtr,cols[8][4]={"2","4","8","16","32","64","128","256"};
UBYTE	sunit[4]={12,10,5,3};
BYTE	*cbuf[4],comptable[16]={-34,-21,-13,-8,-5,-3,-2,-1,0,1,2,3,5,8,13,21};

void DumpRP(void);
void FreePlanes(struct BitMap *bm);
int GetPlanes(struct BitMap *bm);
int DeComp(int ab);
LONG AllocAudBufs(LONG sps);
int decomp(BYTE *buff,int i,int j,int zz);
void PlaySound(LONG len,LONG sps,LONG sstart,int stereo,int comp);
int LoadPic(int scr);
void AnTPlanes(struct BitMap *bm);
void OverscanFix(void);
void CheckScroll(void);
void OverScanX(void);
void FreeNewPic(void);
void ResetScreen(void);

void DumpRP()
{FAST struct IODRPReq	*DReq;
 FAST struct MsgPort	*mp;
 FAST struct ViewPort	*vp=&ShowScreen->ViewPort;
 FAST struct IntuiMessage *msg;
 FAST int going=1;

 if(!(DReq=(struct IODRPReq *)AllocMem(sizeof(struct IODRPReq),MEMF_CLEAR|MEMF_PUBLIC))) return;
 if(!(mp=CreatePort(0,0))) goto Q1;
 DReq->io_Message.mn_ReplyPort=mp;
 if(OpenDevice("printer.device",0,(struct IORequest *)DReq,0)) goto Q2;
 DReq->io_Command  =11;
 DReq->io_RastPort =&ShowScreen->RastPort;
 DReq->io_ColorMap =vp->ColorMap;
 DReq->io_Modes    =vp->Modes;
 DReq->io_SrcWidth =bmhd.w;
 DReq->io_SrcHeight=bmhd.h;
 DReq->io_Special  =0xC4;
 if(density) DReq->io_Special|=(density<<8);
 BeginIO((struct IORequest *)DReq);
 while(going){
	Wait(1<<mp->mp_SigBit|1<<WinPort->mp_SigBit);
	if(CheckIO((struct IORequest *)DReq)) going=0;
	else if(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		if(msg->Code==0x45) Abort=1;
		ReplyMsg((struct Message *)msg);
		if(Abort){
			AbortIO((struct IORequest *)DReq);
			DReq->io_Command=8; DoIO((struct IORequest *)DReq);
			going=0;
		}
	}
 }
 CloseDevice((struct IORequest *)DReq);
Q2: DeletePort(mp);
Q1: FreeMem((UBYTE *)DReq,sizeof(struct IODRPReq));
}


void OverscanFix()
{FAST int gx=384,gy=(SysBase->VBlankFrequency==60)?240:282;

 if(NSS.ViewModes&LACE) gy<<=1;
 if(NSS.ViewModes&HIRES) gx<<=1;
 if(NSS.Width >gx) NSS.Width=gx;
 if(NSS.Height>gy) NSS.Height=gy;
 NewShow.Width=NSS.Width; NewShow.Height=NSS.Height;
}

void CheckScroll()
{FAST struct Screen	*s=ShowScreen;
 FAST struct RasInfo	*ri=s->ViewPort.RasInfo;
 FAST int		k=0,j=0,w=(bmhd.w-s->Width)>>1,h=bmhd.h-s->Height,
			x=s->MouseX,y=s->MouseY;

 if(!(NSS.ViewModes&HIRES)) w<<=1;
 if(x<=0) while(ri->RxOffset&&k++<8) ri->RxOffset--;
 if(y<=0) while(ri->RyOffset&&j++<8) ri->RyOffset--;
 if(x>=(s->Width-2)) while(ri->RxOffset<w&&k++<8) ri->RxOffset++;
 if(y>=(s->Height-2)) while(ri->RyOffset<h&&j++<8) ri->RyOffset++;
 if(k||j){ScrollVPort(&s->ViewPort); MakeScreen(s);}
}

void ResetScreen()
{FAST int iDy=IntuitionBase->ViewLord.DyOffset,
	rows=GfxBase->NormalDisplayRows,
	height=NSS.Height,dy=0;

 if(ShowScreen->ViewPort.Modes&LACE) rows<<=1;
 if(height>rows) dy+=(rows-height)/2;
 if((iDy+dy)<22) dy=(22-iDy);
 if(dy&1) dy++;
 ShowScreen->ViewPort.DyOffset=dy;
 RemakeDisplay();
}

void OverScanX()
{FAST int iDx=IntuitionBase->ViewLord.DxOffset, // LORES
	col=GfxBase->NormalDisplayColumns,	// HIRES
	n=NSS.Width,dx=0;

 if(ShowScreen->ViewPort.Modes&HIRES){
	dx+=(col-n)/2; iDx<<=1;
	if((iDx+dx+n)>936) dx=(936-n-iDx);
	if((iDx+dx)<196) dx=(196-iDx);
 }else{ dx+=((col>>1)-n)/2;
	if((iDx+dx+n)>468) dx=(468-n-iDx);
	if((iDx+dx)<97) dx=(97-iDx);
 }
 ShowScreen->ViewPort.DxOffset=dx;
}

void FreePlanes(struct BitMap *bm)
{FAST int i,w1=(bm->BytesPerRow)<<3,h1=bm->Rows;

 for(i=0;i<bm->Depth;i++){
	if(bm->Planes[i]) FreeRaster(bm->Planes[i],w1,h1);
	bm->Planes[i]=0;
 }
}

void FreeOldPic()
{
 if(!ShowScreen2) return;
 if(ShowWin2){CloseSharedWindow(ShowWin2); ShowWin2=0;}
 if(ShowClose2){CloseSharedWindow(ShowClose2); ShowClose2=0;}
 CloseScreen(ShowScreen2); FreePlanes(&MyBitMap2); ShowScreen2=0;
 RethinkDisplay();
}

int GetPlanes(struct BitMap *bm)
{FAST int i,w1=(bm->BytesPerRow)<<3,h1=bm->Rows,n;

 for(i=0;i<bm->Depth;i++){
	n=AvailMem(MEMF_CHIP|MEMF_LARGEST)-8000;
	if(n<(bm->BytesPerRow*h1)) FreeOldPic();
	if(!(bm->Planes[i]=AllocRaster(w1,h1))) return 0;
 }
 n=12000;
 if(AvailMem(MEMF_CHIP|MEMF_LARGEST)<n) FreeOldPic();
 return 1;
}

void FreeNewPic()
{
 if(ShowScreen){
	if(ShowWin){CloseSharedWindow(ShowWin); ShowWin=0;}
	if(ShowClose){CloseSharedWindow(ShowClose); ShowClose=0;}
	CloseScreen(ShowScreen); ShowScreen=0; RethinkDisplay();
 }
 FreePlanes(&MyBitMap);
}

UBYTE *BodyPtr;

void UnpackPlns(struct BitMap *bm)
{FAST int	n,r,br=bm->BytesPerRow;
 FAST BYTE	*ptr=BodyPtr;
 BYTE		*plns[8];

 movmem((BYTE *)&bm->Planes[0],(BYTE *)&plns[0],8*4);
 for(r=0;r<bm->Rows;r++)
  for(n=0;n<bm->Depth;n++){
	ptr=UnpackRow(ptr,plns[n],br,bmhd.Comp); plns[n]+=br;
  }
}

struct Screen *openidscreen(struct BitMap *bitmap)
{register struct Screen *scr;

 if(((struct Library *)GfxBase)->lib_Version<36) return 0;
 if(ModeNotAvailable(NSS.ViewModes)) return 0;
 scr=(struct Screen *)OpenScreenTags((struct NewScreen *)NULL,
		SA_DisplayID,	NSS.ViewModes,
		SA_Type,	CUSTOMSCREEN|CUSTOMBITMAP,
		SA_Behind,	TRUE,
		SA_Left,	0,
		SA_Top,		0,
		SA_Width,	NSS.Width,
		SA_Height,	NSS.Height,
		SA_Depth,	NSS.Depth,
		SA_BitMap,	bitmap,
		SA_Title,	"DM-SHOW",
		TAG_DONE);
 return scr;
}

int DeComp(int ab)
{FAST struct BitMap *bm=&MyBitMap;
 FAST int	n;
 FAST BYTE	*ptr;
 BYTE		*plns[8];

 OverscanFix();
 movmem((BYTE *)&bm->Planes[0],(BYTE *)&plns[0],8*4);
 if(!(ShowScreen=openidscreen(bm))){
	NSS.ViewModes=HIRES|LACE;
	if(!(ShowScreen=(struct Screen *)OpenScreen(&NSS))) return(0);
 }
 NewShow.Screen=NewClose.Screen=ShowScreen;
 NewShow.Flags&=~ACTIVATE;
 NewShow.IDCMPFlags=VANILLAKEY|MOUSEBUTTONS;
 NewShow.Width=ShowScreen->Width;
 NewShow.Height=ShowScreen->Height;
 if(!(ShowWin=OpenSharedWindow(&NewShow))) return(0);
 if(!(ShowScreen->ViewPort.Modes&HIRES)) NewClose.Width=14;
 ShowClose=OpenSharedWindow(&NewClose);  NewClose.Width=27;
 if(!ShowClose) return 0;
 OverScanX();
 LoadRGB4(&ShowScreen->ViewPort,iFrame.colorMap,iFrame.nColorRegs);
 ResetScreen();
 BodyPtr=ptr=PackPtr;
 if(ab){
	for(n=0;n<bm->Depth;n++){
		movmem(ptr,bm->Planes[n],(LONG)(bm->BytesPerRow*bm->Rows));
		ptr+=(bm->BytesPerRow*bm->Rows);
	}
	return(1);
 }
 UnpackPlns(&MyBitMap);
 return(1);
}

void xRead(UBYTE *buf,LONG len){movmem(PackPtr,buf,len); PackPtr+=len;}

void xSeek(LONG off){PackPtr=PackBuf+off;}

LONG AllocAudBufs(LONG sps)
{FAST LONG	BufSize=AvailMem(MEMF_CHIP|MEMF_LARGEST)>>2;
 FAST int	i;

 if(BufSize>0xFFF8) BufSize=0xFFF8;

 for(i=0;i<4;i++){
	if(!(cbuf[i]=AllocMem(BufSize,MEMF_CHIP|MEMF_PUBLIC))) return(0);
	if(!(sound[i]=(struct IOAudio *)AllocMem(sizeof(struct IOAudio),MEMF_CLEAR|MEMF_PUBLIC))) return(0);
	if(!(sound[i]->ioa_Request.io_Message.mn_ReplyPort=CreatePort(0,0))) return(0);
 }
 sound[0]->ioa_Request.io_Message.mn_Node.ln_Pri=114;
 sound[0]->ioa_Data=&sunit[0]; sound[0]->ioa_Length=4;
 if((OpenDevice(AUDIONAME,0,(struct IORequest *)sound[0],0)))
	{sound[0]->ioa_Request.io_Device=0; return(0);}
 for(i=0;i<4;i++){
	sound[i]->ioa_Request.io_Message.mn_Node.ln_Pri=114;
	sound[i]->ioa_Request.io_Command=CMD_WRITE;
	sound[i]->ioa_Request.io_Flags=ADIOF_PERVOL;
	sound[i]->ioa_Request.io_Device=sound[0]->ioa_Request.io_Device;
	sound[i]->ioa_AllocKey=sound[0]->ioa_AllocKey;
	sound[i]->ioa_Data=(UBYTE *)cbuf[i];
	if(GfxBase->DisplayFlags&PAL)
		sound[i]->ioa_Period=3546895/sps;
	else	sound[i]->ioa_Period=3579547/sps;
	sound[i]->ioa_Volume=64;
	sound[i]->ioa_Cycles=1;
 }
 for(i=2;i>=0;i-=2){
	sound[i+1]->ioa_Request.io_Unit=(struct Unit *)((ULONG)(sound[0]->ioa_Request.io_Unit)&6);
	sound[i]->ioa_Request.io_Unit=(struct Unit *)((ULONG)(sound[0]->ioa_Request.io_Unit)&9);
 }
 return(BufSize);
}

int decomp(BYTE *buff,int i,int j,int zz)
{FAST int x=((buff[i])>>4)&15,y=buff[i]&15;

 buff[j]=comptable[x]+zz; zz=buff[j]; buff[j+1]=comptable[y]+zz;
 return((int)buff[j+1]);
}
/*
int WaitAud(int i)
{FAST struct IntuiMessage *msg;
 FAST ULONG sig=0,as=1<<sound[i]->ioa_Request.io_Message.mn_ReplyPort->mp_SigBit;
 FAST int n=0,r=0;

 while(!n){
	sig=Wait(1<<WinPort->mp_SigBit|as);
	if(sig&as){WaitIO((struct IORequest *)sound[i]); n=1;}
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		ReplyMsg((struct Message *)msg);
		if(msg->Code==0x1B) r=1;
	}
 }
 return(r);
}
*/

void PlaySound(LONG len,LONG sps,LONG sstart,int stereo,int comp)
{FAST struct MsgPort *mp;
 FAST struct IntuiMessage *msg;
 FAST LONG	BUFSIZE,remaining,dlength,dactual;
 FAST int	i,j,k,z,count;

/* LoadMod(0); -deadcode play- */ strcat(sPath,"  8SVX");
 if(comp) strcat(sPath," Fibonacci Delta ");
 if(comp&2) strcat(sPath," Fibonacci Delta 2");
 if(stereo) strcat(sPath," Stereo");
 display(sPath,0);
 if(comp) len<<=1;

 if(!(BUFSIZE=AllocAudBufs(sps))) goto Q1;
 if(stereo) remaining=(len>>1)-(len&1);
 else{	remaining=len;
	sound[1]->ioa_Data=(UBYTE *)cbuf[0];
	sound[3]->ioa_Data=(UBYTE *)cbuf[2];
 }
 dactual=remaining; k=count=0;
 do{	if(remaining>BUFSIZE) dlength=BUFSIZE;
	else{dlength=remaining; dlength-=(dlength&1);}
	if(stereo) xSeek(sstart+dactual-remaining);
	if(comp){
		xRead(cbuf[k]+(dlength>>1),dlength>>1);
		if(remaining==dactual){z=cbuf[k][1+(dlength>>1)]; cbuf[k][0]=z; i=2; j=1;}
		else i=j=0;
		for(;i<(dlength>>1);i++,j+=2) z=decomp(cbuf[k],i+(dlength>>1),j,z);
	}else xRead(cbuf[k],dlength);

	if(stereo){
	  if(comp){
		xSeek(sstart+dactual+(dactual>>1)-remaining);
		xRead(cbuf[k+1]+(dlength>>1),dlength>>1);
		if(remaining==dactual){z=cbuf[k+1][1+(dlength>>1)]; cbuf[k+1][0]=z; i=2; j=1;}
		else{i=j=0;}
		for(;i<(dlength>>1);i++,j+=2) z=decomp(cbuf[k+1],i+(dlength>>1),j,z);
	  }else{xSeek(sstart+len-remaining);
		xRead(cbuf[k+1],dlength);
          }
	}
	remaining-=dlength; sound[k]->ioa_Length=sound[k+1]->ioa_Length=dlength;
	BeginIO((struct IORequest *)sound[k]);
	BeginIO((struct IORequest *)sound[k+1]);
	while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
		ReplyMsg((struct Message *)msg);
		if(msg->Code==0x1b) goto Q1;
	}
	if(remaining<2) WaitIO((struct IORequest *)sound[k+1]);
	else{	if(k) k=0;
		else k=2;
		if(count++) WaitIO((struct IORequest *)sound[k+1]);
	}
 }while(remaining>1);

Q1:
 if(sound[0]){
	for(i=3;i>=0;i--)
		if(sound[i]&&sound[i]->ioa_Request.io_Device) AbortIO((struct IORequest *)sound[i]);
	if(sound[0]->ioa_Request.io_Device) CloseDevice((struct IORequest *)sound[0]);
	for(i=3;i>=0;i--){
		mp=sound[i]->ioa_Request.io_Message.mn_ReplyPort;
		if(mp) DeletePort(mp);
	}
	for(i=3;i>=0;i--){
		if(sound[i]){FreeMem(sound[i],sizeof(struct IOAudio)); sound[i]=0;}
		if(cbuf[i]){FreeMem(cbuf[i],BUFSIZE); cbuf[i]=0;}
	}
 }
}

int LoadPic(int scr)
{struct Voice8Header	*vhdr;
 struct ChunkHeader	*ch;
 CcrtChunk	ccrtTmp;
 FAST CrngChunk	*ptCrng;
 FAST UBYTE	*ColorBuf,*ptr,*ptr2;
 FAST LONG	formsize,animsize=0,*temp;
 FAST int	I,n,is_V=0,a_f=0,sstart,stereo=0;

 AnCnt=0; Anhd=0;
A:
 ch=(struct ChunkHeader *)PackPtr; PackPtr+=12;
 if(ch->type!=FORM) return(AnCnt);
 if(animsize) animsize-=ch->size;
 formsize=ch->size-4; sstart=12;
 if(ch->ftype==ANIM){animsize=formsize;  goto A;}
 if(ch->ftype==ESVX) is_V=1;
 else if(ch->ftype!=ILBM&&ch->ftype!=ACBM&&ch->ftype!=PROP) return(0);
 iFrame.cycleCnt=0;
 while(formsize>0){
  ch=(struct ChunkHeader *)PackPtr; PackPtr+=8;
  if(PackPtr>(PackBuf+PackSize)) return(0);
  formsize-=8; sstart+=8;
  switch(ch->type){
   case BMHD:
	movmem(PackPtr,(UBYTE *)&bmhd,ch->size);
	if(bmhd.d>8||bmhd.Comp>1) return(0);
	if(scr){NSS.TopEdge=0; NSS.LeftEdge=0; NSS.CustomBitMap=&MyBitMap;
		NSS.Type=CUSTOMSCREEN|SCREENBEHIND|CUSTOMBITMAP;
		NSS.Font=0; NSS.DefaultTitle=0; NSS.ViewModes=0; NewShow.TopEdge=0;
		if(bmhd.PageWidth>bmhd.w) bmhd.PageWidth=bmhd.w;
		if(bmhd.PageHeight>bmhd.h) bmhd.PageHeight=bmhd.h;
		NSS.Width=bmhd.PageWidth;
		NSS.Height=bmhd.PageHeight;
		if(bmhd.PageWidth<30||bmhd.PageHeight<30) return 0;
		if(bmhd.PageWidth>400)	NSS.ViewModes=HIRES;
		if(bmhd.PageHeight>300) NSS.ViewModes|=LACE;
		if(bmhd.d==6)	NSS.ViewModes|=0x800;
		NSS.Depth=bmhd.d;
	}
	InitBitMap(&MyBitMap,bmhd.d,bmhd.w,bmhd.h);
	InitBitMap(&AnBitMap,bmhd.d,bmhd.w,bmhd.h); break;
   case VHDR: vhdr=(struct Voice8Header *)PackPtr; sstart+=ch->size; break;
   case CMAP:
	ColorBuf=PackPtr; I=n=0;
	while(n<ch->size)
		iFrame.colorMap[I++]=((ColorBuf[n++]>>4)<<8)+
			((ColorBuf[n++]>>4)<<4)+(ColorBuf[n++]>>4);
	iFrame.nColorRegs=I; break;
   case CAMG:	temp=(LONG *)PackPtr; ViewModes=(temp[0]&0xBFFF);
		NSS.ViewModes=(UWORD)(ViewModes&0xFFFF);
		break;
   case CHAN: temp=(LONG *)PackPtr;
	      if(*temp==6) stereo=1;
//	#define LEFT		2
//	#define RIGHT		4
//	#define STEREO		6
	      break;
   case ANHD:	if(Anhd) Anhd->Next=(BYTE *)PackPtr;
		else AnStart=(AnimHeader *)PackPtr;
		Anhd=(AnimHeader *)PackPtr;
		Anhd->Next=0; break;
   case DLTA:	if(ch->size&1) ch->size++;
		if(Anhd) Anhd->data=PackPtr;
		AnCnt++; PackPtr+=ch->size;
		if(ch->size&1) PackPtr++;
		goto A;
   case ABIT: a_f=1;
   case BODY:
	if(is_V){PlaySound(ch->size,vhdr->Per,sstart+8,stereo,vhdr->Comp); return(0);}
	if(!GetPlanes(&MyBitMap)) return(0);
	if(!scr) return(1);
	n=bmhd.d;
	ptr=cols[n-1];
	ptr2=" Colors";
	if(NSS.ViewModes&HAM){ptr="HAM"; ptr2=0;}
	if(NSS.ViewModes&EXTRA_HALFBRITE){ptr="EHB"; ptr2=0;}
	sprintf(sPath,"%s  %ldx%ld %s",sPath,bmhd.w,bmhd.h,ptr);
	if(ptr2) strcat(sPath,ptr2);
	if(NSS.ViewModes&SUPERHIRES) strcat(sPath," SUPER");
	if(NSS.ViewModes&HIRES) strcat(sPath," HIRES");
	if(NSS.ViewModes&LACE ) strcat(sPath," LACE");

	display(sPath,0);
	if(AvailMem(MEMF_CHIP|MEMF_LARGEST)<64000) FreeOldPic();
	if(!DeComp(a_f)) return(0);
	if(AvailMem(MEMF_CHIP|MEMF_LARGEST)<64000) FreeOldPic();
	ScreenToFront(ShowScreen);
	if(animsize){
		PackPtr+=ch->size;
		if(ch->size&1) PackPtr++;
		goto A;
	}
	return(1);
   case CCRT:
	movmem(PackPtr,(UBYTE *)&ccrtTmp,ch->size);
	if(iFrame.cycleCnt<8){
	 ptCrng=&(iFrame.crngChunks[iFrame.cycleCnt++]);
	 if(ccrtTmp.direction) ccrtTmp.direction=-ccrtTmp.direction;
	 ptCrng->active=ccrtTmp.direction&3;
	 ptCrng->low=ccrtTmp.start; ptCrng->high=ccrtTmp.end;
	 if(ccrtTmp.seconds||ccrtTmp.microseconds)
		ptCrng->rate=0x4000/
		 ((ccrtTmp.seconds*60)+((ccrtTmp.microseconds+8334)/16667));
	}
	break;
   case CRNG: if(iFrame.cycleCnt<8)
		{movmem(PackPtr,(UBYTE *)&iFrame.crngChunks[iFrame.cycleCnt++],ch->size); break;}
   default: sstart+=ch->size; break;
  }
  formsize-=ch->size; sstart+=ch->size;
  PackPtr+=ch->size;
  if(ch->size&1){formsize--; sstart++; PackPtr++;}
 }
 return(0);
}

void SetDLTA(struct BitMap *bm,BYTE *deltas);

void AnTPlanes(struct BitMap *bm)
{FAST int i;

 for(i=0;i<bm->Depth;i++) ShowScreen->BitMap.Planes[i]=bm->Planes[i];
 MakeScreen(ShowScreen); RemakeDisplay();
}

void DMShow(UBYTE *fil)
{FAST struct IntuiMessage *msg;
 FAST int	ScreenNotTop=0,NotDone=1,k,i,j,low,high,Cycled,CyActive=0,
		class,code,secs,angood,toggle=0,speed=1;
 FAST USHORT	cyTmp;
 CrngChunk	*cyCrngs;
 struct BitMap	*Abm[2];

 if(!PackBuf) if(!AutoUnpack(fil,MEMF_PUBLIC)) return;
 PackPtr=PackBuf;
 k=LoadPic(1);
 if(!k){FreeOldPic(); FreeNewPic(); goto Q;}
 if(!AnCnt) if(secs=atoi(ActionArgs[2])) StartTimer(secs);
 FreeOldPic();
 if(AnCnt&&(angood=GetPlanes(&AnBitMap)))
	BltBitMap(&MyBitMap,0,0,&AnBitMap,0,0,MyBitMap.BytesPerRow<<3,MyBitMap.Rows,0xC0,0xFF,0);
 Abm[0]=&AnBitMap; Abm[1]=&MyBitMap;
 Anhd=AnStart;
RESET:
 cyCrngs=iFrame.crngChunks;
 for(i=0;i<iFrame.nColorRegs;i++) cyMap[i]=iFrame.colorMap[i];
 for(i=0;i<iFrame.cycleCnt;i++){
	if(cyCrngs[i].rate==36){cyCrngs[i].rate=0; cyCrngs[i].active&=~1;}
	if((cyCrngs[i].active&1)&&(cyCrngs[i].rate))
		{CyActive=1; cyRates[i]=cyCrngs[i].rate;}
	else	cyRates[i]=0;
	cyClocks[i]=0;
 }
 if(PrintIt){DumpRP(); NotDone=0;}
 while(NotDone){
  if(Abort||(!AnCnt&&secs&&!TimerData[0])) NotDone=0;
  if(ACheckSignal())
   while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
	class=msg->Class; code=msg->Code; ReplyMsg((struct Message *)msg);
	if(class==VANILLAKEY||class==RAWKEY) switch(code){
		case 9: if(CycleOn){
				CycleOn=0;
				LoadRGB4(&ShowScreen->ViewPort,iFrame.colorMap,iFrame.nColorRegs);
			}else{CycleOn=1; goto RESET;}
			break;
		case 0x1b: Abort=1;
		case '+':
		case '=': if(speed) speed--; break;
		case '-':
		case '_': if(speed<30) speed++; break;
	}else if(class==MOUSEBUTTONS&&(code==SELECTDOWN||code==MENUDOWN)) NotDone=0;
	else if(class==CLOSEWINDOW||class==MENUPICK) NotDone=0;
   }
  if(ShowScreen->TopEdge) ScreenNotTop=20;
  if(AnCnt&&angood){
	if(!Anhd->Next){Anhd=AnStart; toggle=0;
		TimerData[0]=speed;
		UnpackPlns(Abm[0]);
		if(speed) Wait(1);
		AnTPlanes(Abm[0]);
		TimerData[0]=speed;
		UnpackPlns(Abm[1]);
		if(speed) Wait(1);
		AnTPlanes(Abm[1]);
	}else if(Anhd->operation==5){
		TimerData[0]=speed;
		SetDLTA(Abm[toggle],Anhd->data);
		AnTPlanes(Abm[toggle]); toggle^=1;
		Anhd=(AnimHeader *)Anhd->Next;
		if(speed) Wait(1);
	}else Anhd=(AnimHeader *)Anhd->Next;
  }else WaitTOF();
 if(ScreenNotTop&&!ShowScreen->TopEdge) if(--ScreenNotTop==0) ResetScreen();
  CheckScroll();
  if(CyActive){
	if(CycleOn){
	  Cycled=0;
	  for(k=0;k<iFrame.cycleCnt;k++){
		if(cyRates[k]){
		   cyClocks[k]+=cyRates[k];
		   if(cyClocks[k]>=16384){
			Cycled=1; cyClocks[k]-=16384;
			low=cyCrngs[k].low; high=cyCrngs[k].high;
			if(cyCrngs[k].active&2){
			  cyTmp=cyMap[low];
			  for(i=low,j=low+1;i<high;i++,j++)  cyMap[i]=cyMap[j];
			  cyMap[high]=cyTmp;
			}else{
			  cyTmp=cyMap[high];
			  for(i=high,j=high-1;i>low;i--,j--) cyMap[i]=cyMap[j];
			  cyMap[low]=cyTmp;
			}
		   }
		}
	  }
	  if(Cycled) LoadRGB4(&ShowScreen->ViewPort,cyMap,iFrame.nColorRegs);
	}
  }
 }
 if(AnCnt){AnTPlanes(&MyBitMap); FreePlanes(&AnBitMap);}
 Toggle^=1;
 ShowWin2=ShowWin; ShowWin=0;
 ShowClose2=ShowClose; ShowClose=0;
 ShowScreen2=ShowScreen; ShowScreen=0;
 movmem((char *)&MyBitMap,(char *)&MyBitMap2,sizeof(struct BitMap));
 setmem((char *)&MyBitMap,sizeof(struct BitMap),0);
Q: if(PackBuf){FreeMem(PackBuf,PackSize); PackBuf=0; PackSize=0;}
}

void DoPattern(struct Window *w,UBYTE *fil,UBYTE *p)
{FAST int	k,i=0,j;

 SetRast(w->RPort,0);
 if(!PackBuf) if(!AutoUnpack(fil,MEMF_PUBLIC)) return;
 PackPtr=PackBuf;
 k=LoadPic(0);
 if(!k) goto Q;
 strcpy(BackPattern,fil);
 BodyPtr=PackPtr;
 UnpackPlns(&MyBitMap);
 if(p&&*p) LoadRGB4(&w->WScreen->ViewPort,iFrame.colorMap,iFrame.nColorRegs);
 while(i<w->Height){
	j=0;
	while(j<w->Width){
		BltBitMapRastPort(&MyBitMap,0,0,w->RPort,j,i,bmhd.w,bmhd.h,0xC0);
		j+=bmhd.w;
	}
	i+=MyBitMap.Rows;
 };
Q: FreeNewPic();
   if(PackBuf){FreeMem(PackBuf,PackSize); PackBuf=0; PackSize=0;}
}

/* fast double buffer ...
main()
{
	struct Screen *myscreen;
	struct DBufInfo *mydbi;
	void *temp;
	int i;
	ULONG secs,micros,oldsecs;
	myscreen=OpenScreenTags(0,SA_DisplayID,0,SA_Depth,8,0);
	mydbi=AllocDBufInfo(&(myscreen->ViewPort));
	CurrentTime(&oldsecs,&micros);
	for(i=0;i<60000;i++)
	{
		ChangeVPBitMap(&(myscreen->ViewPort),myscreen->RastPort.BitMap,mydbi);
	}
	CurrentTime(&secs,&micros);
	printf("#secs=%d\n",secs-oldsecs);
	FreeDBufInfo(mydbi);
	CloseScreen(myscreen);
}
*/

