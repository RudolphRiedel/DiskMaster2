/* DiskMaster II  Sorter Module
**
** Author: Richard "Dragon" Backhaus,Rudolph "Shadowolf" Riedel
** Date: 25.08.1997,07.09.1997
**
** 00-07-01 rri - replaced all c++ style comments by ANSI ones
**              - changed Resort() to make dw->Devi[] obsolete
**
** 00-07-10 rri - replaced MyToUpper() calls by ToUpper() (utility.library)
**              - changed various stricmp() to Stricmp() calls
**
** 00-07-20 rri - removed the "const" atributes from the compare-functions
**                to get rid of some meaningless warnings
**
** 00-08-30 rri - changed order of sort-types to NSDC
**              - added a new sort-type: 'T' - toggle
**
** 00-10-26 rri - commented-out path-invalid-update-code from ReSort()
**                as it hasn`t been executed before 2.5b7 anyways
**
** 2.5b10
**
** 00-12-19 rri - corrected qsort() function calls by changing "count"
**                in all calls from int to ULONG (u_int)
**              - removed one "warning 220" from Resort()
**              - removed one "warning 317" from GlobalSort()
**
** 00-12-26 rri - removed 19 "warning 120"s
**
** 00-12-28 rri - changed function-headers of DMSortN(), DMSortS()
**                DMSortD() and DMSortC()
**
** 01-01-10 rri - changed var names in cmpnameU() and cmpnameD()
**                from "->name" to "->name2"
**
** 01-01-14 rri - bugfix: ReSort() did a FreeMen() on a "->cmt"
**              - added "AsmFreePooled(NamePool,dl[i]->name2,..." to ReSort()
**
** 01-01-16 rri - added a little extra magic to Sort() which let
**                'Sort' behave different during startup.
**
** 01-01-18 rri - removed the "magic" from Sort() and gave
**                it to ReSort() instead
**
** 01-01-28 rri - introduced PoolFreeVec() for comments
**              - changed ->name2 referencies to ->name
**              - introduced PoolFreeVec() for names
**
** 2.5b12
**
** 01-08-01 rri - added sort by extension
**              - optimised and enhanced sort by comment
**              - optimised sort by name
**              - optimised sort by size and sort by extension with
**                new sub-routine CountDirs()
**
** 2.5RC2
**
** 01-12-19 rri - introduced FLAGS
**
** 2.5RC4
**
** 02-05-31 rri - Changed the qsort() calls to make this module compile
**                without warnings under vbcc also.
**              - Removed DMSortD(), DMSortC() and made DMSort() smarter instead.
**
** 02-05-31 rri - Accidently mixed up Date+ / Date-
**
** 2.5RC6
**
** 02-12-07 rri - Changed a few lines all over - dw->Path is pooled now...
**
** 02-12-13 rri - Some fixes for dw->Path/dw->Title and general cleanup
**
** 02-12-16 rri - Changed some if(...->Path...) back to if(...->Path[0]) ...
**
** 2.5RC7
**
** 02-12-25 rri - Removed one useless call to ReSize() from ReSort().
**
** 2.5RC10
**
** 03-04-12 rri - Replaced one FreeMem() call for struct DirList in ReSort()
**                by a PoolFreeVec() call.
**              - Removed two useless lines from ReSort().
**
** 2.5.23
**
** 03-05-18 rri - Simplified cmpdateU(), cmpdateD() and cmpcmtU() to avoid
**                warnings from GCC about missing return-codes.
**
** 03-05-30 rri - Changed type of "lockcount" to LONG.
**
** 03-05-31 rri - Introduced DMMAXWINDOWS.
**              - Removed some "new!..." style comments.
**
*/

#include "DM.h"

extern struct DirWindow     *DirWin[],*CDWin;
extern struct FileInfoBlock Fib;
extern struct Process       *process;

extern LONG lockcount; /* 2.5.23 rri */

extern UBYTE *ActionArgs[];

extern APTR CommentPool, /* 2.5b10 rri */
            NamePool;    /* 2.5b10 rri */

extern ULONG FLAGS; /* 2.5RC2 rri */

typedef int (* SORTFUNC)(const void * , const void *); /* 2.5RC4 rri vbcc */


int SortType=0;

int cmpextU(struct DirList **val1,struct DirList **val2); /* 2.5b12 rri */
int cmpextD(struct DirList **val1,struct DirList **val2); /* 2.5b12 rri */
int CountDirs(struct DirList **dl,ULONG count); /* 2.5b12 rri */



int CountDirs(struct DirList **dl,ULONG count) /* 2.5b12 rri */
{
ULONG i; /* 2.5.23 gcc rri */
int dircount;

dircount=0;

for(i=0; i<=count-1; i++)
 {
  if(dl[i]->dir==1)
   {
    dircount++;
   }
  else
   {
    break;
   }
 }
return(dircount);
}

/*
Name:	DMSort Name + additional compare routines
*/

void DMSortN(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{
if (direction == 0)
 {
  qsort(dl,(size_t) count,(size_t) sizeof(dl),(SORTFUNC)cmpnameU); /* 2.5RC4 rri vbcc */
 }
else if (direction == 1)
 {
  qsort(dl,(size_t) count,(size_t) sizeof(dl),(SORTFUNC)cmpnameD); /* 2.5RC4 rri vbcc */
 }
}


int cmpnameU(struct DirList **val1,struct DirList **val2) /* inserted 25.08.97 dGN! */
{
if(val1[0]->dir==val2[0]->dir)
/* if both files are either files or directories they should be compared */
 {
  return(Stricmp(val1[0]->name,val2[0]->name)); /* 2.5b7 rri */
 }
else if(val1[0]->dir>val2[0]->dir)
/* if only the first file is a dir, it moves ahead */
 {
 return(-10);
 }
/* if only the second file is a dir, it moves ahead */
return(10);
}


int cmpnameD(struct DirList **val1,struct DirList **val2)
{
int i;

i=cmpnameU(val1,val2);

if (i==1||i==(-1)) i=i*(-1);

return i;
}


/*
Name:	DMSort Size + additional compare routines
*/

void DMSortS(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{
int	dircount,filecount;

qsort(dl,(size_t) count,(size_t) sizeof(dl),(SORTFUNC)cmpnameU); /* 2.5RC4 rri vbcc */

dircount=CountDirs(dl,count); /* 2.5b12 rri */
filecount=count-dircount; /* 2.5b12 rri */

if (filecount)
 {
 if (direction==2) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),(SORTFUNC)cmpsizeU); /* 2.5RC4 rri vbcc */
 else if (direction == 3) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),(SORTFUNC)cmpsizeD); /* 2.5RC4 rri vbcc */
 }

}


int cmpsizeU(struct DirList **val1,struct DirList **val2) /* inserted 25.08.97 dGN! */
{
return (val1[0]->size - val2[0]->size);
}


int cmpsizeD(struct DirList **val1,struct DirList **val2) /* inserted 25.08.97 dGN! */
{
return (val2[0]->size - val1[0]->size);
}


/*
Name:	DMSort date compare routines
*/

int cmpdateU(struct DirList **val1,struct DirList **val2)
{
if(val1[0]->dir==val2[0]->dir)
 {
 return(CompareDates((struct DateStamp *) &val2[0]->ds,(struct DateStamp *) &val1[0]->ds));
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-10);
 }
return(10); /* 2.5.23 gcc rri */
}


int cmpdateD(struct DirList **val1,struct DirList **val2) /* inserted 25.08.97 dGN! */
{
if(val1[0]->dir==val2[0]->dir)
 {
 return(CompareDates((struct DateStamp *) &val1[0]->ds,(struct DateStamp *) &val2[0]->ds));
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-1);
 }
return(1); /* 2.5.23 gcc rri */
}


/*
Name:	DMSort comment compare routines
*/

int cmpcmtU(struct DirList **val1,struct DirList **val2)
{
int i;

if(val1[0]->dir==val2[0]->dir)
 {
 if (!val1[0]->cmt&&!val2[0]->cmt) return(Stricmp(val1[0]->name,val2[0]->name)*10);
 if (!val1[0]->cmt) return(-1);
 else if (!val2[0]->cmt) return (1);
 else
  {
   i=Stricmp(val1[0]->cmt,val2[0]->cmt); /* 2.5b12 rri */
   if (i==0) return(Stricmp(val1[0]->name,val2[0]->name)*10);
   return i;
  }
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-10);
 }
return(10); /* 2.5.23 gcc rri */
}


int cmpcmtD(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
int i;

i=cmpcmtU(val1, val2);

if (i==1||i==(-1)) i=i*(-1);

return i;
}


/*
Name:	DMSort Extension + additional compare routines
*/

void DMSortE(struct DirList **dl,ULONG count,LONG direction) /* 2.5b12 rri */
{
int	dircount,filecount;

qsort(dl,(size_t) count,(size_t) sizeof(dl),(SORTFUNC)cmpnameU); /* 2.5RC4 rri vbcc */

dircount=CountDirs(dl,count);
filecount=count-dircount;

if (filecount)
 {
 if (direction==8) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),(SORTFUNC)cmpextU); /* 2.5RC4 rri vbcc */
 else if (direction == 9) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),(SORTFUNC)cmpextD); /* 2.5RC4 rri vbcc */
 }

}


int cmpextU(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
UBYTE *ptr1=val1[0]->name+strlen(val1[0]->name);
UBYTE *ptr2=val2[0]->name+strlen(val2[0]->name);
int i;

for(;ptr1>=val1[0]->name;ptr1--)
 {
  if(*ptr1=='.') break;
 }

for(;ptr2>=val2[0]->name;ptr2--)
 {
  if(*ptr2=='.') break;
 }

if(ptr1<val1[0]->name&&ptr2<val2[0]->name)
 {
  return(Stricmp(val1[0]->name,val2[0]->name));
 }

if(ptr1<val1[0]->name)
 {
  return -10;
 }
if(ptr2<val2[0]->name)
 {
  return 10;
 }

i=(Stricmp(ptr1,ptr2));
if (i==0) return(Stricmp(val1[0]->name,val2[0]->name));
return i*10;
}


int cmpextD(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
int i;

i=cmpextU(val1,val2);

if (i>=10||i<=(-10)) i=i*(-1);

return i;
}



void Sort()
{
switch(ToUpper((ULONG)ActionArgs[1][0])) /* 2.5b10 rri */
 {
  case 'N': SortType=0; break;
  case 'S': SortType=2; break;
  case 'D': SortType=4; break;
  case 'C': SortType=6; break;
  case 'E': SortType=8; break; /* 2.5b12 rri */
  case 'F': SortType=10; break;
  case 'T': SortType=11; break; /* 2.5b7 rri */
  case 'G': GlobalSort(); break;
 }

if(ActionArgs[1][1]&&ActionArgs[1][1]=='-'&&SortType<9)
 {
  SortType++;
 }

if(ActionArgs[2]&&(ToUpper((ULONG)ActionArgs[2][0])=='G')) /* 2.5b10 rri */
 {
  GlobalSort();
 }
else if(CDWin)
      {
       SetSortFlag(CDWin,SortType);
       ReSort();
       SortType=CDWin->Sorting; /* 2.5b7 rri */
      }
}


void GlobalSort(void)
{
struct DirWindow *dw;
int i,a;

a=0; /* 2.5b10 rri */

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&!dw->Flags)
   {
    SetSortFlag(dw,SortType);
    a=i;
   }
 }
ReSort();
SortType=DirWin[a]->Sorting; /* 2.5b7 rri */
}


void SetSortFlag(struct DirWindow *dw, int c)
{

if (c==11) /* 2.5b7 rri */
 {
  if (dw->Sorting!=10)
   {
    dw->Sorting=dw->Sorting+2;
    if (dw->Sorting>9)
     {
      dw->Sorting=dw->Sorting-10;
     }
   }
 }
else dw->Sorting=c;

if(dw->Path[0])
 {
  dw->Flags|=DWFLAG_RESORT;
 }
}


void DMSort(struct DirWindow *dw)
{
switch(dw->Sorting)
 {
  case 0:
  case 1: DMSortN(dw->DirList,(ULONG) dw->FileCount,dw->Sorting);
          break;
  case 2:
  case 3: DMSortS(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b10 rri */
          break;

  case 4: qsort(dw->DirList,(size_t) dw->FileCount,(size_t) sizeof(dw->DirList),(SORTFUNC)cmpdateD); /* 2.5RC4 rri vbcc */
          break;
  case 5: qsort(dw->DirList,(size_t) dw->FileCount,(size_t) sizeof(dw->DirList),(SORTFUNC)cmpdateU); /* 2.5RC4 rri vbcc */
          break;
  case 6: qsort(dw->DirList,(size_t) dw->FileCount,(size_t) sizeof(dw->DirList),(SORTFUNC)cmpcmtU); /* 2.5RC4 rri vbcc */
          break;
  case 7: qsort(dw->DirList,(size_t) dw->FileCount,(size_t) sizeof(dw->DirList),(SORTFUNC)cmpcmtD); /* 2.5RC4 rri vbcc */
          break;
  case 8:
  case 9: DMSortE(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b12 rri */
          break;

  case 10: break;
 }
}


void ResortAll()
{
struct DirWindow	*dw;
int	i;

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&!dw->Flags&&dw->Path[0]) dw->Flags|=DWFLAG_RESORT;
 }
 ReSort();
}


void ReSort()
{
struct DirWindow *dw;
struct DirList **dl;
sFIB *fib = &Fib;
ULONG c,i,j; /* 2.5.23 gcc rri */
BPTR lock; /* 2.5b10 rri */
APTR save=process->pr_WindowPtr;

process->pr_WindowPtr=(APTR)-1;

if(FLAGS&DMFLAG_BATCH) /* 2.5RC2 rri */
 {
  return;
 }

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];

  if(!dw) continue;

  if(dw->Flags&DWFLAG_RESORT)
   {
    c=dw->FileCount;
    dl=dw->DirList;

    DMSortN(dl,c,0);

    for(j=0;j<c;j++)
     if(dl[j]&&dl[j]->sel>1)
      {
       if(dl[j]->cmt) /* 2.5b10 rri */
        {
         PoolFreeVec(dl[j]->cmt); /* 2.5b10 rri */
/* useless!         dl[j]->cmt=NULL; */ /* 2.5RC10 rri */
        }
       if(dl[j]->name) /* 2.5b10 rri */
        {
         PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
/* useless!         dl[j]->name=NULL; */ /* 2.5RC10 rri */
        }
       PoolFreeVec(dl[j]); /* 2.5RC10 rri */
       dl[j]=0;
       dw->FileCount--;
      }
    DMSort(dw);
    DiskShadow(dw,&Fib);
    if(dw->DirLock)
     {
      UnLock(dw->DirLock);
      dw->DirLock=0;
     }
    rdis_files(dw);
    dis_files(dw);
    WinTitle(dw);
    dw->Flags&=~DWFLAG_RESORT;
   }

  else if(!(dw->Flags&DW_CMD)&&dw->Path[0]) /* if it`s a dir window with a valid path */
   {
    if(!(lock=Lock(dw->Path,ACCESS_READ)))  /* if a lock to this path can`t be obtained */
     {

/* this portion of code was never ever executed before 2.5b7 anyways...
   2.5b9 rri */

/*
      CloneBuffer(dw,0); // 2.5RC6 rri
//      dw->Path[0]=0;  // show dev/vol/asn list
      InitDir(dw,0);
*/

     }
    else
     {
      if(Examine(lock,fib))
       {
        if(CompareDates(&dw->PathDate,&fib->fib_Date))
         {
          dw->Flags|=DWFLAG_RELOAD;
          lockcount++;
         }
/*
        else
         {
          ReSize(dw); // useless! 2.5RC7 rri
         }
*/
       }
      UnLock(lock);
     }
   }
 }
process->pr_WindowPtr=(APTR)save;
}
