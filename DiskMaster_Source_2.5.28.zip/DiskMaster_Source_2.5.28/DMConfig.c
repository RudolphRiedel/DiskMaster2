/* DiskMaster II  Config Module    SaveConfig
**
** 2.5RC4
**
** 02-05-29 rri - Reworked SaveWin() to save the new command-line
**                options for 'OpenWindow'.
**              - Added keyboard shortcuts to the requesters
**                within the internal Startup.DM .
**
** 02-05-30 rri - Various changes to make this module compile without
**                errors under vbcc.
**
** 02-05-31 rri - Changed the "Change Font" menu entry in the internal Startup.DM .
**
** 02-08-16 rri - 'SaveWin'�saved 'Path=""' in case a dir-window had no path.
**
** 2.5RC6
**
** 02-10-04 rri - Replaced two strncmp() calls by Strnicmp() calls.
**
** 02-10-07 rri - Modified one LibOpen() call.
**
** 02-12-07 rri - Changed a few lines in SaveWin() - dw->Path is pooled now...
**
** 02-12-13 rri - Some fixes for dw->Path/dw->Title and general cleanup
**
** 02-12-16 rri - Changed one if(dw->Path!=0) back to if(dw->Path[0]) ...
**
** 2.5RC8
**
** 03-01-05 rri - Added "sizes", "separator" options to 'SetX'.
**              - Added "sort by extension" to internal Startup.
**              - Optimised some bytes...
**
** 2.5RC9
**
** 03-01-18 rri - Replaced SAS-C's _ProgramName by ProgName
**
** 03-01-25 rri - Replaced some strcat() calls by DMstrcat() calls.
**
** 2.5RC10
**
** 03-02-28 rri - Changed a call to ActionCmd() in Iconify()
**              - Removed some "new! ..." style comments.
**
** 03-03-01 rri - Renamed FreeUserJunk() to FreeUserData()
**
** 03-03-15 rri - Added DMLayoutMenus() to Iconify() to compensate simpler AddMenuCmd()
**
** 03-03-29 rri - Increased the maximum number of saved colors in SaveScreen() to 60.
**
** 03-04-24 rri - Iconify(): we need two AddPort()'s now as FreeUserData() does
**                a RemPort() now for us and the first command after de-iconify
**                is 'Reset' which just calls FreeUserData()...
**
** 03-04-26 rri - Changed format of Startup.DM, all "important" commands are on top
**                now to give new users a better start.
**                SaveMenus(), SaveWindows() and SaveWin() have been modified.
**              - Added a number of commands to the internal startup.
**
** 2.5.23
**
** 03-05-30 rri - Moved prototypes for SaveMenus(), SaveScreen(), SaveWindows()
**                and SaveWin() from DM.h to this file as there is no need
**                to have these available globally.
**              - Introduced DMMAXWINDOWS.
**              - Added some extrac brackets to avoid warnings from GCC.
**              - Fixed all warnings from GCC except the one complaining
**                about the "0" in "%03.3lx" but despite the warning it works...
**
** 2.5.24
**
** 03-07-19 rri - 'SaveConfig' adds a version-tag to the Startup.DM now.
**                Suggested by Gerd Frank <Gerd.Frank@gmx.de>.
**              - Added a file-requester to 'SaveConfig' as has been
**                suggested countless times...
**              - 'SaveConfig' saves the sort-mode for each window now.
**
** 03-07-20 rri - 'SaveConfig' no longer saves garbage with empty command-lines.
**
** 03-07-27 rri - Added WARN option to 'SaveConfig'.
**              - Added options ICON and WARN to internal startup.
**
** 03-07-28 rri - Modified 'SaveConfig' to use DMFileReq().
**
** 03-08-01 rri - Modified the internal startup again to be more user-friendly
**                for first-timers and closer to the style-guide.
**
** 03-08-02 rri - Made saving of digits conditional.
**              - Added conditional saving of defx / defy.
**              - Added a FilePart() to the creation of the deftool for
**                the icon to be saved with the startup.
**
** 2.5.26
**
** 03-09-07 rri - Added OS4 PPC support thru alternative LibOpen().
**              - Removed all pre 2.5RC4 comments
**              - Bugfix: added a "RexxSysBase&&" in Iconify() to ensure
**                        IsRexxMsg() is only called when the lib is available.
**
** 03-09-14 rri - Bugfix: The internal config had a typo.
**                        Thanks to Gerd Frank for reporting it!
**
** 03-09-16 rri - Corrected the internal config a little more.
**
** 03-09-21 rri - AppIcon setting is only saved when AppIcon!=Progname
**
** 03-09-23 rri - AppIconPath is always valid so 'Iconify' is a bit simpler now.
**
** 03-09-29 rri - Removed some test-lines.
**              - Replaced one DMReq() call by a DMReqTagList() call.
**
** 03-10-01 rri - Removed some test-lines.
**              - Removed the "test!" status from the DMReqTagList() stuff.
**
** 2.5.27
**
** 03-10-25 rri - Modified one DMFileReq() call.
**
** 2.5.28
**
** 03-12-22 rri - The icon data had a comma too much...
**
**
*/

#include "DM.h"
#include <workbench/icon.h> /* 2.5.26 rri */

extern UBYTE
             *ProgName, /* 2.5RC9 rri */
             *ActionArgs[],
             *AppIconPath, /* 2.5b13 rri */
             *AutoCmdStr[],
             BarFormat[],
             dcPath[],
             DispFormat[],
             DMname[], /* 2.5b7 rri */
             FontKeywords[][15],  /* 2.5RC2 jjt */
             g_buttons[], /* 2.5b13 rri */
             *Globuff, /* 2.5b7 rri */
             *KeyCmdStr[],
             PGadStr[],
             sbuff[],
             *Strap, /* 2.5.24 rri */
             TitleFormat[],
             Version[]; /* 2.5.24 rri */

extern UWORD Pens20[],Screen_Depth;

extern ULONG defx,defy, /* 2.5.24 rri */
             FLAGS, /* 2.5b10 rri */
             Screen_Width,Screen_Height,Screen_ID,
             UserColors; /* 2.5b11 rri */

extern LONG digits, /* 2.5.23 rri */
            Notify, /* 2.5.23 rri */
            Globuff_size, /* 2.5b7 rri */
            separator, sizes; /* 2.5RC8 rri */

extern LONG DirPen, FilePen, BackPen, SelectPen; /* 2.5b12 rri */

extern APTR NamePool; /* 2.5.24 rri */

extern struct DirWindow *DirWin[],*CmdWin;
extern struct Menu *DMMenu;
extern struct Screen *Screen,*MyScreen; /* 2.5.24 rri */

extern struct TextFont *DMFonts[];  /* 2.5RC2 jjt */
extern struct MsgPort *WinPort; /* 2.5b7 rri */

LONG IconX=NO_ICON_POSITION,IconY=NO_ICON_POSITION; /* 2.5b9 rri */

UBYTE DefStart[]= /* 2.5.24 rri */

   "AddC Root,10,Root\n"
   "AddC Parent,10,Parent\n"
   "AddC\n"
   "AddC All,30,Select *\n"
   "AddC Clear,30,Deselect *\n"
   "AddC Select,30,Select\n"
   "AddC Exclude,30,DeSelect\n"
   "AddC SwapSelect,30,SwapSel\n"
   "AddC Dupe NS,30,Dupe n s\n"
   "AddC\n"
   "AddC Copy,20,ReqPattern;Copy %s %d warn\n"
   "AddC Move,20,ReqPattern;Move %s %d warn\n"
   "AddC Rename,20,Recurse OFF;Rename %s\n"
   "AddC MakeDir,20,MakeDir\n"
   "AddC Delete,30,ReqPattern;Confirm \"All selected files will be lost!\";Delete %s\n"
   "AddC\n"
   "AddC Protect,20,Recurse OFF;Protect %s\n"
   "AddC De-Protect,20,Protect %s +D\n"
   "AddC Comment,20,Recurse OFF;Comment %s\n"
   "AddC Find File,20,ReqPattern \"Please enter a search pattern:\";Find %s\n"
   "AddC Find Text,20,Read %s SEARCH\n"
   "AddC Read,20,Read %s wait\n"
   "AddC HexRead,20,Read %s HEX wait\n"
   "AddC View,20,View %s\n"
   "AddC Size Check,20,UnMark OFF;Check %s\n"
   "AddC Make Icon,20,Icon %s\n"
   "AddC Info,20,Info %s\n"
   "AddC Auto,20,Auto %s\n"
   "AddC\n"
   "AddC Execute...,20,Extern\n"
   "AddC Run Selected,20,Single;Extern run %n\n"
   "AddC\n"
   "AddC  SYS:,10,NewDir SYS:*\n"
   "AddC   RAM:,10,NewDir RAM:*\n"
   "AddC    CD0:,10,NewDir CD0:*\n"
   
   "AddM DiskMaster2,About (F1)...,?,About\n"
   "AddM DiskMaster2,Barlabel,\n"
   "AddM DiskMaster2,Iconify (F2),I,Iconify\n"
   "AddM DiskMaster2,Barlabel,\n"
   "AddM DiskMaster2,Quit...,Q,Confirm \"Really quit?\" _Yes _No;Quit\n"

   "AddM Archives,Lha Add,StdIO \"CON:0/12/640/180/DM2\";Archive \"Lha -r a\";StdIO CLOSE\n"
   "AddM Archives,ZIP Add,StdIO \"CON:0/12/640/180/DM2\";Archive \"ZIP -rvN\";StdIO CLOSE\n"
   "AddM Archives,Lha Extract,StdIO \"CON:0/12/640/180/DM2\";Extern Lha x %n;StdIO CLOSE\n"
   "AddM Archives,Lha X >Dest,StdIO \"CON:0/12/640/180/DM2\";Extern Lha x %n %d;StdIO CLOSE\n"
   "AddM Archives,Lha X Req,Confirm \"Enter destination path\" C_ontinue _Cancel %P;StdIO \"CON:0/12/640/100/Extract\";Extern Lha x %s %r;StdIO CLOSE\n"
   "AddM Archives,Lha List,StdIO \"CON:0/12/640/180/DM2\";Extern Lha v %n;Wait;StdIO CLOSE\n"
   "AddM Archives,Pack,Pack %s TO %d SUFFIX KEEPORIG\n"
   "AddM Archives,Unpack,Unpack %s TO %d KEEPORIG\n"

   "AddM Settings,Display Format...,F,SetFormat\n"
   "AddM Settings,Numbers A,SetX sizes=1\n"
   "AddM Settings,Numbers B,SetX sizes=2\n"
   "AddM Settings,Numbers C,SetX sizes=3\n"
   "AddM Settings,Width 4,SetX digits=4\n"
   "AddM Settings,Width 5,SetX digits=5\n"
   "AddM Settings,Width 7,SetX digits=7\n"
   "AddM Settings,Barlabel,\n"
   "AddM Settings,Change Font...,Font DIRWIN\n"
   "AddM Settings,Barlabel,\n"
   "AddM Settings,Load Config...,L,Load\n"
   "AddM Settings,Save Config...,S,Save ICON WARN\n"
   "AddM Settings,Edit S:Startup.DM,E,ScrBack;Extern Ed S:Startup.DM;ScrFront\n"

   "AddM Control,Sort by Name,Sort N g\n"
   "AddM Control,Sort by Size,Sort S g\n"
   "AddM Control,Sort by Date,Sort D g\n"
   "AddM Control,Sort by Extension,Sort E g\n"
   "AddM Control,Sort by Comment,Sort C g\n"

   "AddA (FORM????ILBM#?|@database#?|??????JFIF#?|GIF8#?),View %s\n" /* 2.5.26 rri */
   "AddA ??-lh#?,StdIO \"CON:0/12/640/180/DM2\";Extern Lha x %n;StdIO CLOSE\n"
   "AddA PK#?,StdIO \"CON:0/12/640/180/DM2\";Extern UnZIP %n;StdIO CLOSE\n"
   "AddA DEFAULT,Read %s wait\n"

   "AddKeyCmd f1,about\n"
   "AddKeyCmd f2,iconify\n"

   "\x0";


UWORD RenderImageData[] =
{
  0xffff,0xffff,0xffff,0xffff,0xffff,0xf81f,0xffff,0xffff,
  0xe007,0xffff,0xffff,0xe007,0xffff,0xffff,0xc183,0xffff,
  0xffff,0xc3c3,0xffff,0xffff,0xc3c3,0xffff,0xffff,0xff83,
  0xffff,0xffff,0xff87,0xffff,0xffff,0xff07,0xffff,0xffff,
  0xfe0f,0xffff,0xffff,0xfc1f,0xffff,0xffff,0xf83f,0xffff,
  0xffff,0xf001,0xffff,0xffff,0xe001,0xffff,0xffff,0xc001,
  0xffff,0xffff,0xffff,0x0000,0x0000,0x0000,0x0000,0x7c7c,
  0x07e0,0x0000,0x7c7c,0x1ff8,0x0000,0x7c7c,0x1ff8,0x0000,
  0x7c7c,0x3e7c,0x0000,0xfefe,0x3c3c,0x0000,0xfefe,0x3c3c,
  0x0000,0xfefe,0x007c,0x0000,0xeeee,0x0078,0x0001,0xefef,
  0x00f8,0x0001,0xefef,0x01f0,0x0001,0xefef,0x03e0,0x0001,
  0xc7c7,0x07c0,0x0003,0xc7c7,0x8ffe,0x0003,0xc7c7,0x9ffe,
  0x0003,0xc7c7,0xbffe,0x0000,0x0000,0x0000,0x0000,0x0000,
  0x0000,0x7fc0,0x7c7c,0x0000,0x7ff0,0x7c7c,0x0000,0x7ff8,
  0x7c7c,0x0000,0x7878,0x7c7c,0x0000,0x783c,0xfefe,0x0000,
  0x783c,0xfefe,0x0000,0x783c,0xfefe,0x0000,0x783c,0xeeee,
  0x0000,0x783d,0xefef,0x0000,0x783d,0xefef,0x0000,0x783d,
  0xefef,0x0000,0x7879,0xc7c7,0x0000,0x7ffb,0xc7c7,0x8000,
  0x7ff3,0xc7c7,0x8000,0x7fc3,0xc7c7,0x8000,0x0000,0x0000,
  0x0000 /* 2.5.28 rri */
};

struct Image RenderImage=
{
 0,0,   /* Top Corner */
 48,17, /* Width, Height */
 3,     /* Depth */
 &RenderImageData[0], /* Image Data */
 7, 0,  /* PlanePick,PlaneOnOff */
 NULL   /* Next Image */
};

UWORD SelectRenderData[] =
{
  0xffff,0xc007,0xffff,0xffff,0x0000,0x707f,0xfffe,0x0000,
  0x707f,0xfffe,0x07c0,0x707f,0xfffe,0x07c0,0x707f,0xffff,
  0x7fc0,0x203f,0xffff,0x7f81,0x203f,0xffff,0xff01,0x203f,
  0xffff,0xfe02,0x223f,0xffff,0xfc06,0x021f,0xffff,0xf80e,
  0x021f,0xffff,0xf01a,0x021f,0xffff,0xe037,0x071f,0xffff,
  0xc000,0x070f,0xffff,0x8000,0x070f,0xffff,0x0000,0x070f,
  0xfffe,0x0000,0x7fff,0x0000,0x3ff8,0x0000,0x0000,0xfffe,
  0x0f80,0x0001,0xffff,0x0f80,0x0001,0xf83f,0x0f80,0x0001,
  0xf83f,0x0f80,0x0000,0x703f,0x1fc0,0x0000,0x707f,0x1fc0,
  0x0000,0x00ff,0x1fc0,0x0000,0x01fc,0x5dc0,0x0000,0x03fc,
  0x7de0,0x0000,0x07fc,0xfde0,0x0000,0x0ff9,0xfde0,0x0000,
  0x1ff0,0xf8e0,0x0000,0x3fff,0xf8f0,0x0000,0x7fff,0xf8f0,
  0x0000,0xffff,0x98f0,0x0001,0xffff,0x8000,0x0000,0x0000,
  0x0000,0x01ff,0x0001,0x8f80,0x01fe,0x0000,0x8f80,0x01fe,
  0x0000,0x8f80,0x01e0,0x0000,0x8f80,0x01e0,0x8000,0xdfc0,
  0x01e0,0x8000,0xdfc0,0x01e0,0xf000,0xdfc0,0x01e0,0xf001,
  0xddc0,0x01e0,0xf001,0xfde0,0x01e0,0xf001,0xfde0,0x01e0,
  0xf005,0xfde0,0x01e1,0xe008,0xf8e0,0x01ff,0xc000,0x78f0,
  0x01ff,0x8000,0x78f0,0x01ff,0x0000,0x78f0,0x0000,0x0000,
  0x0000 /* 2.5.28 rri */
};

struct Image SelectRender=
{
 0,0,
 48,17,
 3,
 &SelectRenderData[0],
 7,0,
 NULL
};

struct DiskObject do_dm_config=
 {
  WB_DISKMAGIC,
  WB_DISKVERSION,
   { /* Embedded Gadget Structure */
    NULL, /* Next Gadget Pointer */
    0,    /* LeftEdge */
    0,    /* TopEdge */
    48,   /* Width */
    17,   /* Height */
    GFLG_GADGHIMAGE|GFLG_GADGIMAGE, /* Flags */
    GACT_IMMEDIATE|GACT_RELVERIFY, /* Activation */
    GTYP_BOOLGADGET, /* GadgetType */
    (APTR)&RenderImage, /* GadgetRender */
    (APTR)&SelectRender, /* SelectRender */
    NULL, /* *GadgetText */
    0, /* MutualExclude */ /* 2.5RC4 rri vbcc */
    NULL, /* SpecialInfo */
    0, /* GadgetID */
    NULL /* UserData */
   },
  WBPROJECT, /* Icon Type */
  "", /* Default Tool */
  NULL, /* Tool Type Array */
  NO_ICON_POSITION, /* Current X */
  NO_ICON_POSITION, /* Current Y */
  NULL, /* Drawer Structure */
  NULL, /* Tool Window */
  9000 /* Stack Size */
 };



/* 2.5.23 rri */
void SaveMenus(UBYTE *savebuffer);
void SaveScreen(UBYTE *savebuffer);
void SaveWindows(UBYTE *savebuffer);
void SaveWin(struct DirWindow *dw,UBYTE *savebuffer);


void Catsbuff(UBYTE *xxxx) /* 2.5RC8 rri */
{
DMstrcat(sbuff,xxxx);
}


void FillSaveBuffer(UBYTE *savebuffer) /* 2.5b7 rri */
{
 sprintf(savebuffer,";%s\nReset\n",Version); /* 2.5.24 rri */
 SaveScreen(savebuffer);
 SaveWindows(savebuffer);
 SaveMenus(savebuffer);
 if(FLAGS&DMFLAG_EXPAND) DMstrcat(savebuffer,"\nExpand ON\n"); /* 2.5RC2 rri */
}


void SaveConfig()
{
UBYTE *buf=ActionArgs[1];
BPTR fh;
sFIB  destfib; /* 2.5.24 rri */
ULONG icon,
      n=1,
      warn; /* 2.5.24 rri */

icon=GetActionArg("ICON",AATYPE_BOOL,0); /* 2.5b7 rri */
warn=GetActionArg("WARN",AATYPE_BOOL,0); /* 2.5.24 rri */

if(!buf||*buf==0||icon==1||warn==1) /* 2.5.24 rri */
 {
  buf=Strap;
  if(AslBase) /* 2.5.24 rri */
   {
    buf=DMFileReq(Strap,0,TRUE); /* 2.5.27 rri */
    if(*buf)
     {
      if(Strap) PoolFreeVec(Strap);
      if((Strap=PoolAllocVec(NamePool,(ULONG) (strlen(buf)+10) )))
       {
        strcpy(Strap,buf);
        buf=Strap;
       }
      else
       {
        Strap=NULL;
        n=0;
       }
     }
    else
     {
      n=0;
     }
   }
  else
   {
    struct TagItem safetags[]={{DMREQ_BUTTONS,(ULONG) g_buttons},{TAG_END,0}}; /* 2.5.26 rri */
   
    MakeBtnString(0, msgGadIcon, 0); /* 2.5b13 rri */
    n=DMReqTagList(msgReqSave, buf, 128, safetags); /* 2.5.26 rri */
   }
 }

if(n)
 {
  if(warn) /* 2.5.24 rri */
   {
    if((fh=Lock(buf,ACCESS_READ)))
     {
      Examine(fh,&destfib);
      UnLock(fh);
      if(REQ_FileExists(0,&destfib)==0) return;
     }
   }
  if(!GetGlobuff()) return; /* 2.5b7 rri */
  if((fh=Open(buf,MODE_NEWFILE))) /* 2.5.23 gcc rri */
   {
    FillSaveBuffer(Globuff); /* 2.5b7 rri */
    Write(fh,Globuff,(ULONG) strlen(Globuff)); /* 2.5b10 rri */
    Close(fh);
    SmartAddEntry(buf);
    if(icon||n==2) /* 2.5b13 rri */
     {
      strcpy(sbuff,ProgName); /* 2.5RC9 rri */
      do_dm_config.do_DefaultTool=FilePart(sbuff); /* 2.5.24 rri */
      PutDiskObject(buf,&do_dm_config);
      sprintf(sbuff,"%s.info",buf);
      SmartAddEntry(sbuff);
     } /* if (Icon)... */
   } /* if (fh=... */
 } /* if(n)... */
}


void SaveScreen(UBYTE *savebuffer)
{
UBYTE *ptr;
ULONG i,cols; /* 2.5.23 gcc rri */
struct DrawInfo *dri;

ptr=sbuff;

if(MyScreen)
 {
  DMstrcat(savebuffer,"Pens"); /* 2.5RC8 rri */
  if((dri=GetScreenDrawInfo(MyScreen))) /* 2.5.23 gcc rri */
   {
    for(i=0;i<(dri->dri_NumPens);i++)
     {
      /* the cast is necassary as SAS-C won't work with %u only */
      sprintf(ptr," %lu",(ULONG) dri->dri_Pens[i]); /* 2.5.23 gcc rri */
      ptr+=strlen(ptr); /* 2.5b12 rri */
     }
    FreeScreenDrawInfo(MyScreen,dri);
    sprintf(ptr,"\n"); /* 2.5b12 rri */
    DMstrcat(savebuffer,sbuff);
   }

  sprintf(sbuff,"NewScreen ID=%lu D=%lu W=%lu H=%lu F=%s FS=%lu\n", /* 2.5RC4 rri vbcc */
          Screen_ID,(ULONG) Screen_Depth,Screen_Width,Screen_Height, /* 2.5.23 gcc rri */
          MyScreen->Font->ta_Name,(ULONG) MyScreen->Font->ta_YSize); /* 2.5.23 gcc rri */
  DMstrcat(savebuffer,sbuff);

  strcpy(sbuff,"Color");  /* 2.5RC8 rri */
  ptr=sbuff+5;
  cols=1<<MyScreen->BitMap.Depth;
  if(UserColors<cols) cols=UserColors; /* 2.5b11 rri */
  if(cols>60) cols=60; /* 2.5RC10 rri */
  for(i=0;i<cols;i++)
   {
    /* GCC gives a warning for this but it still works... */
    sprintf(ptr," %03.3lx",GetRGB4(MyScreen->ViewPort.ColorMap,i)); /* 2.5b12 rri */
    ptr+=4;
   }
  Catsbuff("\n"); /* 2.5RC8 rri */
  DMstrcat(savebuffer,sbuff);
 }

/* 2.5RC2 jjt */
strcpy(sbuff, "Font");
for (i=DMFONTS_MAIN; i < DMFONTS_SCREEN; i++)
 {
  if (DMFonts[i])
   {
    sprintf(sbuff,"%s %s=%s %ld",sbuff,FontKeywords[i],GetTFName(DMFonts[i]),(LONG) DMFonts[i]->tf_YSize); /* 2.5.23 gcc rri */
   }
 }
Catsbuff("\n"); /* 2.5RC8 rri */
DMstrcat(savebuffer, sbuff);


sprintf(sbuff,"SetX BPen=%ld DPen=%ld FPen=%ld SPen=%ld",
                    BackPen,DirPen,FilePen,SelectPen);  /* 2.5b12 rri */

if(digits!=5) /* 2.5.24 */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," digits=%ld",digits);
 }

if(Notify) /* 2.5b12 rri */
 {
  Catsbuff(" Notify"); /* 2.5RC8 rri */
 }

if(defx&&defy&&(defx==Screen_Width)&&(defy==Screen_Height)) /* 2.5.24 rri */ 
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," defx=%ld defy=%ld",defx,defy);
 }

if(IconX!=(LONG) NO_ICON_POSITION) /* 2.5.23 gcc rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," IconX=%ld",IconX);
 }

if(IconY!=(LONG) NO_ICON_POSITION) /* 2.5.23 gcc rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," IconY=%ld",IconY);
 }

if(AppIconPath&&(Stricmp(AppIconPath,ProgName)!=0)) /* 2.5.26 rri */
 {
  Catsbuff(" AppIcon="); /* 2.5RC8 rri */
  Catsbuff(AppIconPath); /* 2.5RC8 rri */
 }

if(UserColors>4) /* 2.5b12 rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," UserColors=%ld",UserColors);
 }

if(sizes>1) /* 2.5RC8 rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," sizes=%ld",sizes);
 }

if(separator!=0x2e) /* 2.5RC8 rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," separator=%ld",separator);
 }

Catsbuff("\n\n"); /* 2.5RC8 rri */
DMstrcat(savebuffer,sbuff);
}


/* 2.5RC10 rri */
void SaveMenus(UBYTE *savebuffer)
{
struct Menu *menu=DMMenu;
struct MenuItem *item;
struct IntuiText *itext;
UBYTE *ptr,*ptr2,*ptr3,cmd[4],c;
ULONG i;

while(menu)
 {
  item=menu->FirstItem;
  ptr=menu->MenuName;
  while(item)
   {
    itext=(struct IntuiText *)item->ItemFill;
    ptr2=itext->IText;

    ptr3 = GTMENUITEM_USERDATA(item); /* 2.5b5 hys */
    if(ptr3 == NM_BARLABEL)
     {
      sprintf(sbuff, "AddMenu %s, BARLABEL,\n", ptr);
     }
    else
     {
      c=item->Command;
      cmd[0]=cmd[3]=0;
      cmd[1]=',';
      cmd[2]=' ';
      if(c) cmd[0]=c;
      sprintf(sbuff,"AddMenu %s, %s, %s%s\n",ptr,ptr2,cmd,ptr3);
     }
    DMstrcat(savebuffer,sbuff);
    item=item->NextItem;
   }
  menu=menu->NextMenu;
  DMstrcat(savebuffer,"\n");
 }

for(i=0;i<255;i++)
if((ptr=AutoCmdStr[i])) /* 2.5.23 gcc rri */
 {
  sprintf(sbuff,"AddAutoCmd %s\n",ptr);
  DMstrcat(savebuffer,sbuff);
 }

DMstrcat(savebuffer,"\n");

for(i=0;i<100;i++)
if((ptr=KeyCmdStr[i])) /* 2.5.23 gcc rri */
 {
  sprintf(sbuff,"AddKeyCmd %s\n",ptr);
  DMstrcat(savebuffer,sbuff);
 }
}


/* 2.5RC10 rri */
void SaveWindows(UBYTE *savebuffer)
{
struct DirWindow *dw;
ULONG i;

sprintf(sbuff,"Button \"%s\"\nSetFormat \"%s\"\nBarFormat \"%s\"\nTitleFormat \"%s\"\n\n",
        PGadStr,DispFormat,BarFormat,TitleFormat);
DMstrcat(savebuffer,sbuff);

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&!(dw->Flags&DW_CMD)) /* dir-windows first */
   {
    SaveWin(dw,savebuffer);
   }
 }

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&dw->Flags&DW_CMD) /* now cmd-windows */
   {
    SaveWin(dw,savebuffer);
   }
 }
}


/* 2.5RC10 rri */
void SaveWin(struct DirWindow *dw,UBYTE *savebuffer)
{
struct DirList **dl,*dlp;
UBYTE *ptr2="\n"; /* 2.5RC6 rri */
LONG j; /* 2.5.23 rri */
UBYTE sorts[8]="NSDCEF"; /* 2.5.24 rri */
UBYTE *ptr; /* 2.5.24 rri */

if(dw->Flags&DW_SOURCE) ptr2="Lock S\n\n"; /* 2.5.24 rri */
if(dw->Flags&DW_DEST  ) ptr2="Lock D\n\n"; /* 2.5.24 rri */

DMstrcat(savebuffer,"OpenWindow");

if(dw->Flags&DW_CMD)
 {
  DMstrcat(savebuffer," CMD");
 }
else
 {
  if(dw->Path[0])
   {
    sprintf(sbuff," Path=\"%s\"",dw->Path); /* 2.5RC6 rri */
    DMstrcat(savebuffer,sbuff);
   }
 }

if(!(dw->Window->Flags&WFLG_CLOSEGADGET))
 {
  DMstrcat(savebuffer," NOCLOSE");
 }
if(!(dw->Window->Flags&WFLG_DRAGBAR))
 {
  DMstrcat(savebuffer," NODRAG");
 }

/* the casts are necassary as SAS-C won't work with %d only... */
sprintf(sbuff," Left=%ld Top=%ld Width=%ld Height=%ld"
              " ZoomL=%ld ZoomT=%ld ZoomW=%ld ZoomH=%ld",
       (LONG)dw->norm[0],(LONG)dw->norm[1],(LONG)dw->norm[2],(LONG)dw->norm[3], /* 2.5.23 rri */
       (LONG)dw->zoom[0],(LONG)dw->zoom[1],(LONG)dw->zoom[2],(LONG)dw->zoom[3]); /* 2.5.23 rri */

Catsbuff(((dw->Window->Flags&WFLG_ZOOMED) ? " Zoomed\n" : "\n")); /* 2.5RC8 rri */
DMstrcat(savebuffer,sbuff);

/* 2.5.24 rri */
if(!(dw->Flags&DW_CMD))
 {
  sprintf(sbuff,"Sort ");
  ptr=sbuff+strlen(sbuff);
  ptr[1]=0;
  ptr[2]=0;
  ptr[3]=0;
  ptr[4]=0;
  ptr[0]=sorts[dw->Sorting/2];
  if(dw->Sorting%2)
   {
    ptr[1]='-';
   }
  Catsbuff("\n");
  DMstrcat(savebuffer,sbuff);
 }

DMstrcat(savebuffer,ptr2);

if(dw->Flags&DW_CMD)
 {
  dl=dw->DirList;
  for(j=0;j<dw->FileCount;j++)
   {
    dlp=dl[j];
    if(dlp->name) /* 2.5.24 rri */
     {
      /* 2.5b12 rri */
      sprintf(sbuff,"AddCmd %s, %lx%lx, %lx%lx, %s\n",dlp->name,
      dlp->attr&0xf,(dlp->attr>>4)&0xf,(dlp->attr>>8)&0xf,(dlp->attr>>12)&0xf,
      dlp->cmt);
     }
    else /* 2.5.24 rri */
     {
      sprintf(sbuff,"AddCmd\n");
     }
    DMstrcat(savebuffer,sbuff);
   }
  DMstrcat(savebuffer,"\n");
 }
}


void Iconify(void) /* 2.5b7 rri */
{
struct AppIcon *appicon;
struct AppMessage *appmsg;
struct RexxMsg *rexxmsg;
int loop=1;
struct DiskObject *diskobj=0; /* 2.5b13 rri */
struct DiskObject *appobj=0;

if(FLAGS&DMFLAG_BATCH) /* 2.5RC2 rri */
 {
  return; /* 2.5b13 rri */
 }

FLAGS|=DMFLAG_KEEPGLOBAL; /* 2.5RC2 rri */

do_dm_config.do_CurrentX = IconX; /* 2.5b9 rri */
do_dm_config.do_CurrentY = IconY; /* 2.5b9 rri */

#ifdef __PPC__ /* 2.5.26 rri */
if (LibOpen("workbench", &WorkbenchBase, 37, (struct Interface **) &IWorkbench))
#else
if (LibOpen("workbench", &WorkbenchBase, 37)) /* 2.5RC6 rri */
#endif
 {
  if (!GetGlobuff()) return;
  FillSaveBuffer(Globuff);

  if(!CmdWin) /* 2.5b13 rri */
   {
    FindCmdWin();
   }
  if(CmdWin) /* 2.5b13 rri */
   {
    strcpy(dcPath,CmdWin->Path);
   }

  if(IconBase->lib_Version >= 44)
   {
    diskobj = GetIconTags(AppIconPath,
                          ICONGETA_FailIfUnavailable, FALSE, /* 2.5.26 rri */
                          TAG_DONE,0);
   }
  else
   {
    diskobj=GetDiskObjectNew(AppIconPath); /* 2.5.26 rri */
   }

  if(diskobj)
   {
    diskobj->do_CurrentX = IconX; /* 2.5RC2 rri */
    diskobj->do_CurrentY = IconY; /* 2.5RC2 rri */
    appobj=diskobj; /* 2.5RC4 rri vbcc */
   }

  if(!appobj) /* 2.5RC4 rri vbcc */
   {
    appobj= &do_dm_config;
   }

  FreeUserData(); /* 2.5RC10 rri */

  AddPort(WinPort); /* port is removed by FreeUserData() */ /* 2.5RC10 rri */

  appicon=AddAppIconA(0,0,DMname,WinPort,0,appobj,0); /* 2.5RC4 rri vbcc */

  while(loop) /* 2.5b9 rri */
   {
    WaitPort(WinPort);

    while((appmsg=(struct AppMessage *)GetMsg(WinPort))) /* 2.5.23 gcc rri */
     {
      if(RexxSysBase&&IsRexxMsg((struct RexxMsg *)appmsg)) /* 2.5.26 rri  */
       {
        rexxmsg=(struct RexxMsg *)appmsg;
        if(Strnicmp("QUIT",rexxmsg->rm_Args[0],4)==0) /* 2.5RC6 rri */
         {
          FLAGS&=~DMFLAG_KEEPGOING; /* 2.5RC2 rri */
          loop=2;
         }
        else if(Strnicmp("WAKE",rexxmsg->rm_Args[0],4)!=0) /* 2.5RC6 rri */
         {
          ReplyMsg((struct Message *)appmsg); /* 2.5b13 rri */
          continue;
         }
       }

      ReplyMsg((struct Message *)appmsg); /* 2.5b13 rri */

      while((appmsg=(struct AppMessage *)GetMsg(WinPort))) /* 2.5.23 gcc rri */
       {
        ReplyMsg((struct Message *)appmsg);
       }

      RemoveAppIcon(appicon);

      if(loop==1)
       {
        FLAGS|=DMFLAG_BATCH; /* 2.5RC2 rri */

        ActionCmd(254,Globuff); /* 2.5RC10 rri */

        FLAGS&=~DMFLAG_BATCH; /* 2.5RC2 rri */
        DMLayoutMenus(); /* 2.5RC10 rri */
        FindCmdWin();
        AddPort(WinPort); /* port is removed by FreeUserData() */ /* 2.5RC10 rri */
       }
      loop=0;
     }
   }

 }

do_dm_config.do_CurrentX = NO_ICON_POSITION; /* 2.5b9 rri */
do_dm_config.do_CurrentY = NO_ICON_POSITION; /* 2.5b9 rri */

if(diskobj) /* 2.5b13 rri */
 {
  FreeDiskObject(diskobj);
 }

FLAGS&=~DMFLAG_KEEPGLOBAL; /* 2.5RC2 rri */
}
