/* DiskMaster II Palette-Requester
**
** 2.5RC4
**
** 02-05-31 rri - Pens20[] is pre-initialised again based on a 4 color screen.
**                Just to guarantee a correct look in case DM2 is
**                started without Startup.DM
**
** 02-06-30 rri - Removed internal palette-requester.
**              - Placed opening of Reqtools library here to have it only
**                opened in case it's really needed.
**
** 2.5RC6
**
** 02-10-04 rri - Replaced one atoi() call with an atol() call.
**
** 02-10-07 rri - Modified one LibOpen() call.
**
** 2.5RC9
**
** 03-01-21 rri - Replaced one atol() call with a StrToLong().
**
** 2.5RC10
**
** 03-03-07 rri - Increased Pens20[] to 50 entries.
**
** 03-04-09 rri - Bitmap-depth in AllocPens() is now determined thru
**                GetBitMapAttr(&MyScreen->RastPort.BitMap,BMA_DEPTH)
**                when DM2 runs under V39+
**
** 03-04-11 rri - Adjusted the internal color-map ColMap[] to 62 entries,
**                more possible arguments, more possible colors...
**              - Added init "UserCols=0", this prevents loading the colore-table
**                with random-values in case no colors are defined.
**              - Added a--; to AllocPens()
**              - In SetPens() allowed 49 pens to be set for first 59 colors.
**              - Removed V39+ dependany within AllocPens() as it won't be
**                executed in the first place if DM2 does not run under V39+...
**              - Changed the Pens20[] to default V50.
**
** 2.5.23
**
** 03-05-18 rri - Added includes for Reqtools.library.
**              - Added a few double-brackets to assignments to avoid
**                warnings with GCC.
**
** 2.5.26
**
** 03-09-07 rri - Removed old comments from top of file.
**              - Removed a few "new!" style comments.
**              - Added OS4 PPC support thru alternative LibOpen().
**
*/

#include "DM.h"
#include <libraries/reqtools.h> /* 2.5.23 gcc rri */
#include <proto/reqtools.h> /* 2.5.23 gcc rri */

extern struct Screen    *Screen,*MyScreen;
extern struct TextFont  *DMFonts[];

extern UBYTE  *ActionArgs[];
extern UBYTE  Version[];

extern LONG   BackPen; /* 2.5b12 rri */

extern ULONG FLAGS; /* 2.5RC2 rri */

struct ReqToolsBase *ReqToolsBase;

#ifdef __PPC__ /* 2.5.26 rri */
struct ReqToolsIFace   *IReqTools=NULL;
#endif

UWORD   ColMap[62], /* 2.5RC10 rri */
        Pens20[50]={0,1,1,2,1,3,1,0,2,1,2,1,2,0,2,1,2,1,0,1,2,1,0,3,2,1,0,1,2,1,3,2,2,1,1,0,1,0,1,1,2,1,1,0,0,0,0,0,0,0}; /* 2.5RC10 rri */

ULONG UserCols=0, /* 2.5RC10 rri */
      UserColors=4; /* 2.5b11 rri */


void PenAllocation(ULONG i); /* 2.5b13 rri */


void SetColors()
{
UBYTE *ptr;
ULONG c,i=1,g=0,x; /* 2.5b11 rri */

if(!ActionArgs[1])
 {
  if(!ReqToolsBase) /* 2.5RC4 rri */
   {
#ifdef __PPC__ /* 2.5.26 rri */
    LibOpen("reqtools", (struct Library **) &ReqToolsBase, 0, (struct Interface **) &IReqTools);
#else
    LibOpen("reqtools", (struct Library **) &ReqToolsBase, 0); /* 2.5RC6 rri */
#endif
   }
  if(ReqToolsBase) rtPaletteRequestA( Version, NULL, NULL);  
  return;
 }
while(ActionArgs[i])
 {
  ptr=ActionArgs[i++];
  ColMap[g]=0;

  while ((c = *ptr++)) /* 2.5b11 jjt */ /* 2.5.23 gcc rri */
   {
    x = Char2Nibble((ULONG) c);  /* 2.5b11 jjt */
    if (x > 15) x = 0;           /* 2.5b11 jjt */
    ColMap[g]<<=4;
    ColMap[g]|=x;
   }
  g++;
 }
UserCols=g;

if(MyScreen)
 {
  LoadRGB4(&MyScreen->ViewPort,ColMap,(ULONG) g); /* 2.5b10 rri */
  if(FLAGS&DMFLAG_USE30) /* 2.5RC2 rri */
   {
    AllocPens(); /* 2.5b12 */
   }
 }
}


void SetPens()
{
int i=1;
LONG x;

if(MyScreen) /* do nothing when own screen already is open */
 {
  return;
 }

while(ActionArgs[i]&&i<49) /* 2.5RC10 rri */
 {
  Pens20[i-1]=0;
  StrToLong(ActionArgs[i],&x); /* 2.5RC9 rri */
  Pens20[i-1]=x;
  if(Pens20[i-1]>59) Pens20[i-1]=0; /* 2.5RC10 rri */
  i++;
 }

BackPen=Pens20[BACKGROUNDPEN];

}


void PenAllocation(ULONG i) /* 2.5b13 rri */
{
ObtainPen(Screen->ViewPort.ColorMap,i,0,0,0,PEN_EXCLUSIVE|PEN_NO_SETCOLOR);
}


/* only executed under V39+ ! */
void AllocPens(void) /* 2.5b13 rri */
{
ULONG i,a;

for(i=0;i<UserColors;i++)
 {
  PenAllocation(i);
 }

a = ( 1 << ( GetBitMapAttr(MyScreen->RastPort.BitMap,BMA_DEPTH) ) ); /* 2.5RC10 rri */

a--; /* 2.5RC10 rri */

i=a-Pens20[BACKGROUNDPEN];
PenAllocation(i);

i=a-Pens20[TEXTPEN];
PenAllocation(i);

i=a-Pens20[HIGHLIGHTTEXTPEN];
PenAllocation(i);
}
