/* DiskMaster2 window content module - generates and converts the strings
**
** 2.5RC8
**
** 03-01-03 rri - Bugfix: digits calculation for file-size display returned one
**                digit to less on sizes of 10/10x/10xx/10xxx...
**                Thanks for reporting to Jostein Klemmetsrud <klemmetj@c2i.net>!
**
** 03-01-04 rri - Optimised DoFileFormat() by removing three lines for %s.
**              - Added different modes for %s in DoFileFormat()
**
** 03-01-05 rri - Further optimised DoFileFormat(), mostly size-wise.
**
** 2.5RC9
**
** 03-01-08 rri - Replaced some divisions with divisor to base to by bit-shifts.
**              - Bugfix: without dirs "sizes=2" was displayed wrong.
**                Thanks for reporting to Jean Marie Boucher <jeanmarieboucher@lycos.co.uk>!
**
** 03-01-25 rri - Replaced one memmove() cally by a CopyMem() call.
**
** 2.5RC10
**
** 03-03-29 rri - Added some "basecon->DiskFree+=512;" lines to ConvertBase()
**                as became necessary for lowering the min value for digits to 3.
**              - Removed some "new! ..." style comments.
**
** 03-04-12 rri - Dirlist entries now use pooled memory - AllocDlp()/FreeDirTable()
**              - Removed two useless lines from FreeDirTable()
**
** 03-04-19 rri - 'SetFormat' has no longer impact on cmd-windows.
**
** 03-04-24 rri - Bugfix: 'SetFormat "N TS" could look slightly distorted.
**                Thanks for reporting to Richard Mattsson <avart@ftml.net>!
**
** 2.5.23
**
** 03-05-30 rri - Changed type of "digits", "Notify", "LastI" and
**                "lockcount" to LONG.
**              - Changed type of "OldDir" to ULONG.
**              - Fixed quite some warnings from GCC.
**              - Changed type of "Base_Str_Len" from ULONG to LONG.
**              - Introduced DMMAXWINDOWS.
**
** 2.5.24
**
** 03-07-19 rri - Modified access to "Strap" in InitDir().
**              - Corrected one line in WinTitle().
**
** 03-07-20 rri - Made ConvertBase() a bit simpler and added display
**                of "G" (for now hardcoded) to it.
**
** 2.5.26
**
** 03-08-16 rri - "Bugfix": Added a RefreshWindowFrame() right after
**                          SetWindowTitles() in WinTitle(), for some reason
**                          Intutition seems to not always properly update
**                          the title-bar, especially when it is meant to
**                          clear the bar thru ZERO arguments.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC4)
**
** 03-08-20 rri - Added %O as flag for occupied space on disk for 'TitleFormat'.
**
** 03-08-22 rri - New function: AddPercentStr()
**              - Added %P as flag for free space on disk for 'TitleFormat' as
**                suggested by Glenn Edward <glenn_edw@email.com>
**
** 03-08-23 rri - Added %B, %E and %O to 'BarFormat' - percentage of free memory.
**
** 03-08-24 rri - Made calculation of percentage bullet-proof for big numbers.
**
** 03-09-07 rri - Added %N to 'TitleFormat' following a suggestion by
**                Thomas <tonyiommi@gmx.net>.
**                This adds an unique name to the title for window-managers.
**                Status: experimental...
**
** 2.5.28
**
** 04-01-03 rri - Changed one allocation in AllocDlp() from MEMF_PUBLIC to MEMF_ANY.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC8)
**              - Bugfix: the soft-link detection in Fib2Dlp() did not work at all,
**                        put a modified version in GetDirEntry(), access to files in
**                        soft-linked dirs does not work.
**              - Replaced a few AllocMem()/FreeMem() calls by AllocDosObject()/FreeDosObject() calls.
**
**
*/

#include "DM.h"

#define LENGTH(x)  (*(UBYTE *)BADDR(x))
#define STRING(x)  (((char *)BADDR(x))+1)

extern UBYTE BarFormat[],
             DispFormat[],
             *DevHide_List[], /* 2.5b12 jjt */
             DMname[],
             *Globuff, /* 2.5b7 rri */
             sbuff[],
             ScreenTitle[],
             *Strap, /* 2.5.24 rri */
             TitleFormat[],
             Version[];

extern LONG digits, /* 2.5.23 rri */
            Globuff_size, /* 2.5b7 rri */
            LastI, /* 2.5.23 rri */
            lockcount, /* 2.5.23 rri */
            long_month, /* 2.5b13 rri */
            Notify; /* 2.5.23 rri */

extern ULONG DevHide_Count,  /* 2.5b12 jjt */
             FLAGS, /* 2.5RC2 rri */
             OldDir; /* 2.5.23 rri */

extern APTR CommentPool, /* 2.5b10 rri */
            NamePool, /* 2.5b10 rri */
            StringPool; /* 2.5RC10 rri */

extern struct DirList *DClickDir;

extern struct DirWindow *CmdWin,
                        *DestWin,
                        *DirWin[];

extern struct InfoData InfoData;

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */


ULONG gigaflag,Bgigaflag,
      ShowDev=SHOWDEV_ALL; /* 2.5b12 jjt */

LONG  Base_Str_Len=99999, /* 2.5.23 rri */
      BTotal,
      LTotal,
      separator=0x2e, /* 2.5RC8 rri */
      sizes=1; /* 2.5RC8 rri */

UBYTE *AddPercentStr(UBYTE *ptr,ULONG part,ULONG whole); /* 2.5.26 rri */
UBYTE *AddConvStr(UBYTE *ptr,ULONG freebl,ULONG bytes); /* 2.5.23 gcc rri */
int CacheLoad(struct DirWindow *dw);
void ExDone(struct DirWindow *dw);


void ConvertBase(struct BaseConvert *basecon)
{
const UBYTE *base; /* 2.5b13 rri */
UBYTE *ptr;
LONG cnt=0; /* 2.5.24 rri */

ptr=basecon->String;

if (!basecon->BlocksFree)
 {
  basecon->DiskFree=0;
  *ptr++='0'; /* 2.5b13 rri */
  *ptr=0; /* 2.5b13 rri */
  return;
 }

if(basecon->BlocksFree<(2147483647/basecon->BytesPerBlock))
 {
  basecon->DiskFree=(basecon->BlocksFree)*basecon->BytesPerBlock;
  if(basecon->DiskFree>Base_Str_Len) /* 2.5b7 rri */
   {
    basecon->DiskFree+=512; /* 2.5RC10 rri */
    basecon->DiskFree=basecon->DiskFree>>10; /* 2.5RC9 rri */
    cnt++; /* 2.5.24 rri */
   }
 }
else
 {
  basecon->DiskFree+=512; /* 2.5RC10 rri */
  basecon->DiskFree=basecon->BlocksFree>>10; /* 2.5RC9 rri */
  basecon->DiskFree=basecon->DiskFree*basecon->BytesPerBlock;
  cnt++; /* 2.5.24 rri */
 }

while(basecon->DiskFree>Base_Str_Len) /* 2.5.24 rri */
 {
  basecon->DiskFree+=512;
  basecon->DiskFree=basecon->DiskFree>>10;
  cnt++;
 }

switch(cnt)
 {
  case 0:  base=msgUnitBytes;
           break;
  case 1:  base=msgUnitKiloB;
           break;
  case 2:  base=msgUnitMegB;
           break;
  case 3:  base="G";
           break;
  default: base=msgUnitBytes;
           break;
 }

sprintf(ptr,"%ld %s",basecon->DiskFree,base); /* 2.5b13 rri */
}


void ReSize(struct DirWindow *dw) /* 2.5b5 rri */
{
struct DirList **dl=dw->DirList,*dlp;
int i,cols,cols1=0,cols2=0,sels=0;
LONG total[100],bftotal[100], /* 2.5b11 rri - max headroom now 200gig... */
     dirsize=0,
     da=0,db,dc=0; /* 2.5RC7 rri */
ULONG totaltest,bftest;
int x=0,y=0;

bftotal[0]=total[0]=0; /* 2.5b10 rri */

for(i=0;i<101;i++)
 {
  total[i]=0;
  bftotal[i]=0;
 }

for(i=0;i<dw->FileCount;i++)
 {
  dlp=dl[i];
  if(dlp->name) /* 2.5b10 rri */
   {
    cols=strlen(dlp->name);
    if(cols>cols1) cols1=cols;
   }
  if(dlp->cmt)
   {
    cols=strlen(dlp->cmt);
    if(cols>cols2) cols2=cols;
   }
  if(dlp->dir) /* 2.5RC7 rri */
   {
    dc=digits+2;
   }
  else /* if(!dlp->dir) */ /* calculate file-sizes in total */
   {
    if(da<dlp->size) da=dlp->size; /* find biggest file-size */ /* 2.5RC7 rri */
    bftest=bftotal[y]+dlp->size; /* 2gig boundary check */
    if (bftest>0x7fffffff) /* 2.5.23 gcc rri */
     {
      y++;
      if(y>99) /* 2.5b11 rri - better limit display to 200 gig than */
       {       /* crashing the machine... */
        y=99;
        bftotal[y]=0;
       }
     }
    bftotal[y]+=dlp->size;
   }
  if(dlp->sel) /* calculate selected files/dirs only */
   {
    sels++; /* selection counter */
    if(dlp->dir) /* separate dirs from files */
     {
      if(dlp->size>536870912) /* if a single dir is bigger than */
       {                      /* 2^29 * 512 = 256 GByte something is wrong... */
        dlp->size=0;          /* 2.5b11 rri */
       }                  /* the dlp->size var already holds the amount of */
      dirsize+=dlp->size; /* used blocks after 'Check' */
      continue;           /* 2^31 * 512 = 1 TByte max... */
     }
    totaltest=total[x]+dlp->size; /* 2gig boundary check */
    if (totaltest>0x7fffffff) /* 2.5.23 gcc rri */
     {
      x++;
      if(x>99) /* 2.5b11 rri */
       {
        x=99;
        total[x]=0;
       }
     }
    total[x]+=dlp->size;
   }
 }

if(y>0) /* 2.5b5 rri */
 {
  BTotal=0;
  y=0;
  while (bftotal[y])
   {
    BTotal+=(bftotal[y]>>7); /* 2.5RC9 rri *//* 2.5b11 rri - 256 GByte max now */
    y++;
   }
  Bgigaflag=127; /* 2.5b13 rri */
 }
else
 {
  BTotal=bftotal[0];
  Bgigaflag=0;
 }

bftest = 100 * dw->BytesPerBlock; /* 2.5b10 rri */

while(dirsize) /* 2.5b10 rri */
 {
  totaltest=total[x]+bftest;
  if (totaltest>0x7fffffff) /* 2.5.23 gcc rri */
   {
    x++;
   }
  if(dirsize>100)
   {
    total[x]+=bftest;
    dirsize-=100;
   }
  else
   {
    total[x]+=dirsize*dw->BytesPerBlock;
    break;
   }
 }

if(x>0)
 {
  LTotal=0;
  x=0;
  while (total[x])
   {
    LTotal+=(total[x]>>7); /* 2.5RC9 rri */
    x++;
   }
  gigaflag=127; /* 2.5b13 rri */
 }
else
 {
  LTotal=total[0];
  gigaflag=0;
 }

/* 2.5RC7 rri */
db=1;
while(da>9) /* 2.5RC8 rri */
 {
  db++;
  da=da/10;
 }

if(sizes==2) db=digits+2; /* 2.5RC9 rri */
if(sizes==3) db=db+((db-1)/3); /* 2.5RC8 rri */

if(db>dc) dc=db;
dw->ColsCmt=(dc<<12)+cols2; /* 2.5RC7 rri */

dw->Sels=sels;
dw->ColsName=cols1;

if(dw->FileCount&&(dw->DirList[0]->dir==2||dw->DirList[0]->dir==3))
 {
  dw->ColsCmt=0;
 }
}


UBYTE *AddPercentStr(UBYTE *ptr,ULONG part,ULONG whole) /* 2.5.26 rri */
{
ULONG var;

if(part>0xffffff) /* we have to deal with bigger numbers */
 {
  whole = whole / 100;
  var = part + (part % whole);
 }
else /* normal operation */
 {
  var = part * 100;
  var = var + (var % whole);
 }

var = var / whole;

sprintf(ptr,"%ld%%",var);
ptr += strlen(ptr);
return(ptr);
}


UBYTE *AddConvStr(UBYTE *ptr,ULONG freebl,ULONG bytes) /* 2.5.23 gcc rri */
{
struct BaseConvert winbase; /* 2.5b13 rri */

winbase.BytesPerBlock=bytes; /* 2.5b13 rri */

winbase.BlocksFree=freebl; /* 2.5.23 gcc rri */
ConvertBase(&winbase);
strcpy(ptr,winbase.String);
ptr+=strlen(winbase.String);
return(ptr);
}


void MainTitle()
{
UBYTE *ptr=ScreenTitle,*dptr=BarFormat;
ULONG c,chip,fast,any; /* 2.5.26 rri */

struct DateTime DateTime;
UBYTE  Day[16],Time[16],Date[16];

DateStamp(&DateTime.dat_Stamp);

DateTime.dat_Format  = FORMAT_INT; /* yy-mmm-dd e.g. 00-Jul-13 */
DateTime.dat_Flags   = 0;
DateTime.dat_StrDay  = Day;
DateTime.dat_StrDate = Date;
DateTime.dat_StrTime = Time;

DateToStr(&DateTime);

Time[5]=0; /* cut-off seconds from time-string */

/* 2.5.26 rri */
chip=AvailMem(MEMF_CHIP);
fast=AvailMem(MEMF_FAST);
any=AvailMem(MEMF_ANY);

while((c = *dptr++)&&(ptr-ScreenTitle<200))
 {
  if(c!='%') *ptr++=c;
  else switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b10 rri */
   {
    case  0 : return;
    case 'A': strcpy(ptr,DMname);
              ptr+=strlen(DMname);
              break;

    /* 2.5.26 rri */
    case 'C': ptr=AddConvStr(ptr,chip,1);
              break;
    case 'B': ptr=AddPercentStr(ptr,chip,AvailMem(MEMF_CHIP|MEMF_TOTAL));
              break;
    case 'F': ptr=AddConvStr(ptr,fast,1);
              break;
    case 'E': ptr=AddPercentStr(ptr,fast,AvailMem(MEMF_FAST|MEMF_TOTAL));
              break;
    case 'P': ptr=AddConvStr(ptr,any,1);
              break;
    case 'O': ptr=AddPercentStr(ptr,any,AvailMem(MEMF_ANY|MEMF_TOTAL));
              break;

    case 'T': strcpy(ptr,Time); ptr+=strlen(Time); break;

    /* 2.5b7 rri */
    case 'D': ptr[0]=Date[strlen(Date)-2]; /* 2.5b13 rri */
              ptr[1]=Date[strlen(Date)-1]; /* 2.5b13 rri */
              ptr+=2;
              break;
    case 'M': ptr[0]=Date[3];
              ptr[1]=Date[4];
              ptr[2]=Date[5];
              ptr+=3;
              if(Date[6]!='-') *ptr++=Date[6]; /* 2.5b13 rri */
              break;
    case 'Y': ptr[0]=Date[0];
              ptr[1]=Date[1];
              ptr+=2;
              break;
    /* 2.5b7 rri */
    case 'W': strcpy(ptr,Day);
              ptr+=strlen(Day);
              break;
    case 'V': c=0;
              while (Version[11+c])
               {
                *ptr++=Version[11+c++];
               }
              break;
    default : *ptr++=c;
   }
 }
*ptr=0;
}


void WinTitle(struct DirWindow *dw)
{
UBYTE *ptr,*dptr=TitleFormat;
ULONG c;
BPTR lock;
struct BaseConvert winbase;

MainTitle();
if(!dw) return; /* 2.5.24 rri */
ReSize(dw);

sbuff[0]=0; /* 2.5RC6 rri */
ptr=sbuff; /* use sbuff[] to build title-line - 2.5RC6 rri */

if((lock=Lock(dw->Path,ACCESS_READ))) /* 2.5.26 rri */
 {
  Info(lock,&InfoData);
 }

if(dw->FileCount&&dw->DirList[0]->dir>1)
 {
 }
else while((c = *dptr++)&&(ptr-sbuff<100)) /* 2.5RC6 rri */
 {
  if(c!='%') *ptr++=c;
  else switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b7 rri */
   {
    case   0: return;
    case 'A': /* files` sizes  2.5b5 rri */
              ptr=AddConvStr(ptr,BTotal,Bgigaflag+1);  /* 2.5b13 rri */
              break;
    case 'B': /* selected files+dirs sizes */
              ptr=AddConvStr(ptr,LTotal,gigaflag+1);  /* 2.5b13 rri */
              break;
    case 'C': /* amount of files */
              ptr=AddConvStr(ptr,(ULONG) dw->FileCount,1);  /* 2.5b13 rri */
              if(dw->FileCount) /* remove " B" from converted string */
               {
                ptr-=2;
                *ptr=0;
                ptr[1]=0; /* 2.5RC7 rri */
               }
              break;
    case 'F': /* free space available */
              if(lock) /* 2.5.26 rri */
               {
                winbase.BlocksFree=InfoData.id_NumBlocks-InfoData.id_NumBlocksUsed;
                dw->BlocksFree=winbase.BlocksFree;
                winbase.BytesPerBlock=InfoData.id_BytesPerBlock;
                dw->BytesPerBlock=InfoData.id_BytesPerBlock; /* 2.5b5 rri */
                ConvertBase(&winbase);
                dw->DiskFree=winbase.DiskFree;
                strcpy(ptr,winbase.String);
                ptr+=strlen(winbase.String);
               }
              break;
    case 'I': /* number of selected files */
              ptr=AddConvStr(ptr,(ULONG) dw->Sels,1);  /* 2.5b13 rri */
              if(dw->Sels) /* remove " B" from converted string */
               {
                ptr-=2;
                *ptr=0;
                ptr[1]=0; /* 2.5RC7 rri */
               }
              break;
    case 'N': /* unique name for window-managers */ /* 2.5.26 rri */
              sprintf(ptr,"%s.%ld",DMname,dw->Number);
              ptr+=strlen(ptr);
              break;
    case 'O': /* occupied disk-space as percentage of available space */ /* 2.5.26 rri */
              if(lock)
               {
                ptr = AddPercentStr(ptr, InfoData.id_NumBlocksUsed, InfoData.id_NumBlocks);
               }
              break;
    case 'P': /* free disk-space as percentage of available space */ /* 2.5.26 rri */
              if(lock)
               {
                ptr = AddPercentStr(ptr, InfoData.id_NumBlocks-InfoData.id_NumBlocksUsed, InfoData.id_NumBlocks);
               }
              break;

    default : *ptr++=c;
   }
 }
*ptr=0; /* 2.5RC7 rri */

if(lock) /* 2.5.26 rri */
 {
  UnLock(lock);
 }

/* 2.5RC6 rri */
if(dw->Title!=0)
 {
  PoolFreeVec(dw->Title);
 }
dw->Title=CloneStr(sbuff, NamePool);

SetWindowTitles(dw->Window,dw->Title,ScreenTitle);
RefreshWindowFrame(dw->Window); /* 2.5.26 rri */
}


void DoFileFormat(struct DirList *dlp,struct DirWindow *dw) /* 2.5RC7 rri */
{
UBYTE *ptr=sbuff,*dptr=DispFormat,*ptr2,*ptr3,
      digit[10]; /* 2.5RC7 rri */
int c;
struct BaseConvert winbase;
LONG ai, value; /* 2.5RC8 rri */

/* 2.5b7 rri */
struct DateTime DateTime;
UBYTE Time[16],Date[16];

DateTime.dat_Format    = FORMAT_INT; /* 2.5b13 rri */
DateTime.dat_Flags     = 0;
DateTime.dat_StrDay    = NULL;
DateTime.dat_StrDate   = Date;
DateTime.dat_StrTime   = Time;

DateTime.dat_Stamp=dlp->ds;
DateToStr(&DateTime);

Time[5]=0;

/* 2.5b7 rri */

memset(ptr,' ',300); /* 2.5b10 rri */

/* 2.5RC10 rri */
if(dlp->dir==3) /* set display-format for cmd-windows fixed to 'N' */
 {
  digit[0]='N';
  digit[1]=0;
  dptr=digit;
 }

while(*dptr&&(ptr-sbuff<150))
 {
  switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b7 rri */
   {
    case 'N': if(dlp->name) /* 2.5RC8 rri */
               {
                ptr2=dlp->name;
                ptr3=ptr;
                if(ptr2) while(*ptr2) *ptr3++ = *ptr2++;
                ptr+=dw->ColsName;
               }
              break;

    case 'C': /* if(dlp->dir==3) break; */ /* impossible - removed 2.5RC10 rri */
              if(dlp->dir==2)
               {
                ptr3=ptr+2;
                ptr2=0;
                if(dlp->attr==DLT_DEVICE) ptr2="(DEV)";
                else if(dlp->attr==DLT_VOLUME) ptr2="(VOL)";
                else if(dlp->attr==DLT_DIRECTORY) ptr2="(ASN)";
                dw->ColsCmt=7; /* 2.5RC7 rri */
               }
              else
               {
                ptr2=dlp->cmt;
                ptr3=ptr;
               }
              if(ptr2) while(*ptr2) *ptr3++ = *ptr2++;
              ptr+=dw->ColsCmt&0xFFF; /* 2.5RC7 rri */
              break;

    case 'S': if(dlp->dir>1) break;
              value=winbase.BlocksFree=dlp->size;
              ai=(dw->ColsCmt>>12)-1;
              sprintf(digit,"%%%lds",ai+1);

              if(dlp->dir==1) /* 2.5RC8 rri */
               {
                if(dlp->size)
                 {
                  winbase.BytesPerBlock=dw->BytesPerBlock; /* 2.5RC7 rri */
                  ConvertBase(&winbase);
                  sprintf(ptr,digit,winbase.String); /* 2.5RC7 rri */
                 }
               }
              else
               {
                if(sizes==2) /* 2.5RC8 rri */
                 {
                  winbase.BytesPerBlock=1;
                  ConvertBase(&winbase);
                  sprintf(ptr,digit,winbase.String);
                 }
                else /* sizes==1 / sizes==3 */ /* 2.5RC8 rri */
                 {
                  c=0;
                  for(;ai>=0;ai--)
                   {
                    if(sizes==3&&c==3)
                     {
                      ptr[ai]=separator; /* insert separator every three chars */
                      c=0;
                      continue;
                     }
                    ptr[ai]=(value % 10)+0x30; /* add current digit */
                    value=value/10;
                    if(value==0) break;
                    c++;
                   }
                 }
               }
              ptr+=(dw->ColsCmt>>12); /* 2.5RC8 rri */
              break;

    case 'T': if(dlp->dir<2)
               {
                ptr2=Time;
                ptr3=ptr;
                while(*ptr2) *ptr3++ = *ptr2++;
                ptr+=5;
               }
              break;

    case 'D': if(dlp->dir<2)
               {
                ptr[0]=Date[strlen(Date)-2]; /* 2.5b13 rri */
                ptr[1]=Date[strlen(Date)-1]; /* 2.5b13 rri */
                ptr+=2;
               }
              break;

    case 'M': if(dlp->dir<2)
               {
                ptr[0]=Date[3];
                ptr[1]=Date[4];
                ptr[2]=Date[5];
                if(long_month) /* 2.5b13 rri */
                 {
                  if(Date[6]!='-') ptr[3]=Date[6];
                  ptr++;
                 }
                ptr+=3;
               }
              break;

    case 'Y': if(dlp->dir<2)
               {
                ptr[0]=Date[0]; /* 2.5b10 rri */
                ptr[1]=Date[1]; /* 2.5b10 rri */
                ptr+=2;
               }
              break;

    case 'A': if(dlp->dir<2)
               {
                StampProt(ptr,dlp->attr);
                ptr+=8;
                *ptr=' '; /* 2.5RC10 rri */
               }
              break;

    default : if(dlp->dir<2) *ptr++=c;
   }
 }
*ptr=' '; /* 2.5RC6 rri */
dw->Collums=(ptr-sbuff)+1; /* 2.5RC7 rri */
}


void QueryDosList(struct DirWindow *dw, struct DosList *doslist,int type) /* 2.5b12 rri */
{
struct DirList **dl,*dlp;
ULONG l,fl;

dl=dw->DirList;

l=LENGTH(doslist->dol_Name);

/* 2.5b12 jjt */
for (fl=0; fl < DevHide_Count; fl++)
 {
  /* --- Is this dev one the user wants to hide? --- */
  if (strlen(DevHide_List[fl]) == l)
   {
    if((Strnicmp(STRING(doslist->dol_Name),DevHide_List[fl],(LONG)l))==0) break;
   }
 }

if (fl == DevHide_Count)
 {
  if(!AllocDlp(dw)) return;
  dlp=dl[dw->FileCount++];
  dlp->dir=2;
  dlp->attr=type;
  if((dlp->name=PoolAllocVec(NamePool,(ULONG)(l+2))))
   {
    sprintf(dlp->name,"%s:",STRING(doslist->dol_Name)); /* 2.5.23 gcc rri */
   }
 }
}


void GetDevList(struct DirWindow *dw) /* 2.5b12 rri */
{
struct DosList *doslist;
struct DirList **dl;
ULONG x;

dl=dw->DirList;

if (ShowDev & SHOWDEV_DEV)
 {
  doslist = LockDosList(LDF_DEVICES|LDF_READ);
  while((doslist = NextDosEntry(doslist,LDF_DEVICES))) /* 2.5.23 gcc rri */
   {
    if(doslist->dol_Task)
     {
      QueryDosList(dw,doslist,DLT_DEVICE);
     }
   }
  UnLockDosList(LDF_DEVICES|LDF_READ);
  DMSortN(dl,dw->FileCount,0);
 }

x=dw->FileCount;

if (ShowDev & SHOWDEV_VOL)
 {
  doslist = LockDosList(LDF_VOLUMES|LDF_READ);
  while((doslist = NextDosEntry(doslist,LDF_VOLUMES))) /* 2.5.23 gcc rri */
   {
    QueryDosList(dw,doslist,DLT_VOLUME);
   }
  UnLockDosList(LDF_VOLUMES|LDF_READ);
  dl = &dw->DirList[x];
  DMSortN(dl,dw->FileCount-x,0);
 }

x=dw->FileCount;

if (ShowDev & SHOWDEV_ASN)
 {
  doslist = LockDosList(LDF_ASSIGNS|LDF_READ);
  while((doslist = NextDosEntry(doslist,LDF_ASSIGNS))) /* 2.5.23 gcc rri */
   {
    if(doslist->dol_Type==DLT_DIRECTORY)
     {
      QueryDosList(dw,doslist,DLT_DIRECTORY);
     }
   }
  UnLockDosList(LDF_ASSIGNS|LDF_READ);
  dl = &dw->DirList[x];
  DMSortN(dl,dw->FileCount-x,0);
 }

CloneBuffer(dw,0); /* 2.5RC6 rri */

NewSize(dw);
RefreshGadget(&dw->dir_gad,dw->Window); /* 2.5b7 rri */
}


/* --------------------------- DIRECTORY LOAD --------------------------------- */

void GetDirEntry(struct DirWindow *dw)
{
struct DirList  *dlp;
sFIB *fib=dw->Fib;
int i;

if((dw->Flags&DWFLAG_RELOAD)&&!dw->DirLock)
 {
  InitDir(dw,0);
  return;
 }

if(!dw->DirLock||!fib) return;

i=ExNext(dw->DirLock,fib);

if(i&&dw->Pattern[0]&&fib->fib_DirEntryType<0) /* 2.5RC6 rri */
 {
  if(!DMMatch(fib->fib_FileName,dw->Pattern)) return;
 }

if(!i||!AllocDlp(dw))
 {
  ExDone(dw);
  return;
 }
dlp=dw->DirList[dw->FileCount++];

/* soft-link detection - 2.5.28 rri */
if(fib->fib_DirEntryType==3)
 {
  BPTR lock;
  struct FileInfoBlock *info;
  
  strcpy(sbuff,dw->Path);
  AddPart(sbuff,fib->fib_FileName,4000);

  if((lock=Lock(sbuff,ACCESS_READ)))
   {
    if((info=AllocDosObject(DOS_FIB,TAG_DONE) ))
     {
      if(Examine(lock,info))
       {
        fib->fib_DirEntryType = info->fib_DirEntryType;
       }
      FreeDosObject(DOS_FIB,info);
     }
    UnLock(lock);
   }
 }
Fib2Dlp(dlp,fib);
}


void InitDir(struct DirWindow *dw,int set)
{
BPTR lock; /* 2.5b13 rri */

FreeDirTable(dw);
dw->Flags&=~0xF;
dw->Collums=0; /* 2.5RC7 rri */
SetHoriz(dw); /* 2.5RC5 rri */
dw->Index=0; /* 2.5RC3 rri */
SetVert(dw); /* 2.5RC4 rri */

if(!dw->Fib)
 {
  if(!(dw->Fib=AllocDosObject(DOS_FIB,TAG_DONE) )) /* 2.5.28 rri */
   {
    return;
   }
 }

Busy(1); /* 2.5b7 rri */

if(dw->Path[0])
 {
  while (dw->Path[strlen(dw->Path)-1] == '/') /* 2.5b9 rri */
   {
    dw->Path[strlen(dw->Path)-1]=0;
   }
  RefreshGadget(&dw->dir_gad,dw->Window);
  if (dw != CmdWin) StrHist_Add(&PathHistory, dw->Path); /* Cache path */  /* 2.5b10 jjt */
  if((lock=Lock(dw->Path,ACCESS_READ))) /* 2.5.23 gcc rri */
   {
    if(FLAGS&DMFLAG_EXPAND) /* 2.5RC2 rri */
     {
      NameFromLock(lock, sbuff, 4096); /* 2.5RC6 rri */
      CloneBuffer(dw,sbuff); /* 2.5RC6 rri */
     }
    UnLock(lock);
    if(!DiskShadow(dw,dw->Fib)) goto Q;
    RefreshGadget(&dw->dir_gad,dw->Window);
    NewSize(dw);
   }
 }

if(set)
 {
  /* 2.5.24 rri */
  if(Strap) PoolFreeVec(Strap);
  Strap=CloneStr(dw->Path,NamePool);
  goto Q;
 }

if(dw->DirLock&&Notify) /* 2.5b9 rri */
 {
  dw->DM2NotifyReq.nr_Name = dw->Path;
  if (StartNotify(&dw->DM2NotifyReq))
   {
    dw->DM2NotifyReq.nr_UserData=1; /* 2.5RC6 rri */
   }
 }

if(!dw->DirLock&&dw!=CmdWin) /* 2.5b9 rri */
 {
  GetDevList(dw);
 }
else if(dw->Fib->fib_DirEntryType<0&&dw==CmdWin)
      {
       GetCmdFile(dw,dw->Path,dw->Fib->fib_Size);
       Busy(0); /* 2.5b9 rri */
       return;
      }
else if(!CacheLoad(dw))
      {
       lockcount++;
       Busy(0); /* 2.5b7 rri */
       return;
      }

Q:

if(dw->DirLock)
 {
  UnLock(dw->DirLock);
  dw->DirLock=0;
 }

FreeDosObject(DOS_FIB,dw->Fib); /* 2.5.28 rri */
dw->Fib=0;
Busy(0); /* 2.5b7 rri */
}


int AllocDlp(struct DirWindow *dw)
{
struct DirList **dl=dw->DirList;
ULONG size; /* 2.5b10 rri */

if(dw->FileCount>=dw->MaxFile) /* no entry left in table */
 {
  /* allocate new dir-entries table with room for 500 entries more */

  size=dw->MaxFile<<2;
  if(!(dl=AllocMem(size+2000,MEMF_ANY | MEMF_CLEAR))) return(0); /* 2.5.28 rri */
  CopyMem(dw->DirList,dl,size); /* 2.5RC9 rri */
  FreeMem(dw->DirList,size);
  dw->DirList=dl;
  dw->MaxFile+=500;
 }

/* allocate new dir-entry */
if((dl[dw->FileCount]=(struct DirList *) PoolAllocVec(StringPool,sizeof(struct DirList)))) /* 2.5.23 gcc rri */
 {
  return 1;
 }
else return 0;
}


int GetNewPath(struct DirWindow *dw)
{
UBYTE *ptr,*ptr2;

if(FLAGS&DMFLAG_DCLICK&&DClickDir) /* 2.5RC6 rri */
 {
  if(DestWin&&DestWin!=dw&&LastI>=0&&DClickDir->sel)
   {
    DClickDir->sel=0;
    dis_name(DestWin,LastI+DestWin->Index,(LONG) LastI); /* 2.5b10 rri */
   }
  dw->h_prop.HorizPot=0;
  dw->v_prop.VertPot=0;
  LastI = -1;
  dw->Index=0;
  dw->Edge=0; /* DefaultEdge; - 2.5RC3 rri this was never ever initialised! */
  if(OldDir!=333&&DirWin[OldDir]&&DirWin[OldDir]->Path) strcpy(sbuff,DirWin[OldDir]->Path); /* 2.5RC7 rri */
  else sbuff[0]=0;
  ptr=sbuff+strlen(sbuff)-1; /* 2.5RC6 rri */
  ptr2=DClickDir->name;

  if (*ptr=='/')
   {
    *ptr=0;
    ptr--;
   }
  if(*ptr&&*(ptr2+strlen(ptr2)-1)!=':')
   {
    if(*ptr++!=':')
     {
      *ptr++='/';
      *ptr=0;
     }
   }
  else
   {
    ptr=sbuff;
   }

  strcpy(ptr,DClickDir->name);

  CloneBuffer(dw,sbuff); /* 2.5RC6 rri */

  FLAGS&=~DMFLAG_DCLICK; /* 2.5RC2 rri */
  DClickDir=0;
  InitDir(dw,0);
  return(1);
 }
return(0);
}


int DiskShadow(struct DirWindow *dw,sFIB *fib)
{
struct DateStamp *ds1,*ds2;
BPTR lock; /* 2.5b6 rri */

dw->DiskFree=0;
if(!dw->Path[0]) return(1);
if(!(lock=Lock(dw->Path,ACCESS_READ))) return(1);

Info(lock,&InfoData);

dw->BytesPerBlock=InfoData.id_BytesPerBlock; /* 2.5b5 rri */

dw->DirLock=lock;
if(!Examine(lock,fib)) return(0);

/* init struct DateStamp in struct DirWindow */

ds1 = &dw->PathDate;
ds2 = &fib->fib_Date;
ds1->ds_Days=ds2->ds_Days;
ds1->ds_Minute=ds2->ds_Minute;
ds1->ds_Tick=ds2->ds_Tick;

return(1);
}


int CacheLoad(struct DirWindow *dw)
{
struct DirWindow *dw2;
struct DirList **dl,**dl2,*dlp,*dlp2;
LONG i; /* 2.5.23 rri */

dw2=0; /* 2.5b10 rri */

/* look for a dir-window with the same path */
for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw2=DirWin[i];
  if(dw2&&dw!=dw2&&!strcmp(dw->Path,dw2->Path)) break;
 }

/* if there is no window with the same path leave the function */
if(i==DMMAXWINDOWS||!dw2||!dw2->FileCount) return(0); /* 2.5.23 rri */

ReSort();

if(dw2->DirLock||dw2->Flags&DWFLAG_RELOAD)
 {
  dw->Flags|=DWFLAG_RELOAD;
  return(0);
 }

dl2=dw2->DirList;

for(i=0;i<dw2->FileCount;i++)
 {
  dlp2=dl2[i];
  if(dw->Pattern[0])
   {
    if(dlp2->name&&!dlp2->dir) /* 2.5RC6 rri */
     {
      if(!DMMatch(dlp2->name,dw->Pattern)) continue;
     }
   }
  if(!AllocDlp(dw)) return(1);
  dl=dw->DirList;
  dlp=dl[dw->FileCount++];
  dlp->size=dlp2->size;
  dlp->attr=dlp2->attr;
  dlp->ds.ds_Days=dlp2->ds.ds_Days;
  dlp->ds.ds_Minute=dlp2->ds.ds_Minute;
  dlp->ds.ds_Tick=dlp2->ds.ds_Tick;
  dlp->dir=dlp2->dir;
  dlp->name = CloneStr(dlp2->name, NamePool); /* 2.5b10 rri */
  dlp->cmt = CloneStr(dlp2->cmt, CommentPool); /* 2.5b10 rri */
 }

DMSort(dw);
NewSize(dw);
return(1);
}


void ExDone(struct DirWindow *dw)
{
struct DirWindow *dw2;
LONG i; /* 2.5.23 rri */

UnLock(dw->DirLock);
dw->DirLock=0;
FreeDosObject(DOS_FIB,dw->Fib); /* 2.5.28 rri */
dw->Fib=0;
if(lockcount) lockcount--;
DMSort(dw);
NewSize(dw);
for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw2=DirWin[i];
  if(dw2&&(dw2->Flags&DWFLAG_RELOAD)&&!strcmp(dw->Path,dw2->Path))
   {
    dw2->Flags&=~DWFLAG_RELOAD;
   }
 }
}


void Fib2Dlp(struct DirList *dlp,sFIB *fib)
{
dlp->size=fib->fib_Size;
dlp->attr=fib->fib_Protection;
dlp->ds.ds_Days=fib->fib_Date.ds_Days;
dlp->ds.ds_Minute=fib->fib_Date.ds_Minute;
dlp->ds.ds_Tick=fib->fib_Date.ds_Tick;
dlp->name = CloneStr(fib->fib_FileName, NamePool); /* 2.5b10 rri */
dlp->cmt = CloneStr(fib->fib_Comment, CommentPool); /* 2.5b10 rri */
dlp->dir = (fib->fib_DirEntryType>=0) ? 1 : 0; /* 2.5.28 rri */
}


void FreeDirTable(struct DirWindow *dw)
{
struct DirList **dl=dw->DirList;
int i;

if(dw->DirLock)
 {
  UnLock(dw->DirLock);
  dw->DirLock=0;
  if(lockcount) lockcount--;
 }

for(i=0;i<dw->FileCount;i++)
 {
  if(dl[i]->cmt)
   {
    PoolFreeVec(dl[i]->cmt); /* 2.5b10 rri */
   }
  if(dl[i]->name)
   {
    PoolFreeVec(dl[i]->name); /* 2.5b10 rri */
   }
  PoolFreeVec(dl[i]); /* 2.5RC10 rri */
 }
dw->FileCount=0;

if(dw->DM2NotifyReq.nr_UserData) /* 2.5RC6 rri */
 {
  EndNotify(&dw->DM2NotifyReq);
  dw->DM2NotifyReq.nr_UserData=0; /* 2.5RC6 rri */
 }
}
