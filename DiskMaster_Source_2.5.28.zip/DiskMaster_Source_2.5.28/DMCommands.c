/* DiskMaster2 general commands module
**
** 2.5RC8
**
** 03-01-04 rri - Added "separator=" & "sizes=" options to 'SetX'
**
** 03-01-05 rri - Reworked 'SetX' slightly.
**
** 2.5RC9
**
** 03-01-21 rri - Bugfix: ParseCmd1() accepted 0-G instead of 0-F...
**              - Replaced two atol() calls by StrToLong() calls.
**
** 03-01-25 rri - Replaced some strcat() calls by DMstrcat() calls.
**              - Replaced one memmove() cally by a CopyMem() call.
**
** 2.5RC10
**
** 03-02-28 rri - Changed a call to ActionCmd() in GetCmdFile()
**              - Removed some "new! ..." style comments.
**              - Increased stack for external archiver in 'Archive'
**                to 8192 bytes - just to play on the safe side...
**
** 03-03-01 rri - Little optimisation in GetCmdFile()
**
** 03-03-02 rri - Raised DOSPassStr[] to 4096 bytes to meet extended requirements.
**
** 03-03-07 rri - Corrected definition of Pens20[].
**
** 03-03-15 rri - Added DMLayoutMenus() calls to GetCmdFile() and CMD_Font().
**              - Bugfix: 'Font' without argument caused an enforcer-hit.
**
** 03-03-29 rri - Lowered min-value for digits in DMSet() to 3 as requested
**                by Jody Tierney.
**
** 03-04-11 rri - Various little changes in DMSet() for UserColors...
**
** 03-04-12 rri - Modified AddAutoCmd() to use pooled memory.
**
** 03-04-19 rri - Bugfix: 'ReqPattern' could face a buffer-overflow.
**
** 03-04-21 rri - Replaced a MakeFullName() call in AutoFiler() by
**                a strcpy() plus AddPart() call.
**
** 03-04-23 rri - Replaced one ParseArgs() call with a SplitLine() call.
**
** 03-04-24 rri - Simplified AddAutoCmd() - it is always fed with a
**                single command-line now...
**              - Removed end-of-line check from ParseCmd1().
**              - Added an AddPort() to GetCmdFile() as FreeUserData()
**                does a RemPort() now.
**
** 03-04-26 rri - Had to increase min-value for digits in 'SetX' to 4 as the
**                display is wrong for files beyond "999 M". The alternative would
**                be to add a new stage to the conversion function for "1 G" but
**                this would also require a new set of catalogs...
**
** 2.5.23
**
** 03-05-18 rri - Fix: changed "if(1>sizes>3)" in DMSet() to if(sizes<1||sizes>3)
**              - Added a few double-brackets to assignments to avoid
**                warnings with GCC.
**
** 03-05-30 rri - Changed type of "digits" and "Notify" from int to LONG.
**              - Changed type of "Base_Str_Len" from ULONG to LONG.
**              - Fixed a few warnings from GCC.
**              - Introduced DMMAXWINDOWS.
**
** 2.5.24
**
** 03-07-27 rri - Bugfix: 'ChgCmd' had a problem with empty commands.
**
** 03-07-28 rri - Added a file-requester to GetCmdFile().
**
** 03-08-01 rri - Added devx and devy to 'SetX'.
**
** 03-08-02 rri - Renamed devx / devy to defx / defy...
**
** 03-08-03 rri - Changed type of defx / defy to ULONG.
**
** 2.5.26
**
** 03-08-10 rri - Bugfix: changing the dir-gadgets font did not refresh it.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC4)
**
** 03-08-16 rri - Bugfix: 'Swap' also switched the window-attributes and failed
**                        to do so with NOCLOSE -> almost completely rewritten.
**                        Thanks for reporting to Glenn Edward <glenn_edw@email.com>!
**
** 03-09-21 rri - Bugfix: Defining an empty string with "SetX AppIcon=" caused an
**                        enforcer-hit.
**                        
** 03-09-29 rri - Removed some test-lines.
**              - Replaced one DMReq() call by a DMReqTagList() call.
**
** 03-10-01 rri - Removed the "test!" status from the DMReqTagList() stuff.
**
** 2.5.27
**
** 03-10-25 rri - Modified one DMFileReq() call.
**
** 2.5.28
**
** 04-01-03 rri - Replaced one MEMF_PUBLIC with a MEMF_ANY.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC8)
**
*/


#include "DM.h"


extern struct DirWindow  *CDWin,*CmdWin,*DestWin,*DirWin[];
extern struct DirList    *WorkDlp;
extern struct Screen     *Screen,*MyScreen;
extern struct TextFont   *DMFonts[];  /* 2.5RC2 jjt */
extern struct TextAttr   Menu_TAttr, FuckingTopaz;  /* 2.5RC2 jjt */
extern struct MsgPort    *WinPort; /* 2.5RC10 rri */

extern UBYTE
             *ActionArgs[],
             ActionBuf[],
             DMname[],
             *Globuff,
             g_buttons[],  /* 2.5b10 jjt */
             PGadStr[],
             sbuff[],
             sPath[],
             *Strap; /* 2.5.24 rri */


extern WORD  zooming[]; /* 2.5b13 rri */

extern UWORD Pens20[]; /* 2.5RC10 rri */

extern LONG  BackPen, /* 2.5b12 rri */
             Base_Str_Len, /* 2.5.23 rri */
             Bar_Height, /* 2.5b13 rri */
             DirPen, /* 2.5b12 rri */
             FilePen, /* 2.5b12 rri */
             IconX,
             IconY,
             separator, sizes, /* 2.5RC8 rri */
             SelectPen; /* 2.5b12 rri */

extern ULONG DWNum,
             FLAGS, /* 2.5RC2 rri */
             Screen_Height, /* 2.5b13 rri */
             Screen_Width, /* 2.5b13 rri */
             ShowDev, /* 2.5b12 jjt */
             UserColors; /* 2.5b11 rri */

extern APTR StringPool; /* 2.5b12 jjt */
extern APTR NamePool; /* 2.5.24 rri */



BPTR StdIO;

UBYTE
      *AppIconPath, /* 2.5b13 rri */
      *AutoCmdStr[255], /* 2.5RC6 rri */
      dcPath[4096], /* 2.5RC6 rri */
      DOSPassStr[4096], /* 2.5RC10 rri */
      Pattern[64], /* 2.5RC4 rri */
      ReqStr[700],
      *DevHide_List[DEVHIDELIST_MAX],  /* 2.5b12 jjt*/
      FontKeywords[][15]={"DIRWIN", "DIRGAD", "REQTEXT", "REQBUTTONS", "MENU",
                          "Screen", "Fixed-Width", "Proportional"};  /* 2.5RC2 jjt */

LONG digits=5, /* 2.5.23 rri */
     Notify=0; /* 2.5.23 rri */

ULONG defx=0, defy=0, /* 2.5.24 rri */
      DevHide_Count = 0;  /* 2.5b12 jjt */

sFIB Fib;


void DoStdio(UBYTE *str)
{

if(StdIO)
 {
  Close(StdIO);
  StdIO=0;
 }

if(Stricmp(str,"CLOSE")==0) return; /* 2.5b7 rri */

if(MyScreen)
 {
  DMstrcat(str,"/SCREEN"); /* 2.5RC9 rri */
  DMstrcat(str,DMname); /* 2.5RC9 rri */
 }

StdIO=Open(str,MODE_OLDFILE);
}


void GetParent(UBYTE *path,int parent) /* 2.5b6 rri */
{
BPTR lockcurrent,lockresult;
UBYTE *ptr=path+strlen(path);

for(;ptr>=path;ptr--)
 {
  if(*ptr==':')
   {
    ptr++;
    if(*ptr) /*  path was root+1 dir */
     {
      *ptr=0;
      break;
     }
    else /* path already was root */
     {
      if((lockcurrent=Lock(path,ACCESS_READ))) /* 2.5.23 gcc rri */
       {
        lockresult=ParentDir(lockcurrent);
        UnLock(lockcurrent);
        if (lockresult)
         {
          NameFromLock(lockresult,path,512);
          UnLock(lockresult);
          ptr=path+strlen(path)-1; /* 2.5b7 rri */
          if((*ptr==':')||parent) /* 2.5b9 rri */
           {
            break;
           }
         }
        else if (!lockresult&&(IoErr()==0))
         {
          path[0]=0;
          break;
         }
       }
      else /* path not valid anymore */ /* 2.5b13 rri */
       {
        path[0]=0;
        break;
       }
     }
   }
  if(parent&&*ptr=='/') /* if !parent the loop will run `till root */
   {
    *ptr=0;
    break;
   }
 }
}


void DMArchive(UBYTE *cmd,UBYTE *name)
{
struct DirList **dl,*dlp;
UBYTE   *ptr=DOSPassStr; /* 2.5b9 rri */
BPTR lock; /* 2.5b5 rri */
int     i=0,cnt=0,q;

if(!CDWin) return;
if(!name||*name==0)
 {
  name=dcPath;
  strcpy(name,CDWin->Path);
  if(*(name+strlen(name)-1)!=':' && *(name+strlen(name)-1)!='/') DMstrcat(name,"/"); /* 2.5RC9 rri */
  if(!DMReqTagList(msgReqArchive, name, 512, 0)) return;  /* 2.5b13 rri */
 }
dl=CDWin->DirList;

NEXT:

DOSPassStr[0]=0;
*ptr=0; /* 2.5b9 rri */
strcpy(ptr,cmd); /* 2.5b9 rri */
DMstrcat(ptr," "); /* 2.5RC9 rri */
QuoteCat(ptr,name);

while(i<CDWin->FileCount)
 {
  dlp=dl[i++];
  if(dlp&&dlp->sel==1)
   {
    dlp->sel=0;
    cnt++;
    DMstrcat(ptr," "); /* 2.5RC9 rri */
    q=NeedQuote(dlp->name);
    if(q) DMstrcat(ptr,"\""); /* 2.5RC9 rri */
    DMstrcat(ptr,dlp->name); /* 2.5RC9 rri */
    if(q) DMstrcat(ptr,"\""); /* 2.5RC9 rri */
    if(strlen(ptr)>=224||cnt>=30)
     {
      dis_files(CDWin);
      WinTitle(CDWin);
      DOSStart(8192); /* 2.5RC10 rri */
      cnt=0;
      goto NEXT;
     }
   }
 }
if(cnt)
 {
  dis_files(CDWin);
  WinTitle(CDWin);
  DOSStart(8192); /* 2.5RC10 rri */
 }
if((lock=Lock(name,ACCESS_READ))) /* 2.5.23 gcc rri */
 {
  UnLock(lock);
  SmartAddEntry(name);
 }
}


void DMSelect(int sel)
{
struct DirList **dl,*dlp;
int i,c=1,comment;

FLAGS|=DMFLAG_PATREQ; /* 2.5RC2 rri */

if((comment=GetActionArg("COMMENT", AATYPE_BOOL, 0))) /* 2.5.23 gcc rri */
 {
  ActionArgs[comment]=0;
 }

if(!ActionArgs[1])
 {
  ActionArgs[1]=sbuff;
  sbuff[0]='*';
  sbuff[1]=0;
  if(!DMReqTagList(msgReqSelect, sbuff, 31, 0)) return;  /* 2.5b13 rri */
 }
if(!CDWin) return;

while (ActionArgs[c])
 {
  dl=CDWin->DirList;
  for(i=0;i<CDWin->FileCount;i++)
   {
    dlp=dl[i];
    if(comment) /* 2.5b13 rri */
     {
      if(DMMatch(dlp->cmt,ActionArgs[c])) dlp->sel=sel;
     }
    else if(DMMatch(dlp->name,ActionArgs[c])) dlp->sel=sel;
   }
  c++;
 }
dis_files(CDWin);
WinTitle(CDWin);
}


void DMReqPat()
{
struct TagItem patreqtags[]={{DMREQ_BUTTONS,(ULONG) g_buttons},{DMREQ_ABORT,0},{TAG_END,0}}; /* 2.5.26 rri */

if(FLAGS&DMFLAG_PATREQ) return; /* 2.5RC2 rri */
if(WorkDlp&&!WorkDlp->dir) return;
if(ActionArgs[2]) DMstrncpy(Pattern,ActionArgs[2],63); /* 2.5RC10 rri */
/* if(ActionArgs[2]) strcpy(Pattern,ActionArgs[2]);*/ /* danger of overflow! */

if(!ActionArgs[1]) /* 2.5b13 rri */
 {
  strcpy(ReqStr,msgReqPattern);
  ActionArgs[1]=ReqStr;
 }
if(!ActionArgs[5]) /* 2.5b13 rri */
 {
  strcpy(sbuff,msgGadSkip);
  ActionArgs[5]=sbuff;
 }

MakeBtnString(ActionArgs[3], ActionArgs[5], ActionArgs[4]);  /* 2.5b10 jjt */

if(DMReqTagList(ActionArgs[1], Pattern, 63, patreqtags) == 1) /* 2.5.26 rri */
 {
  FLAGS|=DMFLAG_PATREQ; /* 2.5RC2 rri */
 }
}


void AddAutoCmd(UBYTE *str) /* 2.5RC10 rri */
{
ULONG i=0;

if(*str==0)
 {
  sbuff[0]=0;
  if(!DMReqTagList(msgReqAddAuto, sbuff, 512, 0)) return;  /* 2.5b13 rri */
  str=sbuff;
 }

while(AutoCmdStr[i]) i++; /* find next free autocmd */

if(Strnicmp(str,"TEXT",4)==0) i=253; /* 2.5b7 rri */
if(Strnicmp(str,"DEFAULT",7)==0) i=254; /* 2.5b7 rri */

if(AutoCmdStr[i])
 {
  PoolFreeVec(AutoCmdStr[i]); /* 2.5RC10 rri */
  AutoCmdStr[i]=0;
 }

if(i<255&&!AutoCmdStr[i]) /* 2.5RC6 rri */
 {
  AutoCmdStr[i] = CloneStr(str,StringPool); /* 2.5RC10 rri */
 }
}


void AddCmd(struct DirWindow *dw,UBYTE *buf)
{
struct DirList **dl,*dlp;
int x; /* 2.5b13 rri */

if(!dw)
 {
 /* 2.5b13 rri */
  x=Screen_Width/5;
  zooming[0]=x*2;
  zooming[1]=Bar_Height+1;
  zooming[2]=65;
  zooming[3]=65;
  OpenDirWindow("CMD",x*2,(int) Bar_Height+1,x,(int) Screen_Height);

  dw=CmdWin;
 }
if(!dw) return;

if(!buf||*buf==0)
 {
  buf=ActionBuf;
  *buf=0;
  if(!DMReqTagList(msgReqCmd, buf, 512, 0)) return; /* 2.5b13 rri */
 }
if(!(dw->Flags&(DWFLAG_ADD|DW_CMD))) FreeDirTable(dw);
if(!AllocDlp(dw)) return;
dw->Flags=DW_CMD;
dl=dw->DirList;
dlp=dl[dw->FileCount++];
ParseCmd1(dlp,buf);
dw->Flags|=DWFLAG_ADD;
}


void EditCmd(struct DirWindow *dw,int ni)
{
struct DirList **dl=dw->DirList,*dlp=dl[ni];
UBYTE *ptr=dlp->cmt;

FLAGS&=~DMFLAG_CHGCMD; /* 2.5RC2 rri */

if(dlp->name) /* 2.5.24 rri */
 {
  sprintf(ActionBuf,"%s, %lx%lx, %lx%lx, %s",
               dlp->name,dlp->attr&0xf,(dlp->attr>>4)&0xf,
               (dlp->attr>>8)&0xf,(dlp->attr>>12)&0xf,ptr); /* 2.5b12 rri */
 }
else *ActionBuf=0;

if(!DMReqTagList(msgReqCmd, ActionBuf, 512, 0)) return;  /* 2.5b13 rri */
if(ptr)
 {
  PoolFreeVec(dlp->cmt); /* 2.5b10 rri */
 }
dlp->cmt=0;
ParseCmd1(dlp,ActionBuf);
}


void dwcopy(struct DirWindow *source,struct DirWindow *dest) /* 2.5.26 rri */
{
ULONG c;

dest->PathDate     = source->PathDate;
dest->DirList      = source->DirList;
dest->Fib          = source->Fib;
dest->DM2NotifyReq = source->DM2NotifyReq;
dest->SExt         = source->SExt;
dest->dir_str      = source->dir_str;
dest->dir_gad.SpecialInfo=(APTR)&dest->dir_str;
dest->MaxFile      = source->MaxFile;
dest->FileCount    = source->FileCount;
dest->Sels         = source->Sels;
dest->Path         = source->Path;
for(c=0;c<32;c++)
 {
  dest->Pattern[c] = source->Pattern[c];
 }
dest->DirLock      = source->DirLock;
}

void DoSwap()
{
LONG wincounter; /* 2.5RC6 rri */
struct DirWindow *dwsource=CDWin;
struct DirWindow *dwdest=DestWin;
struct DirWindow *winbuffer;

if(!dwsource||!dwdest) return;

if (ActionArgs[1])
 {
  StrToLong(ActionArgs[1],&wincounter); /* 2.5RC9 rri */
  if(DirWin[wincounter]&&!(DirWin[wincounter]->Flags&DW_CMD)&&!(DirWin[wincounter]==CDWin))
  {
   dwdest=DirWin[wincounter];
  }
 }

/* 2.5.26 rri */
if((winbuffer=AllocMem(sizeof (*winbuffer),MEMF_ANY | MEMF_CLEAR))) /* 2.5.28 rri */
 {
  CopyMem(dwsource,winbuffer,sizeof (*winbuffer));
  dwcopy(dwdest,dwsource);
  dwcopy(winbuffer,dwdest);
  RefreshGadget(&dwsource->dir_gad,dwsource->Window);
  RefreshGadget(&dwdest->dir_gad,dwdest->Window);
  FreeMem(winbuffer,sizeof(*winbuffer));
 }

if(dwsource->Path[0]==0)
 {
  FreeDirTable(dwsource);
  GetDevList(dwsource);
 }
else dwsource->Flags|=DWFLAG_RESORT; /* set re-sort flag */

if(dwdest->Path[0]==0)
 {
  FreeDirTable(dwdest);
  GetDevList(dwdest);
 }
else dwdest->Flags|=DWFLAG_RESORT;

ReSort();
}


int UnLockAll()
{
struct DirWindow *dw;
int i;

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&(dw->Flags&(DW_DEST|DW_SOURCE)))
   {
    dw->Flags&=~(DW_DEST|DW_SOURCE);
    ShowDirection(dw,4);
   }
 }
ShowDirection(CDWin,0);
ShowDirection(DestWin,1);
return(0);
}


void ResetFlags()
{
FLAGS&=~(DMFLAG_ABORT | /* 2.5RC2 */
         DMFLAG_ATTR |
         DMFLAG_AUTOFILING |
         DMFLAG_CONFIRM |
         DMFLAG_LOOP |
         DMFLAG_PATREQ |
         DMFLAG_QUIET |
         DMFLAG_REC |
         DMFLAG_RESORT |
         DMFLAG_SINGLE |
         DMFLAG_UNMARK |
         DMFLAG_WINTITLE );

FLAGS|=DMFLAG_TESTWARN; /* 2.5RC2 jjt */

 Pattern[0]='*';
 Pattern[1]=0;
}


void GetCmdFile(struct DirWindow *dw,UBYTE *name,LONG size)
{
sFIB *fib=(&Fib); /* 2.5b10 rri */
BPTR lock=0; /* 2.5b5 rri */

if(!name||*name==0||!(lock=Lock(name,ACCESS_READ))) /* 2.5.24 rri */
 {
  name=DMFileReq(Strap,0,FALSE); /* 2.5.27 rri */
  if(*name)
   {
    if(Strap) PoolFreeVec(Strap);
    if((Strap=PoolAllocVec(NamePool,(ULONG) (strlen(name)+10) )))
     {
      strcpy(Strap,name);
     }
    else
     {
      Strap=NULL;
      return;
     }
   }
  else
   {
    return;
   }
 }
if(lock) UnLock(lock);

if(size<=0)
 {
  if(!(lock=Lock(name,ACCESS_READ))) return;
  if(Examine(lock,fib)) size=fib->fib_Size;
  UnLock(lock);
 }
if(size<=0) return;

strcpy(dcPath,name); /* 2.5.24 rri */

if(!GetGlobuff()) return;

FLAGS|=DMFLAG_KEEPGLOBAL; /* 2.5RC2 rri */

if((lock=Open(dcPath,MODE_OLDFILE))) /* 2.5.23 gcc rri */
 {
  if(dw) CmdWin=dw;
  if(Read(lock,Globuff,size)>0)
   {
    FLAGS|=DMFLAG_BATCH; /* 2.5RC2 rri */
    if(CmdWin) size=CmdWin->Number; /* 2.5RC10 rri */
    else size=254; /* 2.5RC10 rri */
    ActionCmd(size,Globuff); /* 2.5RC10 rri */
    FLAGS&=~DMFLAG_BATCH; /* 2.5RC2 rri */
    DMLayoutMenus(); /* 2.5RC10 rri */
   }
  Close(lock);
 }
FLAGS&=~DMFLAG_KEEPGLOBAL; /* 2.5RC2 rri */

/* 2.5RC10 rri */
Forbid();
if(!FindPort(DMname))
 {
  AddPort(WinPort);
 }
Permit();
}


void AutoFiler(struct DirWindow *dw,UBYTE *name)
{
BPTR fh; /* 2.5b5 rri */
int i,len2,j,k,lenB; /* 2.5b7 rri */
UBYTE *ptr,*ptr2,*ptr3;

/* 2.5RC10 rri */
strcpy(sPath,CDWin->Path); /* CDWin is always valid as either an entry was */
AddPart(sPath,name,4000);  /* double-clicked or supplied by DMRecurse... */

ResetFlags();

FLAGS|=DMFLAG_AUTOFILING; /* 2.5RC2 rri */

if(!(fh=Open(sPath,MODE_OLDFILE))) return;
lenB=Read(fh,sbuff,500); /* 2.5b7 rri */
Close(fh);

for(i=0;i<lenB;i++) /* 2.5b7 rri */
 {
  if (sbuff[i]==0)
   {
    sbuff[i]=1;
   }
 }

for(i=0;i<255;i++) /* 2.5RC6 rri */
 if((ptr=AutoCmdStr[i])) /* 2.5.23 gcc rri */
  {
   ptr2=dcPath;
   len2=0;
   *ptr2=0;

   while(*ptr&&*ptr!=',')
    {
     *ptr2++ = *ptr++;
     len2++;
    }

   ptr++;
   ptr2--;

   while(len2>0&&*ptr2<=' ') /* cut-off spaces and control-chars from the end */
    {                        /* of the pattern-string */
     ptr2--;
     len2--;
    }

   ptr2++;
   *ptr2=0;

   if(len2<=0) j=1;
   else
    {
     ParsePatternNoCase(dcPath,ReqStr,500); /* 2.5b8 rri */
     if (!(j=MatchPatternNoCase(ReqStr,sbuff))) /* 2.5b8 rri */
      {
       if(Stricmp(dcPath,"TEXT")==0) /* 2.5b7 rri */
        {
         k=lenB-1; /* 2.5b7 rri */
         while(k) if(sbuff[k--]==1) break; /* 2.5b7 rri */
         if(!k) j=1;
        }
       else if(Stricmp(dcPath,"DEFAULT")==0) j=1; /* 2.5b7 rri */
      }
    }
   ptr2=dcPath;
   len2=0;
   *ptr2=0;
   ptr3=ptr;
   while(*ptr3&&*ptr3!=',') /* 2.5b9 rri */
    {
     *ptr2++ = *ptr3++;
     len2++;
    }
   if(*ptr3==',')
    {
     ptr2--;
     ptr=ptr3+1;
     while(len2>0&&*ptr2<=' ')
      {
       ptr2--;
       len2--;
      }
     ptr2++;
     *ptr2=0;
     if(len2>0&&j)
      {
       ParsePatternNoCase(dcPath,ReqStr,500); /* 2.5b9 rri */
       j=MatchPatternNoCase(ReqStr,name);
      }
    }
   if(j)
    {
     SplitLine(ptr,dw); /* 2.5R10 rri */
     if(FLAGS&DMFLAG_RESET) return; /* 2.5RC2 rri */
     break;
    }
  }

/*
if(FLAGS&DMFLAG_RESORT)
 {
  InitDir(dw,0);
  dw->Flags|=DWFLAG_RESORT;
  ReSort();
 }
*/

/* CloseRead(); */ /* 2.5b8 jjt */
ReSort();
WinTitle(CDWin);
ResetFlags();
}


void ParseCmd1(struct DirList *dlp,UBYTE *buf)
{
UBYTE cmdnamebuffer[31]; /* 2.5b10 rri */
UBYTE *ptr=cmdnamebuffer; /* 2.5b10 rri */
int i=30, c;

/*
dlp->name = name of command
dlp->dir  = 3 - special cookie
dlp->attr = colors
dlp->cmt  = command-line itself
*/

dlp->dir=3;

while(*buf&&*buf!=','&&i--) *ptr++ = *buf++; /* copy 30 chars max */ /* 2.5RC10 rri */

*ptr-- = 0;

while(*ptr==' '||*ptr==9) *ptr--=0; /* eliminate SPACE`s/TAB`s at the end */

dlp->attr=0x2002; /* 2.5b12  rri */

if(*buf==',')
 {
  buf++;

  buf=SkipWhite(buf);

/* 2.5b12 rri */
  if(buf[2]==','||buf[2]==' ') /* if only two charaters follow */
   {
    c = Char2Nibble((ULONG) *buf);
    if(c>15) c=0; /* 2.5RC9 rri */
    dlp->attr=c;
    buf++;
    c = Char2Nibble((ULONG) *buf);
    if(c>15) c=0; /* 2.5RC9 rri */
    dlp->attr = (c << 4) | dlp->attr;
    buf++;
   }

  buf=SkipWhite(buf);

  if(*buf==',')
   {
    buf++;
    buf=SkipWhite(buf);
   }

  if(buf[2]==','||buf[2]==' ') /* if only two charaters follow */
   {
    c = Char2Nibble((ULONG) *buf);
    if(c>15) c=0; /* 2.5RC9 rri */
    dlp->attr= (c << 8) | dlp->attr;
    buf++;
    c = Char2Nibble((ULONG) *buf);
    if(c>15) c=0; /* 2.5RC9 rri */
    dlp->attr = (c << 12) | dlp->attr;
    buf++;
   }
  else
   {
    dlp->attr=((dlp->attr&0x0f)<<12)|((dlp->attr&0x0f0)<<4)|dlp->attr; /* 0010 -> 0110 */
   }
/* 2.5b12 rri */

  buf=SkipWhite(buf);

  if(*buf==',')
   {
    buf++;
    buf=SkipWhite(buf);
   }

  ptr=sbuff;

  i=0;

  while(*buf>10&&i<512)
   {
    *ptr++ = *buf++;
    i++;
   }
  *ptr=0;

  dlp->name = CloneStr(cmdnamebuffer, StringPool); /* 2.5rc6 rri */

  if(i)
   {
    dlp->cmt = CloneStr(sbuff, StringPool); /* 2.5rc6 rri */
   }
 }
}


void DMSet() /* 2.5b7 rri */
{
ULONG i,c,x; /* 2.5b12 */
LONG a; /* 2.5.23 rri */

defx = GetActionArg("defx", AATYPE_NUM, 0); /* 2.5.24 rri */
defy = GetActionArg("defy", AATYPE_NUM, 0); /* 2.5.24 rri */

IconX = GetActionArg("IconX", AATYPE_NUM, NO_ICON_POSITION); /* 2.5b9 rri */
IconY = GetActionArg("IconY", AATYPE_NUM, NO_ICON_POSITION); /* 2.5b9 rri */

if (GetActionArg("notify",AATYPE_BOOL,0)) /* 2.5b9 rri */
 {
  Notify=1;
 }

if (GetActionArg("UserColors",AATYPE_BOOL,0)) /* 2.5b11 rri */
 {
  i=UserColors; /* old value */
  UserColors = GetActionArg("UserColors", AATYPE_NUM, 4);
  if (UserColors<4) UserColors=4; /* 2.5b11 rri */

  if(MyScreen&&(FLAGS&DMFLAG_USE30)) /* 2.5RC2 rri */
   {
    if(UserColors>i) /* no problem if there are now more of it */
     {
      AllocPens();
     }
    if(UserColors<i) /* whoopie, we have to free some pens... */
     {
      for(c=UserColors;c<i;c++)
       {
        x = ( 1 << ( GetBitMapAttr(MyScreen->RastPort.BitMap,BMA_DEPTH) ) ) - 1; /* 2.5RC10 rri */
        if(c==17||c==18||c==19||                          /* protect pointer */
           c==(x-Pens20[BACKGROUNDPEN]) ||  /* cursor */ /* 2.5RC10 rri */
           c==(x-Pens20[TEXTPEN])       ||  /* and cursor over text*/ /* 2.5RC10 rri */
           c==(x-Pens20[HIGHLIGHTTEXTPEN])) /* some other pen ?? */ /* 2.5RC10 rri */
         {
          continue;
         }
        /* protect the GUI-pens: */
        for(x=0;x<49;x++) /* 2.5RC10 rri */
         {
          if(c==Pens20[x])
           {
            x=42;
            break;
           }
         }
        if(x==42)
         {
          continue;
         }
        ReleasePen(Screen->ViewPort.ColorMap,c);
       }
     }
   }
 }

i=0;

if (GetActionArg("digits",AATYPE_BOOL,0))
 {
  Base_Str_Len=10; /* 2.5b9 rri */
  digits = GetActionArg("digits", AATYPE_NUM, 5);
  if (digits<4) digits=4; /* 2.5RC10 rri */
  if (digits>9) digits=9;

  for (a=1;a<digits;a++) /* 2.5.23 rri */
   {
    Base_Str_Len*=10;
   }
  Base_Str_Len--;
  i=1; /* 2.5RC8 rri */
 }
if (GetActionArg("BPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  BackPen = GetActionArg("BPen", AATYPE_NUM, (LONG) Pens20[BACKGROUNDPEN]);
  if (BackPen>28) BackPen=Pens20[BACKGROUNDPEN];
  i=1;
 }
if (GetActionArg("DPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  DirPen = GetActionArg("DPen", AATYPE_NUM, (LONG) Pens20[HIGHLIGHTTEXTPEN]);
  if (DirPen>28) DirPen=Pens20[HIGHLIGHTTEXTPEN];
  i=1;
 }
if (GetActionArg("FPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  FilePen = GetActionArg("FPen", AATYPE_NUM, (LONG) Pens20[TEXTPEN]);
  if (FilePen>28) FilePen=Pens20[TEXTPEN];
  i=1;
 }
if (GetActionArg("SPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  SelectPen = GetActionArg("SPen", AATYPE_NUM, (LONG) Pens20[FILLPEN]);
  if (SelectPen>28) SelectPen=Pens20[FILLPEN];
  i=1;
 }
if (GetActionArg("separator",AATYPE_BOOL,0)) /* 2.5RC8 rri */
 {
  separator=(GetActionArg("separator",AATYPE_NUM,0x2e)&0x7f);
  if((separator&0x7f)<0x20) separator=0x2e;
  i=1;
 }
if (GetActionArg("sizes",AATYPE_BOOL,0)) /* 2.5RC8 rri */
 {
  sizes=GetActionArg("sizes",AATYPE_NUM,1);
  if(sizes<1 || sizes>3) sizes=1; /* 2.5.23 rri */
  i=1;
 }

if(i==1) /* 2.5b12 rri */
 {
  RefreshWindows(); /* 2.5RC8 rri */
 }

if (GetActionArg("AppIcon",AATYPE_BOOL,0)) /* 2.5b13 rri */
 {
  UBYTE *appstr;

  appstr=(UBYTE *) GetActionArg("AppIcon", AATYPE_STR, 0);
  
  if(appstr!=0 && *appstr !=0 ) /* 2.5.26 rri */
   {
    if(AppIconPath)
     {
      PoolFreeVec(AppIconPath);
      AppIconPath=0;
     }
    AppIconPath=CloneStr(appstr,StringPool); /* 2.5.26 rri */
    if(strlen(AppIconPath)>5 &&
       Stricmp(AppIconPath+(strlen(AppIconPath)-5),".info")==0) /* 2.5b13 rri */
        {
         AppIconPath[strlen(AppIconPath)-5]=0;
        }
   }
 }
}


void CMD_DevList(void) {  /* 2.5b12 jjt */
  ShowDev = 0;
  if (GetActionArg("DEV", AATYPE_BOOL, 0)) ShowDev = SHOWDEV_DEV;
  if (GetActionArg("VOL", AATYPE_BOOL, 0)) ShowDev |= SHOWDEV_VOL;
  if (GetActionArg("ASN", AATYPE_BOOL, 0)) ShowDev |= SHOWDEV_ASN;
  if (ShowDev == 0) ShowDev = SHOWDEV_ALL;
  RefreshDevLists();
}


void CMD_Font(void)
{
UBYTE *fname;
ULONG idx, i, size, changed[DMFONTS_SCREEN]={0};

/* --- Handle newer args --- */
for (idx=DMFONTS_MAIN; idx < DMFONTS_SCREEN; idx++)
 {
  changed[idx] = 0;  /* 2.5RC2 jjt */
  i = (LONG) GetActionArg(FontKeywords[idx], AATYPE_BOOL, 0);  /* i + 1 = font size */
  if (i)
   {
    fname = (UBYTE *) GetActionArg(FontKeywords[idx], AATYPE_STR, 0);
    if(ActionArgs[i+1]) StrToLong(ActionArgs[i+1],(LONG *) &size); /* 2.5RC10 rri */
    else size=8;
    changed[idx] = DMOpenFont(idx, fname, size);
   }
 }

/* --- Update whatever needs updating :-) --- */
if (changed[DMFONTS_MAIN]||changed[DMFONTS_DIRGAD]) /* 2.5.26 rri */
 {
  for (i=0; i<DMMAXWINDOWS; i++) /* 2.5.23 rri */
   {
    if(DirWin[i])
     {
      SetFont(DirWin[i]->Window->RPort, DMFonts[DMFONTS_MAIN]);
      NewSize(DirWin[i]);
     }
   }
 }

if (changed[DMFONTS_MENU])
 {
  FontToAttr(DMFonts[DMFONTS_MENU], &Menu_TAttr);
  DMLayoutMenus(); /* 2.5RC10 rri */
 }
}


void CMD_HideDev(void) {  /* 2.5b12 jjt */
  STRPTR sptr;
  ULONG  append, i, l;

  append = GetActionArg("ADD", AATYPE_BOOL, 0);
  if (append == 0) {
    /* --- Clear the list. --- */
    for (i=0; i < DevHide_Count; i++) PoolFreeVec(DevHide_List[i]);
    DevHide_Count = 0;
  }

  for (i=1; (DevHide_Count < DEVHIDELIST_MAX) && ActionArgs[i]; i++) {
    if (i != append) {
      sptr = CloneStr(ActionArgs[i], StringPool);
      if (sptr) {
        for (l = strlen(sptr) - 1; l > 0; l--) {
          /* --- Remove/end at ":" --- */
          if (sptr[l] == ':') {
            sptr[l] = 0;
            break;
          }
        }

        DevHide_List[DevHide_Count] = sptr;
        DevHide_Count++;
      }
    }
  }

  RefreshDevLists();
}


/*
void MultiSelect(int p)
{
struct DirList **dl,*dlp;
int    i=0,c=0;

dl=CDWin->DirList;
while(c<30||i<CDWin->FileCount)
 {
  dlp=dl[i++];
  if(dlp&&dlp->sel==1)
   {
    dlp->sel=0;
    c++;
    ActionArgs[p++] = dlp->name;
   }
 }
if(c)
 {
  dis_files(CDWin);
  WinTitle(CDWin);
 }
}
*/
