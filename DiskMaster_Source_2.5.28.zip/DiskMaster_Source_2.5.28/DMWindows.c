/* DiskMaster2 windows module  open/close/refresh/scroll/select/display
**
** 2.5RC9
**
** 03-01-25 rri - Replaced one memmove() cally by a CopyMem() call.
**
** 2.5RC10
**
** 03-02-28 rri - DWNum changed to ULONG.
**              - Added and modified prototype for sel_file().
**              - Removed some "new! ..." style comments.
**              - Corrected two ActionCmd() and one sel_file() calls.
**
** 03-03-01 rri - Added init of dw->Number to OpenDirWindow()
**
** 03-04-12 rri - Bugfix: an overseen race-condition caused an enforcer-hit
**                in sel_file().
**                Thanks for reporting to Richard Mattsson <avart@ftml.net>!
**
** 03-04-22 rri - Renamed var *command in sel_file() to *cmd_line to avoid
**                conflict with new global var in DMParser.c
**
** 03-04-23 rri - Replaced one ParseArgs() call with a SplitLine() call.
**
** 03-04-24 rri - Added two additional lines to sel_file(), these may not
**                be necessary but safety first...
**
** 2.5.23
**
** 03-05-18 rri - Added a few double-brackets to assignments to avoid
**                warnings with GCC.
**              - Partly rewritten OpenDirWindow() - as GCC doesn't seem to like
**                structure templates at all DWTemplate and NewWin were replaced
**                by line-by-line inits at first.
**                NewWin_Flags is for the zoom-option in DMParser.c.
**                PBorder/PPair1/PPair2 were also removed as the GCC binary
**                wasn't displaying the frame around gad_parent anymore.
**                This is now a BOOPSI FRAMEICLASS object and properly
**                removed in CloseDirWindow().
**                It is also two pixels higher and wider now.
**
** 03-05-30 rri - Simplified a few AllocMem() / FreeMem() calls.
**              - Changed "dwc" and "maxf" in OpenDirWindow() to LONG.
**              - Renamed "value" in OpenDirWindow() to "returncode"
**              - Changed "LastI" to LONG.
**              - Introduced DMMAXWINDOWS.
**
** 2.5.24
**
** 03-08-01 rri - Added window-layout scaling based on default-values for
**                screen dimensions and current screen dimensions.
**
** 03-08-02 rri - Renamed devx / devy to defx / defy...
**              - Added scaling to ZOOM vars.
**
** 2.5.26
**
** 03-08-10 rri - Bugfix: changing the dir-gadgets font did not refresh it.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC4)
**
** 03-08-16 rri - Bugfix: window-scaling is only enabled for the initial windows now.
**              - Bugfix: "select-dir-RMB" windows opened at the bottom of the screen
**                        when selecting dirs close to the top border.
**              - Improved overall calculation of window dimensions
**                for "select-dir-RMB" windows.
**
** 2.5.27
**
** 03-10-21 rri - Bugfix: "%c" did not work correctly with auto-cmd's.
**                         Thanks for reporting to Richard Mattsson <avart@ftml.net>!
**
** 2.5.28
**
** 04-01-03 rri - Changed three allocations in OpenDirWindow() from MEMF_PUBLIC to MEMF_ANY.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC9)
**              - Replaced a FreeMem() call in CloseDirWindow() by a FreeDosObject() call.
**
**
*/


#include "DM.h"

extern struct DateStamp setStamp;
extern struct DirList *DClickDir;
extern struct DirWindow *DirWin[],*CDWin,*DestWin,*CmdWin;
extern struct FileInfoBlock     Fib;
extern struct GfxBase *GfxBase;
extern struct InfoData InfoData;
extern struct IntuitionBase *IntuitionBase;
extern struct Menu *DMMenu;
extern struct MsgPort *WinPort,*NotifyPort; /* 2.5b7 rri */
extern struct Process *process;
extern struct Screen *Screen,*MyScreen;
extern struct TextAttr FuckingTopaz;
extern struct TextFont *DMFonts[];


extern UWORD Pens20[];

extern UBYTE dcPath[],
             *DMcmt,   /* 2.5.27 rri */
             DMname[], /* 2.5RC6 rri */
             PGadStr[],
             sbuff[];

extern int FontSize,
           SortType;

extern APTR CommentPool; /* 2.5.27 rri */
extern APTR NamePool; /* 2.5RC6 rri */
extern APTR StringPool; /* 2.5RC6 rri */

extern ULONG FLAGS; /* 2.5RC2 rri */

extern  LONG  Bar_Height; /* 2.5.24 rri */
extern ULONG  defx, defy, Screen_Width,Screen_Height; /* 2.5.24 rri */

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */
extern struct Hook          EditHook;     /* 2.5b10 jjt */

int LastY;

UBYTE UndoBuff[516],
      WorkBuf[516];  /* 2.5b10 jjt */

WORD zooming[4]; /* 2.5b13 rri */

LONG DirPen, FilePen, BackPen, SelectPen; /* 2.5b12 rri */
LONG LastI; /* 2.5.23 rri */

ULONG  DMicros,
       DSecs,
       DWNum, /* 2.5RC10 rri */
       OldDir=333, /* 2.5RC7 rri */ /* 2.5.23 gcc rri */
       TOPOFFSET=12; /* 2.5RC2 rri */

ULONG NewWin_Flags = WFLG_ACTIVATE|WFLG_CLOSEGADGET|WFLG_SIZEGADGET|  /* 2.5.23 gcc rri */
                     WFLG_DRAGBAR|WFLG_DEPTHGADGET|WFLG_SMART_REFRESH|
                     WFLG_NOCAREREFRESH;

struct Image *uparrow=NULL, /* 2.5RC2 rri */
             *dnarrow=NULL, /* 2.5RC2 rri */
             *lfarrow=NULL, /* 2.5RC2 rri */
             *rtarrow=NULL, /* 2.5RC2 rri */
             *pborder=NULL; /* 2.5.23 rri */

struct IntuiText GadSText[4]={ /* 2.5.23 rri */
        {1,0,JAM2,3,2,&FuckingTopaz,"S",0},
        {1,0,JAM2,3,2,&FuckingTopaz,"D",0},
        {1,0,JAM2,3,2,&FuckingTopaz,"C",0},
        {1,0,JAM2,3,2,&FuckingTopaz," ",0}
};



void freeze_windows(LONG x); /* 2.5RC2 rri */
void sel_file(ULONG num,WORD my); /* 2.5RC10 rri */


void freeze_windows(LONG x) /* 2.5RC2 rri */
{
struct DirWindow *dw;
LONG i;

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(dw&&dw->Window)
   {
    if(x==1)
     {
      dw->Window->MinWidth=dw->Window->Width;
      dw->Window->MaxWidth=dw->Window->Width;
      dw->Window->MinHeight=dw->Window->Height;
      dw->Window->MaxHeight=dw->Window->Height;
     }
    if(x==0)
     {
      dw->Window->MinWidth=65;
      dw->Window->MinHeight=65;
      dw->Window->MaxWidth=0xFFFF;
      dw->Window->MaxHeight=0xFFFF;
     }
   }
 }
}


void DoWindow()
{
struct IntuiMessage *msg;
struct DirWindow *dw;
struct Gadget *gad;
static struct Gadget *lastgad; /* 2.5b9 rri */
struct MenuItem *item;
ULONG  class,
       DiskKludge=TRUE;  /* 2.5b12 jjt */
UWORD  code,qual;
WORD   my;
int    id,w,t,hot;

while((msg=(struct IntuiMessage *)GetMsg(WinPort))) /* 2.5.23 gcc rri */
 {
  if(RexxSysBase&&do_rexx_cmd((struct RexxMsg *)msg)) continue;
  code=msg->Code;
  qual=msg->Qualifier;
  class=msg->Class;
  my=msg->MouseY;
  dw=FindDMWin(msg->IDCMPWindow);
  FLAGS&=~DMFLAG_DCLICK; /* 2.5RC2 rri */
  gad=(struct Gadget *)msg->IAddress;
  hot=0;
  t=(class==IDCMP_MENUPICK);
  w=(class==IDCMP_MOUSEBUTTONS&&code==SELECTDOWN);
  if(w||t)
   {
    if(DoubleClick(DSecs,DMicros,msg->Seconds,msg->Micros)) FLAGS|=DMFLAG_DCLICK; /* 2.5RC2 rri */
    if(w)
     {
      DSecs=msg->Seconds;
      DMicros=msg->Micros;
     }
   }
  if(t&&dw&&(dw->Window->Flags&WFLG_WINDOWACTIVE)&&dw==CDWin&&DClickDir&&(FLAGS&DMFLAG_DCLICK)) /* 2.5RC2 rri */
   if((msg->MouseY+4)>LastY&&(msg->MouseY-4)<LastY) hot=1;
  LastY=msg->MouseY;
  ReplyMsg((struct Message *)msg);

  if(dw) switch(class)
   {
    case IDCMP_DISKINSERTED:
                        Delay(25);
                        ReSort();
    case IDCMP_DISKREMOVED:  /* 2.5b12 jjt */
                        if (DiskKludge) {  /* 2.5b12 jjt */
                          /* Every open window will send a DISKINSERTED/REMOVED,
                             so only act on one. */
                          RefreshDevLists();
                          DiskKludge = FALSE;
                        }
                        break;
    case IDCMP_CHANGEWINDOW: /* 2.5b13 rri */
                        NewSize(dw);
                        if(dw->Window->Flags&WFLG_ZOOMED) /* 2.5b13 rri */
                         {
                          dw->zoom[0]=dw->Window->LeftEdge;
                          dw->zoom[1]=dw->Window->TopEdge;
                          dw->zoom[2]=dw->Window->Width;
                          dw->zoom[3]=dw->Window->Height;
                         }
                        else /* 2.5b13 rri */
                         {
                          dw->norm[0]=dw->Window->LeftEdge;
                          dw->norm[1]=dw->Window->TopEdge;
                          dw->norm[2]=dw->Window->Width;
                          dw->norm[3]=dw->Window->Height;
                         }
                        break;
    case IDCMP_VANILLAKEY:
    case IDCMP_RAWKEY:
                        DoKeyCmd(dw,code,qual,class);
                        break;
    case IDCMP_MOUSEBUTTONS:
                        if(code==SELECTDOWN)
                         {
                          freeze_windows(1); /* 2.5RC2 rri */
                          sel_file(DWNum,my); /* 2.5RC10 rri */
                          freeze_windows(0); /* 2.5RC2 rri */
                          if(FLAGS&DMFLAG_RESET) /* 2.5rc2 rri */
                           {
                            FLAGS&=~DMFLAG_RESET; /* 2.5RC2 rri */
                            return;
                           }
                         }
                        break;
    case IDCMP_GADGETDOWN:
                        if(gad->GadgetID==1||gad->GadgetID==2) /* 2.5b10 rri */
                         {
                          dw->Window->Flags|=WFLG_REPORTMOUSE; /* 2.5b9 rri */
                          lastgad=gad; /* 2.5b9 rri */
                         }
                        slide_em(dw,gad);
                        break;
    case IDCMP_GADGETUP:
                        dw->Window->Flags&=~WFLG_REPORTMOUSE; /* 2.5b9 rri */
                        lastgad=NULL;
                        id=gad->GadgetID;
                        if(id==7&&dw==CDWin)
                         {
                          SplitLine(PGadStr,CmdWin); /* 2.5RC10 rri */
                         }
                        if ((id == 0) && (code != 27))  /* 2.5b10 jjt */
                         {
                          /* if gadget = stringgadget = ID==0
                             and Esc wasn't what triggered the GADGETUP msg.
                          */
                          dw->Pattern[0]=0;
                          if(FindPattern(dw->Path))
                           {
                            Separate(dw);
                           }
                          InitDir(dw,0);
                         }
                        break;
    case IDCMP_MOUSEMOVE: /* 2.5b9 rri */
                        if(lastgad) slide_em(dw,lastgad); /* 2.5b10 rri */
                        break;
    case IDCMP_CLOSEWINDOW:
                        CloseDirWindow(DWNum);
                        break;
    case IDCMP_MENUPICK:
                        if((item=ItemAddress(DMMenu,(ULONG) code))) /* 2.5.23 gcc rri */
                         {
                          ActionCmd(DWNum, GTMENUITEM_USERDATA(item)); /* 2.5RC10 rri */
                          break;
                         }
                        if(hot)
                         {
                          /* 2.5b13 rri */
                          zooming[0]=CDWin->zoom[0];
                          zooming[1]=CDWin->zoom[1];
                          zooming[2]=CDWin->zoom[2];
                          zooming[3]=CDWin->zoom[3];

                          /* 2.5.26 rri */
                          w=CDWin->Window->TopEdge; /* recycled var! */
                          OpenDirWindow(0,CDWin->Window->LeftEdge,
                                        ((my+w-50) < w) ? w : (my+w-50),
                                        CDWin->Window->Width,
                                        100);

                          WinTitle(DestWin); /* 2.5b6 rri */
                          break;
                         }
    default:            break;
   }
 }
}


void RefreshGadget(struct Gadget *gad,struct Window *win)
{
RefreshGList(gad,win,NULL,1); /* 2.5RC2 rri */
}


void SetHoriz(struct DirWindow *dw)
{
int width;
UWORD hbody=dw->h_prop.HorizBody;

width=dw->Window->GZZWidth/DMFonts[DMFONTS_MAIN]->tf_XSize; /* 2.5RC2 rri */

if(dw->Collums>(width+1)) /* 2.5RC7 */
 {
  dw->h_prop.HorizBody=(width<<16)/(dw->Collums-1); /* 2.5RC7 */
  dw->Edge=(dw->h_prop.HorizPot*(dw->Collums-width))>>16; /* 2.5RC7 */
 }
else
 {
  dw->h_prop.HorizBody=0xFFFF;
  dw->Edge=0;
  dw->h_prop.HorizPot=0;
 }

if(!dw->Edge) dw->h_prop.HorizPot=0;

if(hbody!=dw->h_prop.HorizBody) RefreshGadget(&dw->h_gad,dw->Window);
}


void SetVert(struct DirWindow *dw)
{
UWORD vbody=dw->v_prop.VertBody;

if(dw->FileCount>dw->Rows)
 {
  dw->v_prop.VertBody=((LONG)(dw->Rows-1)<<16)/(dw->FileCount-1);
 }
else
 {
  dw->v_prop.VertBody=0xFFFF;
  dw->Index=0;
 }

if(!dw->Index) dw->v_prop.VertPot=0;

if(vbody!=dw->v_prop.VertBody) RefreshGadget(&dw->v_gad,dw->Window);
}


void dis_name(struct DirWindow *dw,LONG file,LONG pos) /* 2.5b0 rri */
{
struct RastPort *rp;
struct DirList **dl,*dlp;
UBYTE *ptr=sbuff;
ULONG Ap=FilePen,Bp=BackPen,cols; /* 2.5b12 rri */

if(!dw||!dw->Window) /* 2.5b13 rri */
 {
  return;
 }

rp=dw->Window->RPort;
dl=dw->DirList;
dlp=dl[file];

dw->Rows=(dw->Window->GZZHeight-TOPOFFSET)/DMFonts[DMFONTS_MAIN]->tf_YSize; /* 2.5RC2 rri */

if(pos>dw->Rows) return;

memset(ptr,' ',200);

if(file>=0&&file<dw->FileCount&&dlp->sel<2)
 {
  DoFileFormat(dlp,dw); /* 2.5RC7 rri */
  if(dlp->dir==3)
   {
    if(!(dlp->sel))
     {
      Ap=dlp->attr&0xF;
      Bp=(dlp->attr>>4)&0xF;
     }
    if(dlp->sel) /* 2.5b12 rri */
     {
      Ap=(dlp->attr>>8)&0xF;
      Bp=(dlp->attr>>12)&0xF;
     }
   }
  else
   {
    if(dlp->sel)
     {
      Bp=SelectPen; /* 2.5b12 rri */
      if (SelectPen==BackPen) Bp++;
     }
    if(dlp->dir&&dlp->dir<3) Ap=DirPen; /* 2.5b12 rri */
   }
 }

if(Ap==Bp) Ap++;

SetAPen(rp,Ap);
SetBPen(rp,Bp);
Move(rp,(LONG)dw->Window->BorderLeft,(LONG)((pos*DMFonts[DMFONTS_MAIN]->tf_YSize)+dw->Window->BorderTop+TOPOFFSET+DMFonts[DMFONTS_MAIN]->tf_Baseline));
ptr=sbuff+dw->Edge;
cols=dw->Window->GZZWidth/DMFonts[DMFONTS_MAIN]->tf_XSize; /* 2.5RC2 rri */
Text(rp,ptr,cols);
sbuff[0]=0; /*  2.5RC7 rri */
}


void rdis_files(struct DirWindow *dw)
{
struct RastPort *rp=dw->Window->RPort;
int pos,VPot;
LONG s,top=dw->Window->BorderTop+TOPOFFSET,h=DMFonts[DMFONTS_MAIN]->tf_YSize,
     w,maxname=dw->Rows-1; /* 2.5b10 rri */

if(dw->FileCount<maxname) return;

w=dw->Window->GZZWidth; /* 2.5RC2 rri */
s=dw->Window->BorderLeft;
while(1)
 {
  VPot=dw->v_prop.VertPot;
  pos=(VPot*(dw->FileCount-maxname))>>16;
  if(pos==dw->Index) return;
  if(pos>dw->Index&&pos<dw->Index+(maxname>>2))
   {
    ClipBlit(rp,s,top+h,rp,s,top,w,maxname*h,0xC0);
    dw->Index++;
    dis_name(dw,dw->Index+maxname,maxname);
   }
  else if(pos<dw->Index&&pos>dw->Index-(maxname>>2))
    {
     ClipBlit(rp,s,top,rp,s,top+h,w,maxname*h,0xC0);
     dw->Index--;
     dis_name(dw,dw->Index,0);
    }
  else
   {
    dw->Index=pos;
    dis_files(dw);
   }
 }
}


void dis_files(struct DirWindow *dw)
{
LONG i; /* 2.5b10 rri */

if(!dw->FileCount)
 {
  dw->Collums=0; /* 2.5RC7 */
  SetHoriz(dw); /* 2.5RC6 rri */
  SetVert(dw); /* 2.5RC6 rri */
  return; /* 2.5RC2 rri */
 }

ReSize(dw); /* 2.5RC2 rri */

dis_name(dw,dw->Index,0); /* reset completely */

SetHoriz(dw);
SetVert(dw);

for(i=0;i<dw->Rows;i++)
 {
  dis_name(dw,i+dw->Index,i); /* reset again row by row */
 }

SetHoriz(dw); /* 2.5RC7 rri */
SetVert(dw); /* 2.5RC7 rri */
}


void Increment(struct DirWindow *dw,struct Gadget *gad,LONG lines) /* 2.5b10 rri */
{
LONG add,def,repeatdelay=0; /* 2.5RC6 rri */

if (lines<1) lines=1;
if(dw->FileCount<=dw->Rows)  return;
def=0xFFFF/(dw->FileCount-dw->Rows); /* 2.5RC4 rri */
if(gad->GadgetID==3) add = -def;
else add=def; /* 2.5RC6 rri */
add=add*lines;
do
 {
  if((!dw->Index&&add<0)||(dw->Index>(dw->FileCount-dw->Rows-1)&&add>0))
   {
    break;
   }
  def=dw->v_prop.VertPot;
  if((0xFFFF-def-add)<(add/lines)) /* 2.5RC7 rri */
   {
    add=0xFFFF-def;
   }
  else if(def+add<lines)
   {
    add = 1-def; /* 2.5RC6 rri */
   }
  dw->v_prop.VertPot+=add;
  RefreshGadget(&dw->v_gad,dw->Window);
  rdis_files(dw);
  if(!repeatdelay&&gad->Flags&GFLG_SELECTED) /* 2.5RC6 rri */
   {
    Delay(10);
    repeatdelay=1;
   }
 }
while(gad->Flags&GFLG_SELECTED);
}


void HorSlide(struct DirWindow *dw,struct Gadget *gad,LONG lines) /* 2.5b10 rri */
{
LONG add,def,cols,clc,repeatdelay=0; /* 2.5RC6 rri */

if (lines<1) lines=1;

cols=dw->Window->GZZWidth/DMFonts[DMFONTS_MAIN]->tf_XSize; /* 2.5RC2 rri */
clc=(dw->Collums-cols-1); /* 2.5RC7 */
if(clc<=1) return;
def=0xFFFF/clc;
if(gad->GadgetID==5) add = -def;
else add=def+1;
add=add*lines;

do
 {
if((!dw->Edge&&add<0)||(dw->Edge>(clc-1)&&add>0)) break;
  def=dw->h_prop.HorizPot;
  if((0xFFFF-def-add)<(add/lines)) /* 2.5RC7 rri */
   {
    add=0xFFFF-def;
   }
  else if(def+add<lines) add = -def;
  dw->h_prop.HorizPot+=add;
  RefreshGadget(&dw->h_gad,dw->Window);
  SetHoriz(dw);
  for(cols=0;(cols<dw->Rows)&&(cols+dw->Index<dw->FileCount);cols++) /* 2.5RC7 rri */
   {
    dis_name(dw,cols+dw->Index,cols); /* reset again row by row */
   }
  if(!repeatdelay&&gad->Flags&GFLG_SELECTED) /* 2.5RC6 rri */
   {
    Delay(10);
    repeatdelay=1;
   }
 }
while(gad->Flags>0x80);
}


void ShowDirection(struct DirWindow *dw,int n)
{

if(dw)
 {
  if(dw->Flags&DW_SOURCE) n=0;
  if(dw->Flags&DW_DEST) n=1;
  if(dw->Flags&DW_CMD) n=2;
  if(n==4)
   {
    n=1;
    if(dw==CDWin) n=0;
   }
  dw->parent.GadgetText = &GadSText[n];
  RefreshGadget(&dw->parent,dw->Window);
 }
}


void NewSize(struct DirWindow *dw)
{
struct Window *win=dw->Window;
struct RastPort *rp=win->RPort;
LONG tp;

/* ensure the dir-gadget is using the current font - 2.5.26 rri */
TOPOFFSET=DMFonts[DMFONTS_DIRGAD]->tf_YSize+4;
dw->dir_gad.Height=DMFonts[DMFONTS_DIRGAD]->tf_YSize;
dw->SExt.Font=DMFonts[DMFONTS_DIRGAD];

dw->dir_str.BufferPos=0;
tp=win->BorderTop+TOPOFFSET; /* 2.5RC4 rri */
SetAPen(rp,(ULONG) Pens20[BACKGROUNDPEN]);
RectFill(rp,(LONG) win->BorderLeft,
            (LONG) win->BorderTop, /* 2.5.26 rri */
            (LONG) (win->Width-win->BorderRight-1),
            (LONG) (win->Height-win->BorderBottom-1));

RefreshGadget(&dw->dir_gad,dw->Window); /* 2.5.26 rri */

SetAPen(rp,(ULONG) Pens20[SHINEPEN]);
Move(rp,(LONG) win->BorderLeft,tp-2); /* 2.5RC4 rri */
Draw(rp,(LONG) win->Width-win->BorderRight-1,tp-2);

SetAPen(rp,(ULONG) Pens20[SHADOWPEN]);
Move(rp,(LONG) win->BorderLeft,tp-1); /* 2.5RC4 rri */
Draw(rp,(LONG) win->Width-win->BorderRight-1,tp-1); /* 2.5RC4 rri */

ShowDirection(DestWin,1);
ShowDirection(CDWin,0);

dis_files(dw);
rdis_files(dw); /* what is this really good for ? */
WinTitle(dw);
}


void slide_em(struct DirWindow *dw,struct Gadget *gad)
{
UWORD id=gad->GadgetID;

if(id==3||id==4)
 {
  Increment(dw,gad,1);
  return;
 }

if(id==5||id==6)
 {
  HorSlide(dw,gad,1);
  return;
 }

if(id==1)
 {
  if(!(dw->FileCount<(dw->Rows-1)))
   {
    rdis_files(dw);
   }
 }

if(id==2)
 {
  dis_files(dw);
 }
}


void sel_file(ULONG num,WORD my)
{
struct DirList **dl=DirWin[num]->DirList,*dlp; /* 2.5RC10 rri */
struct Message *msg;
LONG i,ni,cm; /* 2.5b10 rri */
UBYTE smear=5;
struct Window *win=DirWin[num]->Window;

cm=(DirWin[num]->Flags&DW_CMD);

if(my>(win->Height-win->BorderBottom)) return;
if(win->MouseX<win->BorderLeft) return; /* 2.5b10 rri */

if((FLAGS&DMFLAG_DCLICK)&&!cm&&(DWNum!=OldDir)) /* 2.5RC7 rri */
 {
  if(GetNewPath(DirWin[num]))
   {
    WinTitle(DestWin); /* 2.5b7 rri */
    return;
   }
 }

if(!DirWin[num]->FileCount) return;
i=(my-win->BorderTop-TOPOFFSET)/DMFonts[DMFONTS_MAIN]->tf_YSize;

do
 {
  ni=i+DirWin[num]->Index;
  if(i<0||i>=DirWin[num]->Rows||ni>=DirWin[num]->FileCount) goto SK;
  if(win->MouseX>(win->Width-win->BorderRight)) goto SK;
  dlp=dl[ni];
  if(!dlp) goto SK;

  if(smear==5) /* simple select */
   {
    dlp->sel^=1;
    smear=dlp->sel;
   }

  else /* click-move select */
   {
    if(dlp->sel==smear)
     {
      goto SK;
     }
    else
     {
      dlp->sel=smear;
     }
   }

  if(dlp->dir&&dlp->dir<3) /* dir double-clicked ? */
   {
    if((FLAGS&DMFLAG_DCLICK)&&DClickDir==dlp&&LastI==i&&!dlp->sel)
     {
      if(GetNewPath(DirWin[num])) return;
     }
    LastI=i;
    DClickDir=dlp;
    OldDir=DWNum; /* 2.5RC7 rri */
    FLAGS&=~DMFLAG_DCLICK; /* 2.5RC2 rri */
   }
  else DClickDir=0;

  if(!dlp->dir) /* file double-clicked ? */
   {
    if(LastI==i&&(FLAGS&DMFLAG_DCLICK)&&!dlp->sel) /* 2.5RC2 rri */
     {
      if(DMcmt) PoolFreeVec(DMcmt); /* 2.5.27 rri */
      DMcmt = CloneStr(dlp->cmt,CommentPool); /* 2.5.27 rri */
      AutoFiler(DirWin[num],dlp->name);
      if(FLAGS&DMFLAG_RESET) return; /* 2.5rc2 rri */
      smear=4; /* this seems to be useless */
     }
    else LastI=i;
   }

  if(dlp->dir==3) /* selected command-window entry? */
   {
    dis_name(DirWin[num],ni,i); /* mark entry as selected */
    if(FLAGS&DMFLAG_CHGCMD) /* 2.5RC2 rri */
     {
      EditCmd(DirWin[num],(int) ni); /* 2.5b10 rri */
     }
    else
     {
      /* 2.5RC6 rri */
      UBYTE *cmd_line; /* 2.5RC10 rri */      /* clone cmd-line in case there is */

      cmd_line=CloneStr(dlp->cmt,StringPool); /* a 'Close'�in it which would */
      ActionCmd(num,cmd_line); /* 2.5RC10 rri */ /* remove the line from memory */
      PoolFreeVec(cmd_line);
      if(CDWin&&CmdWin&&CmdWin->Window->Flags&WFLG_WINDOWACTIVE) /* 2.5b5 rri */
       {
        ActivateWindow(CDWin->Window);
       }
     }

    if(!DirWin[num] || DirWin[num]!=CmdWin) /* 2.5RC10 rri */
     {
      if(DirWin[num]) /* check if old window is still there */ /* 2.5RC6 rri */
       {
        dlp=dl[ni]; /* 2.5RC10 rri */
        if(dlp) /* 2.5RC10 rri */
         {
          dlp->sel=0;
          dis_name(DirWin[num],ni,i); /* unmark entry */
         }
       }
      return;
     }
/*  DirWin[num]=CmdWin; */ /* useless! if it's not unequal it has to be equal - 2.5RC6 rri */
    dlp->sel=0;
    smear=4;
   }
  FLAGS&=~DMFLAG_DCLICK; /* 2.5RC2 rri */
  if(DirWin[num]) dis_name(DirWin[num],ni,ni-DirWin[num]->Index); /* 2.5RC10 rri */
  LastI=i;
  if(smear==4)
   {
    return;
   }

SK:

  ni=(win->MouseY-win->BorderTop-TOPOFFSET); /* 2.5RC3 rri */
  ni/=DMFonts[DMFONTS_MAIN]->tf_YSize; /* 2.5RC3 rri */

  if(ni>i) i++;
  else if(ni<i) i--;
  if(i>=DirWin[num]->Rows&&i<DirWin[num]->FileCount)
   {
    i--;
    Increment(DirWin[num],&DirWin[num]->dn,1);
   }
  if(i<0&&DirWin[num]->Index)
   {
    i++;
    Increment(DirWin[num],&DirWin[num]->up,1);
   }
  WaitTOF();
 }
while(!(msg=GetMsg(WinPort)));

if(msg) ReplyMsg(msg);

WinTitle(DirWin[num]);
}


/* --------------------- Open/Close windows -------------------------------- */

void FindNewDirection(struct DirWindow *dw)
{
struct DirWindow *dw2;
int i=0;

if(dw==CmdWin)
 {
  CmdWin=0;
  if(dw==CDWin) CDWin=0;
  for(i=DMMAXWINDOWS-1;i>=0;i--) /* 2.5.23 rri */
   {
    if((dw2=DirWin[i])) /* 2.5.23 gcc rri */
     {
      if(dw2->Flags&DW_CMD)
       {
        CmdWin=dw2;
        DWNum=i;
        return;
       }
     }
        return;
   }
 }

if(dw==DestWin)
 {
  DestWin=0;
  i=1;
 }
if(dw==CDWin)
 {
  CDWin=DestWin;
  i=1;
 }
if(i)
 {
  for(i=DMMAXWINDOWS-1;i>=0;i--) /* 2.5.23 rri */
   {
    if((dw2=DirWin[i])) /* 2.5.23 gcc rri */
     {
      if(dw2->Flags&DW_CMD)
       {
        DWNum=i;
        ShowDirection(dw2,2);
       }
      else if(CDWin==dw2) DWNum=i;
      else
       {
        DestWin=dw2;
        break;
       }
     }
   }
  ShowDirection(DestWin,1);
  ShowDirection(CDWin,0);
 }
}


void CloseDirWindow(ULONG num) /* 2.5RC10 rri */
{
struct DirWindow *dw=DirWin[num];
int i;

if(!dw) return;
ClearMenuStrip(dw->Window);
CloseSharedWindow(dw->Window);

if(dw->Fib) FreeDosObject(DOS_FIB,dw->Fib); /* 2.5.28 rri */
FreeDirTable(dw);
FreeMem(dw->DirList,(ULONG) (dw->MaxFile<<2)); /* 2.5b10 rri */
FreeMem(dw,sizeof(*dw)); /* 2.5.23 rri */

DirWin[num]=0;

FindNewDirection(dw);
for(i=0;i<DMMAXWINDOWS;i++) if(DirWin[i]) /* 2.5.23 rri */
 {
  if(!DirWin[DWNum]) DWNum=i;
  process->pr_WindowPtr=(APTR)DirWin[i]->Window;
  break;
 }
 if(i==DMMAXWINDOWS) /* 2.5.23 rri */
  {
   process->pr_WindowPtr=(APTR)-1;
   FLAGS&=~DMFLAG_KEEPGOING; /* 2.5RC2 rri */
   DisposeObject(uparrow); /* 2.5RC2 rri */
   DisposeObject(dnarrow); /* 2.5RC2 rri */
   DisposeObject(lfarrow); /* 2.5RC2 rri */
   DisposeObject(rtarrow); /* 2.5RC2 rri */
   DisposeObject(pborder); /* 2.5.23 rri */
   uparrow=NULL; /* 2.5RC2 rri */
   dnarrow=NULL; /* 2.5RC2 rri */
   lfarrow=NULL; /* 2.5RC2 rri */
   rtarrow=NULL; /* 2.5RC2 rri */
   pborder=NULL; /* 2.5.23 rri */
  }
}


int OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi)
{
struct DirWindow *dw;
struct NewWindow *NewWin; /* 2.5.23 gcc rri */
struct DirList **dlist;
int returncode=0,w=Screen->Width,h=Screen->Height; /* 2.5.23 rri */
struct DrawInfo *dri; /* 2.5RC2 rri */
LONG dwc=0, maxf=500; /* 2.5.23 rri */

while(DirWin[dwc]) dwc++;
if(dwc>DMMAXWINDOWS) return returncode; /* 2.5.23 rri */

TOPOFFSET=DMFonts[DMFONTS_DIRGAD]->tf_YSize+4; /* 2.5RC2 rri */

if(Top<Bar_Height) /* 2.5.26 rri */
 {
  Top=Bar_Height+1;
 }

if(Left<0) Left=0; /* 2.5.26 rri */

/* scale window-layout based on given default screen-dimensions */
if(defx&&defy&&(FLAGS&DMFLAG_BATCH)) /* 2.5.26 rri */
 {
  Left = ScalerDiv((ULONG)Left,Screen_Width,defx);
  Top  = ScalerDiv((ULONG)Top,Screen_Height,defy);
  Wid  = ScalerDiv((ULONG)Wid,Screen_Width,defx);
  Hi   = ScalerDiv((ULONG)Hi,Screen_Height,defy);

  zooming[0] = ScalerDiv((ULONG)zooming[0],Screen_Width,defx);
  zooming[1] = ScalerDiv((ULONG)zooming[1],Screen_Height,defy);
  zooming[2] = ScalerDiv((ULONG)zooming[2],Screen_Width,defx);
  zooming[3] = ScalerDiv((ULONG)zooming[3],Screen_Height,defy);
 }

if(Top<Bar_Height) /* 2.5.26 rri */
 {
  Top=Bar_Height+1;
 }

if(Left<0) Left=0;
if(Wid<=0) Wid=w-Left;
if(Wid<65) Wid=65; /* 2.5b13 rri */
if(Hi<= 0) Hi=h-Top;
if(Hi< 65) Hi=65; /* 2.5b13 rri */

while((Left+Wid)>w)
 {
  if(Wid>80) Wid--;
  else if(Left) Left--;
 }
while((Top+Hi)>h)
 {
  if(Hi>70) Hi--;
  else if(Top) Top--;
 }

/* 2.5.23 rri */
if((dw=AllocMem(sizeof (*dw),MEMF_ANY | MEMF_CLEAR))) /* 2.5.28 rri */
 {
  if((dlist=AllocMem((maxf<<2),MEMF_ANY | MEMF_CLEAR))) /* 2.5.28 rri */
   {
    if((NewWin=AllocMem(sizeof(*NewWin),MEMF_ANY | MEMF_CLEAR))) /* 2.5.28 rri */
     {
      NewWin->Screen=Screen;
      NewWin->LeftEdge=Left;
      NewWin->TopEdge=Top;
      NewWin->Width=Wid;
      NewWin->Height=Hi;
      NewWin->IDCMPFlags=IDCMP_ACTIVEWINDOW|IDCMP_CHANGEWINDOW|IDCMP_CLOSEWINDOW|
                         IDCMP_DISKINSERTED|IDCMP_DISKREMOVED|IDCMP_GADGETDOWN|
                         IDCMP_GADGETUP|IDCMP_MENUPICK|IDCMP_MOUSEBUTTONS|
                         IDCMP_MOUSEMOVE|IDCMP_RAWKEY|IDCMP_VANILLAKEY;
      NewWin->Flags=NewWin_Flags;
      NewWin->DetailPen=0;
      NewWin->BlockPen=1;
      NewWin->MinWidth=65;
      NewWin->MinHeight=65;
      NewWin->MaxWidth=0xFFFF;
      NewWin->MaxHeight=0xFFFF;
      NewWin->Type=CUSTOMSCREEN;

      dw->dir_gad.Flags = GFLG_RELWIDTH|GFLG_GADGHCOMP|GFLG_STRINGEXTEND;
      dw->dir_gad.Activation = GACT_IMMEDIATE|GACT_RELVERIFY;
      dw->dir_gad.GadgetType = GTYP_STRGADGET;

      dw->v_gad.LeftEdge = -13;
      dw->v_gad.Width = 10;
      dw->v_gad.Flags = GFLG_RELHEIGHT|GFLG_RELRIGHT|GFLG_GADGHNONE;
      dw->v_gad.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_RIGHTBORDER;
      dw->v_gad.GadgetType = GTYP_PROPGADGET;
      dw->v_gad.GadgetID = 1;

      dw->h_gad.Flags = GFLG_RELBOTTOM|GFLG_RELWIDTH|GFLG_GADGHNONE;
      dw->h_gad.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_BOTTOMBORDER;
      dw->h_gad.GadgetType = GTYP_PROPGADGET;
      dw->h_gad.GadgetID = 2;

      dw->up.Flags = GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE|GFLG_GADGIMAGE;
      dw->up.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_RIGHTBORDER;
      dw->up.GadgetType = GTYP_BOOLGADGET;
      dw->up.GadgetID = 3;

      dw->dn.Flags = GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE|GFLG_GADGIMAGE;
      dw->dn.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_RIGHTBORDER;
      dw->dn.GadgetType = GTYP_BOOLGADGET;
      dw->dn.GadgetID = 4;

      dw->lf.Flags = GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE|GFLG_GADGIMAGE;
      dw->lf.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_BOTTOMBORDER;
      dw->lf.GadgetType = GTYP_BOOLGADGET;
      dw->lf.GadgetID = 5;

      dw->rt.Flags = GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE|GFLG_GADGIMAGE;
      dw->rt.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_BOTTOMBORDER;
      dw->rt.GadgetType = GTYP_BOOLGADGET;
      dw->rt.GadgetID = 6;

      dw->parent.LeftEdge = -14;
      dw->parent.TopEdge = 10;
      dw->parent.Width = 14; /* 2.5.23 rri */
      dw->parent.Height = 12; /* 2.5.23 rri */
      dw->parent.Flags = GFLG_GADGHIMAGE|GFLG_GADGIMAGE|GFLG_RELRIGHT; /* 2.5.23 rri */
      dw->parent.Activation = GACT_IMMEDIATE|GACT_RELVERIFY|GACT_RIGHTBORDER;
      dw->parent.GadgetType = GTYP_BOOLGADGET;
      dw->parent.GadgetID = 7;

      dw->v_prop.Flags = AUTOKNOB | FREEVERT  | PROPNEWLOOK | PROPBORDERLESS;
      dw->v_prop.VertBody = 0xFFFF;

      dw->h_prop.Flags = AUTOKNOB | FREEHORIZ | PROPNEWLOOK | PROPBORDERLESS;
      dw->h_prop.HorizBody = 0xFFFF;

      dw->dir_str.UndoBuffer = (UBYTE *)UndoBuff;
      dw->dir_str.MaxChars = 512;

      if(!uparrow||!dnarrow||!lfarrow||!rtarrow||!pborder) /* 2.5.23 rri */
       {
        if((dri=GetScreenDrawInfo(Screen))) /* 2.5.23 gcc rri */
         {
          uparrow = NewObject(NULL, SYSICLASS, SYSIA_DrawInfo, dri,
                                         SYSIA_Which, UPIMAGE,
                                         TAG_END);
          dnarrow = NewObject(NULL, SYSICLASS, SYSIA_DrawInfo, dri,
                                         SYSIA_Which, DOWNIMAGE,
                                         TAG_END);
          lfarrow = NewObject(NULL, SYSICLASS, SYSIA_DrawInfo, dri,
                                         SYSIA_Which, LEFTIMAGE,
                                         TAG_END);
          rtarrow = NewObject(NULL, SYSICLASS, SYSIA_DrawInfo, dri,
                                         SYSIA_Which, RIGHTIMAGE,
                                         TAG_END);
          pborder = NewObject(NULL,FRAMEICLASS,IA_Pens, dri->dri_Pens, /* 2.5.23 rri */
                                         IA_Width,  dw->parent.Width,
                                         IA_Height, dw->parent.Height,
                                         TAG_END);
          FreeScreenDrawInfo(Screen,dri);
         }
        Delay(2); /* 2.5RC6 rri - for MCP's SysIHack function... */
       }

      if(uparrow && dnarrow && lfarrow && rtarrow && pborder) /* 2.5.23 rri */
       {
        dw->up.LeftEdge = dw->dn.LeftEdge = 1 - uparrow->Width; /* 2.5RC5 rri */
        dw->dn.TopEdge = 1 - lfarrow->Height - dnarrow->Height; /* 2.5RC5 rri */
        dw->up.TopEdge = dw->dn.TopEdge - uparrow->Height; /* 2.5RC4 rri */
        dw->up.Width = dw->dn.Width = uparrow->Width; /* 2.5RC5 rri */
        dw->up.Height = dw->dn.Height = uparrow->Height; /* 2.5RC5 rri */

        dw->rt.LeftEdge = 1 - uparrow->Width - rtarrow->Width; /* 2.5RC5 rri */
        dw->lf.LeftEdge = dw->rt.LeftEdge - lfarrow->Width; /* 2.5RC4 rri */
        dw->lf.TopEdge = dw->rt.TopEdge = 1 - lfarrow->Height; /* 2.5RC5 rri */
        dw->rt.Width = dw->lf.Width = rtarrow->Width; /* 2.5RC5 rri */
        dw->rt.Height = dw->lf.Height = rtarrow->Height; /* 2.5RC5 rri */

        dw->up.GadgetRender = uparrow;
        dw->up.SelectRender = uparrow;
        dw->dn.GadgetRender = dnarrow;
        dw->dn.SelectRender = dnarrow;
        dw->lf.GadgetRender = lfarrow;
        dw->lf.SelectRender = lfarrow;
        dw->rt.GadgetRender = rtarrow;
        dw->rt.SelectRender = rtarrow;
        dw->parent.GadgetRender = pborder; /* 2.5.23 rri */
        dw->parent.SelectRender = pborder; /* 2.5.23 rri */
       }

      CloneBuffer(dw,0); /* 2.5RC6 rri */

      NewWin->FirstGadget=(struct Gadget *)&dw->up;

      dw->up.NextGadget = &dw->dn;
      dw->dn.NextGadget = &dw->lf;
      dw->lf.NextGadget = &dw->rt;
      dw->rt.NextGadget = &dw->h_gad;
      dw->h_gad.NextGadget = &dw->v_gad;
      dw->v_gad.NextGadget = &dw->dir_gad;
      dw->dir_gad.NextGadget = &dw->parent;

      dw->parent.GadgetText = &GadSText[0];

      dw->h_gad.GadgetRender=(APTR)&dw->h_img;
      dw->h_gad.SpecialInfo=(APTR)&dw->h_prop;

      dw->v_gad.GadgetRender=(APTR)&dw->v_img;
      dw->v_gad.SpecialInfo=(APTR)&dw->v_prop;

      dw->dir_gad.SpecialInfo=(APTR)&dw->dir_str;
      dw->dir_gad.UserData = &PathHistory;  /* 2.5b10 jjt */

      NewWin->Title=DMname; /* 2.5RC6 rri */

      dw->dir_str.Extension = &dw->SExt;

      if(path!=0&&Stricmp(path,"CMD")==0) /* 2.5RC6 rri */
       {
        NewWin->Title=0;
       }

      dw->SExt.Font=DMFonts[DMFONTS_DIRGAD];  /* 2.5RC2 rri */
      dw->SExt.Pens[0]=Pens20[TEXTPEN];
      dw->SExt.Pens[1]=Pens20[BACKGROUNDPEN];
      dw->SExt.ActivePens[0]=Pens20[HIGHLIGHTTEXTPEN];
      dw->SExt.ActivePens[1]=Pens20[BACKGROUNDPEN];
      dw->SExt.InitialModes=(1<<2);
      dw->SExt.EditHook = &EditHook;   /* 2.5b10 jjt */
      dw->SExt.WorkBuffer = WorkBuf;  /* 2.5b10 jjt */

      dw->Sorting=SortType;

      /* 2.5b7 rri */
      dw->DM2NotifyReq.nr_stuff.nr_Signal.nr_Task = (struct Task *) FindTask(NULL);
      dw->DM2NotifyReq.nr_Flags = NRF_SEND_MESSAGE;
      dw->DM2NotifyReq.nr_stuff.nr_Msg.nr_Port=NotifyPort;
      dw->DM2NotifyReq.nr_UserData = 0; /* 2.5RC6 rri */

      /* 2.5b13 rri */
      dw->zoom[0]=zooming[0];
      dw->zoom[1]=zooming[1];
      dw->zoom[2]=zooming[2];
      dw->zoom[3]=zooming[3];
      dw->norm[0]=Left;
      dw->norm[1]=Top;
      dw->norm[2]=Wid;
      dw->norm[3]=Hi;

      if((dw->Window=OpenSharedWindow(NewWin)))
       {
        returncode=1; /* 2.5.23 rri */
        dw->dir_gad.TopEdge=dw->parent.TopEdge=dw->Window->BorderTop+1; /* 2.5RC4 rri */
        dw->dir_gad.LeftEdge=dw->Window->BorderLeft;
        dw->dir_gad.Width= - dw->Window->BorderLeft - dw->Window->BorderRight; /* 2.5RC4 rri */
        dw->dir_gad.Height=DMFonts[DMFONTS_DIRGAD]->tf_YSize; /* 2.5RC2 rri */

        dw->v_gad.TopEdge=dw->Window->BorderTop+dw->parent.Height+2; /* 2.5RC4 rri */
        dw->v_gad.Height= - (2*uparrow->Height) - dw->Window->BorderBottom
                          - dw->parent.Height - dw->Window->BorderTop - 4; /* 2.5RC4 rri */

        /* 2.5RC6 rri */
        dw->h_gad.LeftEdge = dw->Window->BorderLeft + 1;
        dw->h_gad.TopEdge = (lfarrow->Height - 3)*(-1);
        dw->h_gad.Width=(2*lfarrow->Width+uparrow->Width+dw->h_gad.LeftEdge+2)*(-1);
        dw->h_gad.Height = lfarrow->Height - 4;

        dw->parent.LeftEdge= -dw->Window->BorderRight + ((dw->Window->BorderRight-dw->parent.Width+2)/2); /* 2.5RC4 rri */

        RefreshWindowFrame(dw->Window); /* 2.5RC4 rri */
        FLAGS|=DMFLAG_KEEPGOING; /* 2.5RC2 rri */

        if(DMMenu&&(!(FLAGS&DMFLAG_BATCH))) /* 2.5RC2 rri */
         {
          SetMenuStrip(dw->Window,DMMenu);
         }
        SetFont(dw->Window->RPort,DMFonts[DMFONTS_MAIN]);  /* 2.5RC2 jjt */
        dw->MaxFile=maxf;
        dw->DirList=dlist;
        DirWin[DWNum=dwc]=dw;
        dw->Number=dwc; /* 2.5RC10 rri */
        process->pr_WindowPtr=(APTR)dw->Window;
        if(!path||Stricmp(path,"CMD")) /* 2.5b13 rri */
         {
          ShowDirection(DestWin,3);
          DestWin=CDWin;
          CDWin=dw;
          ShowDirection(DestWin,1);
          ShowDirection(CDWin,0);
         }
        GetNewPath(dw);
        if(!dw->DirLock&&!dw->Path[0])
         {
          h=0;
          if(path)
           {
            if(Stricmp(path,"CMD")==0) /* 2.5RC6 rri */
             {
              dw->Flags=DW_CMD;
              CloneBuffer(dw,dcPath); /* 2.5RC6 rri */
              CmdWin=dw;
              h=1;
             }
            else
             {
              CloneBuffer(dw,path); /* 2.5RC6 rri */
             }
           }
          InitDir(dw,h);
         }
       } /* OpenSharedWindow... */
      FreeMem(NewWin,sizeof(*NewWin)); /* 2.5.23 gcc rri */
     } /* Alloc NeWin ... */
    if(returncode==0) FreeMem(dlist,(ULONG) (maxf<<2));
   } /* Alloc dlist... */
  if(returncode==0) FreeMem(dw,sizeof(*dw)); /* 2.5.23 rri */
 } /* Alloc dw */
return returncode;
}


struct Window *OpenSharedWindow(struct NewWindow *nw)
{
ULONG   flags=nw->IDCMPFlags;
struct Window   *w;

nw->IDCMPFlags=0;

if((w=OpenWindowTags(nw,WA_NewLookMenus,TRUE,WA_Zoom,zooming,TAG_END,0))) /* 2.5.23 gcc rri */

if(flags)
 {
  w->UserPort=WinPort;
  ModifyIDCMP(w,flags);
 }
nw->IDCMPFlags=flags;
return(w);
}


void CloseSharedWindow(struct Window *Window)
{
Forbid();
if(Window->UserPort)
 {
  struct Node *Node,*Next;
  for(Node=Window->UserPort->mp_MsgList.lh_Head;(Next=Node->ln_Succ);Node=Next) /* 2.5.23 gcc rri */
   {
    if(((struct IntuiMessage *)Node)->IDCMPWindow == Window)
     {
      Remove(Node);
      ReplyMsg((struct Message *)Node);
     }
   }
  Window->UserPort = NULL;
 }
ModifyIDCMP(Window,0); /* 2.5RC4 rri vbcc */
Permit();
CloseWindow(Window);
}
