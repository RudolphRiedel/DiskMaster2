/* DiskMaster2  main module  startup/exit
**
** 2.5RC8
**
** 02-12-30 rri - Set version to 2.5RC8
**
** 03-01-05 rri - Corrected default display-format to "N S C"
**              - Set release date
**
** 2.5RC9
**
** 03-01-05 rri - Set version to 2.5RC9
**
** 03-01-17 rri - Bugfix: rewrote standard main() as introduced in 2.5RC4,
**                now starting thru project-icons works again.
**                Thanks for reporting to Alex Basana <ax.riez@biaccabi.com>
**                and Harald Frank <borg@vmc.de>!
**              - Added InitLibsPortsPools(), joined main() & DMStart(),
**                removed all goto's and cleaned up a bit...
**
** 03-01-18 rri - New var: *ProgName - replaces SAS-C's _ProgramName.
**              - TimerBase is a struct Device...
**              - SysBase instead of IntuitionBase used for USE30.
**
** 03-02-03 rri - Set release date
**
** 2.5RC10
**
** 03-02-07 rri - Set version to 2.5RC10
**
** 03-02-28 rri - Moved declaration of DWNum to DMWindows.c
**              - Removed some "new! ..." style comments.
**
** 03-03-01 rri - Renamed FreeUserJunk() to FreeUserData()
**
** 03-04-12 rri - Added init to 0 to declarations of WinPort, NotifyPort,
**                CommentPool, NamePool, StringPool, ReaderPool and TimerSignal.
**              - Corrected main() - as InitLibsPortsPools() may fail at any
**                stage it is absolut necessary to free all resources
**                conditionally after the main bracket.
**              - Stacked up StringPool to 20000 bytes - some AllocMem()s are
**                overdue to be replaced by PoolAllocVec()...
**
** 03-04-19 rri - Shortened BarFormat[], DispFormat[] and TitleFormat[] to what
**                is set as max in DMParser.c +2.
**
** 03-04-24 rri - Set priority for WinPort to 2 to comply with the autodoc
**                for AddPort() which requests to give named ports at least
**                a prio of 1 instead of 0.
**
** 03-04-27 rri - Set release date
**
** 2.5.23
**
** 03-05-01 rri - Set version to 2.5.23
**
** 03-05-18 rri - Simplified TimerCode() to a version that compiles without
**                warnings and works with both GCC and SAS-C
**              - Added extra brackets around "if((TimerIO=..." and "while((note=..."
**                to avoid warnings with GCC.
**              - Replaced "(ULONG (*)())" cast for "EditHook.h_Entry =" with
**                "(HOOKFUNC)" to avoid warning with GCC.
**              - "TimerInt.is_Code=" needs no cast anymore since TimerCode()
**                does not have a return-code anymore - GCC...
**
** 03-05-30 rri - Simplified a few AllocMem() / FreeMem() calls.
**              - Changed return-code for InitLibsPortsPools()
**                from int to LONG.
**              - Changed "i" in main() from int to LONG.
**              - Moved struct TDat in from DM.h as there is no need
**                to have it available globally.
**              - Moved protos for StartTimer() and TimerCode() in from DM.h
**                as there is no need to have these available globally.
**              - Changed proto for StartTimer() to use a LONG.
**              - Introduced DMMAXWINDOWS.
**              - Added init for *DirWin[] to main()
**              - Changed t, i, wincount and itime in MainLoop()
**                from int to LONG.
**              - Bugfix: overwriting the name pointer of the shell from
**                which DM2 has been started left the shell with an invalid
**                pointer after DM2 has been quit -> enforcer hits!
**                This must have been in since 2.5RC4 when I switched over to
**                plain startup-code without auto-detach...
**              - Changed type of "LastI" and "lockcount" to LONG.
**
** 03-06-29 rri - Replaced IRQ-server code with timer.device based code.
**              - Moved #include <dos/rdargs.h> to DM.h
**
** 03-06-30 rri - Added an WaitIO() after the AbortIO() line.
**
** 03-07-01 rri - Introduced use of HookEntry() for EditHook to get
**                rid of the ASM and REG statements.
**
** 03-07-04 rri - Hopefully eliminated occasional delays by always calling
**                AbortIO(), WaitIO() and SetSignal() after Wait().
**
** 03-07-17 rri - Removed "__priority" as it only was a flag for the
**                SAS-C startup-code anyways.
**                Next is "__stack" but this requires some code...
**              - Set release date
**
** 2.5.24
**
** 03-07-18 rri - Set version to 2.5.24
**              - Added Stack-swapping and changed default-stack to 9000.
**
** 03-07-19 rri - Moved "Strap" over to DMSupport.c
**
** 03-07-20 rri - Removed an "else" line from main() and added init
**                to 0 to "returncode".
**
** 03-08-03 rri - Set release date
**
** 2.5.25
**
** 03-08-03 rri - Set version to 2.5.25
**
** 2.5.26
**
** 03-08-09 rri - Set version to 2.5.26
**
** 03-08-11 rri - Removed all comments from the top that were older
**                than a year (pre 2.5RC4)
**
** 03-08-16 rri - DiskMaster2 does clone the PATH now so it does make no difference
**                anymore if it's started from WB or Shell.
**                Heavily based on FixPath.c from the Term4.7 sources by Olaf Barthel!
**
** 03-08-17 rri - Rewritten AttachCLI() based on WB V44 - OS 3.5
**              - Integrated AttachCLI() into main()
**
** 03-08-31 rri - When compiled for OS4, V45 is the minimum for rexxsyslib.library.
**              - LibCreatePool() and LibDeletePool() are replaced by CreatePool()
**                and DeletePool() when compiling for OS4 now.
**              - UtilityBase is struct UtilityBase for OS4 and no longer
**                struct Library.
**              - Added (struct IORequest *) to a DeleteIORequest() line.
**
** 03-09-06 rri - Bugfix: if InitLibsPortsPools() failed (very unlikely) DM2 crashed
**                        because of a missing check if TimerBase is initialised.
**
** 03-09-07 rri - If compiled for OS4 an alternative LibOpen() comes to use now. 
**                It additionally initialises all library-interfaces
**                thru GetInterface().
**                These interfaces are freed right before CloseLibrary()
**                using DropInterface().
**                ITimer is handled separately.
**              - The OS4 version has it's own version string to be able to call
**                it an alpha-version while the 68k version is still stable.
**              - For 68k EditHook.h_Entry is "(ULONG (*)()) StringHook;" again,
**                for OS4 it's just "StringHook;".
**
** 03-09-21 rri - AppIconPath defaults to ProgName now - first step for
**                removing the internal icon.
**
** 03-09-29 rri - Removed some test-lines.
**
** 03-10-01 rri - Removed the extra versions-string for the OS4 version.
**
** 03-10-03 rri - Set release date
**
** 2.5.27
**
** 03-10-04 rri - Set version to 2.5.27
**
** 03-10-25 rri - Set release date
**
** 2.5.28
**
** 03-12-20 rri - Set version to 2.5.28
**
** 04-01-03 rri - Removed "g_memattrs" and replaced it's references with "MEMF_ANY | MEMF_CLEAR".
**              - Doubled STACKSIZE for OS4 native version.
**              - Changed the memory-attribute for allocated stack-space to MEMF_ANY.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC8)
**
** 04-01-04 rri - Set release date
**
**
*/

#include "DM.h"

#ifdef __PPC__
#define STACKSIZE 18000 /* 2.5.28 */
#else
#define STACKSIZE 9000 /* 2.5.24 */
#endif

#include <libraries/locale.h> /* 2.5RC4 rri */
#include <proto/locale.h> /* 2.5RC4 rri */

extern struct Menu      *DMMenu;
extern struct RexxMsg   *WaitRX;

extern UBYTE *AppIconPath, /* 2.5.26 rri */
             *Globuff, /* 2.5b9 rri */
             sbuff[];

extern LONG LastI, /* 2.5.23 rri */
            Notify; /* 2.5.23 rri */

extern struct TagItem reqtags_Ok[],         /* 2.5b13 jjt */
                      reqtags_OkSkipCan[];  /* 2.5b13 jjt */

struct Library       * AslBase;
struct Library       * DiskfontBase;
struct Library       * GadToolsBase; /* 2.5RC4 rri */
struct GfxBase       * GfxBase; /* 2.5RC4 rri */
struct Library       * IconBase; /* 2.5RC4 rri */
struct IntuitionBase * IntuitionBase; /* 2.5RC4 rri */
struct LocaleBase    * LocaleBase; /* 2.5RC4 rri */
struct RxsLib        * RexxSysBase;
struct Library       * WorkbenchBase;

struct Device        * TimerBase; /* 2.5RC4 rri */ /* 2.5RC9 rri */

#ifdef __PPC__ /* 2.5.26 rri */
struct UtilityBase   *UtilityBase;
#else
struct Library       * UtilityBase; /* 2.5RC4 rri */
#endif

struct Library       *LibBasePtrs[20];  /* 2.5b6 jjt (18.5.00) */

#ifdef __PPC__ /* 2.5.26 rri */

struct WorkbenchIFace  * IWorkbench = NULL;
struct DiskfontIFace   * IDiskfont = NULL;
struct AslIFace        * IAsl = NULL;
struct RexxSysIFace    * IRexxSys = NULL;
struct LocaleIFace     * ILocale = NULL;
struct GraphicsIFace   * IGraphics = NULL;
struct GadToolsIFace   * IGadTools = NULL;
struct IntuitionIFace  * IIntuition = NULL;
struct IconIFace       * IIcon = NULL;
struct UtilityIFace    * IUtility = NULL;

struct Interface       *IFacePtrs[20];

struct TimerIFace      *ITimer = NULL;
#endif


struct Screen    *Screen;
struct Process   *process;

struct MsgPort   *NotifyPort=0, /* 2.5b7 rri */
                 *TimerPort=0, /* 2.5.23 rri */
                 *WinPort=0;

struct DirWindow *DirWin[DMMAXWINDOWS],*CDWin,*DestWin,*CmdWin; /* 2.5.23 rri */
struct DirList   *DClickDir;
struct TextAttr  FuckingTopaz={"topaz.font",8,0,0};
struct StringHistory ReqHistory, PathHistory, ReadHistory;  /* 2.5b10 jjt */
struct Hook EditHook;  /* 2.5b10 jjt */
struct TextFont *DMFonts[DMFONTS_COUNT];  /* 2.5RC2 jjt */

struct timerequest *TimerIO; /* 2.5RC4 rri */

struct StackSwapStruct DM2StackSwap; /* 2.5.24 rri */

struct PathList /* from: "The Amiga Guru Book", p.571 */
{
 BPTR nextPath; /* BPTR to struct PathList */
 BPTR pathLock; /* BPTR to struct FileLock */
};

APTR CommentPool=0, /* 2.5b10 rri */
     NamePool=0, /* 2.5b10 rri */
     StringPool=0, /* 2.5b10 jjt */
     ReaderPool=0; /* 2.5b10 jjt */

int returncode=0; /* 2.5.24 rri */

LONG DMnumber=2, /* 2.5RC4 rri - vbcc */
     LibBaseTotal=0, /* 2.5b6 jjt (18.5.00) */
     lockcount, /* 2.5.23 rri */
     long_month=0; /* 2.5RC6 rri */

ULONG FLAGS=DMFLAG_KEEPGOING; /* 2.5RC6 rri */

UBYTE BarFormat[192], /* 2.5RC10 rri */
      DispFormat[22], /* 2.5RC10 rri */
      DMname[7]="DM.1",
      PGadStr[256],
      *ProgName, /* 2.5RC9 rri */
      ScreenTitle[256],
      *shellarg=NULL, /* 2.5.24 rri */
      TitleFormat[52], /* 2.5RC10 rri */
      Version[]="DiskMaster 2.5.28",
      VerstrA[]="$VER: DiskMaster 2.5.28 (2004-01-04) R.Riedel";

LONG InitLibsPortsPools(void); /* 2.5.23 rri */
void StartTimer(LONG itime); /* 2.5.23 rri */
int DM2main(void); /* 2.5.24 rri */


/* 2.5.24 rri */
int main(int argc, char *argv[])
{
struct WBStartup *Wbs;
ULONG *DM2Stack;

process=(struct Process *)FindTask(NULL);

if(argc!=0) /* started from CLI */
 {
  ProgName=argv[0];
  shellarg=argv[1];
 }
else /* started from WB */
 {
  Wbs = (struct WBStartup *) argv;

  /* 2.5.26 rri */
  if(process->pr_CLI==0) /* it should always be ZERO but this could */
   {                     /* change in the future...                 */
    struct CommandLineInterface *DestCLI;
    BPTR pathList;
#ifdef __PPC__ /* 2.5.26 rri */
    if (LibOpen("workbench", &WorkbenchBase, 44, (struct Interface **) &IWorkbench))
#else
    if (LibOpen("workbench", &WorkbenchBase, 44)) /* we need OS3.5... */
#endif
     {
      if(WorkbenchControl(NULL, WBCTRLA_DuplicateSearchPath, &pathList, TAG_DONE))
       {
        if((DestCLI = AllocDosObject(DOS_CLI,NULL)))
         {
          process->pr_CLI    = MKBADDR(DestCLI);
          process->pr_Flags |= PRF_FREECLI; /* mark for cleanup */
          DestCLI->cli_CommandDir = pathList;
         }
       }
     }
   }
  ProgName=Wbs->sm_ArgList[0].wa_Name;
  if(Wbs->sm_NumArgs>1)
   {
    shellarg=Wbs->sm_ArgList[1].wa_Name;
   }
 }

if(((ULONG)process->pr_Task.tc_SPUpper-(ULONG)process->pr_Task.tc_SPLower)<STACKSIZE)
 {
  if((DM2Stack=AllocVec(STACKSIZE,MEMF_ANY | MEMF_CLEAR))) /* 2.5.28 rri */
   {
    DM2StackSwap.stk_Lower = DM2Stack;
    DM2StackSwap.stk_Upper = (ULONG)DM2Stack+STACKSIZE;
    DM2StackSwap.stk_Pointer=(void *)(DM2StackSwap.stk_Upper-32);
    StackSwap(&DM2StackSwap);
    returncode=DM2main();
    StackSwap(&DM2StackSwap);
    FreeVec(DM2Stack);
   }
  return(returncode);
 }
else
 {
  return(DM2main());
 }
}


int DM2main(void) /* 2.5.24 rri */
{
LONG i; /* 2.5.23 rri */
struct DateTime DateTime; /* 2.5RC6 rri */
UBYTE  Date[16]; /* 2.5RC6 rri */
UBYTE *ShellName; /* 2.5.23 rri */

Forbid();
while(FindPort(DMname))
 {
  sprintf (DMname,"DM.%ld", DMnumber++);
 }
Permit();

/* test!
if(process->pr_CLI)
 {
  struct CommandLineInterface *SourceCLI;
  if(SourceCLI = BADDR(process->pr_CLI))
   {
    struct PathList *xxx;
    kprintf("Path-List:\n");
    xxx = BADDR(SourceCLI->cli_CommandDir);
    while(xxx)
     {
      NameFromLock(xxx->pathLock,sbuff,512);
      kprintf("%s\n",sbuff);
      xxx = BADDR(xxx->nextPath);
     }
    kprintf("\n");
   }
 }
*/

DMnumber--;
ShellName=process->pr_Task.tc_Node.ln_Name; /* save the name pointer for the shell */ /* 2.5.23 rri */
process->pr_Task.tc_Node.ln_Name=DMname;

/* --- init of optional libs: --- */

#ifdef __PPC__ /* 2.5.26 rri */
LibOpen("rexxsyslib", (struct Library **) &RexxSysBase, 45,(struct Interface **) &IRexxSys); /* need V45+ for OS4 */
LibOpen("diskfont", &DiskfontBase, 0, (struct Interface **) &IDiskfont);
LibOpen("asl", &AslBase, 37, (struct Interface **) &IAsl);
if (LibOpen("locale", (struct Library **) &LocaleBase, 38, (struct Interface **) &ILocale))
 {
  OpenDM2Catalog();
 }
#else
LibOpen("rexxsyslib", (struct Library **) &RexxSysBase, 0);  /* 2.5b6 jjt (18.5.00) */
LibOpen("diskfont", &DiskfontBase, 0);                       /* 2.5b6 jjt (18.5.00) */
LibOpen("asl", &AslBase, 37);                                /* 2.5b6 jjt (18.5.00) */
if (LibOpen("locale", (struct Library **) &LocaleBase, 38)) /* 2.5b13 rri */
 {
  OpenDM2Catalog();
 }
#endif

/* --- Initialize reqtags_... strings --- */
reqtags_Ok[0].ti_Data = (ULONG) msgGadOkay;             /* 2.5b13 jjt */
reqtags_OkSkipCan[0].ti_Data = (ULONG) msgGadOkSkipCan; /* 2.5b13 jjt */

/* --- var ini on startup --- */
strcpy (PGadStr,"Parent");
sprintf (DispFormat,"N S C"); /* 2.5RC8 rri */
sprintf (TitleFormat,"%%B/%%F %%I/%%C");
sprintf (BarFormat,"DiskMaster %%V  %%T   C:%%C  F:%%F  Total:%%P"); /* 2.5b9 rri */

/* --- check if months have to be displayed with four chars --- 2.5RC6 rri */
DateTime.dat_Stamp.ds_Days = 160; /* 1978-Jun-10 */
DateTime.dat_Stamp.ds_Minute = 0;
DateTime.dat_Stamp.ds_Tick = 20; /* shortly after midnight... */
DateTime.dat_Format  = FORMAT_INT; /* yy-mmm-dd e.g. 00-Jul-13 */
DateTime.dat_Flags   = 0;
DateTime.dat_StrDay  = 0;
DateTime.dat_StrDate = Date;
DateTime.dat_StrTime = 0;
DateToStr(&DateTime);
if(Date[6]!='-') long_month = 1;

if( (SysBase->LibNode.lib_Version) > 38) FLAGS|=DMFLAG_USE30; /* 2.5RC9 rri */

if(InitLibsPortsPools()) /* 2.5RC9 rri */
 {
  TimerBase = TimerIO->tr_node.io_Device; /* 2.5.23 rri */

  InitScreenDefaults();

  DMFonts[DMFONTS_MAIN]  = OpenFont(&FuckingTopaz);  /* 2.5RC2 jjt */
  DMFonts[DMFONTS_TOPAZ] = OpenFont(&FuckingTopaz);  /* 2.5RC2 jjt */
  DMFonts[DMFONTS_DIRGAD] = OpenFont(&FuckingTopaz);  /* 2.5RC2 rri */

  ReadHistory.mempool = ReaderPool;  /* 2.5b10 jjt */

  AppIconPath=CloneStr(ProgName,StringPool); /* 2.5.26 rri */

#ifdef __PPC__ /* 2.5.26 rri */
  EditHook.h_Entry = StringHook;
#else
  EditHook.h_Entry = (ULONG (*)()) StringHook;
#endif

  StrHist_Init(&ReqHistory);         /* 2.5b10 jjt */
  StrHist_Init(&PathHistory);        /* 2.5b10 jjt */
  StrHist_Init(&ReadHistory);        /* 2.5b10 jjt */

  for(i=0;i<DMMAXWINDOWS;i++) DirWin[i]=NULL; /* 2.5.23 rri */

  if(BootBatch(shellarg)) /* 2.5.24 rri */
   {
    DoWindow();

    while(FLAGS&DMFLAG_KEEPGOING) /* 2.5RC2 rri */
     {
      MainLoop(); /* 2.5b9 rri */
     }
   }

  FreeUserData(); /* 2.5RC10 rri */

  FLAGS&=~DMFLAG_KEEPGOING; /* 2.5RC2 rri */
 }

if(WinPort)    DeletePort(WinPort); /* 2.5RC10 rri */
if(NotifyPort) DeletePort(NotifyPort); /* 2.5RC10 rri */

#ifdef __PPC__ /* 2.5.26 rri */
if(CommentPool) DeletePool(CommentPool);
if(NamePool   ) DeletePool(NamePool   );
if(StringPool ) DeletePool(StringPool );
if(ReaderPool ) DeletePool(ReaderPool );
#else
if(CommentPool) LibDeletePool(CommentPool); /* 2.5RC10 rri */
if(NamePool   ) LibDeletePool(NamePool   ); /* 2.5RC10 rri */
if(StringPool ) LibDeletePool(StringPool ); /* 2.5RC10 rri */
if(ReaderPool ) LibDeletePool(ReaderPool ); /* 2.5RC10 rri */
#endif

for (i=0; i < DMFONTS_COUNT; i++) /* 2.5RC2 jjt */
 {
  if (DMFonts[i])
   {
    CloseFont(DMFonts[i]);
    DMFonts[i] = NULL;
   }
 }

if(TimerBase) /* 2.5.26 rri */
 {
  if(CheckIO(&TimerIO->tr_node) == 0) /* 2.5.23 rri */
   {
    AbortIO(&TimerIO->tr_node);
    WaitIO(&TimerIO->tr_node);
   }
  #ifdef __PPC__ /* 2.5.26 rri */
  DropInterface((struct Interface *)ITimer);
  #endif
  CloseDevice((struct IORequest *)TimerIO);
  DeleteIORequest((struct IORequest *) TimerIO); /* 2.5.26 rri */
 }

if(TimerPort)  DeletePort(TimerPort); /* 2.5.23 rri */

CloseDM2Catalog(); /* 2.5b13 rri */

for (i=0; i < LibBaseTotal; i++)
 {
  #ifdef __PPC__ /* 2.5.26 rri */
  DropInterface(IFacePtrs[i]);
  #endif
  CloseLibrary(LibBasePtrs[i]);  /* 2.5b6 jjt (18.5.00) */
 }
process->pr_Task.tc_Node.ln_Name=ShellName; /* restore the shell's name pointer */ /* 2.5.23 rri */
return 1;
}


LONG InitLibsPortsPools(void) /* 2.5.23 rri */
{
if(
#ifdef __PPC__ /* 2.5.26 rri */
    ( LibOpen("graphics", (struct Library **) &GfxBase, 37, (struct Interface **) &IGraphics) )
 && ( LibOpen("utility", (struct Library **) &UtilityBase, 37, (struct Interface **) &IUtility) )
 && ( LibOpen("gadtools", &GadToolsBase, 37, (struct Interface **) &IGadTools) )
 && ( LibOpen("intuition", (struct Library **) &IntuitionBase, 37, (struct Interface **) &IIntuition) )
 && ( LibOpen("icon", &IconBase, 37, (struct Interface **) &IIcon ) )
#else
    ( LibOpen("graphics", (struct Library **) &GfxBase, 37) )
 && ( LibOpen("utility", &UtilityBase, 37) )
 && ( LibOpen("gadtools", &GadToolsBase, 37) )
 && ( LibOpen("intuition", (struct Library **) &IntuitionBase, 37) )
 && ( LibOpen("icon", &IconBase, 37) )
#endif
 && ( WinPort=CreatePort(DMname,2) ) /* 2.5RC10 rri */
 && ( NotifyPort=CreatePort(0,0) )

 /* 2.5.23 rri */
 && ( TimerPort=CreatePort(0,0) )
 && ( TimerIO=(struct timerequest *)CreateIORequest(TimerPort,sizeof(struct timerequest)) )
 && ( OpenDevice("timer.device",UNIT_VBLANK,&TimerIO->tr_node,0) == 0 )

#ifdef __PPC__ /* 2.5.26 rri */
 && ( ITimer=(struct TimerIFace *)GetInterface((struct Library *) TimerIO->tr_node.io_Device, "main", 1, NULL) )

 && ( CommentPool= CreatePool(MEMF_ANY | MEMF_CLEAR,  8100,  100 ) ) /* 2.5.28 rri */
 && ( NamePool   = CreatePool(MEMF_ANY | MEMF_CLEAR, 16384, 1024 ) ) /* 2.5.28 rri */
 && ( StringPool = CreatePool(MEMF_ANY | MEMF_CLEAR, 20000, 2000 ) ) /* 2.5.28 rri */
 && ( ReaderPool = CreatePool(MEMF_ANY | MEMF_CLEAR,  1200, 1000 ) ) /* 2.5.28 rri */
#else
 && ( CommentPool= LibCreatePool(MEMF_ANY | MEMF_CLEAR,  8100,  100 ) ) /* 2.5.28 rri */
 && ( NamePool   = LibCreatePool(MEMF_ANY | MEMF_CLEAR, 16384, 1024 ) ) /* 2.5.28 rri */
 && ( StringPool = LibCreatePool(MEMF_ANY | MEMF_CLEAR, 20000, 2000 ) ) /* 2.5.28 rri */
 && ( ReaderPool = LibCreatePool(MEMF_ANY | MEMF_CLEAR,  1200, 1000 ) ) /* 2.5.28 rri */
#endif
  )
 {
  return 1;
 }
return 0;
}


#ifdef __PPC__ /* 2.5.26 rri */
BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver, struct Interface **iface)
{
if (*base == 0)
 {
  UBYTE puffer[120];
  sprintf(puffer,"%s.library",name);
  if ((*base = OpenLibrary(puffer, ver)) == 0) return FALSE;
  LibBasePtrs[LibBaseTotal] = *base;
  if ((*iface = GetInterface(*base, "main", 1, NULL)) == 0)
   {
    CloseLibrary(*base);
    *base=NULL;
    LibBasePtrs[LibBaseTotal]=NULL;
    return FALSE;
   }
  IFacePtrs[LibBaseTotal++] = *iface;
 }
return TRUE;
}
#else
BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver) /* 2.5b6 jjt */
{
if (*base == 0)
 {
  UBYTE puffer[120]; /* 2.5RC6 rri */
  sprintf(puffer,"%s.library",name); /* 2.5RC6 rri */
  if ((*base = OpenLibrary(puffer, ver)) == 0) return FALSE; /* 2.5RC6 rri */
  LibBasePtrs[LibBaseTotal++] = *base;
 }
return TRUE;
}
#endif


void MainLoop(void) /* 2.5b9 rri */
{
struct DirWindow *dw;
LONG t,i,wincount; /* 2.5.23 rri */
ULONG sig;
ULONG notifymask = 1L << NotifyPort->mp_SigBit; /* 2.5b7 rri */
ULONG timermask = 1L << TimerPort->mp_SigBit; /* 2.5.23 rri */
ULONG winmask = 1L << WinPort->mp_SigBit; /* 2.5.23 rri */
struct NotifyMessage *note; /* 2.5b7 rri */
struct DateStamp now;
static LONG itime=1; /* 2.5.23 rri */
static LONG Minutes=0;

if(lockcount) /* a dir-window is busy */
 {
  t=0;
  for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
   {
    dw=DirWin[i];
    if(dw) GetDirEntry(dw);
    if(dw&&dw->DirLock) t=1;
   }
  if(!t)
   {
    lockcount=0;
    if(WaitRX)
     {
      ReplyMsg((struct Message *)WaitRX);
      WaitRX=0;
     }
   }
  DoWindow();
 }

else /* waiting for some action... */
 {
  StartTimer(itime); /* 2.5.23 rri */
  sig=Wait(winmask|notifymask|timermask); /* 2.5.23 rri */

  /* always break TimerIO and clear signal */ /* 2.5.23 rri */
  AbortIO(&TimerIO->tr_node);
  WaitIO(&TimerIO->tr_node);
  SetSignal(0L,timermask);

  if(sig & winmask) /* 2.5.23 rri */
   {
    MainTitle();
    DoWindow();
   }

  if (sig & notifymask) /* 2.5b7 rri */
   {
    while((note=(struct NotifyMessage *)GetMsg(NotifyPort))) /* 2.5.23 gcc rri */
     {
      ReplyMsg((struct Message *)note);
     }
    ReSort(); /* 2.5b7 rri */
   }

  if(sig & timermask) /* 2.5.23 rri */
   {
    wincount=0; /* 2.5b3 rri */
    while(DirWin[wincount])
     {
      if(DirWin[wincount]->Window->Flags&WFLG_WINDOWACTIVE)
       {
        itime=1+Notify; /* 2.5b9 rri */
        break;   /* 2.5b6 jjt (11.6.00) */
       }
      else
       {
        itime=4;
        wincount++;
       }
      }

    DClickDir=0;
    LastI=(-1); /* 2.5b10 rri */

    if(CDWin) /* 2.5b3 rri */
     {
      DateStamp(&now); /* get current system time */
      if (now.ds_Minute>Minutes) /* check if a new minute began */
       {
        Minutes=now.ds_Minute; /* update the minute-counter var */
        MainTitle(); /* 2.5b2 rri */
        SetTitles(); /* 2.5b2 rri */
       }
      if(!(CDWin->dir_gad.Flags&GFLG_SELECTED))
       {
        ReSort();
       }
     }
   }
 }
}


void StartTimer(LONG itime) /* 2.5.23 rri */
{
TimerIO->tr_time.tv_secs=itime;
TimerIO->tr_time.tv_micro=0;
TimerIO->tr_node.io_Command=TR_ADDREQUEST;

SendIO(&TimerIO->tr_node);
}
