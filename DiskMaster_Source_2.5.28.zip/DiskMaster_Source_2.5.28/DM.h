/* DiskMaster II global definition Module
**
** 2.5RC4
**
** 02-06-30 rri - Added compiler-dependant definitions.
**              - Modified prototypes for TimerCode() and StringHook()
**
** 02-07-14 rri - Added includes for Timer.device and sorted includes
**
** 02-08-11 rri - Removed MakeDestName() from DMParser.c
**
** 2.5RC6
**
** 02-10-03 rri - Removed "Notified" from struct DirWindow and moved it's
**                function to DM2NotifyReq.nr_UserData.
**
** 02-10-20 rri - Added a few comments to struct DirWindow.
**
** 02-10-27 rri - Removed FreeAutoCmds() from DMCommands.c
**              - Removed FreeKeyCmds() from DMKey.c
** 02-10-28 rri - Removed *Ptr from struct DirWindow - it never ever was used!!
**              - Added "BYTE *UserData" comment for struct Window to struct
**
** 02-12-07 rri - Changed "Title" from struct DirWindow from array of chars
**                to string-pointer - uses pooled memory now.
**              - Changed "Path" from struct DirWindow from array of chars
**                to string-pointer - uses pooled memory now.
**
** 02-12-15 rri - Added include for debug-protos.
**
** 02-12-16 rri - New function in DMSupport.c : CloneBuffer()
**
** 2.5RC7
**
** 02-12-25 rri - Added comment to struct DirWindow->ColsCmt
**
** 02-12-29 rri - Added "Collums" to struct DirWindow as ColFudge replacement.
**              - Changed prototype for DoFileFormat()
**
** 2.5RC9
**
** 03-01-01 jjt - Added DMREQ_PROTREQ tag.
**
** 03-01-09 jjt - Added CharPos() prototype to DMSupport.c.
**
** 03-01-18 rri - Reduced includes to the necessary minimum.
**              - Replaced SAS-C include math.h by min()/max() defines.
**              - Removed the old "new!" type version-tag comments.
**              - Removed StormC compiler definitions.
**
** 03-01-21 rri - Reworked includes again.
**              - Added __amigainterrupt to VBCC defines.
**
** 03-01-25 rri - Added prototype for DMstrcat() to DMSupport.c.
**              - Changed AArg2Str() Prototype.
**
** 2.5RC10
**
** 03-02-28 rri - Removed prototype for sel_file() -> DMWindows.c "private"
**              - Changed prototype for CloseDirWindow()
**              - Changed prototype for ActionCmd()
**
** 03-03-01 rri - Added "Number" to struct DirWindow.
**              - Renamed FreeUserJunk() to FreeUserData()
**
** 03-03-15 rri - Added DMLayoutMenus() to DMMenus.c
**
** 03-04-19 rri - Added prototype for DMstrncpy() to DMSupport.c
**              - Removed proto for DMSetFormat() from DMParser.c
**              - Removed proto for FilterStar() from DMSupport.c
**
** 03-04-21 rri - Removed proto for MakeFullName() from DMParser.c
**
** 03-04-22 rri - Changed proto for ParseArgs() in DMParser.c
**
** 03-04-23 rri - Transformed proto for ParseArgs() into SplitLine()
**
** 03-04-24 rri - Moved protos for AddAutoCmd(), DMArchive(), DMSelect()
**                and AddCmd() to DMCommands.c were they belong...
**
** 2.5.23
**
** 03-05-16 jjt - Added outputRexxVar() prototype to DMRexx.c.
**
** 03-05-18 rri - Added includes for <utility/utility.h> and <proto/bullet.h>
**                to avoid errors with the OS4 inlines for Olaf Barthel's GCC.
**              - Moved include <graphics/gfxmacros.h> down below <proto/Graphics.h>,
**                OS4 gcc...
**              - Moved the <proto/reqtools.h> include to DMPalette.c, it's not
**                needed anywhere else anyway.
**              - Changed proto for TimerCode() in DM.c, this version compiles
**                without warning and works with both GCC and SAS-C
**
** 03-05-19 rri - Modified proto for ParseScreenArgs() to (void) to avoid
**                a warning from GCC.
**
** 03-05-30 rri - Introduced DMMAXWINDOWS.
**              - Moved struct TDat back to DM.c.
**              - Removed protos for StartTimer(), TimerCode(), SaveMenus(),
**                SaveScreen(), SaveWindows() and SaveWin() as there is no need
**                to have these available globally.
**              - Removed INTERRUPT and STDARGS from compiler definitions
**                as there are not used.
**
** 03-06-22 rri - Removed protos for StartTimer() and TimerCode(),
**                this time for real...
**              - Re-Integrated INTERRUPT compiler defines.
**
** 03-06-29 rri - Removed INTERRUPT compiler defines again...
**              - Moved #include <dos/rdargs.h> in from DM.c
**              - Removed #include <hardware/intbits.h>
**
** 03-07-01 rri - Modified proto for StringHook().
**
** 03-07-04 rri - Added forgotten SAVEDS to proto for StringHook().
**              - Removed ASM and REG compiler defines.
**
** 03-07-06 rri - Added SAVEDS definition for Amithlon.
**
** 2.5.24
**
** 03-07-27 rri - Added proto for DMFileReq() to DMRequester.c.
**
** 2.5.26
**
** 03-08-08 jjt - Added DMREQ_FILEREQ tag.
**
** 03-08-10 jjt - Removed pre-2.5RC4 comments from top.
**
** 03-08-31 rri - Added SAVEDS for OS4 PPC GCC.
**              - Added conditional "#include <stdio.h>" for OS4 PPC GCC.
**
** 03-09-05 rri - Replaced compiler-defines by amiga_compiler.h from OS4 SDK.
**
** 03-09-07 rri - Removed MakeRexxMsg() and GetID() from DMRexx.c.
**              - Added alternative prototype for LibOpen().
**
** 03-09-30 rri - Disabled DMReq()
**
** 2.5.27
**
** 03-10-25 rri - Modified proto for DMFileReq().
**
**
*/

#include <amiga_compiler.h>

#define INTUI_V36_NAMES_ONLY 1

#define __USE_SYSBASE /* 2.5b10 rri */

#include <string.h>
#include <stdlib.h> /* qsort...*/

#include <exec/types.h> /* 2.5RC9 rri */

#include <devices/inputevent.h>  /* 2.5b5 jjt */
#include <devices/timer.h> /* 2.5RC4 rri */
#include <dos/dostags.h>
#include <dos/rdargs.h> /* 2.5.23 rri */
#include <intuition/gadgetclass.h> /* 2.5b5 jjt */
#include <intuition/icclass.h>     /* 2.5b5 jjt */
#include <intuition/imageclass.h>  /* 2.5b5 jjt */
#include <Intuition/sghooks.h>
#include <exec/execbase.h> /* 2.5b10 rri */ /* vbcc! */
#include <utility/utility.h> /* 2.5.23 gcc rri */

#include <clib/alib_protos.h>    /* 2.2b5 jjt / hys */

#ifdef __PPC__ /* 2.5.26 rri */
#include <stdio.h>
#endif
#include <clib/alib_stdio_protos.h> /* 2.5RC9 rri */

#include <clib/debug_protos.h> /* 2.5RC6 rri */ /* kprintf("!\n"); */

#include <proto/amigaguide.h>
#include <proto/asl.h>
#include <proto/bullet.h> /* 2.5.23 gcc rri */
#include <proto/diskfont.h>
#include <proto/dos.h>
#include <proto/exec.h>
#include <proto/gadtools.h>
#include <proto/graphics.h>
#include <graphics/gfxmacros.h>  /* 2.5b5 jjt */
#include <proto/icon.h>
#include <proto/iffparse.h> /* 2.5b7 jjt (24.06.00) */
#include <proto/intuition.h>
#include <proto/rexxsyslib.h>
#include <proto/timer.h>
#include <proto/utility.h>  /* 2.5b5 jjt */
#include <proto/wb.h>
#include <proto/xfdmaster.h> /* 2.5b6 jjt */
#include <proto/xpkmaster.h> /* 2.5b6 jjt */

#include "DMLocale.h" /* 2.5b13 rri */

#define max(a,b) ((a) >  (b) ? (a) : (b)) /* 2.5RC9 rri */
#define min(a,b) ((a) <= (b) ? (a) : (b)) /* 2.5RC9 rri */

#define sFIB struct FileInfoBlock

#define ACTION(rmp) (rmp->rm_Action)
#define RESULT1(rmp) (rmp->rm_Result1)
#define RESULT2(rmp) (rmp->rm_Result2)

#define DWFLAG_RESORT 1
#define DWFLAG_ADD 2
#define DW_CMD (1<<2)
#define DWFLAG_RELOAD (1<<3)
#define DW_SOURCE (1<<4)
#define DW_DEST (1<<5)

#define RECURSE_DEL   1
#define RECURSE_COPY  2
#define RECURSE_MOVE  3
#define RECURSE_PROT  (1<<2)
#define RECURSE_REN   (1<<3)
#define RECURSE_EXEC  (1<<4)
#define RECURSE_FIND  (1<<5)
#define RECURSE_NOTE  (1<<6)
#define RECURSE_SHOW  (1<<7)
#define RECURSE_READ  (1<<8)
#define RECURSE_AUTO  (1<<9)
#define RECURSE_REXX  (1<<10)
#define RECURSE_DATE  (1<<11)
/* 2.5b5 rri
#define RECURSE_PRINT (1<<12)
*/
#define RECURSE_CHECK (1<<13)
#define RECURSE_PACK  (1<<14)

/* --- Global BOOL flags --- */ /* 2.5RC2 rri */

#define DMFLAG_ABORT      1
#define DMFLAG_AUTOFILING (1<<1)
#define DMFLAG_ATTR       (1<<2)
#define DMFLAG_BATCH      (1<<3)
#define DMFLAG_CHGCMD     (1<<4) /* change command */
#define DMFLAG_CONFIRM    (1<<5)
#define DMFLAG_DCLICK     (1<<6) /* double-click */
#define DMFLAG_EXPAND     (1<<7)
#define DMFLAG_EXALL      (1<<8) /* use ExAll() or not */
#define DMFLAG_FORCE      (1<<9)
#define DMFLAG_KEEPGLOBAL (1<<10) /* don't free global buffer */
#define DMFLAG_KEEPGOING  (1<<11)
#define DMFLAG_KEEPSEL    (1<<12) /* keep selected */
#define DMFLAG_LOOP       (1<<13)
#define DMFLAG_NOTIFY     (1<<14)
#define DMFLAG_PATREQ     (1<<15) /* pattern requester */
#define DMFLAG_QUIET      (1<<16)
#define DMFLAG_REC        (1<<17) /* recurse */
#define DMFLAG_RESET      (1<<18)
#define DMFLAG_RESORT     (1<<19)
#define DMFLAG_SKIP       (1<<20)
#define DMFLAG_SINGLE     (1<<21)
#define DMFLAG_TESTWARN   (1<<22)
#define DMFLAG_UNMARK     (1<<23)
#define DMFLAG_USE30      (1<<24)
#define DMFLAG_WINTITLE   (1<<25)


/* --- ActionArg Types, passed to GetActionArg() --- */
#define AATYPE_BOOL        1   /* 2.5b5 jjt */
#define AATYPE_STR         2   /* 2.5b5 jjt */
#define AATYPE_NUM         3   /* 2.5b5 jjt */
#define AATYPE_NEXTSTR     4   /* 2.5b6 jjt */
#define AATYPE_TRUENEXTSTR 5   /* 2.5RC3 jjt */

#define STRHIST_MAX 15   /* 2.5b10 jjt */

/* --- Requester Tags (StrReq() & EasyReq()) ---  2.5b10 jjt */
/* (Explained in DMReqTagList() in DMRequester.c )           */
#define DMREQ_TITLE      0x90000001
#define DMREQ_BUTTONS    0x90000002
#define DMREQ_ABORT      0x90000003
#define DMREQ_SCREEN     0x90000004
#define DMREQ_HISTORY    0x90000005
#define DMREQ_MINW       0x90000006  /* 2.5RC2 jjt */
#define DMREQ_DEFBTN     0x90000007  /* 2.5RC2 jjt */
#define DMREQ_PROTREQ    0x90000008  /* 2.5RC9 jjt */
#define DMREQ_FILEREQ    0x90000009  /* 2.5.26 jjt */

/* --- Flags to filter Device List's Display --- */  /* 2.5b12 jjt */
#define SHOWDEV_DEV  1
#define SHOWDEV_VOL  2
#define SHOWDEV_ASN  4
#define SHOWDEV_ALL  7

#define DEVHIDELIST_MAX 100  /* 2.5b12 jjt */

/* 2.5RC2 jjt */
/* - DMFONTS_MAIN up to, but not including, DMFONTS_SCREEN will be saved with the
     Font cmd. by SaveConfig.
   - Anything less than DMFONTS_TOPAZ should also have an entry in the FontKeywords
     array in DMCommands.c.
*/
#define DMFONTS_MAIN     0
#define DMFONTS_DIRGAD   1
#define DMFONTS_REQTXT   2
#define DMFONTS_REQBTN   3
#define DMFONTS_MENU     4
#define DMFONTS_SCREEN   5
#define DMFONTS_TMPFIXED 6
#define DMFONTS_TMPPROP  7
#define DMFONTS_TOPAZ    8
#define DMFONTS_COUNT    9

/* Macro:  Get TextFont name */ /* 2.5RC2 jjt */
#define GetTFName(tf) tf->tf_Message.mn_Node.ln_Name

/* 2.5.23 rri */
/* maximum amount of dir/cmd-windows */
#define DMMAXWINDOWS 255


struct BaseConvert
 {
  LONG  DiskFree,BytesPerBlock,BlocksFree;
  UBYTE String[15]; /* 2.5b7 rri */
 };


struct DirList /* 2.5b10 rri */
 {
  struct DateStamp ds;
  LONG attr,
       dir,
       sel,
       size;
  UBYTE *name, /* 2.5b10 rri */
        *cmt;
};


struct DirWindow /* 2.5b10 rri */
 {
  struct DateStamp PathDate;
  struct DirList **DirList;
  struct FileInfoBlock *Fib; /* fib_Date */
  struct Gadget dir_gad,     /* APTR UserData  dir_gad.UserData=PathHistory */
                v_gad,h_gad,
                up,dn,lf,rt,
                parent;
  struct Image v_img,h_img;
  struct NotifyRequest DM2NotifyReq; /* ULONG nr_UserData = notified flag ! */
  struct PropInfo v_prop,h_prop;
  struct StringInfo dir_str;
  struct StringExtend SExt;
  struct Window *Window; /* BYTE *UserData; */
  LONG   BlocksFree,
         BytesPerBlock,
         ColsCmt, /* &0xFFF=cols comments- >>12=cols file-sizes - 2.5RC7 rri */
         Collums, /* 2.5RC7 rri */
         ColsName,
         DiskFree,
         Edge,
         FileCount,
         Flags,
         Index,
         MaxFile,
         Number, /* 2.5RC10 */
         Rows,
         Sels,
         Sorting;
  UBYTE  *Path,*Title,Pattern[32]; /* 2.5RC6 rri */
  BPTR   DirLock;
  WORD   zoom[4]; /* 2.5b13 rri */
  WORD   norm[4]; /* 2.5b13 rri */
 };


struct XFile {  /* 2.5b6 jjt */
  /* Returned by AutoUnpack.  Use FreeXFile() to dispose. */
  UBYTE                *data;      /* Data buffer */
  ULONG                 len;       /* Amount of data in buffer */
  ULONG                 buflen;    /* Total size of buffer */
  struct xfdBufferInfo *xinfo;     /* May be NULL if XFD lib doesn't exist */
  LONG                  dataisbin; /* TRUE if there's a 0 in the 1st 512 bytes of .data */ /* 2.5b7 jjt (7.7.00) */
};


struct StringHistory {  /* 2.5b10 jjt */
/*   struct SignalSemaphore sema4; */
  APTR                   mempool;
  UBYTE                  *strcache[STRHIST_MAX];
  UWORD                  lencache[STRHIST_MAX];
  ULONG                  total;
  ULONG                  cachepos;
};


/* DM.c */

#ifdef __PPC__ /* 2.5.26 rri */
BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver, struct Interface **iface);
#else
BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver); /* 2.5b6 jjt */
#endif
void MainLoop(void); /* 2.5b9 rri */


/* DMCommands.c */

void AddAutoCmd(UBYTE *str);
void DMArchive(UBYTE *cmd,UBYTE *name);
void DMSelect(int sel);
void AddCmd(struct DirWindow *dw,UBYTE *buf);
void DoStdio(UBYTE *str);
void GetParent(UBYTE *path,int parent); /* 2.5b6 rri */
void DMReqPat(void);
void DoSwap(void);
int  UnLockAll(void);
void ResetFlags(void);
void GetCmdFile(struct DirWindow *dw,UBYTE *name,LONG size); /* 2.5b10 rri */
void AutoFiler(struct DirWindow *dw,UBYTE *name);
void EditCmd(struct DirWindow *dw,int ni);
void ParseCmd1(struct DirList *dlp,UBYTE *buf);
void DMSet(void); /* 2.5b7 rri */
void CMD_DevList(void);  /* 2.5b12 jjt */
void CMD_Font(void);     /* 2.5RC2 jjt */
void CMD_HideDev(void);  /* 2.5b12 jjt */
/* new! 2.2b14
void MultiSelect(int i);
void SingleName(int i);
*/


/* DMConfig.c */

void SaveConfig(void);
void Iconify(void); /* 2.5b7 rri */


/* DMDisk.c */

int  DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new);
void DMRename(UBYTE *old);
void SmartRename(UBYTE *old,UBYTE *new);
void DMComment(UBYTE *name,UBYTE *str,sFIB *fib);
void DMProtect(UBYTE *name,UBYTE *str,sFIB *fib);
void DMSetFileDate(UBYTE *dir,sFIB *fib);
void SmartRemEntry(UBYTE *name);
void SmartAddEntry(UBYTE *name);
ULONG DMCopy(UBYTE *s,UBYTE *dest,sFIB *fib, int opt); /* 2.5b13 rri */
void DMMakeDir(UBYTE *name);
void MakeIcon(UBYTE *name);
void Dupe(void);
void SwapSelect(void);
ULONG DMOpenFont(ULONG idx, STRPTR name, ULONG size); /* 2.5RC2 jjt */
void View(UBYTE *file);
void InfoReq(UBYTE *file);
void DOSExecute(void);
void DOSStart(int StackSize);
void CheckSpace(void);
void PrintDir(void); /* 2.5b9 rri */
void DMSetDate(void);


/* DMKey.c  - 2.4b18 */

void AddKeyCmd(UBYTE *str);
void DoKeyCmd(struct DirWindow *dw,UWORD code,UWORD qual,ULONG class);
ULONG CheckAbortKey(void); /* 2.5RC2 rri */


/* DMMenus.c */

VOID menu_on(VOID);  /* 2.5b10 rri */
VOID menu_off(VOID); /* 2.5RC2 jjt */
LONG DMLayoutMenus(VOID); /* 2.5RC10 rri */
VOID AddMenuCmd(UBYTE *);
VOID MyFreeMenus(VOID);


/* DMPack.c */

void           DMPack(UBYTE *name, sFIB *fib, int comp);  /* 2.5b6 jjt */
struct XFile * AutoUnpack(UBYTE *name);      /* 2.5b6 jjt */
struct XFile * NewXFile(void);               /* 2.5b7 jjt */
void           FreeXFile(struct XFile *xf);  /* 2.5b6 jjt */


/* DMPalette.c */

void SetColors(void);
void SetPens(void);
void AllocPens(void); /* 2.5b12 rri */


/* DMParser.c */

void RefreshCmdWin(struct DirWindow *dw);
void StartRec(int type);
int  DMRecurse(int lenS,int lenD,int opt);
int  addname(UBYTE *path,UBYTE *name,int len);
void SplitLine(UBYTE *buf,struct DirWindow *dw); /* 2.5RC10 rri */
void ActionCmd(ULONG num,UBYTE *buf); /* 2.5RC10 rri */


/* DMRead.c */

void   DMRead(UBYTE *file);  /* 2.5b5 jjt */
void   CloseRead(void);


/* DMRequester.c */

void Busy(int i); /* 2.5b7 rri */
void CMD_Choose(void);  /* 2.5b7 jjt (3.7.00) */
LONG REQ_FileExists(sFIB *srcfib, sFIB *destfib);  /* 2.5b13 jjt */
void About(void);
/* LONG DMReq(CONST_STRPTR body, STRPTR dest, ULONG cmax, ULONG tags, ...); 2.5.26 rri */
LONG DMReqTagList(CONST_STRPTR body, STRPTR dest, ULONG cmax, struct TagItem *tags);  /* 2.5b10 jjt */
void MakeBtnString(const UBYTE yes[], const UBYTE middle[], const UBYTE no[]); /* 2.5b13 rri */
void StrHist_Init(struct StringHistory *sh);   /* 2.5b10 jjt */
/*void StrHist_Clear(struct StringHistory *sh);*/  /* 2.5b10 jjt */
void StrHist_Add(struct StringHistory *sh, STRPTR str);  /* 2.5b10 jjt */
ULONG SAVEDS ASM StringHook(REG(a0,struct Hook *hk),REG(a2,struct SGWork *swork),REG(a1, ULONG *msg)); /* test! */
/* ULONG SAVEDS StringHook(struct Hook *hk,struct SGWork *swork,ULONG *msg);*/  /* 2.5.23 rri */
STRPTR DMFileReq(STRPTR file, STRPTR path, BOOL save); /* 2.5.27 rri */


/* DMRexx.c  - 2.2b15 */

void outputRexxVar(UBYTE *cont); /* 2.5b13 rri */
int  do_rexx_cmd(struct RexxMsg *rm);
void SendRexx(void);
void doDirList(void);
void doSetList(UBYTE *var);
void RexxStatus(void);
void Filestat(void); /* 2.5b5 rri */
void WinInfo(void); /* 2.5b5 rri */
void RXCMD_GetHistory(void);  /* 2.5b11 jjt */


/* DMScreen.c - 2.2b13 */

int  CheckScreen(void);
void GetHostScreen(UBYTE *str);
void GetDRI(struct Screen *s);
void InitScreenDefaults(void);
void ParseScreenArgs(void); /* 2.5.23 rri - set to (void) */
struct Screen *NewOpenScreen(int n,UBYTE *);

/* 2.5b6 rri
struct Screen *ReadOpenScreen(int n,UBYTE *);
*/

struct Screen *DMOpenScreen(ULONG Width,ULONG Height,ULONG ID,UWORD Depth,UBYTE *name); /* 2,5b10 rri */


/* DMSort.c  - 2.2b15 */

void DMSortN(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortS(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortD(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortC(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
int  cmpnameU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpnameD(struct DirList **val1,struct DirList **val2);
int  cmpsizeU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpsizeD(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpdateU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpdateD(struct DirList **val1,struct DirList **val2);
int  cmpcmtU(struct DirList **val1,struct DirList **val2);
int  cmpcmtD(struct DirList **val1,struct DirList **val2);
void Sort(void);
void GlobalSort(void);
void SetSortFlag(struct DirWindow *dw, int c);
void DMSort(struct DirWindow *dw);
void ReSort(void);
void ResortAll(void);


/* DMSupport.c */

void StrToUpper(UBYTE *str); /* 2.5b7 rri */
LONG GetActionArg(STRPTR keyword, UBYTE type, LONG def); /* 2.5b5 jjt */
BOOL IsDir(STRPTR name); /* 2.5b6 jjt */
UBYTE *SkipWhite(UBYTE *ptr);
BOOL AArg2Str(STRPTR keyword, STRPTR dest, ULONG length, BOOL upper, STRPTR def); /* 2.5b6 jjt */ /* 2.5RC9 rri */
void display(const UBYTE format[],UBYTE *arg1); /* 2.5b13 rri */
void QuoteCat(UBYTE *ptr,UBYTE *name);
int  NeedQuote(UBYTE *ptr);
int  DMMatch(UBYTE *string,UBYTE *pattern); /* 2.5b7 rri */
void RefreshWindows(void); /* 2.5b7 rri */
void StampProt(UBYTE *str,LONG prot);
int  GetGlobuff(void); /* 2.5b7 rri */
void FreeGlobuff(void);
void FindCmdWin(void); /* 2.5b7 rri */
int  DOSParse(UBYTE *str,const UBYTE *hail,int i);
APTR   PoolAllocVec(APTR mempool, ULONG size); /* 2.5b10 jjt */
void   PoolFreeVec(APTR memptr);               /* 2.5b10 jjt */
STRPTR CloneStr(CONST_STRPTR str, APTR mempool);     /* 2.5b10 jjt */
void CloneBuffer(struct DirWindow *dw,UBYTE *str); /* 2.5RC6 rri */
void FreeUserData(void); /* 2.5RC10 rri */
void SetTitles(void); /* 2.5b10 rri */
struct DirWindow *FindDMWin(struct Window *win); /* 2.5b10 rri */
int BootBatch(UBYTE *ptr); /* 2.5b10 rri */
ULONG Char2Nibble(ULONG c);  /* 2.5b11 jjt */
void RefreshDevLists(void);  /* 2.5b12 jjt */
int  FindPattern(UBYTE *str);
void Separate(struct DirWindow *dw);
void CheckMonth(void); /* 2.5b13 rri */
void FontToAttr(struct TextFont *font, struct TextAttr *attr);  /* 2.5RC2 jjt */
LONG CharPos(UBYTE c, STRPTR str);  /* 2.5RC9 jjt */
void DMstrcat(UBYTE *dest,const UBYTE *source); /* 2.5RC9 rri */
void DMstrncpy(UBYTE *dest, const UBYTE *source, ULONG size); /* 2.5RC10 rri */


/* DMWinContent.c */ /* 2.5b13 rri */

void ConvertBase(struct BaseConvert *basecon);
void ReSize(struct DirWindow *dw);
void MainTitle(void);
void WinTitle(struct DirWindow *dw);
void DoFileFormat(struct DirList *dlp,struct DirWindow *dw); /* 2.5RC7 rri */
void GetDevList(struct DirWindow *dw);
void InitDir(struct DirWindow *dw,int set);
void GetDirEntry(struct DirWindow *dw);
void Fib2Dlp(struct DirList *dlp,sFIB *fib);
int  AllocDlp(struct DirWindow *dw);
int  GetNewPath(struct DirWindow *dw);
int  DiskShadow(struct DirWindow *dw,sFIB *fib);
void FreeDirTable(struct DirWindow *dw);


/* DMWindows.c */

void DoWindow(void);
void SetHoriz(struct DirWindow *dw);
void SetVert(struct DirWindow *dw);
void dis_name(struct DirWindow *dw,LONG file,LONG pos);
void rdis_files(struct DirWindow *dw);
void dis_files(struct DirWindow *dw);
void Increment(struct DirWindow *dw,struct Gadget *gad,LONG lines); /* 2.5b10 rri */
void HorSlide(struct DirWindow *dw,struct Gadget *gad,LONG lines); /* 2.5b10 rri */
void ShowDirection(struct DirWindow *dw,int n);
void NewSize(struct DirWindow *dw);
void slide_em(struct DirWindow *dw,struct Gadget *gad);
void FindNewDirection(struct DirWindow *dw);
void CloseDirWindow(ULONG num);
int  OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi);
struct Window *OpenSharedWindow(struct NewWindow *nw);
void CloseSharedWindow(struct Window *w);
void RefreshGadget(struct Gadget *,struct Window *);
