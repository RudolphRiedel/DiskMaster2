/* DiskMaster II Rename/Comment/Protect/Filedate/Copy/Move/MakeDir/MakeIcon
**
** 2.5RC9
**
** 03-01-09 jjt - Changed ProtBuff to a LONG (holds protection bits instead of string).
**              - DMProtect() - Moved string parsing to top (the new protection req.
**                doesn't return strings).
**              - DMProtect() - Now uses the new protection req.
**
** 03-01-24 jjt - DMProtect() - The protection req. is back to being localized.
**
** 03-01-25 rri - Added "DMREQ_ABORT, 0" to DMReq() in DMProtect().
**              - Replaced some strcat() calls by DMstrcat() calls.
**              - Replaced one strncpy() call by a CopyMem() call.
**              - Bugfix: 'Font'�did not work with e.g. "topaz.FONT"
**
** 2.5RC10
**
** 03-02-22 rri - Corrected an AddPart() call in DMCopy() to use 4000 bytes
**                as maximum for the resulting path.
**              - Corrected a DMReq() call in DMMakeDir() to use 4000 bytes
**                as maximum for the requested string.
**              - Removed some "new! ..." style comments.
**              - Changed display() in DMCopy() to only print out the filename
**                on 'Copy'/'Move' to fix a buffer-overflow with very long paths.
**
** 03-02-25 rri - Partly rewritten 'View' to make use of "NewGuide.nag_Lock",
**                text.datatype crashes on long paths in "NewGuide.nag_Name"...
**
** 03-02-28 rri - Fixed the fix in DMCopy() for display() messages to also
**                work with the progress-display.
**              - Simplified creation of progress-string.
**
** 2.5.23
**
** 03-05-30 rri - Removed quite a few GCC warnings.
**              - Introduced DMMAXWINDOWS.
**
** 2.5.24
**
** 03-07-19 rri - Added a Busy(1)/Busy(0) pair to DMOpenFont()
**
** 2.5.26
**
** 03-08-10 rri - Bugfix: old comment-strings were not released on 'Comment' which
**                        let the memory pools grow without reason.
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC4)
**
** 03-09-07 rri - Added OS4 PPC support thru alternative LibOpen().
**
** 03-09-29 rri - Removed some test-lines.
**              - Replaced two DMReq() calls by DMReqTagList() calls.
**
** 03-10-01 rri - Removed the "test!" status from the DMReqTagList() stuff.
**
** 2.5.27
**
** 03-10-25 rri - Added file-requester to 'PrintDir'.
**
** 2.5.28
**
** 04-01-03 rri - Removed the allocations for timev1 and timev2 from DMCopy().
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC8)
**
*/


#include "DM.h"

extern struct DateStamp setStamp; /* 2.5b10 rri */
extern struct DirWindow *DirWin[],*DestWin,*CDWin;
extern struct FileInfoBlock Fib;
extern struct Library   *AslBase;
extern struct Screen    *Screen;
extern struct StringHistory PathHistory;  /* 2.5b10 jjt */
extern struct TagItem reqtags_OkSkipCan[];  /* 2.5b13 jjt */
extern struct Library *WorkbenchBase;

extern struct TDat TimerData; /* 2.5RC3 rri */

extern UBYTE *ActionArgs[],
             dcPath[],
             DOSPassStr[],
             g_buttons[], /* 2.5b13 rri */
             *Globuff,
             Pattern[],
             sbuff[],
             ScreenTitle[],
             sPath[],
             Version[],
             FontKeywords[][15];  /* 2.5RC2 jjt */

extern BPTR StdIO;

extern LONG BlkTotal,
            BPB,
            Globuff_size;

extern ULONG FLAGS; /* 2.5b10 rri */

extern APTR NamePool; /* 2.5b10 rri */

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */

extern struct TextFont *DMFonts[];  /* 2.5RC2 jjt */

struct TextAttr MAttr;
struct InfoData InfoData;

struct Library *AmigaGuideBase;

#ifdef __PPC__ /* 2.5.26 rri */
struct AmigaGuideIFace *IAmigaGuide = NULL;
#endif


LONG ProtBuff;  /* 2.5RC9 jjt */


void UpdateDlp(struct DirList *dlp,UBYTE *name);
void AddNewDlp(struct DirWindow *dw,UBYTE *name);
ULONG ParseCpMvArgs(UBYTE *s, UBYTE *dest, int move);  /* 2.5b13 jjt */


int DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new)
{
UBYTE  *ptr=name,*ptr2=sbuff+1;

if(*dev==0) return(0);

if(!new)
 {
  if(ptr) while(*ptr&&*ptr!=':') *ptr2++=(*ptr++); /* 2.5b10 rri */
  *ptr2=0;
  sprintf(sbuff+52,msgReqRelabel,dev); /* 2.5b13 rri */
  if(!DMReqTagList(sbuff+52, sbuff+1, 31, 0) || !sbuff[1]) return(0);  /* 2.5b10 jjt */
 }
else strcpy(sbuff+1,new);
sbuff[0]=(UBYTE)strlen(sbuff+1);
return Relabel(dev,sbuff+1);
}


void DMRename(UBYTE *old)
{
UBYTE *ptr,*new=ActionArgs[2];
sFIB  *fib=(&Fib); /* 2.5b10 rri */
BPTR  lock; /* 2.5b5 rri */

if(!old) return;

if(!new)
 {
  strcpy(dcPath,old);
  new=dcPath;
  ptr=new+strlen(new)-1;
  while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
  if (DMReqTagList(msgReqRename, ptr+1, 107, reqtags_OkSkipCan) != 1) return;  /* 2.5b13 jjt */
 }

if((lock=Lock(old,ACCESS_READ))) /* 2.5.23 rri */
 {
  UnLock(lock); /* 2.5b6 rri */
  if(!Rename(old,new)) FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
  else
   {
    ptr=new+strlen(new)-1; /* place the pointer at the end of the string */
    while(!(lock=Lock(new,ACCESS_READ))&&*ptr!=':') /* 2.5b6 rri */
     {
      *ptr=0; /* Lock() wasn`t sucessfull, shorten string by */
      ptr--;  /* one char and try again */
     }
    if(!lock) /* if Lock() wasn`t sucessfull at all, leave DMRename() */
     {
      FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
      return;
     }
    while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
    if(Examine(lock,fib))
     {
      CopyMem(fib->fib_FileName,ptr+1,107); /* 2.5RC9 rri */
     }
    UnLock(lock);
    if(Strnicmp(new,old,(ptr-new))) /* 2.5C6 rri */
     {
      SmartRemEntry(old);
      SmartAddEntry(new);
     }
    else SmartRename(old,new);
   }
 }
}


void SmartRename(UBYTE *old,UBYTE *new)
{
struct DirWindow *dw;
struct DirList **dl;
UBYTE *ptr;
LONG i,j,c,len; /* 2.5b10 rri */

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(Strnicmp(old,dw->Path,len)) continue; /* 2.5RC6 rri */
  if(Stricmp(old,dw->Path)==0) /* 2.5b7 rri */
   {
    CloneBuffer(dw,new); /* 2.5RC6 rri */
    RefreshGadgets(&dw->dir_gad,dw->Window,0);
    continue;
   }
  ptr=old+len; dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue; /* rename dev/cmd file */
  if(*ptr=='/')
   {
    ptr++;
    len++;
   }
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=old+len;

  for(j=0;j<dw->FileCount;j++)
   if(Stricmp(ptr,dl[j]->name)==0) /* 2.5b7 rri */
    {
     PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
     dl[j]->name = CloneStr(new+len, NamePool); /* 2.5b10 rri */
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
     dw->Flags|=DWFLAG_RESORT;
     break;
    }
 }
}


void DMComment(UBYTE *name,UBYTE *str,sFIB *fib)
{
if(!name) return;
if(!str)
 {
  str=fib->fib_Comment;
  sprintf(sbuff,msgReqComment,fib->fib_FileName); /* 2.5b13 rri */
  if (DMReqTagList(sbuff, str, 80, reqtags_OkSkipCan) != 1) return;  /* 2.5b13 jjt */
 }
if (Stricmp(str,"##")==0) /* 2.5b7 rri */
 {
  *str=0;
 }

if(!SetComment(name,str)) FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
else SmartAddEntry(name);
}


void DMProtect(UBYTE *name,UBYTE *str,sFIB *fib)
{
LONG    choice, /* 2.5RC9 jjt */
        x,incl=(-1); /* 2.5b10 rri */
UBYTE   c;

if(!name) return;
if(!(FLAGS&DMFLAG_ATTR)) /* 2.5RC2 rri */
 {
  ProtBuff = fib->fib_Protection;  /* 2.5RC9 jjt */

  if(str)
   {
    ProtBuff ^= 15;  /* Reverse RWED bits */  /* 2.5RC9 jjt */
    while((c=ToUpper((ULONG)*str++))) /* 2.5.23 gcc rri */
    {
      x=0;
      switch(c)
      {
        case '+': incl=1; break;
        case '-': incl=0; break;
        case 'H': x=128; break;
        case 'S': x=64; break;
        case 'P': x=32; break;
        case 'A': x=16; break;
        case 'R': x=8; break;
        case 'W': x=4; break;
        case 'E': x=2; break;
        case 'D': x=1; break;
        case 'G': FLAGS|=DMFLAG_ATTR; /* 2.5RC2 rri */
        default : break;
      }
      if(incl<0&&x){ProtBuff=0; incl=1;} /* 2.5RC9 jjt */
      if (x) {                           /* 2.5RC9 jjt */
        if (incl) ProtBuff |= x;         /* 2.5RC9 jjt */
        else ProtBuff &= ~x;             /* 2.5RC9 jjt */
      }
    }
    ProtBuff ^= 15;  /* RWED bits back to normal. */  /* 2.5RC9 jjt */
   }
  else
   { /* 2.5RC9 jjt */
    struct TagItem protreqtags[]={{DMREQ_BUTTONS,0},{DMREQ_PROTREQ, (ULONG) &ProtBuff}, /* 2.5.26 rri */
                                  {DMREQ_ABORT, 0},{TAG_END,0}};
    protreqtags[0].ti_Data = (ULONG) msgGadProtect; /* 2.5.26 rri */
    sprintf(sbuff, msgReqProtect, fib->fib_FileName);
    choice = DMReqTagList(sbuff, 0, 0, protreqtags); /* 2.5.26 rri */
    if (choice == 2)
     {
      FLAGS |= DMFLAG_ATTR;
      choice = 1;
     }
    if (choice != 1) return;
   }
 }

if(!SetProtection(name, ProtBuff)) FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
else SmartAddEntry(name);
}


void DMSetFileDate(UBYTE *dir,sFIB *fib)
{
 SetFileDate(dir,&fib->fib_Date);
 SmartAddEntry(dir);
}


void SmartRemEntry(UBYTE *name)
{
struct DirWindow *dw;
struct DirList **dl,*dlp;
UBYTE  *ptr;
LONG i,j,c,len; /* 2.5b10 rri */

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(Strnicmp(name,dw->Path,len)) continue; /* 2.5RC6 rri */
  ptr=name+len;
  dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue;
  if(*ptr==0)
   {
    CloneBuffer(dw,0); /* 2.5RC6 rri */
    InitDir(dw,0);
    continue;
   }
  if(*ptr=='/') ptr++;
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=name+len;
  if(*ptr=='/') ptr++;

  for(j=0;j<dw->FileCount;j++)
   {
    dlp=dl[j];
    if(dlp&&(Stricmp(ptr,dlp->name)==0)) /* 2.5b7 rri */
     {
      dlp->sel=2;
      dlp->dir=(-1); /* 2.5b10 rri */
      dw->Flags|=DWFLAG_RESORT;
      c=dw->Index;
      if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
      break;
     }
   }
 }
}


void SmartAddEntry(UBYTE *name)
{
struct DirWindow *dw;
struct DirList  **dl;
UBYTE           *ptr;
LONG i,j,c,len; /* 2.5b10 rri */

for(i=0;i<DMMAXWINDOWS;i++) /* 2.5.23 rri */
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(Strnicmp(name,dw->Path,len)!=0) continue; /* 2.5RC6 rri */
  ptr=name+len;
  dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue;
  if(len&&dw->Path[len-1]!=':'&&*ptr!='/') continue;
  if(*ptr=='/') ptr++;
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=name+len;
  if(*ptr=='/') ptr++;
  for(j=0;j<dw->FileCount;j++)
   if(Stricmp(ptr,dl[j]->name)==0) /* 2.5b7 rri */
    {
     PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
     dl[j]->name=0;
     if(dl[j]->cmt) PoolFreeVec(dl[j]->cmt); /* 2.5.26 rri */
     dl[j]->cmt=0; /* 2.5.26 rri */
     UpdateDlp(dl[j],name);
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows))
      {
       dis_name(dw,j,j-c);
      }
     dw->Flags|=DWFLAG_RESORT;
     break;
    }
   if(j==dw->FileCount)
    {
     AddNewDlp(dw,name);
     dw->Flags|=DWFLAG_RESORT;
     Increment(dw,&dw->dn,1);
     SetVert(dw);
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows))
      {
       ReSize(dw); /* 2.5RC7 rri */ /* update dw->ColsName, dw->ColsCmt etc */
       DoFileFormat(dw->DirList[j],dw); /* 2.5RC7 rri */ /* format string */
       dis_name(dw,j,j-c); /* 2.5RC7 rri */ /* display dir-entry */
/*
       len=strlen(dw->DirList[j]->name);
       if(len>dw->ColsName)
        {
         dw->ColsName=len;
         dis_files(dw);
         WinTitle(dw);
        }
       else
        {
         dis_name(dw,j,j-c);
        }
*/
      }
    }
 }
}


void UpdateDlp(struct DirList *dlp,UBYTE *name)
{
sFIB *fib=(&Fib); /* 2.5b10 rri */
BPTR lock; /* 2.5b5 rri */

if((lock=Lock(name,ACCESS_READ))) /* 2.5.23 gcc rri */
 {
  if(Examine(lock,fib))
   {
    Fib2Dlp(dlp,fib);
   }
  UnLock(lock);
 }
}


void AddNewDlp(struct DirWindow *dw,UBYTE *name)
{
 if(AllocDlp(dw)) UpdateDlp(dw->DirList[dw->FileCount++],name);
}


ULONG ParseCpMvArgs(UBYTE *s, UBYTE *dest, int move) /* 2.5b13 jjt */
{
LONG  newer;
BPTR  fIn, fOut;
sFIB  srcfib, destfib, *dfptr;

if (Stricmp(s, dest) == 0) /* Src = Dest?   */
 {
  if (move==3)                /* Move - Exit.  */
   {
    FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
    return 0;
   }
  else DMstrcat(dest, ".BAK"); /* Copy - Append ".BAK". */ /* 2.5RC9 rri */
 }

if (GetActionArg("RENAME", AATYPE_BOOL, 0))
 {
  rename:
  if (DMReqTagList(msgReqRename, FilePart(dest), 107, reqtags_OkSkipCan) != 1) return 0;  /* 2.5b13 jjt */
 }

if((fOut=Lock(dest,ACCESS_READ))) /* Dest exists? */ /* 2.5.23 gcc rri */
 {
/* kprintf("desten: %ld\ndest: %s\n\n",strlen(dest),dest); */ /* test! */
  dfptr = (Examine(fOut, &destfib)) ? &destfib : (sFIB *) NULL;
  UnLock(fOut);

  if((fIn = Lock(s, ACCESS_READ))) /* 2.5.23 gcc rri */
   {
    Examine(fIn, &srcfib);
    UnLock(fIn);
   }

  if (GetActionArg("NEWER", AATYPE_BOOL, 0))
   {
    newer = dfptr ? CompareDates(&destfib.fib_Date, &srcfib.fib_Date) : 0;
    if (newer<=0) return 0;
   }

  else if (FLAGS&DMFLAG_SKIP) /* 2.5RC2 rri */
   {
    FLAGS|=DMFLAG_KEEPSEL; /* 2.5RC2 rri */
    return 0;
   }

  else if ((FLAGS&DMFLAG_TESTWARN) && GetActionArg("WARN", AATYPE_BOOL, 0)) /* 2.5RC2 rri */
   {
    switch(REQ_FileExists(&srcfib, dfptr)) /* 2.5b13 rri */
     {
      case 0: return 0;
      case 2: FLAGS&=~DMFLAG_TESTWARN; break; /* 2.5RC2 rri */
      case 3: goto rename;
      case 4: FLAGS|=DMFLAG_SKIP; FLAGS|=DMFLAG_KEEPSEL; return 0; /* 2.5RC2 rri */
      case 5: FLAGS|=DMFLAG_KEEPSEL; return 0; /* 2.5RC2 rri */
     }
   }

  if (GetActionArg("FORCE", AATYPE_BOOL, 0)) SetProtection(dest, 0);
 }

return 1;
}


ULONG DMCopy(UBYTE *s,UBYTE *dest,sFIB *fib,int opt)
{
UBYTE *ptr;
LONG  i=0, /* 2.5RC4 rri vbcc */
      cp,  /* 2.5b13 jjt */
      bufend, /* 2.5.23 gcc rri */
      rate=0,
      status, /* 2.5.23 rri */
      read_size, onepercent; /* 2.5RC2 rri */
BPTR  fIn,fOut; /* 2.5b5 rri */

AddPart(dest, FilePart(s), 4000); /* 2.5RC10 rri */

cp = ParseCpMvArgs(s, dest, opt); /* 2.5b13 rri */

if(!cp)
 {
  return 0; /* 2.5b13 rri */
 }
if (cp)  /* 2.5b13 jjt */
 {
  if(!Globuff) /* 2.5b7 rri */
   {
    if(!GetGlobuff())
     {
      return 0;
     }
   }
  read_size=Globuff_size; /* 2.5RC2 rri */
  if(opt==RECURSE_MOVE)
   {
    if(Rename(s,dest)) /* try to move-by-rename */
     {
      SmartAddEntry(dest);
      SmartRemEntry(s);
      return 0; /* DMRecurse won't need to delete the file */
     }
   }
  sprintf(sbuff,(opt==RECURSE_MOVE) ? msgStatMoving : msgStatCopying,FilePart(s)); /* 2.5RC10 rri */
  bufend=strlen(sbuff); /* 2.5.23 gcc rri */
  display(sbuff,0); /* 2.5RC3 rri */
  if((fIn=Open(s,MODE_OLDFILE))) /* 2.5.23 gcc rri */
   {
    if((fOut=Open(dest,MODE_NEWFILE))) /* 2.5.23 gcc rri */
     {
      struct timeval timev1,timev2; /* 2.5.28 rri */
      status=1;

      /* 2.5RC2 rri */
      /* This part does a speed-check with a small block (4K) if the file
         in question is bigger than 16K.
         On slow drives (4k * 1000000 / micro-secs needed = bytes/secs) with bytes/secs
         < 40960 bytes the read-size is adapted to the data-rate to have the following
         progress-display updated more often during file-copying.
         At 40960 bytes per second the 128 KB buffer would be full every 3.2 seconds which
         means that this is the maximum refresh-rate for this case.
         For modem connections - e.g. using FTP: - I have around 4k per second - 32 seconds
         refresh-rate - just awfull.
         So the read-size is lowered to the data-rate to have the display updated
         once every second. It won't get smaller than 4k though.
      */
      if(fib->fib_Size>32768)
       {
        GetSysTime(&timev2);
        i=Read(fIn,Globuff,4096);
        if(i)
         {
          status=Write(fOut,Globuff,i);
         }
        GetSysTime(&timev1);
        SubTime(&timev1,&timev2);
        timev1.tv_micro+=timev1.tv_secs*1000000;
        if(timev1.tv_micro>80000)
         {
          rate=1000000/timev1.tv_micro*4096; /* 2.5.23 gcc rri */
          if(read_size>rate)
           {
            read_size=rate;
           }
          if (read_size<4096) read_size=4096;
         }
        rate=4096;
       }
      cp = ((4*read_size)<fib->fib_Size) ? 1 : 0; /* recylced var ! */
      onepercent=fib->fib_Size/100;
      GetSysTime(&timev1);
      /* 2.5RC2 */

      while((status>0&&(i=Read(fIn,Globuff,read_size))>0)&&(!(FLAGS&DMFLAG_ABORT))) /* 2.5RC2 rri */
       {
        CheckAbortKey();
        status=Write(fOut,Globuff,i);
        /* 2.5RC2 rri */ /* simple progress-display */
        if(cp)
         {
          rate+=i;
          GetSysTime(&timev2);
          if ((timev2.tv_secs-timev1.tv_secs)>0||rate==fib->fib_Size) /* 2.5RC4 rri */
           {
            sprintf(sbuff+bufend," - %ld %%%%",rate/onepercent); /* 2.5.23 gcc rri */
            display(sbuff,0);
            GetSysTime(&timev1);
           }
         }
        if(status!=i) /* 2.5b9 rri */
         {
          status=(-1); /* 2.5b10 rri */
         }
       }
      Close(fOut);
      if(status==-1||i==-1||(FLAGS&DMFLAG_ABORT)) /* 2.5RC2 rri */
       {
/* modified but removed in 2.5b9 - rri
        Fault(IoErr(),NULL,Globuff,FAULT_MAX);
        display(Globuff,0);

Display() is useless here as it will be overwritten instantly
by "Operation Aborted" when Abort=1 is returned...
*/
        DeleteFile(dest);
        FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
       }
      else
       {
        if(fib->fib_Comment[0]) SetComment(dest,fib->fib_Comment);
        if(fib->fib_Protection) SetProtection(dest,fib->fib_Protection);
        DMSetFileDate(dest,fib);
       }
      ptr = FilePart(dest);
      *ptr=0;
     }
    else
     {
      FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
     }
    Close(fIn);
   }
  else
   {
    FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
   }
 }
return (ULONG) ((FLAGS&DMFLAG_ABORT) == 0); /* 2.5RC2 rri */
}


void DMMakeDir(UBYTE *name)
{
ULONG n; /* 2.5.26 rri */
BPTR lock; /* 2.5b5 rri */
UBYTE *ptr;

if((n=GetActionArg("ICON", AATYPE_BOOL, 0)) == 1) /* 2.5RC2 jjt */
 {
  name=0;
  n = 2;
 }

if(!name)
 {
  struct TagItem mkdirtags[]={{DMREQ_BUTTONS,(ULONG) g_buttons}, /* 2.5.26 rri */
                              {DMREQ_HISTORY,(ULONG) &PathHistory},
                              {DMREQ_DEFBTN, 0},{TAG_END,0}};
  mkdirtags[2].ti_Data = n; /* 2.5.26 rri */

  name=sPath;
  if(*name==0) return;
  ptr=name+strlen(name)-1;
  if(*ptr++!=':')
   {
    *ptr++='/';
    *ptr=0;
   }
  MakeBtnString(0, msgGadIcon, 0);  /* 2.5RC2 jjt  */
  
  n=DMReqTagList(msgReqMakeDir, name, 4000, mkdirtags); /* 2.5.26 rri */

  if(!n) return; /* 2.5b10 jjt */
 }

if((lock=Lock(name,ACCESS_READ))) /* 2.5.23 gcc rri */
 {
  UnLock(lock);
 }

else if((lock=CreateDir(name))) /* 2.5.23 gcc rri */
 {
  UnLock(lock);
  SmartAddEntry(name);
  if(n==2)
   {
    MakeIcon(name);
    DMstrcat(name,".info"); /* 2.5RC9 rri */
    SmartAddEntry(name);
   }
 }
else FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
}


void MakeIcon(UBYTE *name)
{
struct DiskObject *dob;
UBYTE  *ptr;

ptr=name+strlen(name);
if(Stricmp((ptr-5),".info")!=0) /* 2.5b13 rri */
 {
  if((dob=GetDiskObjectNew(name))) /* 2.5.23 gcc rri */
   {
    PutDiskObject(name,dob);
    FreeDiskObject(dob);
   }
 }
}


void Dupe(void)
{
UBYTE  *ptr;
struct DirList **Source,**Dest;
int     i=1,c,comment=0,date=0,name=0,size=0,select=1,state;

while(ActionArgs[i])
 {
  ptr=ActionArgs[i];
  switch(*ptr)
   {
    case 'c':
    case 'C': comment=1;
              break;
    case 'd':
    case 'D': date=1;
              break;
    case 'n':
    case 'N': name=1;
              break;
    case 's':
    case 'S': size=1;
              break;
    case '-': select=0;
              break;
   }
  i++;
 }

Source=CDWin->DirList;
Dest=DestWin->DirList;

if (comment||date||name||size)
 {
  for(i=0;i<CDWin->FileCount;i++)
   {
    if (Source[i]->sel!=select)
     {
      for(c=0;c<DestWin->FileCount;c++)
       {
        state=0;

        if(comment)
         {
          if (Source[i]->cmt&&Dest[c]->cmt)
           {
            if (Stricmp(Source[i]->cmt,Dest[c]->cmt)==0) /* 2.5b7 rri */
             {
              state+=comment;
             }
           }
         }
        if (date)
         {
          if (CompareDates(&Source[i]->ds,&Dest[c]->ds)==0)
           {
            state+=date;
           }
         }
        if (name)
         {
          if(Stricmp(Source[i]->name,Dest[c]->name)==0) /* 2.5b7 rri */
           {
            state+=name;
           }
         }
        if (size&&(Source[i]->dir<1)&&(Dest[c]->dir<1))
         {
          if (Source[i]->size==Dest[c]->size)
           {
            state+=size;
           }
         }
        if (state==(comment+date+name+size))
         {
          Source[i]->sel=select;
         }

       } /* endfor (c... */
     } /* endif (Source... */
   } /* endfor (i... */
  } /* endif (comment||date... */
dis_files(CDWin);
WinTitle(CDWin);
}


void SwapSelect(void)
{
struct DirList **Source;
int     i;

Source=CDWin->DirList;

for(i=0;i<CDWin->FileCount;i++)
 {
  if (Source[i]->sel)
   {
    Source[i]->sel=0;
   }
  else Source[i]->sel=1;
 }
dis_files(CDWin);
WinTitle(CDWin);
}


ULONG DMOpenFont(ULONG idx, STRPTR name, ULONG size) {  /* 2.5RC2 jjt */
  UBYTE  fname[256], title[100];
  ULONG ok=FALSE, success=FALSE, fixedw;
  struct FontRequester *freq=NULL;
  struct TextAttr attr;
  struct TextFont *font=NULL;

  fixedw = (idx == DMFONTS_MAIN) || (idx == DMFONTS_TMPFIXED);

  if (DiskfontBase) {
    if (!name || *name == 0) {
      if (AslBase) {
        sprintf(title, "Font: %s", FontKeywords[idx]);
        name=GetTFName(DMFonts[idx]); /* 2.5RC4 rri */
        size=DMFonts[idx]->tf_YSize; /* 2.5RC4 rri */
        freq = AllocAslRequest (ASL_FontRequest, NULL);
        if (freq)
         {
          Busy(1); /* 2.5.24 rri */
          if (AslRequestTags(freq, ASLFO_Screen,         Screen,
                                   ASLFO_TitleText,      title,
                                   ASLFO_MaxHeight,      24,
                                   ASLFO_InitialName, name, /* 2.5RC4 rri */
                                   ASLFO_InitialSize, size, /* 2.5RC4 rri */
                                   ASLFO_FixedWidthOnly, fixedw,
                                   TAG_DONE))
           {
            CopyMem(&freq->fo_Attr, &attr, sizeof (struct TextAttr));
            ok = TRUE;
           }
          Busy(0); /* 2.5.24 rri */
         }
      }
    }
    else {
      strcpy(fname, name);
      if (strlen(fname)<5 || (Stricmp(fname+strlen(fname)-5,".font") != 0)) DMstrcat(fname, ".font"); /* 2.5RC9 rri */
      attr.ta_Name =  fname;
      attr.ta_YSize = size;
      attr.ta_Style = FS_NORMAL;
      attr.ta_Flags = 0; /* 2.5RC4 rri vbcc */
      ok = TRUE;
    }

    if (ok) font = OpenDiskFont(&attr);

    if (font && fixedw) {
      /* --- Reject proportional fonts when needed --- */
      if (font->tf_Flags & FPF_PROPORTIONAL) {
        display(msgErrorPropFont,0); /* 2.5b13 rri */
        CloseFont(font);
        font = NULL;
      }
    }

    if (font) {
      if (DMFonts[idx]) CloseFont(DMFonts[idx]);
      DMFonts[idx] = font;
      success = TRUE;
    }

    if (freq) FreeAslRequest(freq);
  }

  return success;
}


void View(UBYTE *file) /* 2.5RC10 rri */
{
struct NewAmigaGuide *NewGuide; /* 2.5.23 gcc rri */
UBYTE *path,*name;
BPTR lock;
AMIGAGUIDECONTEXT Context;

#ifdef __PPC__ /* 2.5.26 rri */
if(!AmigaGuideBase) LibOpen("amigaguide", &AmigaGuideBase, 37, (struct Interface **) &IAmigaGuide);
#else
if(!AmigaGuideBase) LibOpen("amigaguide", &AmigaGuideBase, 37);
#endif

if(AmigaGuideBase)
 {
  /* UBYTE text[]="Wish"; UBYTE *node = text; LONG line =148;  */
  if((NewGuide=PoolAllocVec(NamePool,sizeof(struct NewAmigaGuide)))) /* 2.5.23 gcc rri */
   {
    path=CloneStr(file, NamePool);
    name=CloneStr(FilePart(file), NamePool);
    *PathPart(path)=0;
    if((lock=Lock(path,ACCESS_READ))) /* 2.5.23 gcc rri */
     {
      NewGuide->nag_Name = (STRPTR) name;
      NewGuide->nag_Lock = lock;
      NewGuide->nag_Screen = Screen;
  /*  NewGuide->nag_Node = node; NewGuide->nag_Line = line;  */

      /* Open the AmigaGuide client */
      if((Context=OpenAmigaGuideA(NewGuide,NULL))) /* 2.5.23 gcc rri */
       {
        CloseAmigaGuide(Context); /* Close the AmigaGuide client */
       }
      UnLock(lock);
     }
    PoolFreeVec(path);
    PoolFreeVec(name);
    PoolFreeVec(NewGuide); /* 2.5.23 gcc rri */
   }
 }
}


void InfoReq(UBYTE *file)
{
BPTR lock; /* 2.5b5 rri */
UBYTE  *ptr;

ptr=file+strlen(file);
if(Stricmp((ptr-5),".info")==0) /* 2.5b13 rri */
 {
  ptr[-5]=0;
 }

#ifdef __PPC__ /* 2.5.26 rri */
if (!LibOpen("workbench", &WorkbenchBase, 37, (struct Interface **) &IWorkbench)) return;
#else
if (!LibOpen("workbench", &WorkbenchBase, 37)) return;  /* 2.5RC6 rri */
#endif
if(CDWin&&CDWin->Path[0])
 {
  if((lock=Lock(CDWin->Path,ACCESS_READ))) /* 2.5.23 gcc rri */
   {
    WBInfo(lock, file, Screen);
    UnLock(lock);
   }
 }
else /* 2.5b13 rri */
 {
  if((lock=Lock(file,ACCESS_READ))) /* 2.5.23 gcc rri */
   {
    if(NameFromLock(lock,sbuff,500)) /* 2.5RC2 rri */
     {
      WBInfo(lock,sbuff, Screen);
     }
    UnLock(lock);
   }
 }
}


void DOSExecute(void) /* 2.5b9 rri */
{
UBYTE *ptr=DOSPassStr;
int StackSize=8192,i=1;

if (GetActionArg("s=",AATYPE_BOOL,0)==i) /* if arg "s=" is first arg then */
 {
  StackSize=GetActionArg("s",AATYPE_NUM,8192); /* check if for the stack-option */
  i++;
 }

if (StackSize<8192)
 {
  StackSize=8192;
 }

*ptr=0;

if(DOSParse(ptr,msgReqDOSExec,i))
 {
  DOSStart(StackSize); /* 2.5b9 rri */
 }
}


void DOSStart(int StackSize)
{
BPTR ext_path=0; /* 2.5RC4 rri vbcc */

if(CDWin&&CDWin->Path[0])
 {
  ext_path = Lock(CDWin->Path, ACCESS_READ);
 }

SystemTags(DOSPassStr,
           SYS_Input, StdIO?StdIO:Input(),
           SYS_Output, NULL,
           SYS_UserShell, TRUE,
           NP_CurrentDir, ext_path,
           NP_StackSize, StackSize,
           TAG_END);
}


void CheckSpace(void)
{
BPTR lock;
struct BaseConvert checkbase;

if(!CDWin->Path[0])
 {
  if((lock=Lock(ActionArgs[1],ACCESS_READ))) /* 2.5.23 gcc rri */
   {
    Info(lock,&InfoData);
    CDWin->BytesPerBlock=InfoData.id_BytesPerBlock;
    UnLock(lock);
   }
 }

if(DestWin&&DestWin->BytesPerBlock)
 {
  BPB=DestWin->BytesPerBlock;
 }
else
 {
  BPB=CDWin->BytesPerBlock;
 }
if(!BPB)
 {
  return;
 }

StartRec(RECURSE_CHECK);

checkbase.BlocksFree=BlkTotal;
checkbase.BytesPerBlock=BPB;
ConvertBase(&checkbase);

strcpy(sbuff,checkbase.String); /* 2.5b13 rri */

if(DestWin)
 {
  if(BlkTotal>DestWin->BlocksFree)
   {
    sprintf(ScreenTitle,msgErrorCheckSpace,sbuff); /* 2.5b13 rri */
   }
  else
   {
    checkbase.BlocksFree=DestWin->BlocksFree-BlkTotal;
    ConvertBase(&checkbase);
    sprintf(ScreenTitle,msgStatCheckSpace,sbuff,checkbase.String); /* 2.5b13 rri */
   }
 }

display(ScreenTitle,0);
FLAGS|=DMFLAG_WINTITLE; /* 2.5RC2 rri */
}


void PrintDir(void) /* 2.5b9 rri */
{
BPTR PrintFileHandle;
struct DirList **PrintList;

/* 2.5.27 rri */
LONG i;
UBYTE *name=ActionArgs[2];

if(!name||*name==0)
 {
  name=DMFileReq(0,CDWin->Path,TRUE);
 }

if(!name||*name==0)
 {
  FLAGS|=DMFLAG_ABORT;
  return;
 }


PrintList=CDWin->DirList;

if(GetGlobuff()) /* we always need a clear buffer so we call the function... */
 {
  if((PrintFileHandle=Open(name,MODE_NEWFILE))) /* 2.5.27 rri */
   {
    sprintf(Globuff,msgStatPrintDir,CDWin->Path); /* 2.5b13 rri */

    for(i=0;i<CDWin->FileCount;i++)
     {
      if (PrintList[i]->sel==1)
       {
        DoFileFormat(PrintList[i],CDWin); /* 2.5RC7 rri */
        sbuff[CDWin->Collums-1]=0; /* 2.5RC7 rri */
        DMstrcat(Globuff,sbuff); /* 2.5RC9 rri */
        DMstrcat(Globuff,"\n"); /* 2.5RC9 rri */
        PrintList[i]->sel=0;
       }
     }

    Write(PrintFileHandle,Globuff,(LONG)strlen(Globuff)); /* 2.5b10 rri */
    Close(PrintFileHandle);
   }
 }

dis_files(CDWin);
WinTitle(CDWin);


/*

if(Stricmp(ActionArgs[2],"PRT:")==0)
 {
  sprintf(dcPath,"\x1b[0m%s\x1b[0m\n",sbuff);
  dcPath[2]=WorkDlp->dir?'1':'0';
 }
else sprintf(dcPath,"%s\n",sbuff);

*/

}


void DMSetDate()
{
DateStamp(&setStamp);
StartRec(RECURSE_DATE);
}
