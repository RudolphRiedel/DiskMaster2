/* DiskMaster2 requester module
**
** 2.5RC8
**
** 03-01-05 rri - Set year in copyright-note to 2003.
**
** 2.5RC9
**
** 03-01-09 jjt - DMReqTagList() - Added DMREQ_PROTREQ option; creates a protection-bit req.
**
** 03-01-10 jjt - DMReqTagList() - Replaced Borders with BOOPSI FrameIClass image.
**
** 03-01-24 jjt - DMReqTagList() - Protect buttons are now square.
**                               - Changed protect button order to H,S,P,A,R,W,E,D.
**                               - Protect buttons now use DMFONT_REQBTN.
**
** 03-01-25 rri - Added a minor contribution to DMReqTagList():
**                      - Protect buttons text is centered.
**                      - Increased spacing between protect buttons to 7 pixel.
**              - Replaced some strcat() calls by DMstrcat() calls.
**              - Replaced a strncpy() call by a CopyMem() call.
**
** 2.5.23
**
** 03-05-16 jjt - CMD_Choose() - Added STRING arg to create a string requester.
**                             - Added BTNVAR arg - ARexx var to hold the button pressed
**                               when using Choose as a string req.
**
** 03-05-31 rri - Fixed a few warnings from GCC.
**              - Introduced DMMAXWINDOWS.
**
** 03-06-22 rri - Requester windows are opened in the center of the visible
**                part of the screen now.
**                Suggested by Bonnie Dalzell <bdalzell@qis.net>.
**
** 03-07-01 rri - The introduction of HookEntry() in DM.c allowed to
**                make the proto for StringHook() much simpler.
**              - Replaced copyright-symbol in About() by "(c)" as it's not
**                present in all font-sets supported by OS4.
**
** 03-07-04 rri - Added forgotten SAVEDS to StringHook()...
**
** 03-07-17 rri - Changed "DiskMaster II" to "DiskMaster2" in About()
**
** 2.5.24
**
** 03-07-20 rri - DMReqTagList(): the window-title is also used to compute the
**                minimum width of a requester-window now.
**
** 03-07-21 rri - DMReqTagList(): instead of a constant the screens depth-gadget
**                width is added to the length of the window-title text now.
**
** 03-07-27 rri - Updated REQ_FileExists() to meet the requirements of
**                'SaveConfig' which only knows a dest-file but no source-file.
**
** 03-07-28 rri - Added DMFileReq().
**
** 2.5.26
**
** 03-08-08 jjt - DMReqTagList():  Added DMREQ_FILEREQ tag.
**              - Added the constant GID_FILEREQ (GadgetID for filereq button).
**
** 03-08-10 jjt - Removed pre-2.5RC4 comments from top.
**              - CMD_Choose() - Added "FILEREQ" arg.
**              - Added MakeFReqGlyph().
**              - Added FreeFreqGlyph().
**              - DMReqTagList() - The string gadget now uses the button font instead of
**                the req. text font.
**
** 03-08-17 jjt - DMReqTagList() - The string gadget is back to using the req. text font. :-)
**              - CMD_Choose() - Using FILEREQ automatically adds a string req.  No need to
**                also specify STRING.
**
** 03-08-18 jjt - DMReqTagList() - Bugfix:  Req. wouldn't be centered if screen was smaller
**                than its native res.
**                - Thanks for reporting to Rudolph Riedel <rudolph-riedel@t-online.de> ;-)
**
** 03-09-07 rri - Restored prototype for StringHook() as HookEntry() is not
**                available with OS4.
**
** 03-09-20 rri - The amount of struct Requester pointers is connected
**                to DMMAXWINDOWS now.
**              - Changed EMail-address in about-window.
**              - Splitted some lines for the requester-window calculation into
**                smaller operations as the OS4 ppc version seems to fail there.
**
** 03-09-29 rri - Removed some test-lines.
**              - Replaced three DMReq() calls by DMReqTagList() calls.
**
** 03-10-01 rri - Removed DMReq()
**              - Removed the "test!" status from the DMReqTagList() stuff.
**
** 2.5.27
**
** 03-10-25 rri - Added "STRPTR path" to DMFileReq().
**              - Modified one DMFileReq() call.
**
**�2.5.28
**
** 03-12-20 rri - Bugfix: the "File exist" warning requesters without source-file
**                        (like for 'SaveConfig') had no gadgets.
**
** 04-01-03 rri - Removed external reference to g_memattrs.
**              - Added MEMF_ANY to one allocation in Busy() - just to make it 105% correct...
**              - Removed all comments from the top that were older
**                than a year (pre 2.5RC8)
**              - Set year in copyright-note to 2004.
**
*/


#include "DM.h"


/* 2.5.26 jjt */
#define GID_FILEREQ 128


ULONG strtoarray(APTR mempool, CONST_STRPTR str, UBYTE **strary, ULONG arymax, struct RastPort *rp, ULONG *widest);  /* 2.5b10 jjt */
void  restorestrcontents(struct SGWork * swork);  /* 2.5b10 jjt */
struct Border * MakeFReqGlyph(UWORD *pens, ULONG height);  /* 2.2.26 jjt */
void FreeFReqGlyph(struct Border *glyph);  /* 2.5.26 jjt */


extern UBYTE                Version[], ReqStr[], *rexxStr, /* 2.5b7 jjt (3.7.00) */
                            ActionArgs[],
                            sbuff[], /* 2.5b13 rri */
                            dcPath[]; /* 2.5.23 jjt */

extern ULONG                FLAGS, /* 2.5RC2 rri */
                            g_CommonWinFlags;  /* 2.5b10 jjt */

extern APTR                 StringPool; /* 2.5b10 jjt */
extern struct DirWindow     *DirWin[],*CDWin; /* new! 2.4b22 */
extern struct RxsLib        *RexxSysBase; /* new! 2.5b5 */
extern struct Screen        *Screen;
extern struct StringHistory ReqHistory, ReadHistory;  /* 2.5b10 jjt */
extern struct Hook          EditHook;  /* 2.5b10 jjt */
extern struct TextFont      *DMFonts[];  /* 2.5RC2 jjt */

extern ULONG  Screen_ID; /* 2.5.23 rri */

UBYTE            g_buttons[80]; /* 2.5b10 jjt */
LONG             busy; /* 2.5b7 rri */
struct Requester *Requester[DMMAXWINDOWS]; /* 2.5.26 rri */
/* Some often-used taglists   2.5b13 jjt */
struct TagItem reqtags_Ok[]={{DMREQ_BUTTONS,0}, /* 2.5.23 gcc rri */
                             {TAG_END,0}},      /* 2.5.23 gcc rri */
               reqtags_OkSkipCan[]={{DMREQ_BUTTONS,0}, /* 2.5.23 gcc rri */
                                    {DMREQ_ABORT,0},   /* 2.5.23 gcc rri */
                                    {TAG_END,0}};      /* 2.5.23 gcc rri */


void Busy(int i) /* 2.5b7 rri */
{
ULONG a;

if (FLAGS&DMFLAG_USE30) /* if OS-Version >=39 */ /* 2.5RC2 rri */
 {
  if (i&&!busy)
   {
    for(a=0;a<DMMAXWINDOWS;a++) /* 2.5.23 gcc rri */
     {
      if (DirWin[a])
       {
        Requester[a]=(struct Requester *)AllocMem(sizeof(struct Requester), MEMF_ANY | MEMF_CLEAR); /* 2.5.28 rri */
        if (Requester[a])
         {
          if (Request(Requester[a],DirWin[a]->Window))
           {
            SetWindowPointer(DirWin[a]->Window,WA_BusyPointer, TRUE, TAG_DONE );
            busy=1;
           }
         }
       }
     }
   }
  else if(!i&&busy)
   {
    for(a=0;a<DMMAXWINDOWS;a++) /* 2.5.23 gcc rri */
     {
      if (DirWin[a])
       {
        if (Requester[a])
         {
          SetWindowPointer (DirWin[a]->Window,TAG_DONE);
          EndRequest(Requester[a],DirWin[a]->Window);
          FreeMem((void *)(Requester[a]),sizeof(struct Requester));
          Requester[a]=0;
          busy=0;
         }
       }
     }
   }
 }
}


void About()
{
sprintf(sbuff,"DiskMaster2\n\n" /* 2.5b13 rri */
              "Copyright (c) 1991-1997\n"
              " by Greg Cunningham\n\n"
              "Copyright (c) 1997-2004\n"
              " by Rudolph Riedel\n\n"
              "DM2 is mailware:\n"
              " Rudolph.Riedel@T-Online.de \n\n"
              "%s", msgReqAbout);

DMReqTagList(sbuff, 0, 0, reqtags_Ok);  /* 2.5b13 jjt */
}


LONG REQ_FileExists(sFIB *srcfib, sFIB *destfib) /* 2.5b13 jjt */
{
struct TagItem warntags[]={{DMREQ_BUTTONS,(ULONG) g_buttons},{DMREQ_ABORT,0},{TAG_END,0}}; /* 2.5.28 rri */

UBYTE srcdate[20], srctime[10],
      destdate[20]={"Unknown"}, desttime[10]={0};
LONG  ch, dsize=0;
struct DateTime dt;

dt.dat_Format = FORMAT_DOS;
dt.dat_Flags = 0;
dt.dat_StrDay = 0;

if(srcfib)
 {
  dt.dat_Stamp = srcfib->fib_Date;
  dt.dat_StrDate = srcdate;
  dt.dat_StrTime = srctime;
  DateToStr(&dt);
 }

if (destfib)
 {
  dt.dat_Stamp = destfib->fib_Date;
  dt.dat_StrDate = destdate;
  dt.dat_StrTime = desttime;
  DateToStr(&dt);
  dsize = destfib->fib_Size;
 }

if(srcfib)
 {
  sprintf(sbuff, msgReqFileExists, destfib->fib_FileName, /* 2.5b13 rri */
                                   srcfib->fib_Size, srcdate, srctime,
                                   dsize, destdate, desttime);
  warntags[0].ti_Data = (ULONG) msgGadOARSC; /* 2.5.26 rri */
  ch = DMReqTagList(sbuff, 0, 0, warntags); /* 2.5.26 rri */
 }
else /* 2.5.24 rri */
 {
  UBYTE *one=NULL;

  strcpy(sbuff,msgReqFileExists);
  for(ch=0;;ch++)
   {
    if(sbuff[ch] == 0x0a)
     {
      if(!one)
       {
        ch++;
        sbuff[ch] = 0;
        one=sbuff;
        continue;
       }
      else
       {
        one=sbuff+ch+1;
        break;
       }
     }
   }
  DMstrcat(sbuff,one);
  one = sbuff+200;
  sprintf(one, sbuff, destfib->fib_FileName, dsize, destdate, desttime);
  MakeBtnString(0,0,0); /* 2.5.28 rri */
  ch = DMReqTagList(one, 0, 0, warntags); /* 2.5.26 rri */
 }

return ch;
}


void CMD_Choose(void) /* 2.5b7 jjt (3.7.00) */
{
LONG   setconfirm, choice, bt, freq;
STRPTR btntxt, ret, retary[15], defstr, btnout; /* 2.5.23 jjt */
struct TagItem choosetags[]={{DMREQ_TITLE,   0}, /* 2.5.26 rri */
                             {DMREQ_BUTTONS, 0},
                             {DMREQ_ABORT,   0},
                             {DMREQ_MINW,    0},
                             {DMREQ_DEFBTN,  0},
                             {DMREQ_FILEREQ, 0},
                             {TAG_END,       0}};

setconfirm = GetActionArg("ASKONCE", AATYPE_BOOL, 0);
if (setconfirm && (FLAGS&DMFLAG_CONFIRM)) return; /* 2.5RC2 rri */

btntxt = (STRPTR) GetActionArg("BUTTONS", AATYPE_NEXTSTR, (LONG) msgGadOkay); /* 2.5b13 rri */

freq = GetActionArg("FILEREQ", AATYPE_BOOL, 0);  /* 2.5.26 jjt */

if (freq || (GetActionArg("STRING", AATYPE_BOOL, 0)))  /* 2.5.26 jjt */
 {
  strcpy(ReqStr, (STRPTR) GetActionArg("STRING", AATYPE_STR, (LONG) ""));
  defstr = ReqStr;
  btnout = sbuff;
 }
else
 {
  defstr=NULL;
  btnout=ReqStr;
 }

strcpy(dcPath, (STRPTR) GetActionArg("BUTTONVAR", AATYPE_NEXTSTR, (LONG) "BTNVAR"));  /* 2.5.23 jjt */

ret = (GetActionArg("RETBUTTONS", AATYPE_BOOL, 0) ? btntxt : (STRPTR) GetActionArg("RETURN", AATYPE_NEXTSTR, 0));

/* 2.5.26 rri */
choosetags[0].ti_Data = GetActionArg("TITLE", AATYPE_NEXTSTR, (LONG) Version);
choosetags[1].ti_Data = (ULONG) btntxt;
choosetags[2].ti_Data = GetActionArg("ABORT", AATYPE_NUM, -1);
choosetags[3].ti_Data = GetActionArg("MINW", AATYPE_NUM, 0);
choosetags[4].ti_Data = GetActionArg("DEFAULT", AATYPE_NUM, 1);
choosetags[5].ti_Data = freq;

choice = DMReqTagList((STRPTR) GetActionArg("TEXT", AATYPE_NEXTSTR, 0), defstr, 700, choosetags); /* 2.5.26 rri */

if (ret)
 {
  /* --- RETURN or RETBUTTONS was given --- */
  bt = strtoarray(StringPool, ret, retary, 15, 0, 0);
  if (choice == 0) choice = bt;  /* 2.5b11 jjt */
  strcpy(btnout, retary[choice - 1]);  /* 2.5.23 jjt */
  PoolFreeVec(*retary);
 }
else sprintf(btnout, "%ld", choice);  /* 2.5.23 */

outputRexxVar(btnout);  /* 2.5.23 jjt */
if (setconfirm) FLAGS|=DMFLAG_CONFIRM; /* 2.5RC2 rri */
rexxStr = ReqStr;
}


LONG DMReqTagList(CONST_STRPTR body, STRPTR dest, ULONG cmax, struct TagItem* tags) {
  UBYTE               *bodystrs[30]={0}, *btnstrs[15]={0}, defgads[50], btnkeys[15],
                      *p,*titlestr, /* 2.5.24 rri */
                      *tmpstr,
                      protlabels[16]={'H', 0, 'S', 0, 'P', 0, 'A', 0, 'R', 0, 'W', 0, 'E', 0, 'D', 0};
  WORD                WinL, WinT; /* 2.5.23 rri */
  UWORD               bgpat[2]={0x5555, 0xAAAA};
  LONG                done=FALSE, choice=0, abortbtn, defbtn,
                      *protectptr, protectmask[8]={128,64,32,16,8,4,2,1}, n;
  ULONG               stotal, btotal,
                      i, bt, bb, bl, blr, sgadw=20, /* 2.5.24 rri */
                      scrcharh, bdycharh, btncharh,
                      smax=0, bmax=0, bspc, x=0, y, w, h, class, code,
                      pbw, strh, frw;
  APTR                vi;
  struct Screen       *scrn;
  struct DrawInfo     *di;
  struct DimensionInfo DimI; /* 2.5.23 rri */
  struct RastPort     *rp;
  struct TextAttr     bdyta, btnta, boldta;
  struct TextFont     *oldfnt, *bdyfnt, *btnfnt;
  struct Gadget       *glist=NULL, *prvgad, *strgad=0,
                      *protectgads[8];
  struct IntuiText    protitxt[8];
  struct Image        *protbrdr=NULL;
  struct Border       *freqglyph=NULL;
  struct StringInfo   *si=0;
  struct NewGadget    ng;
  struct Window       *win;
  struct IntuiMessage *msg;
  struct StringHistory *sh;

  Busy(1); /* 2.5b10 rri */

  /*
    body - Up to 30 lines.  "|" or \n = line break.
    dest - Buffer to copy string buffer to.  If NULL, then no string gadget appears.
    cmax - Maximum length of <dest>.
    tags - DMREQ_TITLE - Defaults to Version.
           DMREQ_BUTTONS - Defaults to "Okay|Cancel".  Separate w/ a "|".
                           Ex:  "Yes|Maybe|No".
                           Maximum of 15 buttons.
           DMREQ_ABORT   - If the button pressed equals this number then Abort = 1 and
                           the req. returns 0.
                           Defaults to -1 (or 0xFFFFFFFF).
           DMREQ_SCREEN  - Screen pointer to open req. on.  Defaults to Screen.
           DMREQ_HISTORY - StringHistory struct to use.  Defaults to ReqHistory.
           DMREQ_MINW    - Minimum width of the req.  Defaults to (but will never be) 0.
           DMREQ_DEFBTN  - The button num. to return when <RETURN> is pressed.  Defaults to 1.
                           * Pressing <Return> in a string gadget will also return this
                             value.
                           * Button 0 cannot be the default.
                           * It's safe to use zero or numbers greater than the total number
                             of buttons.  In these cases "1" will be used.
           DMREQ_PROTREQ - Create a protection bits requester.  The value is the address of
                           a LONG which holds the protection bits.  The protection buttons
                           will be initialized according to this var, & the req. will also
                           copy the new values into this var.
           DMREQ_FILEREQ - Adds a button beside the string gadget that can open a file req.
                           * Ignored if <dest> is NULL.

    DMReq() returns the number (LONG) of the button pressed.  Buttons are numbered
    1, 2, 3, ..., 0.
    Pressing <Return> returns 1, Esc = 0.
    If DMREQ_ABORT <> -1 then Esc will also set the Abort flag.
  */

  scrn = (struct Screen *) GetTagData(DMREQ_SCREEN, (ULONG) Screen, tags);
  sh = (struct StringHistory *) GetTagData(DMREQ_HISTORY, (ULONG) &ReqHistory, tags);
  abortbtn = GetTagData(DMREQ_ABORT, 0xFFFFFFFF, tags);
  protectptr = (LONG *) GetTagData(DMREQ_PROTREQ,0,tags); /* 2.5.23 gcc rri */

  if ((vi = GetVisualInfo(scrn, TAG_END))) {
    if ((di = GetScreenDrawInfo(scrn))) {

      rp = &scrn->RastPort;
      /* 2.5RC2 jjt */
      oldfnt = rp->Font;
      bdyfnt = DMFonts[DMFONTS_REQTXT] ? DMFonts[DMFONTS_REQTXT] : oldfnt;
      btnfnt = DMFonts[DMFONTS_REQBTN] ? DMFonts[DMFONTS_REQBTN] : oldfnt;
      FontToAttr(bdyfnt, &bdyta);
      FontToAttr(btnfnt, &btnta);
      CopyMem(&btnta, &boldta, sizeof(struct TextAttr));
      boldta.ta_Style = FSF_BOLD;

      scrcharh = oldfnt->tf_YSize + 1;
      bdycharh = bdyfnt->tf_YSize + 1;
      btncharh = btnfnt->tf_YSize + 1;

      strh = bdycharh + 5;  /* Heigth of str & filereq gads */ /* 2.5.26 jjt */
      frw = dest && (GetTagData(DMREQ_FILEREQ, 0, tags)) ? strh : 0; /* Filereq width */ /* 2.5.26 jjt */

      bt = scrn->WBorTop + scrcharh;
      bb = scrn->WBorBottom;
      bl = scrn->WBorLeft;
      blr =  bl + scrn->WBorRight;

      /* get width of screen-gadget (depth-gadget) 2.5.24 rri */
      prvgad = scrn->FirstGadget;
      while(prvgad&&!(prvgad->GadgetType&GTYP_SDEPTH))
       {
        prvgad = prvgad->NextGadget;
       }
      if(prvgad) sgadw = prvgad->Width;

      /* --- Init Body Texts --- */
      SetFont(rp, bdyfnt);
      stotal = strtoarray(sh->mempool, body, bodystrs, 30, rp, &smax);

      /* --- Init Button Texts --- */
      sprintf(defgads,"%s|%s",msgGadOkay,msgGadCancel); /* 2.5b13 rri */
      SetFont(rp, btnfnt);

      tmpstr = (STRPTR) GetTagData(DMREQ_BUTTONS, (ULONG) defgads, tags); /* 2.5.26 rri */
      btotal = strtoarray(sh->mempool, tmpstr, btnstrs, 15, rp, &bmax); /* 2.5.26 rri */
      bmax += 10;

      /* --- Init Button Keyboard Shortcuts --- */  /* 2.5RC4 jjt */
      for (i=0; i < btotal; i++) {
        p = strchr(btnstrs[i], '_');
        btnkeys[i] = p ? *(p+1): 0;  /* Set to char after "_" or 0. */
      }

      SetFont(rp, oldfnt);

      defbtn = GetTagData(DMREQ_DEFBTN, 1, tags);          /* 2.5RC2 jjt */
      if((defbtn==(LONG)0)||(defbtn>(LONG)btotal)) defbtn=1; /* 2.5.23 gcc rri */

      i = GetTagData(DMREQ_MINW, 0, tags);  /* 2.5RC2 jjt */

      w = max(smax, ((bmax + 4) * btotal));
      w += blr; /* split into separate lines as the OS4 ppc version */
      w += 18;  /* seems to fail here somehow - 2.5.26 rri */
      w = max(w, i);  /* 2.5RC2 jjt */

      /* 2.5.24 rri - consider window-title length for minwidth of requester */
      titlestr=(UBYTE *)GetTagData(DMREQ_TITLE, (ULONG) Version, tags);
      WinL = TextLength(rp,titlestr,(ULONG) (strlen(titlestr))); /* var borrowed! */
      WinL += blr;   /* split into separate lines as the OS4 ppc version */
      WinL += sgadw; /* seems to fail here somehow - 2.5.26 rri */
      w = max(w,(ULONG) WinL);

      h = bdycharh * stotal + bt + bb + btncharh + 25;  /* 2.5RC9 jjt */
      bspc = btotal == 1 ? 0 : (w - blr - 8 - (bmax * btotal)) / (btotal - 1);

      /* --- Create Gadgets --- */
      prvgad = CreateContext(&glist);

      ng.ng_LeftEdge = bl + 4;
      ng.ng_TopEdge = bdycharh * stotal + bt + 16;
      ng.ng_VisualInfo = vi;
      ng.ng_Height = 0; /* Kludge to prevent compiler warning. */ /* 2.5RC9 jjt */

      if (protectptr) {  /* 2.5RC9 jjt */
        /* --- Protection Buttons --- */
        n = *protectptr ^ 15;  /* Protection bits w/ REWD reversed. */

        pbw = max((ULONG)btnfnt->tf_XSize * 2,btncharh) + 5; /* 2.5.23 gcc rri */

        protbrdr = (struct Image *) NewObject(NULL, "frameiclass", IA_Width, pbw,
                                                                   IA_Height, pbw,
                                                                   IA_Pens, di->dri_Pens,
                                                                   TAG_END);

        ng.ng_LeftEdge = (w / 2) - ((pbw * 8 + 49) / 2); /* 2.5RC9 rri */
        ng.ng_Width = pbw;
        ng.ng_Height = pbw;  /* 2.5RC9 jjt */
        for (i = 0; i < 8; i++) {
          protitxt[i].LeftEdge = (pbw-btnfnt->tf_XSize)/2; /* 2.5RC9 rri */
          protitxt[i].TopEdge = (pbw-btnfnt->tf_YSize)/2; /* 2.5RC9 rri */
          protitxt[i].FrontPen = di->dri_Pens[TEXTPEN];
          protitxt[i].DrawMode = JAM1;
          protitxt[i].ITextFont = &btnta;
          protitxt[i].IText = &(protlabels[i*2]);
          protitxt[i].NextText = NULL;

          prvgad = CreateGadget(GENERIC_KIND,prvgad,&ng,0); /* 2.5.23 gcc rri */
          protectgads[i] = prvgad;
          prvgad->Flags = GFLG_GADGHIMAGE | GFLG_GADGIMAGE;
          if (n & protectmask[i]) prvgad->Flags |= GFLG_SELECTED;
          prvgad->GadgetType |= GTYP_BOOLGADGET;
          prvgad->Activation = GACT_TOGGLESELECT;
          prvgad->GadgetRender = protbrdr;
          prvgad->SelectRender = protbrdr;
          prvgad->GadgetText = &protitxt[i];
          ng.ng_LeftEdge += pbw + 7; /* 2.5RC9 rri */
        }
        ng.ng_LeftEdge = bl + 4;
      }

      else if (dest) {
        /* --- String Gadget --- */

        if ((*dest == 32) && (*(dest+1) == 0)) *dest = 0;  /* Test/change " " to "" */  /* 2.5RC2 jjt */

        ng.ng_GadgetText = NULL;
        ng.ng_Width = w - (blr + 8) - frw; /* 2.5.26 jjt */
        ng.ng_Height = strh;  /* 2.5.26 jjt */
        ng.ng_TextAttr = &bdyta;
        ng.ng_UserData = sh;
        ng.ng_GadgetID = defbtn;  /* 2.5RC2 jjt */
        strgad = prvgad = CreateGadget(STRING_KIND, prvgad, &ng, GTST_String, dest,
                                                                 GTST_MaxChars, cmax,
                                                                 GTST_EditHook, (ULONG) &EditHook,
                                                                 STRINGA_ExitHelp, TRUE,  /* 2.5RC4 jjt */
                                                                 TAG_END);

        if (frw) {  /* 2.5.26 jjt */
          /* --- FileReq Gadget --- */

          ng.ng_LeftEdge += ng.ng_Width;
          ng.ng_Width = frw;
          ng.ng_GadgetID = GID_FILEREQ;

          freqglyph = MakeFReqGlyph(di->dri_Pens, frw);

          prvgad = CreateGadget(GENERIC_KIND, prvgad, &ng, 0);
          prvgad->Flags = GFLG_GADGHCOMP;
          prvgad->GadgetType |= GTYP_BOOLGADGET;
          prvgad->Activation = GACT_RELVERIFY;
          prvgad->GadgetRender = freqglyph;

          ng.ng_LeftEdge = bl + 4;
        }
      }

      if (protectptr || dest) {
        x = ng.ng_Height + 4;
        h += x;
        ng.ng_TopEdge += x;
      }

      if (bspc == 0) ng.ng_LeftEdge = (w / 2) - (bmax / 2);
      ng.ng_Width = bmax;
      ng.ng_Height = btncharh + 5;
      ng.ng_Flags = PLACETEXT_IN;
      ng.ng_GadgetID = 1;
      ng.ng_UserData = NULL;

      for (i = 0; i < btotal; i++) {
        ng.ng_GadgetText = btnstrs[i];
        ng.ng_TextAttr = ((LONG) i + 1 == defbtn) ? &boldta : &btnta; /* 2.5.23 gcc rri */
        prvgad = CreateGadget(BUTTON_KIND, prvgad, &ng, GT_Underscore, '_',  /* 2.5RC4 jjt */
                                                        TAG_END);
        ng.ng_LeftEdge += bmax + bspc;
        ng.ng_GadgetID++;
        if (i + 2 == btotal) ng.ng_GadgetID = 0;
      }

      /* 2.5.23 rri */
      if(GetDisplayInfoData(NULL,(APTR)&DimI,sizeof (struct DimensionInfo),DTAG_DIMS,Screen_ID))
       {
        WinL = min((DimI.TxtOScan.MaxX - DimI.TxtOScan.MinX + 1), scrn->Width);  /* 2.5.26 jjt */
        WinL = WinL/2 - (w / 2) - scrn->LeftEdge;
        WinT = min((DimI.TxtOScan.MaxY - DimI.TxtOScan.MinY + 1), scrn->Height); /* 2.5.26 jjt */
        WinT = WinT/2 - (h / 2) - scrn->TopEdge;
       }
      else
       {
        WinL = (scrn->Width / 2) - (w / 2);
        WinT = (scrn->Height / 2) - (h / 2);
       }

      if (prvgad) {
        /* --- Open Window --- */
        if ((win = OpenWindowTags(NULL, WA_Left,       WinL, /* 2.5.23 rri */
                                        WA_Top,        WinT, /* 2.5.23 rri */
                                        WA_Width,      w,
                                        WA_Height,     h,
                                        WA_Title,      titlestr, /* 2.5.24 rri */
                                        WA_IDCMP,      IDCMP_REFRESHWINDOW | IDCMP_ACTIVEWINDOW |
                                                       IDCMP_VANILLAKEY | IDCMP_RAWKEY |
                                                       STRINGIDCMP | BUTTONIDCMP,
                                        WA_Gadgets,    glist,
                                        WA_PubScreen,  scrn,
                                        WA_PubScreenFallBack, TRUE,
                                        WA_Flags,      g_CommonWinFlags,
                                        WA_AutoAdjust, TRUE,
                                        TAG_END))) {
          rp = win->RPort;
          SetFont(rp, bdyfnt);  /* 2.5RC2 jjt */
          SetAfPt(rp, bgpat, 1);
          SetAPen(rp, (ULONG) di->dri_Pens[SHINEPEN]);
          RectFill(rp, bl, bt, w - bl - 1, h - bb - 1);  /* Fill window */
          EraseRect(rp, bl + 4, bt + 4, w - bl - 5, h - bb - ng.ng_Height - x - 9);  /* Clear text area*/

          if (dest) {
            y = bdycharh * stotal + bt + 16;
            EraseRect(rp, bl + 4, y, w - bl - 5, y + bdycharh + 4);  /* Clear string gad area. */  /* 2.5.26 jjt */
          }
          DrawBevelBox(rp, bl + 4, bt + 4, w - blr - 8, stotal * bdycharh + 8, GTBB_Recessed, TRUE,
                                                                               GT_VisualInfo, vi,
                                                                               TAG_END);
          RefreshGList(glist, win, NULL, -1);
          GT_RefreshWindow(win, NULL);
          if (dest) {
            si = (struct StringInfo *) strgad->SpecialInfo;
            si->BufferPos = si->NumChars;
            /* ActivateGadget(strgad, win, NULL); */ /* 2.5RC4 jjt (IDCMP_ACTIVEWINDOW will catch this) */
          }

          /* --- Print Body Text --- */
          SetAPen(rp, (ULONG) di->dri_Pens[TEXTPEN]);
          x = bl + 9;
          y = bdyfnt->tf_Baseline + bt + 8;  /* 2.5RC2 jjt */
          for (i = 0; i < stotal; i++) {
            Move(rp, x, y);
            Text(rp, bodystrs[i], (ULONG) strlen(bodystrs[i]));
            y += bdycharh;
          }

          /* --- Handle IDCMP --- */
          while(!done) {
            WaitPort(win->UserPort);
            while ((msg = GT_GetIMsg(win->UserPort))) {
              class = msg->Class;
              code = msg->Code;
              prvgad = (struct Gadget *) msg->IAddress;
              GT_ReplyIMsg(msg);

              if (class == IDCMP_REFRESHWINDOW) {
                GT_BeginRefresh(win);
                GT_EndRefresh(win, TRUE);
              }

              if ((class == IDCMP_ACTIVEWINDOW) && strgad) ActivateGadget(strgad, win, NULL);  /* 2.5RC4 jjt */

              if (class == IDCMP_GADGETUP) {
                if (prvgad->GadgetID == GID_FILEREQ) {  /* 2.5.26 jjt */
                  tmpstr = DMFileReq(si->Buffer, 0, FALSE); /* 2.5.27 rri */
                  if (*tmpstr) GT_SetGadgetAttrs(strgad, win, NULL, GTST_String, tmpstr, TAG_END);
                }

                else if (!((prvgad == strgad) && code)) {  /* Ignore string gadget if code <> 0 */
                  done = TRUE;
                  choice = prvgad->GadgetID;
                }
              }

              if ((class == IDCMP_VANILLAKEY) || (class == IDCMP_RAWKEY)) {
                if (code == 13) {  /* Return pressed */
                  done = TRUE;
                  choice = defbtn;
                }
                if (code == 27) {  /* Esc pressed    */
                  done = TRUE;
                  choice = abortbtn ? abortbtn : 0;
                }
                if (code == 0x5f) ActivateGadget(strgad, win, NULL);  /* Help pressed */
                else {
                  /* --- Test for keyboard shortcut --- */  /* 2.5RC4 jjt */
                  n = CharPos((UBYTE) code, btnkeys);
                  if (n++ != -1) {
                    choice = (ULONG) n == btotal ? 0 : n; /* 2.5.23 gcc rri */
                    done = TRUE;
                  }
                  else if (protectptr) {  /* 2.5RC9 jjt */
                    /* --- Test for protection gadget shortcuts, & toggle gadget --- */
                    n = CharPos((UBYTE) code, "HSPARWED");
                    if (n != -1) {
                      RemoveGList(win, glist, -1);
                      protectgads[n]->Flags ^= GFLG_SELECTED;
                      AddGList(win, glist, 0, -1, NULL);
                      RefreshGList(glist, win, NULL, -1);
                    }
                  }
                }
              }

            } /* while msg loop */
          } /* while !done loop*/

          if (choice == abortbtn) {
            choice = 0;
            FLAGS|=DMFLAG_ABORT; /* 2.5RC2 rri */
          }

          if (dest && choice) {
            strcpy(dest, si->Buffer);
            StrHist_Add(sh, dest);
          }

          if (protectptr) {
            n = 0;
            for (i=0; i < 8; i++) {
              if (protectgads[i]->Flags & GFLG_SELECTED) n |= protectmask[i];
            }
            *protectptr = n ^ 15;
          }

          CloseWindow(win);
        }
      }
      FreeGadgets(glist);
      if (protbrdr) DisposeObject(protbrdr);   /* 2.5RC9 jjt */
      if (freqglyph) FreeFReqGlyph(freqglyph); /* 2.5.26 jjt */
      FreeScreenDrawInfo(scrn, di);
    }
    FreeVisualInfo(vi);
  }

  PoolFreeVec(*bodystrs);
  PoolFreeVec(*btnstrs);

  Busy(0); /* 2.5b10 rri */

  return choice;
}


ULONG strtoarray(APTR mempool, CONST_STRPTR str, STRPTR strary[], ULONG arymax, struct RastPort *rp, ULONG *widest) /* 2.5b10 jjt */
{
UBYTE *sptr;
ULONG c, l, stotal=0, x;

if (str && (sptr = CloneStr(str, mempool)))
 {
  for(c = 1;(stotal < arymax && c != 0); stotal++) /* 2.5.26 rri */
   {
    strary[stotal] = sptr;
    l = 0;
    for (;;)
     {
      c = *sptr++;
      if ((c == '\n') || (c == '|') || (c == 0))
       {
        *(sptr - 1) = 0;
        break;
       }
      l++;
     }
    if (rp)
     {
      x = TextLength(rp, strary[stotal], l);
      *widest = max(*widest, x);
     }
   }
 }
for (c = stotal; c < arymax; c++) strary[c] = 0; /* Zero-out remaining elements. */

return stotal;
}


void MakeBtnString(const UBYTE yes[], const UBYTE middle[], const UBYTE no[]) /* 2.5b13 rri */
{
strcpy(g_buttons, yes ? yes : msgGadOkay); /* 2.5b13 rri */
DMstrcat(g_buttons, "|"); /* 2.5RC9 rri */

if (middle)
 {
  DMstrcat(g_buttons, middle); /* 2.5RC9 rri */
  DMstrcat(g_buttons, "|"); /* 2.5RC9 rri */
 }
DMstrcat(g_buttons, no ? no : msgGadCancel); /* 2.5RC9 rri */
}


void StrHist_Init(struct StringHistory *sh) {  /* 2.5b10 jjt */
/*   ULONG i;

  InitSemaphore(&(sh->sema4));

  for(i=0; i < STRHIST_MAX; i++) {
    sh->strcache[i] = NULL;
    sh->lencache[i] = 0;
  }
*/
  sh->mempool = StringPool;
  sh->cachepos = sh->total = 0;
}


/*
void StrHist_Clear(struct StringHistory *sh) {
  ULONG                  i;
  struct SignalSemaphore *sammy;

  sammy = &sh->sema4;
  ObtainSemaphore(sammy);
  for(i=0; i < sh->total; i++) {
    PoolFreeVec(sh->strcache[i]);

    sh->strcache[i] = NULL;
    sh->lencache[i] = 0;

  }
  sh->cachepos = sh->total = 0;
  ReleaseSemaphore(sammy);
}
*/


void StrHist_Add(struct StringHistory *sh, STRPTR str) {  /* 2.5b10 jjt */
  UBYTE                  *sptr;
  LONG                   l;
  ULONG                  i; /* 2.5.23 gcc rri */
/*
  struct SignalSemaphore *sammy;

  sammy = &sh->sema4;
  ObtainSemaphore(sammy);
*/

  if (str && (l = strlen(str))) {
    /* --- Check if string already exists --- */
    for(i=0; i < sh->total; i++) {
      if (Stricmp(sh->strcache[i], str) == 0) {  /* 2.5b12 jjt */
        /* --- Already cached; move it to end of cache. --- */
        sptr = sh->strcache[i];
        i += 1;
        goto ashift;
      }
    }

    /* --- Clone string & add it to the cache --- */
    if ((sptr = CloneStr(str, sh->mempool))) {
      if (sh->total == STRHIST_MAX) {
        /* --- Cache full; dump first item & shift the array --- */
        PoolFreeVec(sh->strcache[0]);
        i = 1;
ashift: for(; i < STRHIST_MAX; i++) {
          sh->strcache[i - 1] = sh->strcache[i];
          sh->lencache[i - 1] = sh->lencache[i];
        }
        sh->total -= 1;
      }
      sh->strcache[sh->total] = sptr;
      sh->lencache[sh->total] = l;
      sh->total += 1;
    }
  }

  sh->cachepos = sh->total;
/*   ReleaseSemaphore(sammy); */
}


/* 2.5b10 jjt */
ULONG SAVEDS ASM StringHook(REG(a0,struct Hook *hk),      /* 2.5.26 rri */
                            REG(a2,struct SGWork *swork),
                            REG(a1, ULONG *msg))
{
LONG   dir = 0;
ULONG  cp, /* 2.5.23 gcc rri */
       rc = 0xFFFFFFFF, jump = 0;
struct StringHistory *sh;

if(hk) {} /* 2.5.23 gcc rri - just some dummy code to make it look like hk is used...*/

if (*msg == SGH_KEY)
 {
  if (swork->Code == 27)
   {
    restorestrcontents(swork);
    swork->Actions |= SGA_USE | SGA_END;
   }
  else if (swork->IEvent->ie_Class == IECLASS_RAWKEY)
   {
    if (swork->IEvent->ie_Code == CURSORUP) dir = -1;
    else if (swork->IEvent->ie_Code == CURSORDOWN) dir = 1;
    jump = swork->IEvent->ie_Qualifier & (IEQUALIFIER_LSHIFT | IEQUALIFIER_RSHIFT);
   }
 }
else if (*msg != SGH_CLICK) rc = 0;

if (dir)
 {
  sh = (struct StringHistory *) swork->Gadget->UserData;
  if (sh->total)
   {
    if (jump) cp = (dir == 1) ? sh->total : 0;
    else
     {
      cp = sh->cachepos + dir;
      if (cp > STRHIST_MAX) cp = 0; /* 2.5.23 gcc rri */
      else if (cp > sh->total) cp = sh->total;
     }
    if (cp == sh->total) restorestrcontents(swork);
    else
     {
/*    ObtainSemaphore(&sh->sema4); */
      CopyMem(sh->strcache[cp],swork->WorkBuffer,(ULONG) ((struct StringInfo *) swork->Gadget->SpecialInfo)->MaxChars - 1); /* 2.5RC9 rri */
      swork->NumChars = swork->BufferPos = sh->lencache[cp];
/*    ReleaseSemaphore(&sh->sema4); */
     }
    sh->cachepos = cp;
    swork->Actions |= SGA_USE;
   }
 }
return (ULONG) rc;
}


void restorestrcontents(struct SGWork * swork) {  /* 2.5b10 jjt */
  strcpy(swork->WorkBuffer, ((struct StringInfo *) swork->Gadget->SpecialInfo)->UndoBuffer);
  swork->NumChars = swork->BufferPos = strlen(((struct StringInfo *) swork->Gadget->SpecialInfo)->UndoBuffer);
}


STRPTR DMFileReq(STRPTR file, STRPTR path, BOOL save) /* 2.5.27 rri */
{
struct FileRequester *dm2_filereq;

*sbuff=0;

if(AslBase)
 {
  dm2_filereq = AllocAslRequestTags(ASL_FileRequest,
                                    ASLFR_TitleText, Version,
                                    ASLFR_Screen, Screen,
                                    ASLFR_DoSaveMode, save,
                                    ASLFR_DoMultiSelect, FALSE,
                                    TAG_DONE);
  if (dm2_filereq != NULL)
   {
    if(file&&!path) /* 2.5.27 rri */
     {
      
      strcpy(sbuff,file);
      *PathPart(sbuff)=0;
     }
    else
     {
      if(path) /* 2.5.27 rri */
       {
        strcpy(sbuff,path);
       }
      file=sbuff;
     }
    Busy(1);
    if (AslRequestTags(dm2_filereq,
                       ASLFR_InitialFile, FilePart(file),
                       ASLFR_InitialDrawer, sbuff,
                       TAG_DONE))
     {
      if(*dm2_filereq->fr_File)
       {
        strcpy(sbuff,dm2_filereq->fr_Drawer);
        AddPart(sbuff,dm2_filereq->fr_File,500);
       }
      else
       {
        *sbuff=0;
       }
     }
    else
     {
      *sbuff=0;
     }
    Busy(0);
    FreeAslRequest(dm2_filereq);
   }
 }
return(sbuff);
}


struct Border * MakeFReqGlyph(UWORD *pens, ULONG height) {  /* 2.2.26 jjt */
  WORD  *coords;
  ULONG l, hl;
  struct Border *glyph;

  glyph = PoolAllocVec(StringPool, sizeof (struct Border) * 3);
  coords = PoolAllocVec(StringPool, sizeof (WORD) * 28);

  height--;
  l = height - 3;
  hl = l / 2 + 2;

  /* Shine border data */
  coords[0] = 0;
  coords[1] = height;
  coords[2] = 0;
  coords[3] = 0;
  coords[4] = height;
  coords[5] = 0;

  /* Shadow border data */

  coords[6] = height;
  coords[7] = 1;
  coords[8] = height;
  coords[9] = height;
  coords[10] = 1;
  coords[11] = height;

  /* Glyph data */
  coords[12] = hl;
  coords[13] = 3;
  coords[14] = 3;
  coords[15] = 3;
  coords[16] = 3;
  coords[17] = l;
  coords[18] = l;
  coords[19] = l;
  coords[20] = l;
  coords[21] = hl;
  coords[22] = hl;
  coords[23] = 3;
  coords[24] = hl;
  coords[25] = hl;
  coords[26] = l;
  coords[27] = hl;

  glyph[0].BackPen = glyph[1].BackPen = glyph[2].BackPen = pens[BACKGROUNDPEN];
  glyph[0].DrawMode = glyph[1].DrawMode = glyph[2].DrawMode = JAM1;
  glyph[0].Count = glyph[1].Count = 3;

  glyph[0].FrontPen = pens[SHINEPEN];
  glyph[0].XY = coords;
  glyph[0].NextBorder = &(glyph[1]);

  glyph[1].FrontPen = pens[SHADOWPEN];
  glyph[1].XY = &(coords[6]);
  glyph[1].NextBorder = &(glyph[2]);

  glyph[2].FrontPen = pens[TEXTPEN];
  glyph[2].Count = 8;
  glyph[2].XY = &(coords[12]);
  glyph[2].NextBorder = NULL;

  return glyph;
}


void FreeFReqGlyph(struct Border *glyph) {  /* 2.5.26 jjt */
  if (glyph) {
    PoolFreeVec(glyph->XY);
    PoolFreeVec(glyph);
  }
}
