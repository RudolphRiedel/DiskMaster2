
	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Text Reader/printer			15-Oct-91	*
	*								*
	*								*
	\***************************************************************/

#include "DM.h"

#define RP	ShowWin->RPort
#define MY	ShowWin->MouseY
#define MX	ShowWin->MouseX
#define WIDTH	ShowWin->Width
#define HEIGHT	ShowWin->Height

extern struct MsgPort	*WinPort;
extern struct NewWindow NewShow,NewClose;
extern struct Window	*ShowWin,*ShowClose;
extern struct TextFont	*MyTopaz;
extern UBYTE	sbuff[],*ActionArgs[],dcPath[],*PackBuf;
extern int	Abort,PrintIt,prNAME,prDATE,prLINE,Lpp,ColFudge,LMarg,RMarg;
extern ULONG	PackSize;

struct Screen	*RScreen;

UBYTE	*rptr,digits[]="0123456789ABCDEF",readtitle[84],PStr[100],UserPStr[200],
	tBuf[24];
int	VROWS,NumChars,ShowHex,SearchLen,Tedge,pfh,Lines,
	Found,SearchHex,Soffs[32],LineCount,pagenum,AutoSearch;

void SetupSearch(void);
void Reader(void);
int CountLines(UBYTE *buf,int size);

void SearchIt(UBYTE *ptr,int len)
{FAST UBYTE	*ptr2,*ptr3=0;
 FAST int	slen,o=0,o2=0,pNum=0,len2=0,c;

 Soffs[0]=-1;
 if(ShowHex) len=17;
RETRY:
 ptr2=dcPath; slen=0;
 while(len){
	c=MyToUpper(*ptr);
	if(SearchHex) c=*ptr;
	if(slen<SearchLen&&(*ptr2==c||*ptr2=='?')){slen++; ptr2++;}
	else if(slen){
		if(slen==SearchLen) Soffs[pNum++]=o-SearchLen;
		Soffs[pNum]=-1; o=o2; len=len2; ptr=ptr3; goto RETRY;
	}
	len--; o++;
	if(!ShowHex&&*ptr=='\t') while(o&7) o++;
	ptr++;
	if(slen==1){o2=o; len2=len; ptr3=ptr;}
 }
}

UBYTE *Write_Window(UBYTE *ptr,int row,int pix)
{FAST struct RastPort *rp;
 FAST int	i,i2,len,y,x;
 FAST UBYTE	*ptr2=sbuff,*tptr=PackBuf+PackSize,*pptr,*save=ptr;

 memset(sbuff,' ',256);
 if(ShowHex){
	if(ptr>=tptr) goto DIE;
	i2=(int)(ptr-PackBuf); i=7;
	while(i>=0){ptr2[i--]=digits[i2&0xF]; i2>>=4;}
	ptr2+=8; *ptr2++=':'; *ptr2++=' '; pptr=sbuff+46;
	for(i=0;i<4&&ptr<tptr;i++){
		i2=0;
		while(i2++<4&&ptr<tptr){
			*ptr2++=digits[(*ptr&0xF0)>>4];
			*ptr2++=digits[*ptr&0xF];
			*pptr++=*ptr++;
		}
		*ptr2++=' ';
	}
 }else{ i2=0;
	while(*ptr&&*ptr!=10&&i2<512&&ptr<tptr){
		i2++;
		if(*ptr=='\t'){
			ptr++; *ptr2++=' ';
			while(i2&7){*ptr2++=' '; i2++;}
		}else *ptr2++=*ptr++;
	}
	if(*ptr==0||*ptr==10) ptr++;
 }
DIE:
 rp=ShowWin->RPort; rp->Mask=1; y=(row<<3)+pix;
 if(SearchLen) rp->Mask=3;
 Move(rp,0,y); Text(rp,sbuff+Tedge,NumChars); i2=0;
 if(pfh){
	if(ShowHex){
		pptr=sbuff+46;
		for(i=0;i<16;i++){
			if(*pptr<' '||(*pptr>=0x7F&&*pptr<=0x98)||*pptr==0xAE||*pptr==0xFF||*pptr==0xC9||*pptr==0xEB)
				*pptr='.';
			pptr++;
		}
		if(Write(pfh,sbuff,62)<=0) return(0);
		Write(pfh,"\x0a",1);
	}else{	i2=(ptr-save);
		if(i2) if(Write(pfh,save,i2)<=0) return(0);
		if(i2>(RMarg-LMarg)) LineCount++;
	}
	if(++LineCount>=Lpp){
		LineCount=2;
		if(prLINE){
			sprintf(dcPath,"\n\n\t\t\t\tPage %ld",pagenum);
			Write(pfh,dcPath,strlen(dcPath)); LineCount=4;
		}
		Write(pfh,"\f",1); pagenum++;
	}
 }
 if(SearchLen>0){
	SearchIt(save,ptr-save);
	if(Soffs[0]>=0) Found=1;
	while((i=Soffs[i2++])>=Tedge&&i<=(Tedge+NumChars)){
		SetAPen(rp,3); SetBPen(rp,2);
		if(ShowHex){
		  Move(rp,(46+i)<<3,y); Text(rp,sbuff+i+46,SearchLen);
		  len=SearchLen;
		  while(len){
			x=(i<<1)+((i>>2)+10);
			Move(rp,x<<3,y);
			Text(rp,sbuff+x,2);
			len--; i++;
		  }
		}else{Move(rp,(i-Tedge)<<3,y); Text(rp,sbuff+i,SearchLen);}
		SetAPen(rp,1); SetBPen(rp,0);
	}
 }
 return(ptr);
}

UBYTE *BackupLines(UBYTE *ptr,int lines)
{
 while(lines--&&ptr>PackBuf){
	if(ptr>PackBuf) ptr--;
	if(ptr>PackBuf&&(*ptr==10||*ptr==0)) ptr--;
	while(ptr>PackBuf&&*ptr&&*ptr!=10) ptr--;
	if(*ptr==0||*ptr==10) ptr++;
 }
 return(ptr);
}

UBYTE *ScrollDn(UBYTE *ptr,int smooth)
{FAST struct RastPort *rp=ShowWin->RPort;
 FAST UBYTE	*ptr2;
 FAST int	i;

 rp->Mask=1;
 if(SearchLen) rp->Mask=3;
 if(smooth) for(i=0;i<8;i++){
	ScrollRaster(rp,0,-1,0,1,ShowWin->Width,VROWS<<3);
	ptr2=Write_Window(ptr,0,i); WaitTOF();
 }else{ ClipBlit(rp,0,1,rp,0,9,ShowWin->Width,(VROWS-1)<<3,0xC0);
	ptr2=Write_Window(ptr,0,7);
 }
 return(ptr2);
}

UBYTE *ScrollUp(UBYTE *ptr,int smooth)
{FAST struct RastPort *rp=ShowWin->RPort;
 FAST UBYTE	*ptr2;
 FAST int	i;

 rp->Mask=1;
 if(SearchLen) rp->Mask=3;
 if(smooth) for(i=0;i<8;i++){
	ScrollRaster(rp,0,1,0,1,ShowWin->Width,ShowWin->Height);
	ptr2=Write_Window(ptr,VROWS-1,14-i); WaitTOF();
 }else{ ClipBlit(rp,0,9,rp,0,1,ShowWin->Width,(VROWS-1)<<3,0xC0);
	ptr2=Write_Window(ptr,VROWS-1,7);
 }
 return(ptr2);
}

UBYTE *FillText(UBYTE *ptr)
{FAST int i;

 for(i=0;i<VROWS&&ptr;i++) ptr=Write_Window(ptr,i,7);
 if(SearchLen<0) SearchLen=0;
 return(ptr);
}

void SetupSearch()
{FAST UBYTE	*ptr=dcPath,*dest=ptr;
 FAST int	c,len=strlen(dcPath);

 SearchLen=len; SearchHex=0;
 if(*ptr=='$'&&len>1){
	ptr++; *dest=0; SearchLen=0; SearchHex=1;
	if(!(len&1)) goto SODD;
	else goto SEVEN;
NEXT:	*dest=0; SearchLen++;
SEVEN:	if(!(c=MyToUpper(*ptr++))) return;
	if(c>='A'&&c<='F') *dest=(c-55)<<4;
	else *dest=(c-'0')<<4;
SODD:	if(!(c=MyToUpper(*ptr++))) return;
	if(c>='A'&&c<='F') *dest|=(c-55);
	else *dest|=(c-'0');
	dest++; goto NEXT;
 }else MyStrUpper(dcPath);
}

void DoPrint(sFIB *fib)
{struct DirList dlt;
 FAST UBYTE	*ptr=PackBuf;

 PrDefault(); LineCount=2; pagenum=1;
 if(!(pfh=Open("PRT:",MODE_NEWFILE))) return;
 if(PStr[0]) if(Write(pfh,PStr,strlen(PStr))<=0){Abort=1; goto Q;}
 if(prLINE&&Lpp>3) Lpp-=3;
 if(prNAME){
	if(Write(pfh,"\x1B[4m",4)<=0){Abort=1; goto Q;}
	fib->fib_Comment[0]=0; Fib2Dlp(&dlt,fib);
	DoFileFormat(&dlt,30,0); Write(pfh,sbuff,ColFudge);
	Write(pfh,"\x1B[0m\n\n",6); LineCount=4;
 }
 if(PStr[0]) if(Write(pfh,PStr,strlen(PStr))<=0){Abort=1; goto Q;}
 if(UserPStr[0]) if(Write(pfh,UserPStr,strlen(UserPStr))<=0){Abort=1; goto Q;}
 dcPath[0]=0; SearchLen=-1; ptr=FillText(ptr);
 if(!ptr) Abort=1;
 while(!Abort){
	if(CheckAbortKey()) goto Q;
	if(ShowHex){
		if(ptr<(PackBuf+PackSize)){
			if(!ScrollUp(ptr,0)) Abort=1;
			ptr+=16;
		}else goto Q;
	}else if(ptr<(PackBuf+PackSize)) ptr=ScrollUp(ptr,0);
	else goto Q;
	if(!ptr) Abort=1;
 }
Q: if(!Abort){
	if(prLINE){
		while(++LineCount<Lpp) Write(pfh,"\n",1);
		sprintf(dcPath,"\t\t\t\tPage %ld",pagenum);
		Write(pfh,dcPath,strlen(dcPath));
	}
	Write(pfh,"\f",1);
  }
  Close(pfh); pfh=0;
  if(prLINE&&Lpp) Lpp+=3;
}

void Reader()
{FAST struct IntuiMessage *msg;
 FAST UBYTE	*ptr=PackBuf,*ptr2,*tptr;
 FAST int	class,code,qual,stoped=1,shift,y,smooth=0,k,ln;

 SetAPen(&RScreen->RastPort,0);
 SetBPen(&RScreen->RastPort,1);
 ptr2=FillText(ptr);
 if(SearchLen>0){ptr2=ptr=PackBuf; code=0x33; goto DOKEY;}
 for(;;){
   smooth=0;
   if(stoped) WaitPort(WinPort);
   else{y=RScreen->MouseY; shift=0;
	if(y<0) Delay(8);
	else if(y<HEIGHT/5){code=0x3e; goto DOKEY;}
	else if(y<HEIGHT/3){code=0x3e; smooth=1; goto DOKEY;}
	else if(y>HEIGHT-(HEIGHT/6)){code=0x1e; goto DOKEY;}
	else if(y>HEIGHT-(HEIGHT/3)){code=0x1e; smooth=1; goto DOKEY;}
	else Delay(8);
   }
   while(msg=(struct IntuiMessage *)GetMsg(WinPort)){
	class=msg->Class; code=msg->Code; qual=msg->Qualifier;
	ReplyMsg((struct Message *)msg);
	shift=(qual&3);
	if(class==CLOSEWINDOW) return;
	if(class==MOUSEBUTTONS){
		if(code==SELECTDOWN) stoped^=1;
		if(code==MENUDOWN) return;
	}
	if(class==RAWKEY){
DOKEY:		switch(code){
		/*ESC */case 0x45: Abort=1;
		/* ret*/case 0x44:
		/* ret*/case 0x43:
		/* Q  */case 0x10: return;
		/*left*/case 0x4F:
			case 0x2D: if(Tedge>=8){Tedge-=8; ptr2=FillText(ptr);}
				   break;
		/*righ*/case 0x4E:
			case 0x2F: if(!ShowHex&&Tedge<170){Tedge+=8; ptr2=FillText(ptr);}
				   break;
		/*spac*/case 0x40: stoped^=1; break;
		/* S  */case 0x21: SearchLen=-1; ptr2=FillText(ptr);
				   if(DMReq("Enter search text/HEX","Search",0,0,dcPath,80))
					{SetupSearch(); ptr2=ptr=PackBuf; code=0x33;}
				   break;
		/* M  */case 0x37: ShowHex^=1; ptr2=FillText((UBYTE *)((ULONG)(ptr)&~4)); break;
		/* T  */case 0x14:
		/*HOME*/case 0x3D: ptr2=FillText(ptr=PackBuf); break;
		}
		if(ShowHex) switch(code){
		/* DN */case 0x4D:
			case 0x1E: if(!shift){
					if(ptr2<(PackBuf+PackSize)){ptr+=16; ScrollUp(ptr2,smooth); ptr2+=16;}
					break;
				   }
		/*PGDN*/case 0x1F: if(ptr2>=(PackBuf+PackSize-(16*VROWS))) goto HEXEND;
				   ptr2=FillText(ptr=ptr2); break;
		/* C  */case 0x33: Found=0;
				   if(!SearchLen) break;
				   while(!Found){
					if(ptr2>=(PackBuf+PackSize-(16*VROWS))){
						if(AutoSearch) return;
						goto HEXEND;
					}
					ptr2=FillText(ptr=ptr2);
					if(CheckAbortKey()) return;
				   }
				   break;
		/* B  */case 0x35:
		/*END */case 0x1D:
HEXEND: 			   ptr=(PackBuf+(PackSize-1&~0xf))-(16*(VROWS-1));
				   if(ptr<PackBuf) ptr=PackBuf;
				   ptr2=FillText(ptr); break;
		/* UP */case 0x4C:
			case 0x3E: if(!shift){
					if((ptr-16)>=PackBuf){ptr-=16; ptr2-=16; ScrollDn(ptr,smooth);}
					break;
				   }
		/*PGUP*/case 0x3F: ptr-=(16*VROWS);
				   if(ptr<PackBuf) ptr=PackBuf;
				   ptr2=FillText(ptr);
			default:   break;
		}else switch(code){
		/* UP */case 0x4C:
			case 0x3E: if(!shift){
				    if(ptr>PackBuf){
					tptr=ptr;
					ptr=BackupLines(ptr,1);
					if(ptr==tptr) break;
					ScrollDn(ptr,smooth);
					ptr2=BackupLines(ptr2,1);
				    }
				    break;
				   }
		/*PGUP*/case 0x3F: if(ptr>PackBuf){
					ptr=BackupLines(ptr,VROWS);
					ptr2=FillText(ptr);
				   }
				   break;
		/* DN */case 0x4D:
			case 0x1E: if(!shift){
				    if(ptr2<(PackBuf+PackSize)){
					while(*ptr&&*ptr!=10) ptr++;
					if(*ptr==0||*ptr==10) ptr++;
					ptr2=ScrollUp(ptr2,smooth);
				    }
				    break;
				   }
		/*PGDN*/case 0x1F: if(ptr2<(PackBuf+PackSize)) ptr2=FillText(ptr=ptr2);
				   break;
		/* C  */case 0x33: Found=0;
				   if(!SearchLen) break;
				   while(!Found&&ptr2<(PackBuf+PackSize)){
					ptr2=FillText(ptr=ptr2);
					if(CheckAbortKey()) return;
				   }
				   if(!Found&&AutoSearch) return;
				   break;
		/* B  */case 0x35:
		/*END */case 0x1D: ptr=BackupLines(PackBuf+PackSize-1,VROWS); ptr2=FillText(ptr);
			default  : break;
		}
	}
   }
   Move(&RScreen->RastPort,400,7);
   if(ShowHex){
	k=(ptr-PackBuf)+(16*VROWS);
	if(k>PackSize) k=PackSize;
	sprintf(tBuf,"%06lX-%06lX of %06lX",(ptr-PackBuf),k,PackSize);
	Text(&RScreen->RastPort,tBuf,23);
   }else{
	ln=CountLines(PackBuf,ptr2-PackBuf+1); k=ln/VROWS;
	sprintf(tBuf," (%4ld/%4ld) (%3ld/%3ld) ",ln,Lines,k?k:1,Lines/VROWS);
	Text(&RScreen->RastPort,tBuf,23);
   }
 }
}

void CloseRead()
{
 if(ShowClose){CloseSharedWindow(ShowClose); ShowClose=0;}
 if(ShowWin){CloseSharedWindow(ShowWin); ShowWin=0;}
 if(RScreen){CloseScreen(RScreen); RScreen=0;}
}

void DMRead(UBYTE *file,sFIB *fib)
{FAST LONG	*lptr;
 FAST UBYTE	*ptr;
 FAST int	i=2,k,h;

 ShowHex=Tedge=0; SearchLen=-1; AutoSearch=0;
 if(!AutoUnpack(file,MEMF_PUBLIC|MEMF_CLEAR)) goto ERR;

 if(PrintIt){
	lptr=(LONG *)PackBuf;
	if(lptr[0]==0x464f524d&&lptr[2]==0x494c424d){DMShow(file); return;}
	k=199;
	if(k>=PackSize) k=PackSize-1;
	while(k) if(!PackBuf[k--]) break;
	if(k) ShowHex=1;
 }
 if(!RScreen) dcPath[0]=0;
 while(ptr=ActionArgs[i]){
	if(!stricmp(ptr,"HEX")) ShowHex=1;
	else if(!stricmp(ptr,"SEARCH")){
		i++;
		if(ActionArgs[i]) strcpy(dcPath,ActionArgs[i]);
		else if(!dcPath[0]) if(!DMReq("Enter search text/HEX","Search",0,0,dcPath,80)) dcPath[0]=0;
		if(dcPath[0]){SetupSearch(); AutoSearch=1;}
	}else break;
	i++;
 }
 if(!RScreen){
	if(!(RScreen=MyOpenScreen(i,0,"DM-READER"))) return;
	NewShow.Width=RScreen->Width;
	NewShow.TopEdge=RScreen->BarHeight;
	h=(RScreen->Height-NewShow.TopEdge-1);
	NewShow.Height=(h&~7)+1;

	NewClose.Screen=NewShow.Screen=RScreen;
	NewClose.Height=RScreen->BarHeight;
	if(!(ShowClose=OpenSharedWindow(&NewClose))) goto ERR;
	NewShow.IDCMPFlags=RAWKEY|MOUSEBUTTONS;
	NewShow.Flags|=ACTIVATE;
	if(!(ShowWin=OpenSharedWindow(&NewShow))) goto ERR;
	SetFont(ShowWin->RPort,MyTopaz); SetAPen(ShowWin->RPort,1);
 }
 sprintf(readtitle,"    %-76s",fib->fib_FileName);
 ActivateWindow(ShowWin); SetWindowTitles(ShowWin,0,readtitle);
 NumChars=RScreen->BitMap.BytesPerRow;
 VROWS=ShowWin->Height>>3;
 Lines=CountLines(PackBuf,PackSize);
 if(!Abort){
	if(PrintIt) DoPrint(fib);
	else Reader();
 }
 goto DIE;
ERR: CloseRead(); Abort=1;
DIE: if(PackBuf){FreeMem(PackBuf,PackSize); PackBuf=0; PackSize=0;}
}

