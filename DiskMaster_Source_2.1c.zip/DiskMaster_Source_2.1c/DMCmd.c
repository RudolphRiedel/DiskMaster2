	/***************************************************************\
	*			DiskMaster II		12-Oct-90	*
	*	Command module				15-Oct-91	*
	*								*
	*	Batch parse/Cmmnd exe/Smart control			*
	*								*
	\***************************************************************/

#include "DM.h"
#define AA		ActionArgs

#define RECURSE_DEL	1
#define RECURSE_COPY	2
#define RECURSE_MOVE	3
#define RECURSE_PROT	(1<<2)
#define RECURSE_REN	(1<<3)
#define RECURSE_EXEC	(1<<4)
#define RECURSE_FIND	(1<<5)
#define RECURSE_NOTE	(1<<6)
#define RECURSE_SHOW	(1<<7)
#define RECURSE_READ	(1<<8)
#define RECURSE_AUTO	(1<<9)
#define RECURSE_REXX	(1<<10)
#define RECURSE_DATE	(1<<11)
#define RECURSE_PRINT	(1<<12)
#define RECURSE_CHECK	(1<<13)
#define RECURSE_PACK	(1<<14)

#define ENCODEEXTRA(n) ((n+7)>>3)

extern struct GfxBase		*GfxBase;
extern struct Library		*ScrSharBase;
extern struct IntuitionBase	*IntuitionBase;
extern struct Library		*RexxSysBase;
extern struct Screen		*Screen,*MyScreen;
extern struct Process		*process;
extern struct MsgPort		*WinPort;
extern struct DirWindow 	*DirWin[],*CDWin,*DestWin,*CmdWin;
extern struct DirList		*DClickDir;
extern struct InfoData		InfoData;
extern struct TextAttr		MAttr,FuckingTopaz;
extern struct FileHandle	FakeHandle;
extern struct RexxMsg		*WaitRX,*rxMsg;
extern struct Menu		*DMMenu;
extern struct Window		*BWindow;

extern LONG	TimerData[];
extern int	KeepGoing,DWNum,lockcount,CDelay,Abort,RexxOutstanding,scrPublic,
		UserCols,rexxErr,ColFudge,pfh,Use20,SortType,LastI,RemMenu;
extern UBYTE	sbuff[];
extern UBYTE	*rexxStr,ScreenTitle[],DispFormat[],PGadStr[],TitleFormat[],
		Version[],BarFormat[],DMname[];
extern UWORD	Pens20[],ColMap[];

struct InfoData InfoData;
struct DirList	*WorkDlp;
struct NewScreen NewScreen={0,0,640,200,2,0,1,HIRES,CUSTOMSCREEN,&MAttr,"DM"};
struct StandardPacket	SPkt;
struct DateStamp	setStamp;
sFIB	Fib;
struct TagItem Tags[20];

struct NewWindow NewBWindow={0,12,640,188,0,1,0,
	BORDERLESS|NOCAREREFRESH|SMART_REFRESH|BACKDROP,
	0,0,0,0,0,0,0,0,0,CUSTOMSCREEN};

LONG	Globuff_size,RecurseAttr,BlkTotal,DirTotal,ModSize,PackSize;

int	PatReqFlag,ConfirmFlag,RecurseDepth,NoteFlag,AttrFlag,RecFlag,SingleFlag,
	StdIO,LoopFlag,PrintIt,ChgCmd,unMark,expandflag=0,PackOpt,BPB;
UBYTE	*Globuff,*ActionArgs[32],*AutoCmdStr[256],*KeyCmdStr[100],sPath[512],
	dcPath[512],*Module,*PackBuf,
	ActionBuf[1024],Pattern[32],ProtBuff[32]="-HSPA +RWED",RexxPassStr[1024],
	DOSPassStr[1024],HostID[32],ReqStr[700];


struct RexxMsg *MakeRexxMsg(void);
void SendRexx(void);
UBYTE *DOSCD(void);
void DMSetDate(void);
void DMReqPat(void);
void DoSwap(void);
int UnLockAll(void);
void ResetFlags(void);
int CheckScreen(void);
int MTInit(UBYTE *data);
void MTEnd(void);
void FreeMod(void);
void ResortAll(void);

void GetDRI(struct Screen *s)
{FAST struct DrawInfo *dri;

 if(!s) return;
 if(dri=GetScreenDrawInfo(s)){
	movmem((UBYTE *)dri->dri_Pens,(UBYTE *)&Pens20,18);
	FreeScreenDrawInfo(s,dri);
 }
}

void GetHostScreen(UBYTE *str)
{FAST struct Screen *s;

 if(MyScreen) return;
 if(Use20){
	if(HostID[0]){UnlockPubScreen(HostID,Screen); HostID[0]=0; Screen=(struct Screen *)OpenWorkBench();}
	if(!str||*str==0) return;
	s=LockPubScreen(str);
	if(s){Screen=s; strcpy(HostID,str); GetDRI(s);}
 }
}

void DoStdio(UBYTE *str)
{FAST struct FileHandle *fh;

 if(StdIO){
	Close(StdIO); StdIO=0;
	process->pr_ConsoleTask=(APTR)FakeHandle.fh_Type;
	process->pr_COS=process->pr_CIS=(LONG)(&FakeHandle)>>2;
 }
 if(!stricmp(str,"CLOSE")) return;
 if(MyScreen) strcat(str,"/SCREENDM");
 StdIO=Open(str,MODE_OLDFILE);
 if(StdIO){
	fh=(struct FileHandle *)(StdIO<<2);
	process->pr_ConsoleTask=(APTR)fh->fh_Type;
	process->pr_CIS=process->pr_COS=StdIO;
 }
}

int CheckAbortKey()
{FAST struct IntuiMessage *msg,*succ;
 FAST struct MsgPort *mp=WinPort;
 FAST LONG	sig=1<<mp->mp_SigBit;
 FAST int	class,code;

 if(SetSignal(0,sig)&sig){

	Forbid(); msg=(struct IntuiMessage *)mp->mp_MsgList.lh_Head;
	while(succ=(struct IntuiMessage *)msg->ExecMessage.mn_Node.ln_Succ){
		class=msg->Class; code=msg->Code;
		if(class==CLOSEWINDOW||(class==VANILLAKEY&&code==0x1b)||(class==RAWKEY&&code==0x45)){
			Remove((struct Node *)msg); Abort=1;
			ReplyMsg((struct Message *)msg);
		}
		msg=succ;
	}
	Permit();
 }
 return(Abort);
}

UBYTE *SkipWhite(UBYTE *ptr)
{
 while(*ptr==' '||*ptr==9) ptr++;
 return(ptr);
}

void GetParent(UBYTE *path,int root)
{FAST UBYTE *ptr=path+strlen(path);

 for(;ptr>=path;ptr--){
	if(*ptr==':'){
		ptr++;
		if(*ptr) *ptr=0;
		else path[0]=0;
		break;
	}
	if(!root&&*ptr=='/'){*ptr=0; break;}
 }
}

int NeedQuote(UBYTE *ptr)
{
 while(*ptr){
	if(*ptr==' ') return(1);
	if(*ptr=='\\') return(0);
	ptr++;
 }
 return(0);
}

int DOSParse(UBYTE *str,UBYTE *hail)
{FAST UBYTE	*ptr=str,*ptr2;
 FAST int	i=1,q;

 while(AA[i]){
	ptr2=AA[i]; *ptr++=' '; q=NeedQuote(ptr2);
	if(q) *ptr++='"';
	while(*ptr2){
		if(*ptr2=='\\'){
			if(q) *ptr++='"';
			ptr2++; *ptr++='\n';
			q=NeedQuote(ptr2);
		}
		*ptr++=*ptr2++;
	}
	if(q) *ptr++='"';
	*ptr=0; i++;
 }
 if(i<2&&!DMReq(hail,0,0,0,str,1024)) return(0);
 return(1);
}

struct RexxMsg *MakeRexxMsg(){return(CreateRexxMsg(WinPort,"dm",DMname));}

void SendRexx()
{FAST UBYTE *arg;
 FAST struct RexxMsg *rmsg;
 FAST struct MsgPort *port;
 FAST struct DirWindow	*dw;
 FAST int	fail=0,ro,t,i,xi=4;
 FAST ULONG	sig;

 if(!RexxSysBase) return;
 if(!DOSParse(RexxPassStr,"Please enter ARexx string.")) return;
 if(!(arg=CreateArgstring(RexxPassStr,strlen(RexxPassStr)))) return;
 if(rmsg=MakeRexxMsg()){
	ACTION(rmsg)=RXCOMM; ARG0(rmsg)=(STRPTR)arg; Forbid();
	if(port=FindPort("REXX")){
		PutMsg(port,(struct Message *)rmsg); RexxOutstanding++;
	}else fail=1;
	Permit();
	if(fail) DeleteRexxMsg(rmsg);
 }
 ro=RexxOutstanding;
 if(fail) DeleteArgstring(arg);
 else if(LoopFlag) while(KeepGoing&&!Abort&&RexxOutstanding==ro){
	if(lockcount){
		t=0;
		for(i=0;i<255;i++){
			dw=DirWin[i];
			GetDirEntry(dw);
			if(dw&&dw->DirLock) t=1;
		}
		if(!t){ lockcount=0;
			if(WaitRX){ReplyMsg((struct Message *)WaitRX); WaitRX=0;}
		}
		DoWindow(); xi=4;
	}else{	StartTimer(1); sig=Wait((1<<WinPort->mp_SigBit)|1); TimerData[0]=0;
		if(sig!=1){DoWindow(); xi=4;}
		else{	if(!CDelay) CDelay=1;
			else CDelay--;
			if(!CDelay){DClickDir=0; LastI=-1; MainTitle(); SetTitles(); CDelay=1;}
			xi--;
			if(xi<=0){xi=4; ReSort();}
		}
	}
 }
}

struct Screen *MyOpenScreen(int n,int m,UBYTE *name)
{FAST struct Screen *s;
 FAST UBYTE	*str;
 FAST int	i,t=2,w=0,Rows=GfxBase->NormalDisplayRows,
		Cols=GfxBase->NormalDisplayColumns;

 NewScreen.TopEdge=0; NewScreen.Depth=2;
 NewScreen.Height=Rows; NewScreen.Width=Cols;
 NewScreen.ViewModes=HIRES;
 NewScreen.DefaultTitle=name;
 memset((UBYTE*)Tags,0,20*8);
 Tags[0].ti_Tag=(1<<31)+47; Tags[0].ti_Data=(ULONG)DMname;
 Tags[1].ti_Tag=(1<<31)+58; Tags[1].ti_Data=(ULONG)&Pens20;
 while(str=AA[n++]){
	i=atoi(str);
	if(i){	switch(w){
			case 0: NewScreen.Depth=i; break;
			case 1: Tags[t].ti_Tag=(1<<31)+0x23; Tags[t++].ti_Data=(ULONG)i; break;
			case 2: Tags[t].ti_Tag=(1<<31)+0x24; Tags[t++].ti_Data=(ULONG)i; break;
		}
		w++;
	}else{	i=MyToUpper(*str);
		if(i=='I'||i=='L'||i=='H'){
			NewScreen.ViewModes=HIRES|LACE;
			if(i=='H') NewScreen.TopEdge=NewScreen.Height;
			else NewScreen.Height<<=1;
		}else if(i=='A'){
			Tags[t].ti_Tag=(1<<31)+0x34; Tags[t++].ti_Data=(ULONG)1;
			Tags[t].ti_Tag=(1<<31)+0x39; Tags[t++].ti_Data=(ULONG)1;
		}else if(i=='S'){Tags[t].ti_Tag=(1<<31)+0x32; Tags[t++].ti_Data=(ULONG)0x8020;}
		else if(i=='P'){Tags[t].ti_Tag=(1<<31)+0x32; Tags[t++].ti_Data=(ULONG)0x39024;}
	}
 }

 i=0;
 if((AA[0][0]&0xDF)!='O') i=1;
 if(Use20){
	if(s=(struct Screen *)OpenScreenTagList(&NewScreen,&Tags[i]))
		if(!i) PubScreenStatus(s,0);
 }else s=OpenScreen(&NewScreen);
 if(s){ if(UserCols) LoadRGB4(&s->ViewPort,ColMap,UserCols);
	if(m){	NewBWindow.Screen=s;
		NewBWindow.Width=s->Width;
		NewBWindow.Height=s->Height-12;
		if(!(BWindow=OpenWindow(&NewBWindow))){CloseScreen(s); return(0);}
	}
 }
 return(s);
}

int CheckScreen()
{FAST struct Window *w;

 if(!MyScreen) return(0);
 w=MyScreen->FirstWindow;
 while(w){
	if(w->UserPort!=WinPort&&w!=BWindow) return(1);
	w=w->NextWindow;
 }
 return(0);
}

void display(UBYTE *format,UBYTE *arg1)
{sprintf(ScreenTitle,format,arg1); SetTitles(); CDelay=5;}

void ReSort()
{FAST struct DirWindow	*dw;
 FAST struct DateStamp	*ds,*ds2;
 FAST struct DirList	**dl;
 FAST sFIB	*fib=&Fib;
 FAST int	i,j,c,lock;
 FAST APTR	save=process->pr_WindowPtr;

 process->pr_WindowPtr=(APTR)-1;
 for(i=0;i<255;i++){
   dw=DirWin[i];
   if(!dw) continue;
   if(dw->Flags&DWFLAG_RESORT){
	c=dw->FileCount;
	dl=dw->DirList;
	DMSort(dl,c);
	for(j=0;j<c;j++)
		if(dl[j]&&dl[j]->sel>1){
			if(dl[j]->cmt) FreeMem(dl[j]->cmt,strlen(dl[j]->cmt)+1);
			FreeMem(dl[j],sizeof(struct DirList));
			dl[j]=0;
			dw->FileCount--;
		}
	c=dw->FileCount;
	switch(SortType){
		case 0: DMSort(dl,c); break;
		case 1: DMSrtS(dl,c); break;
		case 2: DMSrtD(dl,c); break;
	}
	DiskShadow(dw,&Fib);
	if(dw->DirLock){UnLock(dw->DirLock); dw->DirLock=0;}
	rdis_files(dw); dis_files(dw); WinTitle(dw); dw->Flags&=~DWFLAG_RESORT;
   }else if(!(dw->Flags&DW_CMD)&&dw->Path[0]){
	if(!(lock=Lock(dw->Path,ACCESS_READ))){
	   if(dw->Devi[0]){
		Delay(25);
		if(lock=Lock(dw->Devi,ACCESS_READ)){
			UnLock(lock);
			strcpy(dw->Path,dw->Devi); InitDir(dw,0);
		}
	   }
	}else{
	   if(Examine(lock,fib)){
		ds=&fib->fib_Date; ds2=&dw->PathDate;
		if(ds->ds_Days!=ds2->ds_Days||ds->ds_Minute!=ds2->ds_Minute||ds->ds_Tick!=ds2->ds_Tick)
			{dw->Flags|=DWFLAG_RELOAD; lockcount++;}
		else ReSize(dw);
	   }
	   UnLock(lock);
	}
   }
 }
 process->pr_WindowPtr=(APTR)save;
}

void SmartRename(UBYTE *old,UBYTE *new)
{FAST struct DirWindow	*dw;
 FAST struct DirList	**dl;
 FAST UBYTE		*ptr;
 FAST int		i,j,len,c;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(!dw) continue;
	len=strlen(dw->Path);
	if(strncmp(old,dw->Path,len)) continue;
	if(!stricmp(old,dw->Path)){
		strcpy(dw->Path,new); RefreshGadgets(&dw->dir_gad,dw->Window,0);
		continue;
	}
	ptr=old+len; dl=dw->DirList;
	if(dw->FileCount&&dl[0]->dir>1) continue; /* rename dev/cmd file */
	if(*ptr=='/'){ptr++; len++;}
	while(*ptr) if(*ptr++=='/') break;
	if(*ptr) continue;
	ptr=old+len;
	for(j=0;j<dw->FileCount;j++)
		if(!stricmp(ptr,dl[j]->name)){
			strcpy(dl[j]->name,new+len); c=dw->Index;
			if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
			dw->Flags|=DWFLAG_RESORT; break;
		}
 }
}

void ResortAll()
{FAST struct DirWindow	*dw;
 FAST int		i;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(dw&&!dw->Flags&&dw->Path[0]) dw->Flags|=DWFLAG_RESORT;
 }
 ReSort();
}

void SmartRemEntry(UBYTE *name)
{FAST struct DirWindow	*dw;
 FAST struct DirList	**dl,*dlp;
 FAST UBYTE		*ptr;
 FAST int		i,j,len,c;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(!dw) continue;
	len=strlen(dw->Path);
	if(strncmp(name,dw->Path,len)) continue;
	ptr=name+len; dl=dw->DirList;
	if(dw->FileCount&&dl[0]->dir>1) continue;
	if(*ptr==0){dw->Path[0]=0; InitDir(dw,0); continue;}
	if(*ptr=='/') ptr++;
	while(*ptr) if(*ptr++=='/') break;
	if(*ptr) continue;
	ptr=name+len;
	if(*ptr=='/') ptr++;
	for(j=0;j<dw->FileCount;j++){
		dlp=dl[j];
		if(dlp&&!stricmp(ptr,dlp->name)){
			dlp->sel=2; dlp->dir=-1;
			dw->Flags|=DWFLAG_RESORT; c=dw->Index;
			if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
			break;
		}
	}
 }
}

void UpdateDlp(struct DirList *dlp,UBYTE *name)
{FAST sFIB	*fib=&Fib;
 FAST int	lock;

 if(lock=Lock(name,ACCESS_READ)){
	if(Examine(lock,fib)) Fib2Dlp(dlp,fib);
	UnLock(lock);
 }
}

void AddNewDlp(struct DirWindow *dw,UBYTE *name)
{
 if(AllocDlp(dw)) UpdateDlp(dw->DirList[dw->FileCount++],name);
}

void SmartAddEntry(UBYTE *name)
{FAST struct DirWindow	*dw;
 FAST struct DirList	**dl;
 FAST UBYTE		*ptr;
 FAST int		i,j,len,c;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(!dw) continue;
	len=strlen(dw->Path);
	if(strncmp(name,dw->Path,len)) continue;
	ptr=name+len; dl=dw->DirList;
	if(dw->FileCount&&dl[0]->dir>1) continue;
	if(len&&dw->Path[len-1]!=':'&&*ptr!='/') continue;
	if(*ptr=='/') ptr++;
	while(*ptr) if(*ptr++=='/') break;
	if(*ptr) continue;
	ptr=name+len;
	if(*ptr=='/') ptr++;
	for(j=0;j<dw->FileCount;j++)
		if(!stricmp(ptr,dl[j]->name)){
			UpdateDlp(dl[j],name); c=dw->Index;
			if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
			dw->Flags|=DWFLAG_RESORT; break;
		}
	if(j==dw->FileCount){
		AddNewDlp(dw,name); dw->Flags|=DWFLAG_RESORT;
		Increment(dw,&dw->dn); SetVert(dw); c=dw->Index;
		if(j>=c&&j<(c+dw->Rows)){
			len=strlen(dw->DirList[j]->name);
			if(len>dw->ColsName){dw->ColsName=len; dis_files(dw); WinTitle(dw);}
			else dis_name(dw,j,j-c);
		}
	}
 }
}

void QuoteCat(UBYTE *ptr,UBYTE *name)
{FAST int q=NeedQuote(name);

 if(q) strcat(ptr,"\"");
 strcat(ptr,name);
 if(q) strcat(ptr,"\"");
}

UBYTE *DOSCD()
{FAST UBYTE	*ptr=DOSPassStr;

 *ptr=0;
 if(CDWin&&CDWin->Path[0]){
	strcpy(ptr,"CD ");
	QuoteCat(ptr,CDWin->Path);
	strcat(ptr,"\n"); ptr+=strlen(ptr);
 }
 return ptr;
}

void DOSExecute(void)
{FAST UBYTE *ptr=DOSCD();
 struct TagItem stags[3];

 if(DOSParse(ptr,"Please enter command string.")){
	stags[0].ti_Tag = SYS_Input;
	stags[0].ti_Data= StdIO?StdIO:Input();
	stags[1].ti_Tag = SYS_Output;
	stags[1].ti_Data= StdIO?NULL:Output();
	stags[2].ti_Tag = TAG_DONE;
	System(DOSPassStr,stags);
 }
}

void DMArchive(UBYTE *cmd,UBYTE *name)
{FAST struct DirList **dl,*dlp;
 FAST UBYTE	*ptr;
 FAST int	i=0,cnt=0,lock,q;

 if(!CDWin) return;
 if(!name||*name==0){
	name=dcPath; strcpy(name,CDWin->Path);
	if(*(name+strlen(name)-1)!=':') strcat(name,"/");
	if(!DMReq("Enter new archive name",0,0,0,name,512)) return;
 }
 dl=CDWin->DirList;
NEXT:
 DOSPassStr[0]=0; ptr=DOSCD(); strcat(ptr,cmd); strcat(ptr," ");
 QuoteCat(ptr,name);
 while(i<CDWin->FileCount){
	dlp=dl[i++];
	if(dlp&&dlp->sel==1){
		dlp->sel=0; cnt++; strcat(ptr," ");
		q=NeedQuote(dlp->name);
		if(q) strcat(ptr,"\"");
		strcat(ptr,dlp->name);
		if(q) strcat(ptr,"\"");
		if(strlen(ptr)>=224||cnt>=30){
			dis_files(CDWin); WinTitle(CDWin); Execute(DOSPassStr,0,0); cnt=0; goto NEXT;
		}
	}
 }
 if(cnt){dis_files(CDWin); WinTitle(CDWin); Execute(DOSPassStr,0,0);}
 if(lock=Lock(name,ACCESS_READ)){UnLock(lock); SmartAddEntry(name);}
}

void DMComment(UBYTE *name,UBYTE *str,sFIB *fib)
{
 if(!name) return;
 if(!str){
	str=fib->fib_Comment;
	sprintf(sbuff,"Enter comment for %s",fib->fib_FileName);
	if(!DMReq(sbuff,0,0,"Abort",str,80)) return;
 }
 if(!SetComment(name,str)) Abort=1;
 else SmartAddEntry(name);
}

void DMProtect(UBYTE *name,UBYTE *str,sFIB *fib)
{FAST LONG	Attr=fib->fib_Protection;
 FAST int	incl=-1,x;
 FAST UBYTE	c;

 if(!name) return;
 if(!AttrFlag){
	if(str){strcpy(ProtBuff,str); AttrFlag=1;}
	else{	sprintf(sbuff,"Protection mask for %s",fib->fib_FileName);
		if(!DMReq(sbuff,0,0,"Abort",ProtBuff,30)) return;
	}
 }
 str=ProtBuff;
 while(c=MyToUpper(*str++)){
	x=0;
	switch(c){
		case '+': incl=1; break;
		case '-': incl=0; break;
		case 'H': x=128; break;
		case 'S': x=64; break;
		case 'P': x=32; break;
		case 'A': x=16; break;
		case 'R': x=8; break;
		case 'W': x=4; break;
		case 'E': x=2; break;
		case 'D': x=1; break;
		case 'G': AttrFlag=1;
		default : break;
	}
	if(incl<0&&x){Attr=0xf; incl=1;}
	if(x>=16){
		Attr|=x;
		if(!incl) Attr&=~x;
	}else if(x){
		Attr&=~x;
		if(!incl) Attr|=x;
	}
 }
 if(!SetProtection(name,Attr)) Abort=1;
 else SmartAddEntry(name);
}

void DMSetFileDate(UBYTE *dir,sFIB *fib)
{struct MsgPort		*task;
 struct StandardPacket	*pkt=&SPkt;
 int	lock,lock2;

 if(Use20) SetFileDate(dir,&fib->fib_Date);
 else{	if(!(task=(struct MsgPort *)DeviceProc(dir))) return;
	if(!(lock=Lock(dir,ACCESS_READ))) return;
	lock2=ParentDir(lock); UnLock(lock); strcpy(&sbuff[1],fib->fib_FileName);
	sbuff[0]=(UBYTE)strlen(fib->fib_FileName);
	pkt->sp_Pkt.dp_Arg1=0;
	pkt->sp_Pkt.dp_Arg2=(ULONG)lock2;
	pkt->sp_Pkt.dp_Arg3=(ULONG)&sbuff>>2;
	pkt->sp_Pkt.dp_Arg4=(ULONG)&fib->fib_Date;
	pkt->sp_Pkt.dp_Type=ACTION_SET_DATE;
	pkt->sp_Msg.mn_Node.ln_Name=(char *)&(pkt->sp_Pkt);
	pkt->sp_Pkt.dp_Link=&(pkt->sp_Msg);
	pkt->sp_Pkt.dp_Port=&process->pr_MsgPort;
	PutMsg(task,(struct Message *)pkt); WaitPort(&process->pr_MsgPort);
	GetMsg(&process->pr_MsgPort); UnLock(lock2);
 }
 SmartAddEntry(dir);
}

void FreeGlobuff(){if(Globuff){FreeMem(Globuff,Globuff_size); Globuff=0;}}

int GetGlobuff(LONG size)
{
 if(size<2048) size=2048;
// if(size>(128<<10)) size=(128<<10);
 if(size>(4<<20)) size=(4<<20);
 Globuff_size=size;
N:
 if(Globuff=(UBYTE *)AllocMem(Globuff_size,MEMF_PUBLIC)) return(1);
 if((Globuff_size>>=1)>=2048) goto N;
 display("Out of memory!",0); return(0);
}

UBYTE *MakeDestName(UBYTE *s,UBYTE *d)
{FAST UBYTE *dptr=d+strlen(d)-1,*sptr=s+strlen(s)-1,*dptrR,*ptr2;

	while(sptr>s&&*sptr!='/'&&*sptr!=':') sptr--;
	sptr++;
	if(*dptr++!=':'){dptrR=dptr; *dptr++='/';}
	else dptrR=dptr;
	strcpy(dptr,sptr);
	if(AA[3]&&!stricmp(AA[3],"RENAME")){
		ptr2=dptrR;
		if(*ptr2=='/') ptr2++;
		DMReq("Enter new name.",0,0,"Abort",ptr2,30);
	}
	return(dptrR);
}

ULONG PackTemp[3]={0x444D5030,0,0};
UBYTE DMPSign[8];

void DMPack(UBYTE *name,UBYTE *dest,ULONG size,int comp)
{FAST struct LhBuffer *lh;
 FAST UBYTE *buf,*ptr,*ptr2=MakeDestName(name,dest);
 FAST int fh,n;
 FAST ULONG dsize,*lptr;
 ULONG temp;

 if(!(lh=CreateBuffer(0))) return;
 if(!(buf=AllocMem(size,MEMF_PUBLIC))) goto Q1;
 lh->lh_Src=buf;
 lh->lh_SrcSize=size;

 if(!(fh=Open(name,MODE_OLDFILE))) goto Q2;
 Read(fh,(UBYTE *)&temp,4);
 if(temp==0x444D5030){
	if(comp) goto Q2;
 }else if(!comp) goto Q2;
 Seek(fh,0,-1); n=Read(fh,buf,size); Close(fh);
 if(n<=0) goto Q2;

 if(temp==0x444D5030){
	lptr=(ULONG *)buf;
	if(!(lh->lh_Dst=AllocMem(dsize=lptr[2],MEMF_PUBLIC))) goto Q2;
	lh->lh_DstSize=dsize;
	display("Unpacking %s",name);
	lh->lh_Src=buf+12;
	if(LhDecode(lh)){
		ptr=dest+strlen(dest)-4;
		if(!stricmp(ptr,".dmp")) *ptr=0;
		if(fh=Open(dest,MODE_NEWFILE)){
			Write(fh,lh->lh_Dst,lh->lh_DstSize);
			Close(fh);
			SmartAddEntry(dest);
		}
	}
 }else{ if(!AA[3]&&!NoteFlag){
		DMPSign[0]=DMPSign[1]=DMPSign[2]=DMPSign[3]=0;
		if(!DMReq("Enter signature",0,0,0,DMPSign,5)) goto Q2;
		NoteFlag=1;
	}
	if(NoteFlag) AA[3]=DMPSign;
	display("Packing %s",name);
	dsize=size+ENCODEEXTRA(size);
	if(!(lh->lh_Dst=AllocMem(dsize,MEMF_PUBLIC))) goto Q2;
	PackTemp[1]=0;
	if(AA[3]){lptr=(ULONG *)AA[3]; PackTemp[1]=*lptr;}
	PackTemp[2]=lh->lh_DstSize=dsize;
	if(LhEncode(lh)){
		strcat(dest,".dmp");
		if(fh=Open(dest,MODE_NEWFILE)){
			Write(fh,(UBYTE *)&PackTemp,12);
			Write(fh,lh->lh_Dst,lh->lh_DstSize);
			Close(fh);
			SmartAddEntry(dest);
		}
	}
 }

    FreeMem(lh->lh_Dst,dsize);
Q2: FreeMem(buf,size);
Q1: DeleteBuffer(lh); *ptr2=0;
}

int DMCopy(UBYTE *s,UBYTE *dest,sFIB *fib)
{FAST struct DateStamp *ds1,*ds2;
 FAST int	fIn,fOut,status,i,newer;
 FAST UBYTE	*ptr=MakeDestName(s,dest);

	if(!strcmp(dest,s)) strcat(dest,".BAK");

	if(AA[3]){
	  if(!stricmp(AA[3],"NEWER")&&(fOut=Lock(dest,ACCESS_READ))){
		newer=0;
		if(Examine(fOut,&Fib)){
			ds2=&Fib.fib_Date; ds1=&fib->fib_Date;
			i=ds1->ds_Days-ds2->ds_Days;
			if(i>0) newer=1;
			else if(!i){
				i=ds1->ds_Minute-ds2->ds_Minute;
				if(i>0) newer=1;
				else if(!i){
					i=ds1->ds_Tick-ds2->ds_Tick;
					if(i>0) newer=1;
				}
			}
		}
		UnLock(fOut);
		if(!newer) return(1);
	  }
	  if(Abort) goto Q0;
	}
	if(!(fIn=Open(s,MODE_OLDFILE))) goto Q0;
	if(!(GetGlobuff(fib->fib_Size))) goto Q1;
	if(!(fOut=Open(dest,MODE_NEWFILE))) goto Q2;
	status=1;
	while(status>0&&(i=Read(fIn,Globuff,Globuff_size))==Globuff_size)
		status=Write(fOut,Globuff,i);
	if(status>0&&i>0) status=Write(fOut,Globuff,i);
	if(status>=0&&i>=0){
		FreeGlobuff(); Close(fIn); Close(fOut);
		if(fib->fib_Comment[0]) SetComment(dest,fib->fib_Comment);
		if(fib->fib_Protection) SetProtection(dest,fib->fib_Protection);
		DMSetFileDate(dest,fib); *ptr=0; return(1);
	} //else if(i=IoErr())
Q3:	Close(fOut); DeleteFile(dest);
Q2:	FreeGlobuff();
Q1:	Close(fIn);
Q0:	*ptr=0; display("Error Copying %s",s); Abort=1; return(0);
}

void DMRename(UBYTE *old)
{FAST UBYTE	*ptr,*new=AA[2];

 if(!old) return;
 if(!new){
	strcpy(dcPath,old); new=dcPath;
	ptr=new+strlen(new)-1;
	while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
	if(!DMReq("Enter new filename.",0,0,"Abort",ptr+1,30)) return;
 }
 if(!Rename(old,new)) Abort=1;
 else{	ptr=new+strlen(new)-1;
	while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
	if(strncmp(new,old,ptr-new)){SmartRemEntry(old); SmartAddEntry(new);}
	else SmartRename(old,new);
 }
}

void MakeIcon(UBYTE *name)
{struct DiskObject *dob;
 FAST struct Library *IconBase=OpenLibrary("icon.library",36);

 if(!IconBase) return;
 if(dob=GetDefDiskObject(WBDRAWER)){
	PutDiskObject(name,dob);
	FreeDiskObject(dob);
 }
 CloseLibrary(IconBase);
}

void DMMakeDir(UBYTE *name)
{FAST int	lock,n=0;
 FAST UBYTE	*ptr;

 if(!name){
	name=sPath;
	if(*name==0) return;
	ptr=name+strlen(name)-1;
	if(*ptr++!=':'){*ptr++='/'; *ptr=0;}
	n=DMReq("Please enter new directory name",0,0,"Make Icon",name,512);
	if(Abort){Abort=0; n=2;}
	else if(!n) return;
 }
 if(lock=Lock(name,ACCESS_READ)) UnLock(lock);
 else if(lock=CreateDir(name)){
	UnLock(lock); SmartAddEntry(name);
	if(n==2){MakeIcon(name); strcat(name,".info"); SmartAddEntry(name);}
 }else Abort=1;
}

int addname(UBYTE *path,UBYTE *name,int len)
{FAST UBYTE *pt=path+len,ch;
 FAST int i=0;

 if(len!=0&&(ch=path[len-1])!='/'&&ch!=':'){*pt++='/'; ++i;}
 for(;*pt++=*name++;++i);
 *pt=0; return len+i;
}

int get_blocks(long size,int bpb)
{
 FAST int data_blk,list_blk;

 data_blk=(size+bpb-1)/bpb;	// number of data blocks
 list_blk=(data_blk-1)/72;	// number of file list blocks
 return(1+list_blk+data_blk);	// file header + list + data blocks
}

int DMRecurse(int lenS,int lenD,int opt)
{FAST sFIB	*info;
 FAST int	lock,dir=0,reEx=0,i=0;

 if(!lenS) return(0);
 if(!(lock=Lock(sPath,ACCESS_READ))) return(0);
 if(!(info=(sFIB *)AllocMem(sizeof(sFIB),MEMF_PUBLIC))){Abort=1; goto RECERR;}
 if(!Examine(lock,info)){Abort=1; goto RECERR;}
 if(info->fib_DirEntryType>0&&!RecFlag&&!SingleFlag){
	if(lenD){i=addname(dcPath,info->fib_FileName,lenD); DMMakeDir(dcPath);}
	if(opt==RECURSE_CHECK){
		BlkTotal++;
		DirTotal+=CDWin->BytesPerBlock;
	}
	while(ExNext(lock,info)){
		RecurseDepth++;
		if(DMRecurse(addname(sPath,info->fib_FileName,lenS),i,opt))
			Examine(lock,info);
		RecurseDepth--;
		if(CheckAbortKey()) goto RECERR;
	}
	dir=1;
 }
RECERR:
 UnLock(lock); sPath[lenS]=0;
 if(Abort) goto EX;
 if(!(opt&3)) display(sPath,0);
 if(!RecurseDepth||dir||DMMatch(info->fib_FileName,Pattern)){
	if(!dir&&(opt&RECURSE_COPY)){
		if(opt==RECURSE_COPY)
			display("Copying %s",sPath);
		else	display("Moving %s" ,sPath);
		DMCopy(sPath,dcPath,info);
	}
	if((opt&RECURSE_DEL)&&!Abort){
		if(!(DeleteFile(sPath))){
			reEx=IoErr();
			if(reEx==222) display("File Protected",0);
			else if(reEx==202) display("File in use",0);
			else display("Delete Failed",0);
			reEx=0; goto EX;
		}else reEx=1;
		if(opt==RECURSE_DEL) display("Deleted %s",sPath);
		SmartRemEntry(sPath);
	}
	if(RecFlag||!dir) switch(opt){
		case RECURSE_PROT: DMProtect(sPath,AA[2],info); break;
		case RECURSE_NOTE: DMComment(sPath,AA[2],info); break;
		case RECURSE_AUTO: AutoFiler(CmdWin,info->fib_FileName); break;
		case RECURSE_REN : DMRename(sPath); break;
		case RECURSE_EXEC: DOSExecute(); break;
		case RECURSE_SHOW: DMShow(sPath); break;
		case RECURSE_PACK: DMPack(sPath,dcPath,info->fib_Size,PackOpt); break;
		case RECURSE_READ: DMRead(sPath,info); break;
		case RECURSE_DATE: info->fib_Date.ds_Days=setStamp.ds_Days;
				   info->fib_Date.ds_Minute=setStamp.ds_Minute;
				   info->fib_Date.ds_Tick=0;
				   DMSetFileDate(sPath,info); break;
		case RECURSE_FIND:
			sprintf(sbuff,"Found %s   Open New Window?",info->fib_FileName);
			if(!DMReq(sbuff,0,"Open","Abort",0,0)&&!Abort){
				GetParent(sPath,0); OpenDirWindow(sPath,200,40,260,120); Abort=1;
			}
			break;
		case RECURSE_CHECK:
			BlkTotal+=get_blocks(info->fib_Size,BPB);
			DirTotal+=(get_blocks(info->fib_Size,CDWin->BytesPerBlock)*CDWin->BytesPerBlock);
		default: break;
	}
 }
EX:if(lenD) dcPath[lenD]=0;
 sPath[lenS]=0;
 if(info) FreeMem(info,sizeof(sFIB));
 return(reEx);
}

void DMMove(UBYTE *s,UBYTE *dest)
{FAST int	err;
 FAST UBYTE	*ptr;

 if(!s) return;
 if(!dest){
	dest=dcPath; *dest=0;
	if(DestWin) strcpy(dest,DestWin->Path);
	if(!DMReq("Enter destination path.",0,0,"Abort",dcPath,512)) return;
 }
 if(!strncmp(s,dest,strlen(s))){Abort=1; return;}
 if(Pattern[0]=='*'&&!Pattern[1]){
	display("Moving %s",s); ptr=MakeDestName(s,dest);
	if(Rename(s,dest)){SmartRemEntry(s); SmartAddEntry(dest); return;}
	else{	err=IoErr();
		if(err!=215&&err!=203){display("File move error!",0); Abort=1; return;}
	}
	*ptr=0;
 }
 RecurseDepth=0; DMRecurse(addname(sPath,s,0),addname(dcPath,dest,0),RECURSE_MOVE);
}

void DMSelect(int sel)
{FAST struct DirList **dl,*dlp;
 FAST int	i;
 FAST UBYTE	*str=sbuff+30;

 PatReqFlag=1;
 if(!AA[1]){
	AA[1]=sbuff; sbuff[0]='*'; sbuff[1]=0;
	if(!DMReq("Please specify pattern.",0,0,0,sbuff,31)) return;
 }
 if(!CDWin) return;
 dl=CDWin->DirList;
 for(i=0;i<CDWin->FileCount;i++){
	dlp=dl[i];
	if(dlp->dir==4){
		sprintf(str,"%s%s",dlp->name,dlp->cmt);
		if(DMMatch(str,AA[1])) dlp->sel=sel;
	}else if(DMMatch(dlp->name,AA[1])) dlp->sel=sel;
 }
 dis_files(CDWin); WinTitle(CDWin);
}

void ParseCmd1(struct DirList *dlp,UBYTE *buf)
{FAST UBYTE	*ptr=dlp->name;
 FAST int	i=30;

 dlp->dir=3;
 while(*buf&&*buf!=10&&*buf!=','&&i--) *ptr++=*buf++;
 *ptr--=0;
 while(*ptr==' '||*ptr==9) *ptr--=0;
 dlp->attr=2;
 if(*buf==','){
	buf++; buf=SkipWhite(buf);
	if(buf[2]==','){
		if(*buf>='0'&&*buf<='9'){dlp->attr=(*buf-'0'); buf++;}
		if(*buf>='0'&&*buf<='9'){dlp->attr|=(*buf-'0')<<4; buf++;}
	}
	if(*buf==','){buf++; buf=SkipWhite(buf);}
	ptr=sbuff; i=0;
	while(*buf>10&&i<512){*ptr++=*buf++; i++;}
	*ptr=0;
	if(i) if(dlp->cmt=AllocMem(strlen(sbuff)+1,MEMF_PUBLIC)) strcpy(dlp->cmt,sbuff);
 }
}

void AddCmd(struct DirWindow *dw,UBYTE *buf)
{FAST struct DirList	**dl,*dlp;

 if(!dw){OpenDirWindow("CMD",265,20,110,170); dw=CmdWin;}
 if(!dw) return;
 if(!buf||*buf==0){
	buf=ActionBuf; *buf=0;
	if(!DMReq("Command template: Title,##,<command string>",0,0,0,buf,512)) return;
 }
 if(!(dw->Flags&(DWFLAG_ADD|DW_CMD))) FreeDirTable(dw);
 if(!AllocDlp(dw)) return;
 dw->Flags=DW_CMD; dl=dw->DirList; dlp=dl[dw->FileCount++];
 ParseCmd1(dlp,buf); dw->Flags|=DWFLAG_ADD;
}

void EditCmd(struct DirWindow *dw,int ni)
{FAST struct DirList **dl=dw->DirList,*dlp=dl[ni];
 FAST UBYTE *ptr=dlp->cmt;

 ChgCmd=0;
 sprintf(ActionBuf,"%s, %ld%ld, %s",dlp->name,dlp->attr&0xF,(dlp->attr>>4)&0xF,ptr);
 if(!DMReq("Command template: Title,##,<command string>",0,0,0,ActionBuf,512)) return;
 if(ptr) FreeMem(ptr,strlen(ptr)+1);
 dlp->cmt=0; ParseCmd1(dlp,ActionBuf);
}

void DMReqPat()
{
 if(PatReqFlag) return;
 if(WorkDlp&&!WorkDlp->dir) return;
 if(AA[2]) strcpy(Pattern,AA[2]);
 if(!AA[1]) AA[1]="Directories selected.  Specify pattern.";
 if(!AA[5]) AA[5]="Abort";
 if(DMReq(AA[1],AA[3],AA[4],AA[5],Pattern,31)) PatReqFlag=1;
}

void DMSetFormat(UBYTE *str,UBYTE *fbuf)
{FAST struct DirWindow *dw;
 FAST int	i;

 if(str&&*str) strcpy(fbuf,str);
 else if(!DMReq("Please enter new format.",0,0,0,fbuf,190)) return;
 if(fbuf==DispFormat) for(i=0;i<255;i++) if(dw=DirWin[i]){dis_files(dw); WinTitle(dw);}
}

void AddAutoCmd(UBYTE *str)
{FAST int i=0,len=0;
 FAST UBYTE *ptr;

 if(*str==0){
	sbuff[0]=0;
	if(!DMReq("Auto Command: data,pattern,command string",0,0,0,sbuff,512)) return;
	str=sbuff;
 }
 ptr=str;
 while(*ptr&&*ptr!=10){ptr++; len++;}
 while(AutoCmdStr[i]) i++;
 if(AutoMatch(str,"TEXT",4)) i=253;
 if(AutoMatch(str,"DEFAULT",7)) i=254;
 if(ptr=AutoCmdStr[i]){FreeMem(ptr,strlen(ptr)+1); AutoCmdStr[i]=0;}
 if(i<256&&!AutoCmdStr[i])
	if(AutoCmdStr[i]=AllocMem(len+1,MEMF_PUBLIC|MEMF_CLEAR)) movmem(str,AutoCmdStr[i],len);
}

void FreeAutoCmds()
{FAST UBYTE	*ptr;
 FAST int	i;

 for(i=0;i<256;i++)
	if(ptr=AutoCmdStr[i]){FreeMem(ptr,strlen(ptr)+1); AutoCmdStr[i]=0;}
}

void AddKeyCmd(UBYTE *str)
{FAST int i=0,len=0;
 FAST UBYTE *ptr;

 if(*str==0){
	sbuff[0]=0;
	if(!DMReq("Key Command: C,command string",0,0,0,sbuff,512)) return;
	str=sbuff;
 }
 ptr=str;
 while(*ptr&&*ptr!=10){ptr++; len++;}
 while(KeyCmdStr[i]) i++;
 if(i<100) if(KeyCmdStr[i]=AllocMem(len+1,MEMF_PUBLIC|MEMF_CLEAR))
		movmem(str,KeyCmdStr[i],len);
}

void FreeKeyCmds()
{FAST UBYTE	*ptr;
 FAST int	i;

 for(i=0;i<100;i++)
	if(ptr=KeyCmdStr[i]){FreeMem(ptr,strlen(ptr)+1); KeyCmdStr[i]=0;}
}

void StartRec(int type)
{RecurseDepth=0; DMRecurse(addname(sPath,AA[1],0),0,type);}

void DMSetDate(){DateStamp(&setStamp); StartRec(RECURSE_DATE);}

void RefreshCmdWin(struct DirWindow *dw)
{
 if(dw&&(dw->Flags&DW_CMD)&&(dw->Flags&DWFLAG_ADD)){
	CmdWin=dw; ReSize(dw); NewSize(dw); FindNewDirection(dw);
	ShowDirection(dw,2); dw->Flags&=~DWFLAG_ADD;
 }
}

UBYTE *__asm GetRexxVar1(register __a0 struct RexxMsg *,register __a1 UBYTE *);
LONG __asm SetRexxVar1(FAST __a0 struct RexxMsg *,FAST __a1 UBYTE *,FAST __a2 UBYTE *,FAST __d0 long);

void doDirList(UBYTE *var)
{FAST struct DirList **dl=CDWin->DirList;
 FAST UBYTE *ptr=dcPath+100;
 FAST int i;

 if(!var||*var==0) var="DIRLIST";
 MyStrUpper(var); sprintf(dcPath,"%s.0",var); sprintf(ptr,"%ld",CDWin->FileCount);
 SetRexxVar1(rxMsg,dcPath,ptr,strlen(ptr));
 for(i=0;i<CDWin->FileCount;i++){
	sprintf(dcPath,"%s.%ld",var,i+1);
	DoFileFormat(dl[i],30,80); ptr=sbuff+ColFudge;
	if(dl[i]->dir==1) *ptr='D';
	ptr++;
	if(dl[i]->sel) *ptr='S';
	SetRexxVar1(rxMsg,dcPath,sbuff,ColFudge+2);
 }
 dcPath[0]=0;
}

void doSetList(UBYTE *var)
{FAST struct DirWindow *dw=CDWin;
 FAST struct DirList *dlp;
 UBYTE *ptr;

 if(!var) return;
 MyStrUpper(var); FreeDirTable(dw); dw->Path[0]=dw->Devi[0]=0; dw->ColsCmt=dw->ColsName=0;
 sprintf(dcPath,"%s.0",var);
 if((ptr=GetRexxVar1(rxMsg,dcPath))&&(*ptr)) strcpy(dw->Path,ptr);
 for(;;){
	sprintf(dcPath,"%s.%ld",var,dw->FileCount+1);
	if(!(ptr=GetRexxVar1(rxMsg,dcPath))||!AllocDlp(dw)||*ptr==0) break;
	dlp=dw->DirList[dw->FileCount++]; dlp->dir=4; movmem(ptr,dlp->name,30);
	if(strlen(ptr)>30){
		ptr+=30;
		if(dlp->cmt=AllocMem(strlen(ptr)+1,MEMF_PUBLIC|MEMF_CLEAR))
			strcpy(dlp->cmt,ptr);
	}
 }
 dcPath[0]=0; ReSize(dw); NewSize(dw);
}

void RefreshGadget(struct Gadget *,struct Window *);

void DoSwap()
{FAST struct DirList **dl;
 FAST UBYTE	*ptr=ReqStr;
 FAST int	len;
 FAST struct DirWindow *dw=CDWin;

 if(!dw||!DestWin) return;
 dl=dw->DirList; dw->DirList=DestWin->DirList; DestWin->DirList=dl;
 len=(char *)&dw->v_img-(char *)&dw->Fib;
 movmem((char *)&dw->Fib,ptr,len);
 movmem((char *)&DestWin->Fib,(char *)&dw->Fib,len);
 movmem(ptr,(char *)&DestWin->Fib,len);
 RefreshGadget(&dw->dir_gad,dw->Window); dis_files(dw); WinTitle(dw);
 dw=DestWin;
 RefreshGadget(&dw->dir_gad,dw->Window); dis_files(dw); WinTitle(dw);
}

void FreeMod()
{
 if(Module) FreeMem(Module,ModSize);
 Module=0; ModSize=0;
}

void LoadMod(UBYTE *name)
{FAST int n;

 if(Module){MTEnd(); FreeMod();}
 if(!name||!AA[1]) return;
 if(!AutoUnpack(name,MEMF_PUBLIC|MEMF_CHIP)) return;
 Module=PackBuf; ModSize=PackSize; PackBuf=0; PackSize=0;
 if(n=MTInit(Module)){display("Module error",0); FreeMod(); Delay(50);}
}

void DoCmd(struct DirWindow *dw)
{FAST struct Window *win;
 UBYTE		temp[4];
 FAST ULONG	*CmdL=(ULONG *)temp;
 FAST int	l,t,w,h,lock,i;

 if(!AA[0]) return;
 MyStrUpper(AA[0]); movmem(AA[0],temp,4);
 switch(*CmdL){
/*About*/ case 0x41424f55: About(); break;
/*AddAut*/case 0x41444441: AddAutoCmd(AA[1]); break;
/*AddCmd*/case 0x41444443: AddCmd(dw,AA[1]); break;
/*AddKey*/case 0x4144444b: AddKeyCmd(AA[1]); break;
/*AddMen*/case 0x4144444d: AddMenuCmd(AA[1]); break;
/*Archiv*/case 0x41524348: DMArchive(AA[1],AA[2]); break;
/*AUTO  */case 0x4155544F: StartRec(RECURSE_AUTO); break;
/*Back  */case 0x4241434b: if(BWindow) DoPattern(BWindow,AA[1],AA[2]); break;
/*BarFor*/case 0x42415246: DMSetFormat(AA[1],BarFormat); break;
/*Batch */case 0x42415443: GetCmdFile(dw,AA[1],0); break;
/*Button*/case 0x42555454: if(!AA[1][0]) DMReq("Enter new command string.",0,0,0,PGadStr,250);
			   else strcpy(PGadStr,AA[1]); break;
/*Check */case 0x43484543: if(!CDWin->Path[0]){
				if(lock=Lock(AA[1],ACCESS_READ)){
					Info(lock,&InfoData);
					CDWin->BytesPerBlock=InfoData.id_BytesPerBlock;
					UnLock(lock);
				}
			   }
			   if(DestWin&&DestWin->BytesPerBlock)
					BPB=DestWin->BytesPerBlock;
			   else 	BPB=CDWin->BytesPerBlock;
			   if(!BPB) break;
			   StartRec(RECURSE_CHECK);
			   i=(BlkTotal*BPB);
			   if(DestWin){
				l=DestWin->DiskFree-i;
				if(l<0) sprintf(ScreenTitle,"Total: %ld  Not enough room.",i);
				else    sprintf(ScreenTitle,"Total: %ld  Leaving %ld free.",i,l);
			   }else sprintf(ScreenTitle,"Total: %ld",i);
			   display(ScreenTitle,0); break;
/*ChgCmd*/case 0x43484743: ChgCmd=1; display("Select Command to Edit",0); break;
/*CloseW*/case 0x434c4f53: CloseDirWindow(DWNum); break;
/*Color */case 0x434f4c4f: SetColors(); break;
/*Commen*/case 0x434f4d4d: StartRec(RECURSE_NOTE); break;
/*Confir*/case 0x434f4e46: if(!ConfirmFlag&&!PatReqFlag){h=0;
				if(AA[4]){strcpy(ReqStr,AA[4]); h=512; rexxStr=ReqStr;}
				if(!DMReq(AA[1],AA[2],AA[3],0,rexxStr,h)) Abort=1;
				if(!AA[4]) ConfirmFlag=1;
			   }
			   break;
/*Copy	*/case 0x434f5059: if(!AA[1]) break;
			   if(!AA[2]){
				AA[2]=dcPath; dcPath[0]=0;
				if(DestWin) strcpy(dcPath,DestWin->Path);
				if(!DMReq("Enter destination path.",0,0,"Abort",dcPath,512)) break;
			   }
			   RecurseDepth=0; DMRecurse(addname(sPath,AA[1],0),addname(dcPath,AA[2],0),RECURSE_COPY); break;
/*Delete*/case 0x44454c45: StartRec(RECURSE_DEL); break;
/*Desele*/case 0x44455345: DMSelect(0); break;
/*DirLis*/case 0x4449524c: if(rxMsg&&CDWin) doDirList(AA[1]); break;
/*DiskCo*/case 0x4449534b: MainDiskEntry(); break;
/*Displa*/case 0x44495350: StartRec(0); break;
/*Expand*/case 0x45585041: if(AA[1]) expandflag=(MyToUpper(AA[1][1])!='F');
			   else expandflag^=1;
			   break;
/*Extern*/case 0x45585445: if(LoopFlag){RecurseDepth=0; DMRecurse(strlen(sPath),0,RECURSE_EXEC);}
			   else DOSExecute(); ReSort(); break;
/*Find  */case 0x46494e44: if(WorkDlp->dir) StartRec(RECURSE_FIND); break;
/*Format*/case 0x464f524d: MainDiskEntry(); break;
/*Font  */case 0x464f4e54: DMOpenFont(AA[1]); break;
/*Host  */case 0x484f5354: GetHostScreen(AA[1]); break;
/*Lock  */case 0x4c4f434b: if(!CDWin) break;
			   switch(MyToUpper(AA[1][0])){
				case 'S': CDWin->Flags|=DW_SOURCE; CDWin->Flags&=~DW_DEST;
					  ShowDirection(CDWin,0); break;
				case 'D': CDWin->Flags|=DW_DEST; CDWin->Flags&=~DW_SOURCE;
					  ShowDirection(CDWin,1); break;
			   }
			   break;
/*MakeDi*/case 0x4d414b45: DMMakeDir(AA[1]); break;
/*Move	*/case 0x4d4f5645: DMMove(AA[1],AA[2]); break;
/*Msg	*/case 0x4d534700: display(AA[1],AA[2]); break;
/*NewDir*/case 0x4e455744: if(CDWin){
				if(AA[1]) strcpy(CDWin->Path,AA[1]);
				else CDWin->Path[0]=0;
				InitDir(CDWin,0);
			   }
			   break;
/*OpenWi*/case 0x4f50454e: RefreshCmdWin(dw);
			   if(AA[0][4]=='W'){
				l=atoi(AA[1]); t=atoi(AA[2]); w=atoi(AA[3]);
				h=atoi(AA[4]); OpenDirWindow(AA[5],l,t,w,h);
			   }else if(!MyScreen) MyScreen=MyOpenScreen(1,1,"DM");
			   if(MyScreen) Screen=MyScreen;
			   break;
/*PACK  */case 0x5041434B: PackOpt=1;
/*UNPACK*/case 0x554E5041: if(!AA[1]) break;
			   if(!AA[2]){
				AA[2]=dcPath; dcPath[0]=0;
				if(DestWin) strcpy(dcPath,DestWin->Path);
				if(!DMReq("Enter destination path.",0,0,"Abort",dcPath,512)) break;
			   }
			   RecurseDepth=0;
			   DMRecurse(addname(sPath,AA[1],0),addname(dcPath,AA[2],0),RECURSE_PACK);
			   PackOpt=0; break;
/*Parent*/case 0x50415245: if(CDWin&&CDWin->Path[0]){GetParent(CDWin->Path,0); InitDir(CDWin,0);}
			   break;
/*Pens  */case 0x50454e53: SetPens(); break;
/*PLAY  */case 0x504c4159: LoadMod(AA[1]); break;
/*Priori*/case 0x5052494f: if(!AA[1]){
				AA[1]=dcPath; dcPath[0]='0'; dcPath[1]=0;
				if(!DMReq("Enter new priority.",0,0,0,dcPath,512)) break;
			   }
			   SetTaskPri(FindTask(0),atoi(AA[1])); break;
/*Print */case 0x5052494e: PrintIt=1;
			   if(MyToUpper(AA[0][5])=='D'){
				if(!AA[1]||!AA[2]||!CDWin){Abort=1; break;}
				if(!pfh){
					if(!(pfh=Open(AA[2],MODE_NEWFILE))){Abort=1; break;}
					sprintf(sbuff,"Listing of %s\n",CDWin->Path);
					if(Write(pfh,sbuff,strlen(sbuff))<=0){Abort=1; break;}
				}
				DoFileFormat(WorkDlp,CDWin->ColsName,CDWin->ColsCmt);
				sbuff[ColFudge-1]=0;
				if(!stricmp(AA[2],"PRT:")){
					sprintf(dcPath,"\x1b[0m%s\x1b[0m\n",sbuff);
					dcPath[2]=WorkDlp->dir?'1':'0';
				}else sprintf(dcPath,"%s\n",sbuff);
				if(Write(pfh,dcPath,strlen(dcPath))<=0) Abort=1;
			   }else StartRec(RECURSE_READ);
			   break;
/*Protec*/case 0x50524f54: StartRec(RECURSE_PROT); break;
/*Quit	*/case 0x51554954: KeepGoing=CheckScreen(); break;
/*Read	*/case 0x52454144: StartRec(RECURSE_READ); break;
/*Recurs*/case 0x52454355: RecFlag=(MyToUpper(AA[1][1])=='F'); break;
/*RemMen*/case 0x52454d4d: RemMenu=1; display("Select menu item to remove",0); break;
/*Rename*/case 0x52454e41: if(WorkDlp->dir==2&&RecFlag){
				if(DMRelabel(WorkDlp->name,AA[1],AA[2])) InitDir(CDWin,0);
			   }else StartRec(RECURSE_REN); break;
/*ReqPat*/case 0x52455150: DMReqPat(); break;
/*RESET */case 0x52455345: FreeUserJunk(); break;
/*REXX	*/case 0x52455858: SendRexx(); break;
/*Root	*/case 0x524f4f54: if(CDWin&&CDWin->Path[0]){GetParent(CDWin->Path,1); InitDir(CDWin,0);} break;
/*Save  */case 0x53415645: SaveConfig(); break;
/*ScrBac*/case 0x53435242: WBenchToFront(); break;
/*ScrFro*/case 0x53435246: ScreenToFront(Screen); break;
/*Select*/case 0x53454c45: DMSelect(1); break;
/*SetDat*/case 0x53455444: DMSetDate(); break;
/*SetLis*/case 0x5345544c: if(rxMsg&&CDWin) doSetList(AA[1]); break;
/*SetFor*/case 0x53455446: DMSetFormat(AA[1],DispFormat); break;
/*SetPat*/case 0x53455450: if(AA[0][4]=='R') PrintReq();
			   else{PatReqFlag=1; strcpy(Pattern,AA[1]);}
			   break;
/*ShowPi*/case 0x53484f57: StartRec(RECURSE_SHOW); break;
/*Single*/case 0x53494e47: SingleFlag=1; break;
/*Sort  */case 0x534f5254: switch(MyToUpper(AA[1][0])){
				case 'N': SortType=0; break;
				case 'S': SortType=1; break;
				case 'D': SortType=2; break;
			   }
			   ResortAll(); break;
/*Status*/case 0x53544154: switch(MyToUpper(AA[1][0])){
				case 'P': rexxStr=CDWin->Path; break;
				case 'F': rexxStr=DispFormat; break;
				case 'V': rexxStr=Version; break;
				case 'H': if(HostID[0]) rexxStr=HostID;
					  else rexxStr=DMname; break;
				case 'D': if(DestWin) rexxStr=DestWin->Path;
			   }
			   break;
/*Stdio */case 0x53544449: DoStdio(AA[1]); break;
/*Swap  */case 0x53574150: DoSwap(); break;
/*TitleF*/case 0x5449544C: DMSetFormat(AA[1],TitleFormat); break;
/*UnLock*/case 0x554e4c4f: if(AA[1][0]) UnLockAll();
			   else if(CDWin){CDWin->Flags&=~(DW_DEST|DW_SOURCE); ShowDirection(CDWin,0);}
			   break;
/*UnMark*/case 0x554e4d41: if(AA[1]&&!stricmp(AA[1],"OFF")) unMark=1;
			   else unMark=0;
			   break;
/*Wait  */case 0x57414954: if(t=atoi(AA[1])) Delay(t*50);
			   else if(StdIO){
				if(!AA[1]) AA[1]="Press RETURN to continue...";
				Write(StdIO,AA[1],strlen(AA[1])); Read(StdIO,&sbuff,1);
			   }else WaitPort(WinPort);
			   break;
/*Window*/case 0x57494e44: win=0;
			   if(!AA[1]){rexxErr=1; break;}
			   if(!stricmp(AA[1],"DEST")) win=DestWin->Window;
			   else if(!stricmp(AA[1],"NEXT")){
				t=DWNum+1;
				while(t!=DWNum){
				  if(t>=254) t=0;
				  if(DirWin[t]&&!(DirWin[t]->Flags&DW_CMD))
					{win=DirWin[t]->Window; break;}
				  t++;
				}
			   }else for(t=0;t<255;t++){
				  if(DirWin[t]) if(!stricmp(DirWin[t]->Path,AA[1]))
						{win=DirWin[t]->Window; break;}
			   }
			   if(win) ActivateWindow(win);
			   else rexxErr=1;
			   break;
 }
}

int UnLockAll()
{FAST struct DirWindow *dw;
 FAST int i;

 for(i=0;i<255;i++){
	dw=DirWin[i];
	if(dw&&(dw->Flags&(DW_DEST|DW_SOURCE)))
		{dw->Flags&=~(DW_DEST|DW_SOURCE); ShowDirection(dw,4);}
 }
 ShowDirection(CDWin,0); ShowDirection(DestWin,1); return(0);
}

UBYTE *ParseArgs(UBYTE *buf,struct DirWindow *dw)
{FAST UBYTE	*ptr,q;
 FAST int	i,inq;

NXTCMD:
 ptr=ActionBuf; i=inq=0;
 while(*buf==' '||*buf==9) buf++;
 while(*buf>10){
	if(*buf=='"'||*buf==39) inq^=1;
	if(!inq&&*buf==';') break;
	*ptr++=*buf++;
 }
 *ptr=0; ptr=ActionBuf;
 while(i<30){
	while(*ptr&&(*ptr<=' '||*ptr==',')) ptr++;
	if(*ptr=='"'||*ptr==39){
		q=*ptr++; AA[i]=ptr;
		while(*ptr&&*ptr!=q) ptr++;
		if(AA[i]==ptr) AA[i]=0;
	}else{	AA[i]=ptr;
		while(*ptr&&*ptr!=' '&&*ptr!=',') ptr++;
		if(AA[i]==ptr) AA[i]=0;
	}
	i++;
	if(*ptr) *ptr++=0;
	else break;
 }
 while(i<30) AA[i++]=0;
 i=0;
 while(AA[i]){
	ptr=AA[i];
	if(*ptr=='%') switch(MyToUpper(ptr[1])){
		case 'S': AA[i]=sPath; LoopFlag=1;
			  if(!CDWin){AA[i]=0; Abort=1;}
			  break;
		case 'D': AA[i]=dcPath;
			  if(DestWin) strcpy(dcPath,DestWin->Path);
			  else{AA[i]=0; Abort=1;}
			  if(AA[i]&&*AA[i]==0) AA[i]=0;
			  break;
		case 'P': if(!CDWin){AA[i]=0; Abort=1;}
			  else AA[i]=CDWin->Path;
			  break;
		case 'R': AA[i]=ReqStr; break;
	}
	i++;
 }
 if(!Abort){DoCmd(dw); dw=CmdWin;}
 if(*buf==';'&&!Abort){buf++; goto NXTCMD;}
 return(buf);
}

void MakeFullName(UBYTE *buf,struct DirWindow *dw,UBYTE *name)
{
 if(!dw) dw=CDWin;
 if(!dw){*buf=0; return;}
 strcpy(buf,dw->Path);
 if(*buf&&buf[strlen(buf)-1]!=':') strcat(buf,"/");
 strcat(buf,name);
}

void ResetFlags()
{
 Abort=PatReqFlag=ConfirmFlag=RecurseAttr=NoteFlag=AttrFlag=RecFlag=SingleFlag=PrintIt=unMark=0;
 LoopFlag=0; Pattern[0]='*'; Pattern[1]=0;
}

void ActionCmd(struct DirWindow *dw,UBYTE *buf)
{FAST struct DirWindow *dw2;
 FAST struct DirList **dl,*dlp=0;
 FAST UBYTE	*ptr,*BufS;
 FAST int	c,k,loop,dloop,destlocked,j,item;

 if(!buf) return;
 ResetFlags(); rexxStr=0; ReqStr[0]=0;
 while(*buf){
NXTLIN: while(*buf&&*buf<=' ') buf++;
	if(*buf==0) break;
	k=(*buf==';');
	if(MyToUpper(*buf)=='A'&&MyToUpper(buf[1])=='D') k=-1;
	if(k){	if(k<0){AA[0]=ptr=ActionBuf;
			while(*buf>' ') *ptr++=*buf++;
			*ptr=0;
			if(*buf==' '||*buf==9) buf++;
			AA[1]=buf; DoCmd(dw); dw=CmdWin;
		}
		while(*buf&&*buf!=10) buf++;
	}else{	loop=dloop=0; BufS=buf; destlocked=0; BlkTotal=0; item=0;
		while(*BufS&&*BufS!=10){
			if(*BufS=='%'&&MyToUpper(BufS[1])=='S') loop=1;
			if(*BufS=='%'&&MyToUpper(BufS[1])=='D') dloop=1;
			BufS++;
		}
		if(loop) for(j=0;j<255;j++){
			dw2=DirWin[j];
			if(dw2&&(dw2->Flags&DW_SOURCE)&&dw2->Sels){CDWin=dw2; break;}
		}
		BufS=buf; sPath[0]=0;
NXTLOOP:	if(CDWin) strcpy(sPath,CDWin->Path);
		DirTotal=0;
		if(loop){
		  if(!CDWin) return;
		  dl=CDWin->DirList;
		  while(item<CDWin->FileCount){
			dlp=dl[item];
			if(dlp->sel==1){
				while(item>=(CDWin->Index+CDWin->Rows-1)&&item<CDWin->FileCount-1) Increment(CDWin,&CDWin->dn);
				MakeFullName(sPath,CDWin,dlp->name); break;
			}
			item++;
		  }
		  if(item>=CDWin->FileCount){
			CDWin->Sels=0;
			for(j=0;j<255;j++){
				dw2=DirWin[j];
				if(dw2&&(dw2->Flags&DW_SOURCE)&&dw2->Sels){CDWin=dw2; item=0; goto NXTLOOP;}
			}
			while(*buf&&*buf!=10) buf++;
			goto NXTLIN;
		  }
		  if(CDWin->Flags&DW_DEST) return;
		}
		WorkDlp=dlp;
		if(dloop) for(j=0;j<255;j++){
		  dw2=DirWin[j];
		  if(dw2&&(dw2->Flags&DW_DEST)){
			DestWin=dw2; destlocked=1; ParseArgs(buf,dw); dw=CmdWin;
			if(CheckAbortKey()){rexxErr=1; Abort=0; display("Operation Aborted",0); goto DIE;}
			if(CDWin&&dlp->sel==1) MakeFullName(sPath,CDWin,dlp->name);
			buf=BufS;
		  }
		}
		if(!destlocked){
			buf=ParseArgs(buf,dw); dw=CmdWin;
			if(CheckAbortKey()){rexxErr=1; Abort=0; display("Operation Aborted",0); goto DIE;}
		}
		if(loop&&CDWin&&dlp){
			if(DirTotal&&dlp->dir==1) dlp->size=DirTotal;
			if(item<CDWin->FileCount&&dlp->sel<2&&!unMark) dlp->sel=0;
			c=CDWin->Index;
			if(item>=c&&item<(c+CDWin->Rows)) dis_name(CDWin,item,item-c);
			dlp=0;
			if(!SingleFlag){buf=BufS; item++; goto NXTLOOP;}
		}
	}
 }
DIE:
 CloseRead(); FreeOldPic(); RefreshCmdWin(dw);
 ReSort(); WinTitle(CDWin); ResetFlags();
 if(pfh){Close(pfh); pfh=0;}
}

int DoKeyCmd(struct DirWindow *dw,int c)
{FAST int	i;
 FAST UBYTE	*ptr;

 for(i=0;i<100;i++)
   if(ptr=KeyCmdStr[i])
	if(c==*ptr){
		while(*ptr&&*ptr!=',') ptr++;
		ActionCmd(dw,ptr); return(1);
	}
 return(0);
}

void GetCmdFile(struct DirWindow *dw,UBYTE *name,int size)
{FAST sFIB	*fib=&Fib;
 FAST int	lock,fh;
 FAST UBYTE	*buf;

 if(size<=0){
	if(!(lock=Lock(name,ACCESS_READ))) return;
	if(Examine(lock,fib)) size=fib->fib_Size;
	UnLock(lock);
 }
 if(size<=0) return;
 if(!(buf=AllocMem(size+4,MEMF_PUBLIC|MEMF_CLEAR))) return;
 if(fh=Open(name,MODE_OLDFILE)){
	if(dw) CmdWin=dw;
	strcpy(dcPath,name);
	if(Read(fh,buf,size)>0) ActionCmd(dw,buf);
	Close(fh);
 }
 FreeMem(buf,size+4);
}

int AutoUnpack(UBYTE *name,int type)
{FAST struct LhBuffer *lh;
 FAST sFIB	*fib=&Fib;
 FAST UBYTE	*buf;
 FAST ULONG	dsize,*lptr,size;
 FAST int	fh,n,ret=0,lock;
 ULONG		temp;

 if(PackBuf){FreeMem(PackBuf,PackSize); PackBuf=0; PackSize=0;}

 if(!(lock=Lock(name,ACCESS_READ))) return(0);
 if(Examine(lock,fib)) size=fib->fib_Size;
 UnLock(lock);
 if(!size) return(0);

 if(!(fh=Open(name,MODE_OLDFILE))) return(0);
 Read(fh,(UBYTE *)&temp,4); Close(fh);
 if(temp!=0x444D5030){
	if(!(buf=AllocMem(size,type))) return(0);
	if(!(fh=Open(name,MODE_OLDFILE))){FreeMem(buf,size); return(0);}
	Read(fh,buf,size); Close(fh);
	PackBuf=buf; PackSize=size;
	return(1);
 }
 if(!(lh=CreateBuffer(0))) return(0);
 if(!(buf=AllocMem(size,MEMF_PUBLIC))) goto Q1;
 lh->lh_Src=buf;
 lh->lh_SrcSize=size;

 if(!(fh=Open(name,MODE_OLDFILE))) goto Q2;
 n=Read(fh,buf,size); Close(fh);
 if(n<=0) goto Q2;

 lptr=(ULONG *)buf;
 if(!(lh->lh_Dst=AllocMem(dsize=lptr[2],type))) goto Q2;
 lh->lh_DstSize=dsize;
 display("Unpacking %s",name);
 lh->lh_Src=buf+12;
 if(LhDecode(lh)){
	PackBuf=lh->lh_Dst; PackSize=dsize;
	ret=1; goto Q2;
 }
 FreeMem(lh->lh_Dst,dsize);
Q2: FreeMem(buf,size);
Q1: DeleteBuffer(lh);
 return(ret);
}

void AutoFiler(struct DirWindow *dw,UBYTE *name)
{FAST int	fh,i,len2,j,k;
 FAST UBYTE	*ptr,*ptr2,*ptr3;

 MakeFullName(sPath,CDWin,name); ResetFlags();
 if(!(fh=Open(sPath,MODE_OLDFILE))) return;
 Read(fh,sbuff,200); Close(fh);
 for(i=0;i<256;i++)
	if(ptr=AutoCmdStr[i]){
		ptr2=dcPath; len2=0; *ptr2=0;
		while(*ptr&&*ptr!=','){*ptr2++=*ptr++; len2++;}
		ptr++; ptr2--;
		while(len2>0&&*ptr2<=' '){ptr2--; len2--;}
		ptr2++; *ptr2=0; MyStrUpper(dcPath);
		if(len2<=0) j=1;
		else if(!(j=AutoMatch(sbuff,dcPath,len2))){
			if(!stricmp(dcPath,"TEXT")){
				k=199;
				while(k) if(!sbuff[k--]) break;
				if(!k) j=1;
			}else if(!stricmp(dcPath,"DEFAULT")) j=1;
		}
		ptr2=dcPath; len2=0; *ptr2=0; ptr3=ptr;
		while(*ptr3&&*ptr3!=','&&len2<32){*ptr2++=*ptr3++; len2++;}
		if(*ptr3==','){
			ptr2--; ptr=ptr3+1;
			while(len2>0&&*ptr2<=' '){ptr2--; len2--;}
			ptr2++; *ptr2=0; MyStrUpper(dcPath);
			if(len2>0&&j) j=DMMatch(name,dcPath);
		}
		if(j){ParseArgs(ptr,dw); break;}
	}
 CloseRead(); FreeOldPic(); ReSort(); WinTitle(CDWin); ResetFlags();
}

