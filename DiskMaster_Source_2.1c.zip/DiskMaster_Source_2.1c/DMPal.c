
	/***************************************************************\
	*	DM2 Palette		   By Greg Cunningham		*
	*				� 1990 Nomad Development	*
	*	DMPal.c 						*
	*				Update: Feb 4,1991		*
	\***************************************************************/

#include "DM.h"

extern struct Screen	*Screen,*MyScreen;
extern struct Process	*process;
extern struct MsgPort	*WinPort;
extern struct TextFont	*MyTopaz;
extern struct TextAttr	FuckingTopaz;
extern UBYTE		*ActionArgs[];

struct Window	*Palette;

int	cursel,pColors,UserCols;
UWORD	*ColorP,ColMap[32],backup[32],Pens20[12]={0,1,1,2,1,3,1,0,3,0xFFFF};

struct IntuiText
	pcnl={3,0,JAM2,121,-9,&FuckingTopaz,"Cancel",0},
	rtxt={3,0,JAM2, -9, 1,&FuckingTopaz,"R",&pcnl},
	gtxt={3,0,JAM2, -9, 1,&FuckingTopaz,"G",0},
	btxt={3,0,JAM2, -9, 1,&FuckingTopaz,"B",0};

struct Image	img,r_img,g_img,b_img;
struct PropInfo r_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0},
		g_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0},
		b_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0};

struct Gadget
 blue_gad={		0,13,48,169,9,GADGHNONE,GADGIMMEDIATE|RELVERIFY,
	PROPGADGET,(APTR)&b_img,0,&btxt,0,(APTR)&b_prop,80,0},
 green_gad={&blue_gad,	13,38,169,9,GADGHNONE,GADGIMMEDIATE|RELVERIFY,
	PROPGADGET,(APTR)&g_img,0,&gtxt,0,(APTR)&g_prop,81,0},
 red_gad={&green_gad,	13,28,169,9,GADGHNONE,GADGIMMEDIATE|RELVERIFY,
	PROPGADGET,(APTR)&r_img,0,&rtxt,0,(APTR)&r_prop,82,0};

struct NewWindow
 NewPal={40,28,187,59,3,2,RAWKEY|GADGETDOWN|CLOSEWINDOW|MOUSEBUTTONS,
	RMBTRAP|SMART_REFRESH|NOCAREREFRESH|WINDOWDRAG|WINDOWCLOSE|WINDOWDEPTH,
	&red_gad,0,"Color Palette",0,0,0,0,0,0,CUSTOMSCREEN};

void ColorHex(void);
void set_col(void);
void PaletteGads(void);

void ColorHex()
{FAST struct RastPort *rp=Palette->RPort;
 UBYTE buf[8];

 sprintf(buf,"%lX-%03lX",cursel,ColorP[cursel]);
 Move(rp,136,Screen->BarHeight+8); Text(rp,buf,5);
}

void set_col()
{FAST UWORD col=ColorP[cursel];

 r_prop.HorizPot=(col>>8)*0x1111;
 g_prop.HorizPot=((col>>4)&0xF)*0x1111;
 b_prop.HorizPot=(col&0xF)*0x1111;
}

void OpenPalette()
{FAST struct RastPort *rp;
 FAST int i,I,n,t=Screen->BarHeight+2;

 if(Palette){
	CloseSharedWindow(Palette); Palette=0;
	movmem((char *)ColorP,(char *)ColMap,UserCols<<1);
 }else{ NewPal.Screen=Screen;
	ColorP=(UWORD *)Screen->ViewPort.ColorMap->ColorTable;
	UserCols=pColors=1<<Screen->BitMap.Depth;
	movmem((char *)ColorP,(char *)backup,64); cursel=0; set_col();
	red_gad.TopEdge  =t+18;
	green_gad.TopEdge=t+28;
	blue_gad.TopEdge =t+38;
	NewPal.Height	 =t+49;
	if(Palette=OpenSharedWindow(&NewPal)){
		SetFont(Palette->RPort,MyTopaz);
		n=130/pColors; rp=Palette->RPort;
		for(I=1;I<pColors;I++){
			SetAPen(rp,I); i=I*n; RectFill(rp,i+4,t,i+n+2,t+14);
		}
		ColorHex();
	}
 }
}

void PaletteMouse(int code,int x,int y)
{FAST int		newsel,i;
 FAST struct Screen	*next=Screen->NextScreen;

 if(code==105&&next&&Screen){
	i=1<<(next->BitMap.Depth+1);
	if(i>64) i=64;
	movmem((char *)next->ViewPort.ColorMap->ColorTable,(char *)ColorP,i);
	LoadRGB4(&Screen->ViewPort,ColorP,32);
 }else if(y>26||code!=SELECTDOWN) return;
 else if(x>130){
	movmem((char *)backup,(char *)ColorP,64);
	LoadRGB4(&Screen->ViewPort,ColorP,32);
	OpenPalette(); return;
 }else{	newsel=(x-4)/(130/pColors);
	if(newsel!=cursel)
		{cursel=newsel; set_col(); RefreshGadgets(&red_gad,Palette,0);}
 }
 ColorHex();
}

void PaletteGads()
{FAST LONG sig=1<<WinPort->mp_SigBit;

 do{	Delay(4);
	ColorP[cursel]=((r_prop.HorizPot>>4)&0xF00)+
		((g_prop.HorizPot>>8)&0xF0)+(b_prop.HorizPot>>12);
	LoadRGB4(&Screen->ViewPort,ColorP,32); ColorHex();
 }while(!(SetSignal(0,sig)&sig));
 ColorHex();
}

void DoPalette(int code,int x,int y,int class)
{
 switch(class){
	case CLOSEWINDOW: OpenPalette(); break;
	case GADGETDOWN: PaletteGads(); break;
	case MOUSEBUTTONS: PaletteMouse(code,x,y); break;
 }
}

void SetColors()
{FAST UBYTE *ptr;
 FAST int c,i=1,g=0,x;

 if(!ActionArgs[1]){OpenPalette(); return;}
 while(ActionArgs[i]){
	ptr=ActionArgs[i++]; ColMap[g]=0;
	while(c=MyToUpper(*ptr++)){
		if(c=='.') g++;
		x=0;
		if(c>='0'&&c<='9') x=c-'0';
		if(c>='A'&&c<='F') x=c-'7';
		ColMap[g]<<=4; ColMap[g]|=x;
	}
	g++;
 }
 UserCols=g;
 if(MyScreen) LoadRGB4(&MyScreen->ViewPort,ColMap,g);
}

void SetPens()
{FAST UBYTE *ptr;
 FAST int c,i=1,g=0,x;

 while(ActionArgs[i]){
	ptr=ActionArgs[i++]; Pens20[g]=0;
	while(c=MyToUpper(*ptr++)){
		if(c=='.') g++;
		x=0;
		if(c>='0'&&c<='9') x=c-'0';
		Pens20[g]*=10; Pens20[g]+=x;
	}
	g++;
 }
 Pens20[g]=0xFFFF;
}

