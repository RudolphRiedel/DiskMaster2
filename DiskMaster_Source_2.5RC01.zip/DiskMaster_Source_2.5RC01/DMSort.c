/* DiskMaster II  Sorter Module
**
** Author: Richard "Dragon" Backhaus,Rudolph "Shadowolf" Riedel
** Date: 25.08.1997,07.09.1997
**
** 00-07-01 rri - replaced all c++ style comments by ANSI ones
**              - changed Resort() to make dw->Devi[] obsolete
**
** 00-07-10 rri - replaced MyToUpper() calls by ToUpper() (utility.library)
**              - changed various stricmp() to Stricmp() calls
**
** 00-07-20 rri - removed the "const" atributes from the compare-functions
**                to get rid of some meaningless warnings
**
** 00-08-30 rri - changed order of sort-types to NSDC
**              - added a new sort-type: 'T' - toggle
**
** 00-10-26 rri - commented-out path-invalid-update-code from ReSort()
**                as it hasn`t been executed before 2.5b7 anyways
**
** 2.5b10
**
** 00-12-19 rri - corrected qsort() function calls by changing "count"
**                in all calls from int to ULONG (u_int)
**              - removed one "warning 220" from Resort()
**              - removed one "warning 317" from GlobalSort()
**
** 00-12-26 rri - removed 19 "warning 120"s
**
** 00-12-28 rri - changed function-headers of DMSortN(), DMSortS()
**                DMSortD() and DMSortC()
**
** 01-01-10 rri - changed var names in cmpnameU() and cmpnameD()
**                from "->name" to "->name2"
**
** 01-01-14 rri - bugfix: ReSort() did a FreeMen() on a "->cmt"
**              - added "AsmFreePooled(NamePool,dl[i]->name2,..." to ReSort()
**
** 01-01-16 rri - added a little extra magic to Sort() which let
**                'Sort' behave different during startup.
**
** 01-01-18 rri - removed the "magic" from Sort() and gave
**                it to ReSort() instead
**
** 01-01-28 rri - introduced PoolFreeVec() for comments
**              - changed ->name2 referencies to ->name
**              - introduced PoolFreeVec() for names
**
** 2.5b12
**
** 01-08-01 rri - added sort by extension
**              - optimised and enhanced sort by comment
**              - optimised sort by name
**              - optimised sort by size and sort by extension with
**                new sub-routine CountDirs()
**
*/

#include "DM.h"

extern struct DirWindow     *DirWin[],*CDWin;
extern struct FileInfoBlock Fib;
extern struct Process       *process;

extern int BatchFlag, /* 2.5b10 rri */
           lockcount;

extern UBYTE *ActionArgs[]; /* new! 2.3 */

extern APTR CommentPool, /* 2.5b10 rri */
            NamePool;    /* 2.5b10 rri */


int SortType=0; /* new! 2.3 */

int cmpextU(struct DirList **val1,struct DirList **val2); /* 2.5b12 rri */
int cmpextD(struct DirList **val1,struct DirList **val2); /* 2.5b12 rri */
int CountDirs(struct DirList **dl,ULONG count); /* 2.5b12 rri */



int CountDirs(struct DirList **dl,ULONG count) /* 2.5b12 rri */
{
int i, dircount;

dircount=0;

for(i=0; i<=count-1; i++)
 {
  if(dl[i]->dir==1)
   {
    dircount++;
   }
  else
   {
    break;
   }
 }
return(dircount);
}

/*
Name:	DMSort Name + additional compare routines
*/

void DMSortN(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{

if (direction == 0)
 {
  qsort(dl,(size_t) count,(size_t) sizeof(dl),*cmpnameU); /* new! inserted 25.08.97 dGN! */
 }
else if (direction == 1)
 {
  qsort(dl,(size_t) count,(size_t) sizeof(dl),*cmpnameD);
 }
}


int cmpnameU(struct DirList **val1,struct DirList **val2) /* new! inserted 25.08.97 dGN! */
{
if(val1[0]->dir==val2[0]->dir)
/* if both files are either files or directories they should be compared */
 {
  return(Stricmp(val1[0]->name,val2[0]->name)); /* 2.5b7 rri */
 }
else if(val1[0]->dir>val2[0]->dir)
/* if only the first file is a dir, it moves ahead */
 {
 return(-10);
 }
else if(val1[0]->dir<val2[0]->dir)
/* if only the second file is a dir, it moves ahead */
 {
 return(10);
 }
}


int cmpnameD(struct DirList **val1,struct DirList **val2)
{
int i;

i=cmpnameU(val1,val2);

if (i==1||i==(-1)) i=i*(-1);

return i;
}


/*
Name:	DMSort Size + additional compare routines
*/

void DMSortS(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{
int	dircount,filecount;

qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpnameU);

dircount=CountDirs(dl,count); /* 2.5b12 rri */
filecount=count-dircount; /* 2.5b12 rri */

if (filecount) /* new! 2.2b15 */
 {
 if (direction==2) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),&cmpsizeU);
 else if (direction == 3) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),&cmpsizeD);
 }

}


int cmpsizeU(struct DirList **val1,struct DirList **val2) /* new! inserted 25.08.97 dGN! */
{
return (val1[0]->size - val2[0]->size);
}


int cmpsizeD(struct DirList **val1,struct DirList **val2) /* new! inserted 25.08.97 dGN! */
{
return (val2[0]->size - val1[0]->size);
}


/*
Name:	DMSort Date + additional compare routines
*/

void DMSortD(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{

if (direction == 5) qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpdateU); /* new! inserted 25.08.97 dGN! */
else if (direction == 4)qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpdateD);
}


int cmpdateU(struct DirList **val1,struct DirList **val2)
{
if(val1[0]->dir==val2[0]->dir)
 {
 return(CompareDates((struct DateStamp *) &val2[0]->ds,(struct DateStamp *) &val1[0]->ds));	/* new! 2.2b15 */
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-10);
 }
else if(val1[0]->dir<val2[0]->dir)
 {
 return(10);
 }
}


int cmpdateD(struct DirList **val1,struct DirList **val2) /* new! inserted 25.08.97 dGN! */
{
if(val1[0]->dir==val2[0]->dir)
 {
 return(CompareDates((struct DateStamp *) &val1[0]->ds,(struct DateStamp *) &val2[0]->ds));	/* new! 2.2b15 */
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-1);
 }
else if(val1[0]->dir<val2[0]->dir)
 {
 return(1);
 }
}


/*
Name:	DMSort Comment + additional compare routines
*/

void DMSortC(struct DirList **dl,ULONG count,LONG direction) /* 2.5b10 rri */
{
if (direction == 6) qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpcmtU); /* new! inserted 25.08.97 dGN! */
else if (direction == 7)qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpcmtD);
}


int cmpcmtU(struct DirList **val1,struct DirList **val2)
{
int i;

if(val1[0]->dir==val2[0]->dir)
 {
 if (!val1[0]->cmt&&!val2[0]->cmt) return(Stricmp(val1[0]->name,val2[0]->name)*10);
 if (!val1[0]->cmt) return(-1);
 else if (!val2[0]->cmt) return (1);
 else
  {
   i=Stricmp(val1[0]->cmt,val2[0]->cmt); /* 2.5b12 rri */
   if (i==0) return(Stricmp(val1[0]->name,val2[0]->name)*10);
   return i;
  }
 }
else if(val1[0]->dir>val2[0]->dir)
 {
 return(-10);
 }
else if(val1[0]->dir<val2[0]->dir)
 {
 return(10);
 }
}


int cmpcmtD(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
int i;

i=cmpcmtU(val1, val2);

if (i==1||i==(-1)) i=i*(-1);

return i;
}


/*
Name:	DMSort Extension + additional Compare routines
*/

void DMSortE(struct DirList **dl,ULONG count,LONG direction) /* 2.5b12 rri */
{
int	dircount,filecount;

qsort(dl,(size_t) count,(size_t) sizeof(dl),&cmpnameU);

dircount=CountDirs(dl,count);
filecount=count-dircount;

if (filecount)
 {
 if (direction==8) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),&cmpextU);
 else if (direction == 9) qsort(&dl[dircount],(size_t) filecount,(size_t) sizeof(dl),&cmpextD);
 }

}


int cmpextU(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
UBYTE *ptr1=val1[0]->name+strlen(val1[0]->name);
UBYTE *ptr2=val2[0]->name+strlen(val2[0]->name);
int i;

for(;ptr1>=val1[0]->name;ptr1--)
 {
  if(*ptr1=='.') break;
 }

for(;ptr2>=val2[0]->name;ptr2--)
 {
  if(*ptr2=='.') break;
 }

if(ptr1<val1[0]->name&&ptr2<val2[0]->name)
 {
  return(Stricmp(val1[0]->name,val2[0]->name));
 }

if(ptr1<val1[0]->name)
 {
  return -10;
 }
if(ptr2<val2[0]->name)
 {
  return 10;
 }

i=(Stricmp(ptr1,ptr2));
if (i==0) return(Stricmp(val1[0]->name,val2[0]->name));
return i*10;
}


int cmpextD(struct DirList **val1,struct DirList **val2) /* 2.5b12 rri */
{
int i;

i=cmpextU(val1,val2);

if (i>=10||i<=(-10)) i=i*(-1);

return i;
}



void Sort() /* new! 2.3 / 2.4 */
{
switch(ToUpper((ULONG)ActionArgs[1][0])) /* 2.5b10 rri */
 {
  case 'N': SortType=0; break;
  case 'S': SortType=2; break;
  case 'D': SortType=4; break;
  case 'C': SortType=6; break;
  case 'E': SortType=8; break; /* 2.5b12 rri */
  case 'F': SortType=10; break;
  case 'T': SortType=11; break; /* 2.5b7 rri */
  case 'G': GlobalSort(); break;
 }

if(ActionArgs[1][1]&&ActionArgs[1][1]=='-'&&SortType<9) /* new! 2.4 */
 {
  SortType++;
 }

if(ActionArgs[2]&&(ToUpper((ULONG)ActionArgs[2][0])=='G')) /* 2.5b10 rri */
 {
  GlobalSort();
 }
else if(CDWin)
      {
       SetSortFlag(CDWin,SortType);
       ReSort();
       SortType=CDWin->Sorting; /* 2.5b7 rri */
      }
}


void GlobalSort(void)
{
struct DirWindow *dw;
int i,a;

a=0; /* 2.5b10 rri */

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(dw&&!dw->Flags)
   {
    SetSortFlag(dw,SortType); /* new! 2.4 */
    a=i;
   }
 }
ReSort();
SortType=DirWin[a]->Sorting; /* 2.5b7 rri */
}


void SetSortFlag(struct DirWindow *dw, int c)
{

if (c==11) /* 2.5b7 rri */
 {
  if (dw->Sorting!=10)
   {
    dw->Sorting=dw->Sorting+2;
    if (dw->Sorting>9)
     {
      dw->Sorting=dw->Sorting-10;
     }
   }
 }
else dw->Sorting=c;

if(dw->Path[0]) /* new! 2.4 */
 {
  dw->Flags|=DWFLAG_RESORT;
 }
}


void DMSort(struct DirWindow *dw)
{

switch(dw->Sorting)
 {
  case 0:
  case 1: DMSortN(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b10 rri */
          break;
  case 2:
  case 3: DMSortS(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b10 rri */
          break;
  case 4:
  case 5: DMSortD(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b10 rri */
          break;
  case 6:
  case 7: DMSortC(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b10 rri */
          break;
  case 8:
  case 9: DMSortE(dw->DirList,(ULONG) dw->FileCount,dw->Sorting); /* 2.5b12 rri */
          break;

  case 10: break;
 }
}


void ResortAll()
{
struct DirWindow	*dw;
int	i;

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(dw&&!dw->Flags&&dw->Path[0]) dw->Flags|=DWFLAG_RESORT;
 }
 ReSort();
}


void ReSort()
{
struct DirWindow *dw;
struct DirList **dl;
sFIB *fib = &Fib;
int	i,j;
ULONG c;
BPTR lock; /* 2.5b10 rri */
APTR save=process->pr_WindowPtr;

process->pr_WindowPtr=(APTR)-1;

if(BatchFlag) /* 2.5b10 rri */
 {
  return;
 }

for(i=0;i<255;i++)
 {
  dw=DirWin[i];

  if(!dw) continue;

  if(dw->Flags&DWFLAG_RESORT)
   {
    c=dw->FileCount;
    dl=dw->DirList;
    DMSortN(dl,c,0);
    for(j=0;j<c;j++)
     if(dl[j]&&dl[j]->sel>1)
      {
       if(dl[j]->cmt) /* 2.5b10 rri */
        {
         PoolFreeVec(dl[j]->cmt); /* 2.5b10 rri */
         dl[j]->cmt=NULL;
        }
       if(dl[j]->name) /* 2.5b10 rri */
        {
         PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
         dl[j]->name=NULL;
        }
       FreeMem(dl[j],sizeof(struct DirList));
       dl[j]=0;
       dw->FileCount--;
      }
    DMSort(dw);
    DiskShadow(dw,&Fib);
    if(dw->DirLock)
     {
      UnLock(dw->DirLock);
      dw->DirLock=0;
     }
    rdis_files(dw);
    dis_files(dw);
    WinTitle(dw);
    dw->Flags&=~DWFLAG_RESORT;
   }

  else if(!(dw->Flags&DW_CMD)&&dw->Path[0]) /* if it`s a dir window with a valid path */
   {
    if(!(lock=Lock(dw->Path,ACCESS_READ)))  /* if a lock to this path can`t be obtained */
     {

/* this portion of code was never ever executed before 2.5b7 anyways...
   2.5b9 rri */

/*      dw->Path[0]=0;*/  /* show dev/vol/asn list */
/*      InitDir(dw,0); */

     }
    else
     {
      if(Examine(lock,fib))
       {
        if(CompareDates(&dw->PathDate,&fib->fib_Date))
         {
          dw->Flags|=DWFLAG_RELOAD;
          lockcount++;
         }
        else ReSize(dw);
       }
      UnLock(lock);
     }
   }
 }
process->pr_WindowPtr=(APTR)save;
}
