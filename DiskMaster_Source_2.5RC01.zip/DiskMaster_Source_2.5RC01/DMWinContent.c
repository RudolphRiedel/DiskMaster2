/* DiskMaster II  Window content module - generates and converts the strings
**                                        displayed by DMWindows.c
** 2.5b13
**
** 01-08-10 rri - file created by transferring functions from DMWin.c
**
** 01-08-11 rri - mem-sizes displayed in new-style format
**              - new sub-routine AddConvStr() saves some bytes
**              - Bugfix: in french locales the month is abreviated with
**                four instead of three chars - overseen for the Screen-Title.
**                reported by: Jean Marie Boucher <boucher21@caramail.com>
**              - removed AddTStr()
**
** 01-08-26 rri - optimised some bytes out of ConvertBase()
**              - optimised and correct InitDir() by using NameFromLock()
**                for expanding names instead of a strins() loop
**
** 01-09-29 rri - localised display-size units B / K / M as suggested
**                by Francis Labrie <francis.labrie@smoguli.com>
**
** 01-10-20 rri - added check for long_month to DoFileFormat() and made
**                month appear as chars again
**
**
*/

#include "DM.h"

#define LENGTH(x)  (*(UBYTE *)BADDR(x))
#define STRING(x)  (((char *)BADDR(x))+1)

extern UBYTE BarFormat[],
             DispFormat[],
             *DevHide_List[], /* 2.5b12 jjt */
             DMname[],
             *NextPath,
             *Globuff, /* 2.5b7 rri */
             sbuff[],
             ScreenTitle[],
             Strap[],
             TitleFormat[],
             Version[];

extern int ColFudge,
           DClick,
           expandflag, /* 2.5b6 rri */
           LastI,
           lockcount,
           Notify, /* 2.5b9 rri */
           Use30;

extern LONG Globuff_size, /* 2.5b7 rri */
            long_month; /* 2.5b13 rri */

extern ULONG DevHide_Count;  /* 2.5b12 jjt */

extern APTR CommentPool; /* 2.5b10 rri */
extern APTR NamePool; /* 2.5b10 rri */

extern struct DirList *DClickDir;

extern struct DirWindow *CmdWin,
                        *DestWin,
                        *DirWin[];

extern struct InfoData InfoData;

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */


ULONG gigaflag,Bgigaflag; /* new! 2.5b5 */

int DefaultEdge;

LONG LTotal,BTotal; /* new! 2.5b5 */

ULONG Base_Str_Len=99999, /* 2.5b7 rri */
      ShowDev=SHOWDEV_ALL; /* 2.5b12 jjt */

UBYTE *AddConvStr(UBYTE *ptr,ULONG free,ULONG bytes); /* 2.5b13 rri */
int CacheLoad(struct DirWindow *dw);
void DoExAll(struct DirWindow *dw);
void ExDone(struct DirWindow *dw);



void ConvertBase(struct BaseConvert *basecon) /* new! 2.5b4 */
{
const UBYTE *base; /* 2.5b13 rri */
UBYTE *ptr;

ptr=basecon->String;

if (!basecon->BlocksFree)
 {
  basecon->DiskFree=0;
  *ptr++='0'; /* 2.5b13 rri */
  *ptr=0; /* 2.5b13 rri */
  return;
 }

if(basecon->BlocksFree<(2147483647/basecon->BytesPerBlock))
 {
  basecon->DiskFree=(basecon->BlocksFree)*basecon->BytesPerBlock;
  base=msgUnitBytes; /* 2.5b13 rri */

  if(basecon->DiskFree>Base_Str_Len) /* 2.5b7 rri */
   {
    basecon->DiskFree=basecon->DiskFree/1024;
    base=msgUnitKiloB; /* 2.5b13 rri */
   }
 }
else
 {
  basecon->DiskFree=(basecon->BlocksFree)/1024;
  basecon->DiskFree=basecon->DiskFree*basecon->BytesPerBlock;
  base=msgUnitKiloB; /* 2.5b13 rri */
 }

if(basecon->DiskFree>Base_Str_Len) /* 2.5b7 rri */
 {
  basecon->DiskFree=basecon->DiskFree/1024;
  base=msgUnitMegB; /* 2.5b13 rri */
 }

sprintf(ptr,"%ld %s",basecon->DiskFree,base); /* 2.5b13 rri */
}


void ReSize(struct DirWindow *dw) /* 2.5b5 rri */
{
struct DirList **dl=dw->DirList,*dlp;
int i,cols,cols1=0,cols2=0,sels=0;
LONG total[100],bftotal[100], /* 2.5b11 rri - max headroom now 200gig... */
     dirsize=0;
ULONG totaltest,bftest;
int x=0,y=0;

bftotal[0]=total[0]=0; /* 2.5b10 rri */

for(i=0;i<101;i++)
 {
  total[i]=0;
  bftotal[i]=0;
 }

for(i=0;i<dw->FileCount;i++)
 {
  dlp=dl[i];
  if(dlp->name) /* 2.5b10 rri */
   {
    cols=strlen(dlp->name);
    if(cols>cols1) cols1=cols;
   }
  if(dlp->cmt)
   {
    cols=strlen(dlp->cmt);
    if(cols>cols2) cols2=cols;
   }
  if(!dlp->dir) /* calculate file-sizes in total */
   {
    bftest=bftotal[y]+dlp->size; /* 2gig boundary check */
    if (bftest>2147483648)
     {
      y++;
      if(y>99) /* 2.5b11 rri - better limit display to 200 gig than */
       {       /* crashing the machine... */
        y=99;
        bftotal[y]=0;
       }
     }
    bftotal[y]+=dlp->size;
   }
  if(dlp->sel) /* calculate selected files/dirs only */
   {
    sels++; /* selection counter */
    if(dlp->dir) /* separate dirs from files */
     {
      if(dlp->size>536870912) /* if a single dir is bigger than */
       {                      /* 2^29 * 512 = 256 GByte something is wrong... */
        dlp->size=0;          /* 2.5b11 rri */
       }                  /* the dlp->size var already holds the amount of */
      dirsize+=dlp->size; /* used blocks after 'Check' */
      continue;           /* 2^31 * 512 = 1 TByte max... */
     }
    totaltest=total[x]+dlp->size; /* 2gig boundary check */
    if (totaltest>2147483648)
     {
      x++;
      if(x>99) /* 2.5b11 rri */
       {
        x=99;
        total[x]=0;
       }
     }
    total[x]+=dlp->size;
   }
 }

if(y>0) /* 2.5b5 rri */
 {
  BTotal=0;
  y=0;
  while (bftotal[y])
   {
    BTotal+=(bftotal[y]/128); /* 2.5b11 rri - 256 GByte max now */
    y++;
   }
  Bgigaflag=127; /* 2.5b13 rri */
 }
else
 {
  BTotal=bftotal[0];
  Bgigaflag=0;
 }

bftest = 100 * dw->BytesPerBlock; /* 2.5b10 rri */

while(dirsize) /* 2.5b10 rri */
 {
  totaltest=total[x]+bftest;
  if (totaltest>2147483648)
   {
    x++;
   }
  if(dirsize>100)
   {
    total[x]+=bftest;
    dirsize-=100;
   }
  else
   {
    total[x]+=dirsize*dw->BytesPerBlock;
    break;
   }
 }

if(x>0)
 {
  LTotal=0;
  x=0;
  while (total[x])
   {
    LTotal+=(total[x]/128); /* 2.5b11 rri */
    x++;
   }
  gigaflag=127; /* 2.5b13 rri */
 }
else
 {
  LTotal=total[0];
  gigaflag=0;
 }

dw->Sels=sels;
dw->ColsName=cols1;
dw->ColsCmt=cols2;

if(dw->FileCount&&(dw->DirList[0]->dir==2||dw->DirList[0]->dir==3))
 {
  dw->ColsCmt=0;
 }
}


UBYTE *AddConvStr(UBYTE *ptr,ULONG free,ULONG bytes) /* 2.5b13 rri */
{
struct BaseConvert winbase; /* 2.5b13 rri */

winbase.BytesPerBlock=bytes; /* 2.5b13 rri */

winbase.BlocksFree=free;
ConvertBase(&winbase);
strcpy(ptr,winbase.String);
ptr+=strlen(winbase.String);
return(ptr);
}


void MainTitle()
{
UBYTE *ptr=ScreenTitle,*dptr=BarFormat;
int   c;

struct DateTime DateTime;
UBYTE  Day[16],Time[16],Date[16];

DateStamp(&DateTime.dat_Stamp);

DateTime.dat_Format  = FORMAT_INT; /* yy-mmm-dd e.g. 00-Jul-13 */
DateTime.dat_Flags   = 0;
DateTime.dat_StrDay  = Day;
DateTime.dat_StrDate = Date;
DateTime.dat_StrTime = Time;

DateToStr(&DateTime);

Time[5]=0; /* new! 2.5b3 cut-off seconds from time-string */

while((c = *dptr++)&&(ptr-ScreenTitle<200)) /* new! 2.4b19 */
 {
  if(c!='%') *ptr++=c;
  else switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b10 rri */
   {
    case  0 : return;
    case 'A': strcpy(ptr,DMname); /* new! 2.4b21 */
              ptr+=strlen(DMname);
              break;
    case 'C':
              ptr=AddConvStr(ptr,AvailMem(MEMF_CHIP),1); /* 2.5b13 rri */
              break;
    case 'F':
              ptr=AddConvStr(ptr,AvailMem(MEMF_FAST),1); /* 2.5b13 rri */
              break;
    case 'P':
              ptr=AddConvStr(ptr,AvailMem(0),1);  /* 2.5b13 rri */
              break;
    case 'T': strcpy(ptr,Time); ptr+=strlen(Time); break;
    /* 2.5b7 rri */
    case 'D': ptr[0]=Date[strlen(Date)-2]; /* 2.5b13 rri */
              ptr[1]=Date[strlen(Date)-1]; /* 2.5b13 rri */
              ptr+=2;
              break;
    case 'M': ptr[0]=Date[3];
              ptr[1]=Date[4];
              ptr[2]=Date[5];
              ptr+=3;
              if(Date[6]!='-') *ptr++=Date[6]; /* 2.5b13 rri */
              break;
    case 'Y': ptr[0]=Date[0];
              ptr[1]=Date[1];
              ptr+=2;
              break;
    /* 2.5b7 rri */
    case 'W': strcpy(ptr,Day);
              ptr+=strlen(Day);
              break;
    case 'V': /* new! 2.3 */
              c=0;
              while (Version[11+c])
              {
               *ptr++=Version[11+c++];
              }
              break;
    default : *ptr++=c;
   }
 }
*ptr=0;
}


void WinTitle(struct DirWindow *dw)
{
UBYTE *ptr,*dptr=TitleFormat;
int     c;
BPTR lock; /* 2.5b5 rri */
struct BaseConvert winbase; /* 2.5b5 rri */

MainTitle();
if(!dw) return;
ReSize(dw);

ptr=dw->Title;
if(dw->FileCount&&dw->DirList[0]->dir>1);

else while((c = *dptr++)&&(ptr-dw->Title<40)) /* new! 2.4b19 */
 {
  if(c!='%') *ptr++=c;
  else switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b7 rri */
   {
    case   0: return;
    case 'A': /* files` sizes  2.5b5 rri */
              ptr=AddConvStr(ptr,BTotal,Bgigaflag+1);  /* 2.5b13 rri */
              break;
    case 'B': /* selected files+dirs sizes */
              ptr=AddConvStr(ptr,LTotal,gigaflag+1);  /* 2.5b13 rri */
              break;
    case 'C': /* amount of files */
              ptr=AddConvStr(ptr,(ULONG) dw->FileCount,1);  /* 2.5b13 rri */
              if(dw->FileCount) /* remove " B" from converted string */
               {
                ptr-=2;
                *ptr=0;
               }
              break;
    case 'F': /* free space available */
              if(lock=Lock(dw->Path,ACCESS_READ)) /* new! 2.5b4 */
               {
                Info(lock,&InfoData);
                winbase.BlocksFree=InfoData.id_NumBlocks-InfoData.id_NumBlocksUsed; /* new! 2.5b4a5 */
                dw->BlocksFree=winbase.BlocksFree;
                winbase.BytesPerBlock=InfoData.id_BytesPerBlock;
                dw->BytesPerBlock=InfoData.id_BytesPerBlock; /* 2.5b5 rri */
                ConvertBase(&winbase);
                dw->DiskFree=winbase.DiskFree;
                strcpy(ptr,winbase.String);
                ptr+=strlen(winbase.String);
                UnLock(lock);
               }
              break;
    case 'I': /* number of selected files */
              ptr=AddConvStr(ptr,(ULONG) dw->Sels,1);  /* 2.5b13 rri */
              if(dw->Sels) /* remove " B" from converted string */
               {
                ptr-=2;
                *ptr=0;
               }
              break;

    default : *ptr++=c;
   }
 }
*ptr=0;
SetWindowTitles(dw->Window,dw->Title,ScreenTitle);
}


void DoFileFormat(struct DirList *dlp,LONG colsN,LONG colsC,LONG blocksize) /* 2.5b10 rri */
{
UBYTE *ptr=sbuff,*dptr=DispFormat,*ptr2,*ptr3;
int c;
struct BaseConvert winbase; /* new! 2.5b5 */

/* 2.5b7 rri */
struct DateTime DateTime;
UBYTE Time[16],Date[16];


DateTime.dat_Format    = FORMAT_INT; /* 2.5b13 rri */
DateTime.dat_Flags     = 0;
DateTime.dat_StrDay    = NULL;
DateTime.dat_StrDate   = Date;
DateTime.dat_StrTime   = Time;

DateTime.dat_Stamp=dlp->ds;
DateToStr(&DateTime);

Time[5]=0;

/* 2.5b7 rri */

memset(ptr,' ',300); /* 2.5b10 rri */

while(*dptr&&(ptr-sbuff<150)) /* new! 2.4b19 */
 {
  switch(c=ToUpper((ULONG) *dptr++)) /* 2.5b7 rri */
   {
    case 'N': if(dlp->name)
               {
                strcpy(ptr,dlp->name); /* 2.5b13 rri */
                ptr[strlen(dlp->name)]=' ';
                ptr+=colsN;
               }
              break;

    case 'C': if(dlp->dir==3) break;
              if(dlp->dir==2)
               {
                ptr3=ptr+2;
                ptr2=0;
                if(dlp->attr==DLT_DEVICE) ptr2="(DEV)";
                else if(dlp->attr==DLT_VOLUME) ptr2="(VOL)";
                else if(dlp->attr==DLT_DIRECTORY) ptr2="(ASN)";
                colsC=7;
               }
              else
               {
                ptr2=dlp->cmt;
                ptr3=ptr;
               }
              if(ptr2) while(*ptr2) *ptr3++ = *ptr2++;
              ptr+=colsC;
              break;

    case 'S': if(dlp->dir>1) break;
              if(dlp->dir==1&&dlp->size) /* new! 2.5b5 */
               {
                winbase.BlocksFree=dlp->size;
                winbase.BytesPerBlock=blocksize; /* 2.5b5 rri */
                ConvertBase(&winbase);
                sprintf(ptr,"%11s",winbase.String); /* 2.5b7 rri */
               }
              else
               {
                sprintf(ptr,"%11ld",dlp->size); /* 2.5b7 rri */
               }
              ptr[11]=' '; /* 2.5b7 rri */
              ptr+=10; /* 2.5b7 rri */
              if(dlp->dir&&!dlp->size) *ptr=' ';
              ptr++;
              break;

    case 'T': if(dlp->dir<2)
               {
                strcpy(ptr,Time);
                ptr+=5; /* new! 2.4 */
               }
              break;
    case 'D': if(dlp->dir<2)
               {
                ptr[0]=Date[strlen(Date)-2]; /* 2.5b13 rri */
                ptr[1]=Date[strlen(Date)-1]; /* 2.5b13 rri */
                ptr+=2;
               }
              break;

    case 'M': if(dlp->dir<2)
               {
                ptr[0]=Date[3];
                ptr[1]=Date[4];
                ptr[2]=Date[5];
                if(long_month) /* 2.5b13 rri */
                 {
                  if(Date[6]!='-') ptr[3]=Date[6];
                  ptr++;
                 }
                ptr+=3;
               }
              break;

    case 'Y': if(dlp->dir<2)
               {
                ptr[0]=Date[0]; /* 2.5b10 rri */
                ptr[1]=Date[1]; /* 2.5b10 rri */
                ptr+=2;
               }
              break;

    case 'A': if(dlp->dir<2)
               {
                StampProt(ptr,dlp->attr );
                ptr+=8;
               }
              break;

    default : if(dlp->dir<2) *ptr++=c;
   }
 }
ColFudge=(ptr-sbuff)+1;
}


void QueryDosList(struct DirWindow *dw, struct DosList *doslist,int type) /* 2.5b12 rri */
{
struct DirList **dl,*dlp;
ULONG l,fl;

dl=dw->DirList;

l=LENGTH(doslist->dol_Name);

/* 2.5b12 jjt */
for (fl=0; fl < DevHide_Count; fl++)
 {
  /* --- Is this dev one the user wants to hide? --- */
  if (strlen(DevHide_List[fl]) == l)
   {
    if((Strnicmp(STRING(doslist->dol_Name),DevHide_List[fl],(LONG)l))==0) break;
   }
 }

if (fl == DevHide_Count)
 {
  if(!AllocDlp(dw)) return;
  dlp=dl[dw->FileCount++];
  dlp->dir=2;
  dlp->attr=type;
  if(dlp->name=PoolAllocVec(NamePool,(ULONG)(l+2)))
   {
    sprintf(dlp->name,"%b:",doslist->dol_Name);
   }
 }
}


void GetDevList(struct DirWindow *dw) /* 2.5b12 rri */
{
struct DosList *doslist;
struct DirList **dl;
ULONG x;

dl=dw->DirList;

if (ShowDev & SHOWDEV_DEV)
{
doslist = LockDosList(LDF_DEVICES|LDF_READ);
while (doslist = NextDosEntry(doslist,LDF_DEVICES))
 {
  if(doslist->dol_Task)
   {
    QueryDosList(dw,doslist,DLT_DEVICE);
   }
 }
UnLockDosList(LDF_DEVICES|LDF_READ);
DMSortN(dl,dw->FileCount,0);
}

x=dw->FileCount;

if (ShowDev & SHOWDEV_VOL)
{
doslist = LockDosList(LDF_VOLUMES|LDF_READ);
while (doslist = NextDosEntry(doslist,LDF_VOLUMES))
 {
  QueryDosList(dw,doslist,DLT_VOLUME);
 }
UnLockDosList(LDF_VOLUMES|LDF_READ);

dl = &dw->DirList[x];
DMSortN(dl,dw->FileCount-x,0);
}

x=dw->FileCount;

if (ShowDev & SHOWDEV_ASN)
{
doslist = LockDosList(LDF_ASSIGNS|LDF_READ);
while (doslist = NextDosEntry(doslist,LDF_ASSIGNS))
 {
  if(doslist->dol_Type==DLT_DIRECTORY)
   {
    QueryDosList(dw,doslist,DLT_DIRECTORY);
   }
 }
UnLockDosList(LDF_ASSIGNS|LDF_READ);

dl = &dw->DirList[x];
DMSortN(dl,dw->FileCount-x,0);
}

dw->Path[0]=0;
ReSize(dw);
NewSize(dw);
RefreshGadget(&dw->dir_gad,dw->Window); /* 2.5b7 rri */
}


/* --------------------------- DIRECTORY LOAD --------------------------------- */


void GetDirEntry(struct DirWindow *dw)
{
struct DirList  *dlp;
sFIB *fib=dw->Fib;
int i;

if((dw->Flags&DWFLAG_RELOAD)&&!dw->DirLock)
 {
  InitDir(dw,0);
  return;
 }

if(!dw->DirLock||!fib) return;

if (Use30)
 {
  DoExAll(dw);
 }
else
 {
  i=ExNext(dw->DirLock,fib);
  if(i&&dw->Pattern[0]) if(!DMMatch(fib->fib_FileName,dw->Pattern)) return;

  if(!i||!AllocDlp(dw))
   {
    ExDone(dw);
    return;
   }
  dlp=dw->DirList[dw->FileCount++];
  Fib2Dlp(dlp,fib);
 }
}


void InitDir(struct DirWindow *dw,int set)
{
BPTR lock; /* 2.5b13 rri */

FreeDirTable(dw);
dw->Flags&=~0xF;
if(!dw->Fib)
 {
  if(!(dw->Fib=(sFIB *)AllocMem(sizeof(sFIB),MEMF_PUBLIC)))
   {
    return;
   }
 }

Busy(1); /* 2.5b7 rri */

if (dw->Path[0])
 {

  while (dw->Path[strlen(dw->Path)-1] == '/') /* 2.5b9 rri */
   {
    dw->Path[strlen(dw->Path)-1]=0;
   }
  RefreshGadget(&dw->dir_gad,dw->Window);

  if (dw != CmdWin) StrHist_Add(&PathHistory, dw->Path); /* Cache path */  /* 2.5b10 jjt */

  if (lock=Lock(dw->Path,ACCESS_READ))
   {
    if(expandflag) /* 2.5b6 rri */
     {
      NameFromLock(lock, dw->Path, 512); /* 2.5b13 rri */
     }
    UnLock(lock);
    if(!DiskShadow(dw,dw->Fib)) goto Q;
    RefreshGadget(&dw->dir_gad,dw->Window);
    NewSize(dw);
   }
 }

if(set)
 {
  strcpy(Strap+4,dw->Path);
  goto Q;
 }

if(dw->DirLock&&Notify) /* 2.5b9 rri */
 {
  dw->DM2NotifyReq.nr_Name = dw->Path;
  if (StartNotify(&dw->DM2NotifyReq))
   {
    dw->Notified=1;
   }
 }

if(!dw->DirLock&&dw!=CmdWin) /* 2.5b9 rri */
 {
  GetDevList(dw);
 }
else if(dw->Fib->fib_DirEntryType<0&&dw==CmdWin) /* new! 2.4 */
      {
       GetCmdFile(dw,dw->Path,dw->Fib->fib_Size);
       Busy(0); /* 2.5b9 rri */
       return;
      }
else if(!CacheLoad(dw))
      {
       lockcount++;
       Busy(0); /* 2.5b7 rri */
       return;
      }

Q:

if(dw->DirLock)
 {
  UnLock(dw->DirLock);
  dw->DirLock=0;
 }

FreeMem(dw->Fib,sizeof(sFIB));
dw->Fib=0;
Busy(0); /* 2.5b7 rri */
}


void DoExAll(struct DirWindow *dw) /* rewritten in 2.5b7 rri */
{
struct ExAllControl *eac;
struct ExAllData *ead,*eadp;
struct DirList *dlp;
LONG more,res2;
ULONG n;
BPTR lock;
sFIB *info;
UBYTE buffer[100];

if((eac = AllocDosObject(DOS_EXALLCONTROL,NULL)) != NULL)
 {
  if (GetGlobuff())
   {
    ead=(struct ExAllData *)Globuff;
    eac->eac_MatchString=NULL;
    if(dw->Pattern[0])
     {
      strcpy(buffer,dw->Pattern);
      FilterStar(buffer);
      if (ParsePatternNoCase(buffer,sbuff,300)>=0)
       {
        eac->eac_MatchString=sbuff;
       }
     }
    eac->eac_LastKey = 0;
    eac->eac_MatchFunc=NULL;
    do
     {
      more = ExAll(dw->DirLock, ead, Globuff_size, ED_COMMENT, eac);
      res2 = IoErr();
      for (eadp=ead,n=eac->eac_Entries;n!=0;eadp=eadp->ed_Next,--n)
       {
        if(!AllocDlp(dw)) break;
        dlp=dw->DirList[dw->FileCount++];
        dlp->name = CloneStr(eadp->ed_Name, NamePool); /* 2.5b10 rri */
        dlp->size=eadp->ed_Size;
        dlp->attr=eadp->ed_Prot;
        dlp->ds.ds_Days=eadp->ed_Days;
        dlp->ds.ds_Minute=eadp->ed_Mins;
        dlp->ds.ds_Tick=eadp->ed_Ticks;
        dlp->dir=0;

        if(eadp->ed_Type==3)
         {
          if(lock=Lock(eadp->ed_Name,ACCESS_READ))
           {
            if(info=AllocMem(sizeof(sFIB),MEMF_PUBLIC))
             {
              if(Examine(lock,info))
               {
                if(info->fib_DirEntryType>0)
                 {
                  dlp->dir=1;
                 }
               }
              FreeMem(info,sizeof(info));
             }
            UnLock(lock);
           }
         }
        else if(eadp->ed_Type>=0) dlp->dir=1;

        dlp->cmt = CloneStr(eadp->ed_Comment, CommentPool); /* 2.5b10 rri */
       }
      if ((!more) && (res2 == ERROR_NO_MORE_ENTRIES))
       {
        continue; /* ExAll failed normally with no entries */
       }
     } while (more);
   }
  FreeDosObject(DOS_EXALLCONTROL,eac);
 }
ExDone(dw);
}


int AllocDlp(struct DirWindow *dw)
{
struct DirList **dl=dw->DirList;
ULONG size; /* 2.5b10 rri */

if(dw->FileCount>=dw->MaxFile)
 {
  size=dw->MaxFile<<2;
  if(!(dl=(struct DirList **)AllocMem(size+2000,MEMF_PUBLIC|MEMF_CLEAR)))
      return(0);
  memmove(dl,dw->DirList,(size_t) size); /* 2.5b10 rri */
  FreeMem(dw->DirList,size);
  dw->DirList=dl;
  dw->MaxFile+=500;
 }
 return((int)(dl[dw->FileCount]=(struct DirList *)AllocMem(sizeof(struct DirList),MEMF_PUBLIC|MEMF_CLEAR)));
}


int GetNewPath(struct DirWindow *dw)
{
UBYTE *ptr,*ptr2;

if(NextPath&&DClick&&DClickDir)
 {
  if(DestWin&&DestWin!=dw&&LastI>=0&&DClickDir->sel) /* new! 2.5b3 */
   {
    DClickDir->sel=0;
    dis_name(DestWin,LastI+DestWin->Index,(LONG) LastI); /* 2.5b10 rri */
   }
  dw->h_prop.HorizPot=0;
  dw->v_prop.VertPot=0;
  LastI = -1;
  dw->Index=0;
  dw->Edge=DefaultEdge;

  strcpy(dw->Path,NextPath);

  ptr=dw->Path+strlen(dw->Path)-1;
  ptr2=DClickDir->name;

  if (*ptr=='/') /* new! 2.2b15 */
   {
    *ptr=0;
    ptr--;
   }
  if(*ptr&&*(ptr2+strlen(ptr2)-1)!=':')
   {
    if(*ptr++!=':')
     {
      *ptr++='/';
      *ptr=0;
     }
   }
  else
   {
    ptr=dw->Path;
   }

  strcpy(ptr,DClickDir->name);
  DClick=0;
  DClickDir=0;
  InitDir(dw,0);
  return(1);
 }
return(0);
}


int DiskShadow(struct DirWindow *dw,sFIB *fib)
{
struct DateStamp *ds1,*ds2;
BPTR lock; /* 2.5b6 rri */

dw->DiskFree=0;
if(!dw->Path[0]) return(1);
if(!(lock=Lock(dw->Path,ACCESS_READ))) return(1);

Info(lock,&InfoData);

dw->BytesPerBlock=InfoData.id_BytesPerBlock; /* 2.5b5 rri */

dw->DirLock=lock;
if(!Examine(lock,fib)) return(0);

/* init struct DateStamp in struct DirList */

ds1 = &dw->PathDate;
ds2 = &fib->fib_Date;
ds1->ds_Days=ds2->ds_Days;
ds1->ds_Minute=ds2->ds_Minute;
ds1->ds_Tick=ds2->ds_Tick;

return(1);
}


int CacheLoad(struct DirWindow *dw)
{
struct DirWindow *dw2;
struct DirList **dl,**dl2,*dlp,*dlp2;
int i;

dw2=0; /* 2.5b10 rri */

/* look for a dir-window with the same path */
for(i=0;i<255;i++)
 {
  dw2=DirWin[i];
  if(dw2&&dw!=dw2&&!strcmp(dw->Path,dw2->Path)) break;
 }

/* if there is no window with the same path leave the function */
if(i==255||!dw2||!dw2->FileCount) return(0);

ReSort();

if(dw2->DirLock||dw2->Flags&DWFLAG_RELOAD)
 {
  dw->Flags|=DWFLAG_RELOAD;
  return(0);
 }

dl2=dw2->DirList;

for(i=0;i<dw2->FileCount;i++)
 {
  dlp2=dl2[i];
  if(dw->Pattern[0])
   {
    if(dlp2->name) /* 2.5b10 rri */
     {
      if(!DMMatch(dlp2->name,dw->Pattern)) continue;
     }
   }
  if(!AllocDlp(dw)) return(1);
  dl=dw->DirList;
  dlp=dl[dw->FileCount++];
  dlp->size=dlp2->size;
  dlp->attr=dlp2->attr;
  dlp->ds.ds_Days=dlp2->ds.ds_Days;
  dlp->ds.ds_Minute=dlp2->ds.ds_Minute;
  dlp->ds.ds_Tick=dlp2->ds.ds_Tick;
  dlp->dir=dlp2->dir;
  dlp->name = CloneStr(dlp2->name, NamePool); /* 2.5b10 rri */
  dlp->cmt = CloneStr(dlp2->cmt, CommentPool); /* 2.5b10 rri */
 }

DMSort(dw); /* new! 2.2b15 */
ReSize(dw);
NewSize(dw);
return(1);
}


void ExDone(struct DirWindow *dw)
{
struct DirWindow *dw2;
int i;

UnLock(dw->DirLock);
dw->DirLock=0;
FreeMem(dw->Fib,sizeof(sFIB));
dw->Fib=0;
if(lockcount) lockcount--;
DMSort(dw); /* new! 2.2b15 */
ReSize(dw);
NewSize(dw);
for(i=0;i<255;i++)
 {
  dw2=DirWin[i];
  if(dw2&&(dw2->Flags&DWFLAG_RELOAD)&&!strcmp(dw->Path,dw2->Path))
   {
    dw2->Flags&=~DWFLAG_RELOAD;
   }
 }
}


void Fib2Dlp(struct DirList *dlp,sFIB *fib)
{

dlp->size=fib->fib_Size;
dlp->attr=fib->fib_Protection;
dlp->ds.ds_Days=fib->fib_Date.ds_Days;
dlp->ds.ds_Minute=fib->fib_Date.ds_Minute;
dlp->ds.ds_Tick=fib->fib_Date.ds_Tick;
dlp->dir=0;
if(fib->fib_DirEntryType>=0) dlp->dir=1;
dlp->name = CloneStr(fib->fib_FileName, NamePool); /* 2.5b10 rri */
dlp->cmt = CloneStr(fib->fib_Comment, CommentPool); /* 2.5b10 rri */
}


void FreeDirTable(struct DirWindow *dw)
{
struct DirList **dl=dw->DirList;
int i;

if(dw->DirLock)
 {
  UnLock(dw->DirLock);
  dw->DirLock=0;
  if(lockcount) lockcount--;
 }

for(i=0;i<dw->FileCount;i++)
 {
  if(dl[i]->cmt)
   {
    PoolFreeVec(dl[i]->cmt); /* 2.5b10 rri */
    dl[i]->cmt=NULL;
   }
  if(dl[i]->name)
   {
    PoolFreeVec(dl[i]->name); /* 2.5b10 rri */
    dl[i]->name=NULL;
   }
  FreeMem(dl[i],sizeof(struct DirList));
 }
dw->FileCount=0;

if(dw->Notified) /* 2.5b7 rri */
 {
  EndNotify(&dw->DM2NotifyReq);
  dw->Notified=0;
 }

}
