/* DiskMaster II  Request modules
**
** 00-06-26 rri - Busy() works now
**              - replaced all c++ style comments by ANSI ones
**
** 00-06-28 rri - new global var: busy
**
** 00-06-28 jjt - Rewrote EasyReq().
**              - About() changed to use new EasyReq().
**
** 00-07-03 jjt - Removed some commented-out code (old EasyReq() & related).
**              - Moved Choose's code from DMCommand.c's DoCmd() to here, CMD_Choose().
**              - Added extern refs to ConfirmFlag, ReqStr (DMCommand.c), & rexxStr (DMRexx.c).
**
** 00-07-10 rri - replaced MyToUpper() calls by ToUpper() (utility.library)
**
** 00-08-27 jjt - Quick hacks to OpenReq(), & DMReq():  ReqWin doesn't use a shared msg port.
**                Allows DMReq() to work from reader task.
**                Note:  This is a temporary fix.
**
** 00-11-12 jjt - EasyReq() - If args = 0 then any "%"s in body are translated to "%%".
**
** 2.5b10
** 00-11-25 jjt - New funcs:  StrReq() & strtoary().
**
** 00-11-26 jjt - Rewrote DMReq() to be a temp. frontend for StrReq().
**
** 00-11-27 jjt - Rewrote EasyReq() to use StrReq().
**
** 00-12-02 jjt - Rewrote strtoary().
**              - New func:  killstrary().
**              - Changed string limits:
**                - Max lines of text = 30.
**                - Max. buttons = 15.
**                - Max. string length = 256.
**
** 00-12-03 jjt - Rewrote strtoary() again.
**              - Removed killstrary().
**              - Removed max. string length limit.
**
** 00-12-07 jjt - StrReq() - Switched from a switch() to some if()/else if()s.  Saved a few bytes.
**
** 00-12-09 jjt - STRICT compatibility:
**                - StrReq() - Initialized bodystrs, btnstrs, strgad, & si to 0.
**                (Warning 317)
**
** 00-12-13 jjt - Added extern refs to ReqHistory, DirHistory, & EditHook.
**              - StrReq() - Added the EditHook.
**                         - Returned strings are now cached.
**              - New functions:  StrData_New(),
**                                StrHist_Init(), StrHist_Clear(), StrHist_Add(), &
**                                StringHook();
**
**              - Removed:  StrData_New(), & all StringData references.
**                          DirHistory extern reference - It was never used.
**              - StrReq() - Chooses ReqHistory or ReadHistory.
**              - Commented-out semaphore usage (not necessary w/ ReadHistory).
**
**
**
** 00-12-19 jjt - StrReq() - Changed args; uses a tag list for many options.
**
** 00-12-21 jjt - StringHook() - Pressing Esc will cancel a string gadget.
**              - StrReq() - Only [Return], [Esc], or a button will close the req.
**                         - [Esc] will also set Abort if DMREQ_ABORT is present.
**                         - New tags DMREQ_NOSTRING & DMREQ_RETURNTEXT allow EasyReq()
**                           to be removed.
**
** 00-12-23 jjt - Removed EasyReq() & DMReq().
**              - Renamed StrReq() to DMReqTagList(), & changed its args (several times...).
**                It now takes most options from a taglist, or uses defaults.
**              - Added DMReq() - Allows tag list to be built on stack.
**              - Added MakeBtnString() - Creates a "|" separated string, g_buttons, from
**                                        two or three strings (yes, abort, no).
**              - Added restorestrcontents() - Copies a string's undo buffer back to work buf.
**              - Added reqtags_ContAbortCan & reqtags_Ok - Two often-used configurations.
**              - About() now calls DMReqTagList().
**              - Changed CMD_Choose() - It now handles returning the number or string of
**                                       the pressed button.
**                                     - ABORT arg is now a number instead of a boolean.
**                                     - Button 0 & the abort-button never return a string.
**
** 00-12-25 jjt - DMReqTagList() - IDCMP_VANILLAKEY & IDCMP_GADGETUP handled with same code.
**                               - Removed strreq var.  Saved bytes.
**                               - Switched to EraseRect().  Able to remove a SetAfPt() & a
**                                 SetAPen() & save some bytes.
**              - StringHook() - Removed an unnecessary line.
**                             - Bug fix:  Now using strncpy().
**              - CMD_Choose() - A little housekeeping.  Saved a few bytes.
**              - StrHist_Clear() - No longer resets strcache & lencache elements to 0.  So
**                                  far this isn't a necessary feature.  Saves bytes.
**              - StrHist_Init() - No longer initializes strcache & lencache elements to 0.
**                                 It doesn't look like this was necessary.
**                                 ...It was broken anyway (had ">" instead of "<").  Ha!
**
** 00-12-27 jjt - Changing as many local vars & function return-values to (U)LONG as possible.
**                Saves bytes.
**              - StringHook() - Removed a 317 warning.
**
** 00-12-29 jjt - Found 2 more vars that could be switched to LONGs.
**              - Removed all 120 warnings.
**
** 00-12-31 jjt - StrHist_Add() - Bug fix:  Had "sh->total -= 1" inside the for loop, which
**                                caused strange behavior when the cache exceeded STRHIST_MAX.
**                              - Added a test to make sure the supplied string isn't NULL or
**                                an empty string.
**              - StringHook() - Shift cursor-down jumps to the string's original contents
**                               instead of the last cached string.
**
** 01-01-07 jjt - StrHist_Add() - If the string is in the cache then the cached string gets
**                                moved to the end of the cache.
**
** 01-01-09 jjt - strtoarray() takes one more arg:  ptr to mempool.
**              - Updated CloneStr() calls & changed FreeVec()s to PoolFreeVec().
**              - StrHist_Init() - Sets .mempool field to StringPool.
**              - Removed StrHist_Clear().
**
** 01-02-10 rri - added Busy(1)/Busy(0) calls to DMReqTagList()
**              - removed Busy(1)/Busy(0) calls from About()
**
** 2.5b11
**
** 01-03-03 jjt - Bug fix:  DMReqTagList() - Added a SetFont().
**                Reported by Ed Vishoot <edv@infinet.com>
**
** 01-03-04 jjt - StringHook() - Small improvement to jump var's init.
**              - CMD_Choose() - Button #0 can return text (again).
**                Reported by Ed Vishoot <edv@infinet.com>
**
** 2.5b12
**
** 01-07-28 jjt - StrHist_Add() - Replaced a len check & Strnicmp() with Stricmp().
**
** 2.5b13
**
** 01-08-06 jjt - Added REQ_FileExists().
**
** 01-08-08 jjt - REQ_FileExists() - Added "All" button.
**
** 01-08-24 jjt - REQ_FileExists() - Removed the "fname" arg (uses fib->FileName instead).
**                                 - Removed the custom title ("DM Warning").
**
** 01-09-08 jjt - Changed strtoarray(), DMReq(), & DMReqTagList() to remove #104 warnings.
**
** 01-09-10 rri - localise: msgGadCAC, msgGadOkay
**                          REQ_FileExists() - msgReqFileExists, msgGadOARAC
**                          'Choose' - msgGadOkay
**                          MakeBtnString() - msgGadContinue, msgGadCancel
**              - removed reqtags_Ok/reqtags_ContAbortCan as these can't be
**                used with localisation
**
** 01-09-18 rri - corrected button-array for REQ_FileExists()
**              - changed prototype for MakeBtnString()
**              - localised def-buttons in DMReqTagList()
**
** 01-09-20 rri - replaced msgGadContinue in MakeBtnString() by msgGadOkay
**              - corrected def-buttons localisation in DMReqTagList()
**
**
** 01-09-23 jjt - DMReqTagList() - Small improvement to GadgetID init.
**
** 01-09-25 rri - rearranged 'About' requester and added string for translators,
**                suggested by Francis Labrie
**
** 01-09-29 jjt - reqtags_Ok & reqtags_OkSkipCan are back.  The DMREQ_BUTTONS tag gets
**                initialized in dm.c.
**              - About() uses reqtags_Ok.
**
** 01-10-29 rri - modified REQ_FileExists() to display the destination's
**                filename in the requester.
**
*/

#include "DM.h"


ULONG strtoarray(APTR mempool, CONST_STRPTR str, UBYTE **strary, ULONG arymax, struct RastPort *rp, ULONG *widest);  /* 2.5b10 jjt */
void  restorestrcontents(struct SGWork * swork);  /* 2.5b10 jjt */


extern UBYTE                Version[], ReqStr[], *rexxStr, /* 2.5b7 jjt (3.7.00) */
                            ActionArgs[],
                            sbuff[]; /* 2.5b13 rri */
extern LONG                 Abort, Use30, ConfirmFlag;  /* 2.5b7 jjt (3.7.00) */
extern ULONG                g_CommonWinFlags, g_memattrs;  /* 2.5b10 jjt */
extern APTR                 StringPool; /* 2.5b10 jjt */
extern struct DirWindow     *DirWin[255],*CDWin; /* new! 2.4b22 */
extern struct RxsLib        *RexxSysBase; /* new! 2.5b5 */
extern struct Screen        *Screen;
extern struct StringHistory ReqHistory, ReadHistory;  /* 2.5b10 jjt */
extern struct Hook          EditHook;  /* 2.5b10 jjt */


UBYTE            g_buttons[80]; /* 2.5b10 jjt */
LONG             busy; /* 2.5b7 rri */
struct Requester *Requester[256]; /* 2.5b7 rri */
/* Some often-used taglists   2.5b13 jjt */
struct TagItem reqtags_Ok[]={DMREQ_BUTTONS, 0,
                             TAG_END},
               reqtags_OkSkipCan[]={DMREQ_BUTTONS, 0,
                                    DMREQ_ABORT, 0,
                                    TAG_END};


void Busy(int i) /* 2.5b7 rri */
{
ULONG a;

if (Use30) /* if OS-Version >=39 */
 {
  if (i&&!busy)
   {
    for(a=0;a<255;a++)
     {
      if (DirWin[a])
       {
        Requester[a]=(struct Requester *)AllocMem(sizeof(struct Requester),MEMF_CLEAR);
        if (Requester[a])
         {
          if (Request(Requester[a],DirWin[a]->Window))
           {
            SetWindowPointer(DirWin[a]->Window,WA_BusyPointer, TRUE, TAG_DONE );
            busy=1;
           }
         }
       }
     }
   }
  else if(!i&&busy)
   {
    for(a=0;a<255;a++)
     {
      if (DirWin[a])
       {
        if (Requester[a])
         {
          SetWindowPointer (DirWin[a]->Window,TAG_DONE);
          EndRequest(Requester[a],DirWin[a]->Window);
          FreeMem((void *)(Requester[a]),sizeof(struct Requester));
          Requester[a]=0;
          busy=0;
         }
       }
     }
   }
 }
}


void About()
{
sprintf(sbuff,"DiskMaster II\n\n" /* 2.5b13 rri */
              "Copyright � 1991-1997\n"
              " by Greg Cunningham\n\n"
              "Copyright � 1997-2001\n"
              " by Rudolph Riedel\n\n"
              "DM2 is mailware:\n"
              " Rudolph-Riedel@T-Online.de \n\n"
              "%s", msgReqAbout);

DMReqTagList(sbuff, 0, 0, reqtags_Ok);  /* 2.5b13 jjt */
}


LONG REQ_FileExists(sFIB *srcfib, sFIB *destfib) {  /* 2.5b13 jjt */
  UBYTE rbdy[500],
        srcdate[20], srctime[10],
        destdate[20]={"Unknown"}, desttime[10]={0};
  LONG  ch, dsize=0;
  struct DateTime dt;

  dt.dat_Format = FORMAT_DOS;
  dt.dat_Flags = 0;
  dt.dat_StrDay = 0;

  dt.dat_Stamp = srcfib->fib_Date;
  dt.dat_StrDate = srcdate;
  dt.dat_StrTime = srctime;
  DateToStr(&dt);

  if (destfib) {
    dt.dat_Stamp = destfib->fib_Date;
    dt.dat_StrDate = destdate;
    dt.dat_StrTime = desttime;
    DateToStr(&dt);

    dsize = destfib->fib_Size;
  }

  sprintf(rbdy, msgReqFileExists, destfib->fib_FileName, /* 2.5b13 rri */
                                  srcfib->fib_Size, srcdate, srctime,
                                  dsize, destdate, desttime);

  ch = DMReq(rbdy, 0, 0, DMREQ_BUTTONS, msgGadOARSC,  /* 2.5b13 rri */
                         DMREQ_ABORT,    0,
                         TAG_END);
  return ch;
}


void CMD_Choose(void) {  /* 2.5b7 jjt (3.7.00) */
  LONG   setconfirm, choice, bt;
  STRPTR btntxt, ret, retary[15];

  setconfirm = GetActionArg("ASKONCE", AATYPE_BOOL, 0);
  if (setconfirm && ConfirmFlag) return;

  btntxt = (STRPTR) GetActionArg("BUTTONS", AATYPE_NEXTSTR, (LONG) msgGadOkay); /* 2.5b13 rri */
  ret = (GetActionArg("RETBUTTONS", AATYPE_BOOL, 0) ? btntxt : (STRPTR) GetActionArg("RETURN", AATYPE_NEXTSTR, 0));

  choice = DMReq((STRPTR) GetActionArg("TEXT", AATYPE_NEXTSTR, 0), 0, 0, DMREQ_TITLE,   GetActionArg("TITLE", AATYPE_NEXTSTR, (LONG) Version),
                                                                         DMREQ_BUTTONS, btntxt,
                                                                         DMREQ_ABORT,   GetActionArg("Abort", AATYPE_NUM, -1),
                                                                         TAG_END);

  if (ret) {
    /* --- RETURN or RETBUTTONS was given --- */
    bt = strtoarray(StringPool, ret, retary, 15, 0, 0);
    if (choice == 0) choice = bt;  /* 2.5b11 jjt */
    strcpy(ReqStr, retary[choice - 1]);
    PoolFreeVec(*retary);
  }
  else stcl_d(ReqStr, choice);

  if (setconfirm) ConfirmFlag = 1;
  rexxStr = ReqStr;
}


LONG DMReq(CONST_STRPTR body, STRPTR dest, ULONG cmax, ULONG tags, ...) {
  return DMReqTagList(body, dest, cmax, (struct TagItem *) &tags);
}


LONG DMReqTagList(CONST_STRPTR body, STRPTR dest, ULONG cmax, struct TagItem* tags) {
  UBYTE               *bodystrs[30]={0}, *btnstrs[15]={0},defgads[50];
  UWORD               bgpat[2]={0x5555, 0xAAAA};
  LONG                done=FALSE, choice=0, abortbtn;
  ULONG               stotal, btotal,
                      i, charh, bt, bb, bl, blr,
                      smax=0, bmax=0, bspc, x, y, w, h, class, code;
  APTR                vi;
  struct Screen       *scrn;
  struct DrawInfo     *di;
  struct RastPort     *rp;
  struct TextAttr     boldta;
  struct Gadget       *glist=NULL, *prvgad, *strgad=0;
  struct StringInfo   *si=0;
  struct NewGadget    ng;
  struct Window       *win;
  struct IntuiMessage *msg;
  struct StringHistory *sh;

Busy(1); /* 2.5b10 rri */

  /*
    body - Up to 30 lines.  "|" or \n = line break.
    dest - Buffer to copy string buffer to.  If NULL, then no string gadget appears.
    cmax - Maximum length of <dest>.
    tags - DMREQ_TITLE - Defaults to Version.
           DMREQ_BUTTONS - Defaults to "Okay|Cancel".  Separate w/ a "|".
                           Ex:  "Yes|Maybe|No".
                           Maximum of 15 buttons.
           DMREQ_ABORT   - If the button pressed equals this number then Abort = 1 and
                           the req. returns 0.
                           Defaults to -1 (or 0xFFFFFFFF).
           DMREQ_SCREEN  - Screen pointer to open req. on.  Defaults to Screen.
           DMREQ_HISTORY - StringHistory struct to use.  Defaults to ReqHistory.

    DMReq() returns the number (LONG) of the button pressed.  Buttons are numbered
    1, 2, 3, ..., 0.
    Pressing <Return> returns 1, Esc = 0.
    If DMREQ_ABORT <> -1 then Esc will also set the Abort flag.
  */

  scrn = (struct Screen *) GetTagData(DMREQ_SCREEN, (ULONG) Screen, tags);
  sh = (struct StringHistory *) GetTagData(DMREQ_HISTORY, (ULONG) &ReqHistory, tags);
  abortbtn = GetTagData(DMREQ_ABORT, 0xFFFFFFFF, tags);

  if ((vi = GetVisualInfo(scrn, TAG_END))) {
    if ((di = GetScreenDrawInfo(scrn))) {
      rp = &scrn->RastPort;
      CopyMem(scrn->Font, &boldta, sizeof(struct TextAttr));
      boldta.ta_Style = FSF_BOLD;
      charh = scrn->Font->ta_YSize + 1;
      bt = scrn->WBorTop + charh;
      bb = scrn->WBorBottom;
      bl = scrn->WBorLeft;
      blr =  bl + scrn->WBorRight;

      /* --- Init Body Texts --- */
      stotal = strtoarray(sh->mempool, body, bodystrs, 30, rp, &smax);

      /* --- Init Button Texts --- */
      sprintf(defgads,"%s|%s",msgGadOkay,msgGadCancel); /* 2.5b13 rri */
      btotal = strtoarray(sh->mempool,(STRPTR) GetTagData(DMREQ_BUTTONS, (ULONG) defgads, tags), btnstrs, 15, rp, &bmax); /* 2.5b13 rri */
      bmax += 10;

      w = max(smax, ((bmax + 4) * btotal)) + blr + 18;
      x = dest ? charh + 7: 0;
      h = charh * (stotal + 1) + bt + bb + x + 25;
      bspc = btotal == 1 ? 0 : (w - blr - 8 - (bmax * btotal)) / (btotal - 1);

      /* --- Create Gadgets --- */
      prvgad = CreateContext(&glist);

      ng.ng_LeftEdge = bl + 4;
      ng.ng_TopEdge = charh * stotal + bt + 16;
      ng.ng_Height = charh + 5;
      ng.ng_TextAttr = scrn->Font;
      ng.ng_VisualInfo = vi;
      ng.ng_GadgetID = 1;

      if (dest) {
        ng.ng_GadgetText = NULL;
        ng.ng_Width = w - (blr + 8);
        ng.ng_UserData = sh;
        strgad = prvgad = CreateGadget(STRING_KIND, prvgad, &ng, GTST_String, dest,
                                                                 GTST_MaxChars, cmax,
                                                                 GTST_EditHook, (ULONG) &EditHook,
                                                                 TAG_END);
        ng.ng_TopEdge += ng.ng_Height + 2;
      }

      if (bspc == 0) ng.ng_LeftEdge = (w / 2) - (bmax / 2);
      ng.ng_Width = bmax;
      ng.ng_Flags = PLACETEXT_IN;
      ng.ng_UserData = NULL;
      ng.ng_TextAttr = &boldta;

      for (i = 0; i < btotal; i++) {
        ng.ng_GadgetText = btnstrs[i];
        prvgad = CreateGadget(BUTTON_KIND, prvgad, &ng, TAG_END);
        ng.ng_LeftEdge += bmax + bspc;
        ng.ng_GadgetID++;
        if (i + 2 == btotal) ng.ng_GadgetID = 0;
        ng.ng_TextAttr = scrn->Font;
      }

      if (prvgad) {
        /* --- Open Window --- */
        if ((win = OpenWindowTags(NULL, WA_Left,       (scrn->Width / 2) - (w / 2),
                                        WA_Top,        (scrn->Height / 2) - (h / 2),
                                        WA_Width,      w,
                                        WA_Height,     h,
                                        WA_Title,      GetTagData(DMREQ_TITLE, (ULONG) Version, tags),
                                        WA_IDCMP,      IDCMP_REFRESHWINDOW | IDCMP_VANILLAKEY | STRINGIDCMP | BUTTONIDCMP,
                                        WA_Gadgets,    glist,
                                        WA_PubScreen,  scrn,
                                        WA_PubScreenFallBack, TRUE,
                                        WA_Flags,      g_CommonWinFlags,
                                        WA_AutoAdjust, TRUE,
                                        TAG_END))) {
          rp = win->RPort;
          SetFont(rp, di->dri_Font);  /* 2.5b11 jjt */
          SetAfPt(rp, bgpat, 1);
          SetAPen(rp, (ULONG) di->dri_Pens[SHINEPEN]);
          RectFill(rp, bl, bt, w - bl - 1, h - bb - 1);  /* Fill window */
/*
          SetAfPt(rp, NULL, 0);
          SetAPen(rp, di->dri_Pens[BACKGROUNDPEN]);
*/
/*          RectFill(rp, bl + 4, bt + 4, w - bl - 5, h - bb - ng.ng_Height - x - 9);*/  /* Clear text area*/
          EraseRect(rp, bl + 4, bt + 4, w - bl - 5, h - bb - ng.ng_Height - x - 9);  /* Clear text area*/
          if (dest) {
            y = charh * stotal + bt + 16;
/*            RectFill(rp, bl + 4, y, w - bl - 5, y + charh + 4);*/  /* Clear string gad area. */
            EraseRect(rp, bl + 4, y, w - bl - 5, y + charh + 4);  /* Clear string gad area. */
          }
          DrawBevelBox(rp, bl + 4, bt + 4, w - blr - 8, stotal * charh + 8, GTBB_Recessed, TRUE,
                                                                            GT_VisualInfo, vi,
                                                                            TAG_END);
          RefreshGList(glist, win, NULL, -1);
          GT_RefreshWindow(win, NULL);
          if (dest) {
            si = (struct StringInfo *) strgad->SpecialInfo;
            si->BufferPos = si->NumChars;
            ActivateGadget(strgad, win, NULL);
          }

          /* --- Print Body Text --- */
          SetAPen(rp, (ULONG) di->dri_Pens[TEXTPEN]);
          x = bl + 9;
          y = di->dri_Font->tf_Baseline + bt + 8;
          for (i = 0; i < stotal; i++) {
            Move(rp, x, y);
            Text(rp, bodystrs[i], (ULONG) strlen(bodystrs[i]));
            y += charh;
          }

          /* --- Handle IDCMP --- */
          while(!done) {
            WaitPort(win->UserPort);
            while ((msg = GT_GetIMsg(win->UserPort))) {
              class = msg->Class;
              code = msg->Code;
              prvgad = (struct Gadget *) msg->IAddress;
              GT_ReplyIMsg(msg);

              if (class == IDCMP_REFRESHWINDOW) {
                GT_BeginRefresh(win);
                GT_EndRefresh(win, TRUE);
              }

              else if ((class == IDCMP_VANILLAKEY) || (class == IDCMP_GADGETUP)) {
                done = TRUE;
                if (code == 13) choice = 1;                                          /* Return pressed */
                else if (code == 27) choice = abortbtn ? abortbtn : 0;               /* Esc pressed    */
                else if (class == IDCMP_GADGETUP) choice = (LONG) prvgad->GadgetID;  /* Gadget pressed */
                else done = FALSE;

                if (done && (choice == abortbtn)) {
                  choice = 0;
                  Abort = 1;
                }
              }
            }
          }

          if (dest && choice) {
            strcpy(dest, si->Buffer);
            StrHist_Add(sh, dest);
          }

          CloseWindow(win);
        }
      }
      FreeGadgets(glist);
      FreeScreenDrawInfo(scrn, di);
    }
    FreeVisualInfo(vi);
  }

  PoolFreeVec(*bodystrs);
  PoolFreeVec(*btnstrs);

  Busy(0); /* 2.5b10 rri */

  return choice;
}


ULONG strtoarray(APTR mempool, CONST_STRPTR str, UBYTE **strary, ULONG arymax, struct RastPort *rp, ULONG *widest) {  /* 2.5b10 jjt */
  UBYTE *sptr;
  ULONG c, l, stotal=0, x;

  if (str && (sptr = CloneStr(str, mempool))) {
    for (c = 1; stotal < arymax, c != 0; stotal++, strary++) {
      *strary = sptr;
      l = 0;
      for (;;) {
        c = *sptr++;
        if ((c == '\n') || (c == '|') || (c == 0)) {
          *(sptr - 1) = 0;
          break;
        }
        l++;
      }
      if (rp) {
        x = TextLength(rp, *strary, l);
        *widest = max(*widest, x);
      }
    }
  }
  for (c = stotal; c < arymax; c++, strary++) *strary = 0;  /* Zero-out remaining elements. */

  return stotal;
}


void MakeBtnString(const UBYTE yes[], const UBYTE middle[], const UBYTE no[]) /* 2.5b13 rri */
{
strcpy(g_buttons, yes ? yes : msgGadOkay); /* 2.5b13 rri */
strcat(g_buttons, "|");

if (middle)
 {
  strcat(g_buttons, middle);
  strcat(g_buttons, "|");
 }
strcat(g_buttons, no ? no : msgGadCancel); /* 2.5b13 rri */
}


void StrHist_Init(struct StringHistory *sh) {  /* 2.5b10 jjt */
/*   ULONG i;

  InitSemaphore(&(sh->sema4));

  for(i=0; i < STRHIST_MAX; i++) {
    sh->strcache[i] = NULL;
    sh->lencache[i] = 0;
  }
*/
  sh->mempool = StringPool;
  sh->cachepos = sh->total = 0;
}


/*
void StrHist_Clear(struct StringHistory *sh) {
  ULONG                  i;
  struct SignalSemaphore *sammy;

  sammy = &sh->sema4;
  ObtainSemaphore(sammy);
  for(i=0; i < sh->total; i++) {
    PoolFreeVec(sh->strcache[i]);

    sh->strcache[i] = NULL;
    sh->lencache[i] = 0;

  }
  sh->cachepos = sh->total = 0;
  ReleaseSemaphore(sammy);
}
*/


void StrHist_Add(struct StringHistory *sh, STRPTR str) {  /* 2.5b10 jjt */
  UBYTE                  *sptr;
  LONG                   i, l;
/*
  struct SignalSemaphore *sammy;

  sammy = &sh->sema4;
  ObtainSemaphore(sammy);
*/

  if (str && (l = strlen(str))) {
    /* --- Check if string already exists --- */
    for(i=0; i < sh->total; i++) {
      if (Stricmp(sh->strcache[i], str) == 0) {  /* 2.5b12 jjt */
        /* --- Already cached; move it to end of cache. --- */
        sptr = sh->strcache[i];
        i += 1;
        goto ashift;
      }
    }

    /* --- Clone string & add it to the cache --- */
    if ((sptr = CloneStr(str, sh->mempool))) {
      if (sh->total == STRHIST_MAX) {
        /* --- Cache full; dump first item & shift the array --- */
        PoolFreeVec(sh->strcache[0]);
        i = 1;
ashift: for(; i < STRHIST_MAX; i++) {
          sh->strcache[i - 1] = sh->strcache[i];
          sh->lencache[i - 1] = sh->lencache[i];
        }
        sh->total -= 1;
      }
      sh->strcache[sh->total] = sptr;
      sh->lencache[sh->total] = l;
      sh->total += 1;
    }
  }

  sh->cachepos = sh->total;
/*   ReleaseSemaphore(sammy); */
}


/* 2.5b10 jjt */
ULONG __saveds __asm StringHook(register __a0 struct Hook *hk,
                                register __a2 struct SGWork *swork,
                                register __a1 ULONG *msg) {
  LONG                 dir = 0, cp;
  ULONG                rc = 0xFFFFFFFF, jump = 0;
  struct StringHistory *sh;

    if (*msg == SGH_KEY) {
      if (swork->Code == 27) {
        restorestrcontents(swork);
        swork->Actions |= SGA_USE | SGA_END;
      }
      else if (swork->IEvent->ie_Class == IECLASS_RAWKEY) {
        if (swork->IEvent->ie_Code == CURSORUP) dir = -1;
        else if (swork->IEvent->ie_Code == CURSORDOWN) dir = 1;
        jump = swork->IEvent->ie_Qualifier & (IEQUALIFIER_LSHIFT | IEQUALIFIER_RSHIFT);
      }
    }
    else if (*msg != SGH_CLICK) rc = 0;

    if (dir) {
      sh = (struct StringHistory *) swork->Gadget->UserData;
      if (sh->total) {
        if (jump) cp = (dir == 1) ? sh->total : 0;
        else {
          cp = sh->cachepos + dir;
          if (cp < 0) cp = 0;
          else if (cp > sh->total) cp = sh->total;
        }
        if (cp == sh->total) restorestrcontents(swork);
        else {
/*           ObtainSemaphore(&sh->sema4); */
          strncpy(swork->WorkBuffer, sh->strcache[cp], ((struct StringInfo *) swork->Gadget->SpecialInfo)->MaxChars - 1);
          swork->NumChars = swork->BufferPos = sh->lencache[cp];
/*           ReleaseSemaphore(&sh->sema4); */
        }
        sh->cachepos = cp;
        swork->Actions |= SGA_USE;
      }
    }

  return (ULONG) rc;
}


void restorestrcontents(struct SGWork * swork) {  /* 2.5b10 jjt */
  strcpy(swork->WorkBuffer, ((struct StringInfo *) swork->Gadget->SpecialInfo)->UndoBuffer);
  swork->NumChars = swork->BufferPos = strlen(((struct StringInfo *) swork->Gadget->SpecialInfo)->UndoBuffer);
}
