/* DiskMaster II Rename/Comment/Protect/Filedate/Copy/Move/MakeDir/MakeIcon
**
** 00-07-10 rri - replaced all c++ style comments by ANSI ones
**              - replaced MyToUpper() calls by ToUpper() (utility.library)
**              - changed various stricmp() to Stricmp() calls
**
** 00-08-17 rri - removed some dead lines with StamProt() info
**
** 00-08-27 rri - moved FreeGlobuff() / GetGlobuff() to DMSupport.c
**              - adapted DMCopy() to new GetGlobuff()
**
** 2.5b9
**
** 00-09-22 rri - bugfix: DMCopy() did not trapped all error conditions
**                reported by Leon <leond@netidea.com>
**
** 00-10-12 rri - added function PrintDir()
**
** 00-10-15 rri - rewritten PrintDir()
**              - optimized var-header
**
** 00-11-08 rri - modified DOSStart(), it makes use of NP_CurrentDir now
**                and can be called from DOSEXecute to save some lines
**              - general cleanup of DOSExecute()
**
** 2.5b10
**
** 00-11-26 rri - bugfix in DOSExecute() - path`s with "s" in front were
**                mistaken for stack-arguments
**                reported by Jostein Klemmetsrud <klemmetj@c2i.net>
**              - moved DMSetDate() in from DMCommand.c
**
** 00-12-07 rri - removed one "warning 220" from DMRelabel(), DMRename()
**                DMProtect(), SmartRemEntry(), UpdateDlp(), DMCopy()
**                and two from DMOpenFont()
**
** 00-12-22 jjt - Updated DMReq() calls to either DMReq() or DMReqTagList().
**              - Added extern refs to reqtags_ContAbortCan & PathHistory.
**              - DMMove() & DMMakeDir() - Reqs use PathHistory.
**
** 00-12-26 rri - changed type of BPB from int to LONG
**              - removed six "warning 120"`s
**              - changed UserCols from int to ULONG
**
** 00-12-28 rri - changed a few vars from int to LONG
**
** 01-01-10 rri - changed a few lines for pooled names
**
** 01-01-14 rri - set string-pointers to NULL after AsmFreePooled()
**
** 01-01-28 rri - introduced CloneStr() / PoolFreeVec() for names
**              - changed ->name2 referencies to ->name
**              - removed some dead lines
**
** 2.5b12
**
** 01-07-23 rri - modified DMCopy() with test-functions
**
** 01-07-27 rri - removed palette restoration from View()
**              - removed the DMCopy() test-functions
**
** 2.5b13
**
** 01-08-07 jjt - DMCopy() - Added "WARN" option.
**                         - Moved the "RENAME" portion nearer to the top.
**                         - Examine() is called outside of "NEWER" so that "WARN" can also
**                           use the FIB.
**                         - The lock "fOut" is freed right after Examine() so that "NEWER" &
**                           "WARN" can return without leaving a locked file.
**                         - Returns 1 if it didn't exit prematurely.
**
** 01-08-08 jjt - DMCopy() - TestWarnFlag can bypass "WARN" test.
**                         - Copy/Move RENAME "fix" removed; it works as designed again.
**
** 01-08-12 rri - usage of a new sub-routine in DMParser.c saved some lines
**                in DMMove.c
**
** 01-08-21 jjt - Added ParseCpMvArgs().
**              - DMCopy() & DMMove() use ParseCpMvArgs().
**              - Added CpMvArgTest.  When 0 DMCopy() skips the call to ParseCpMvArgs()
**                (because DMMove already called it; just use the copy routine).
**
** 01-09-08 rri - localisation:
**                 DMMove() - msgStatMoving, msgErrorMoving
**                 DMOpenFont() - msgErrorPropFont
**                 DMRelabel() - msgReqRelabel
**                 DMRename() - msgReqRename
**                 DMComment() - msgReqComment
**                 DMProtect() - msgReqProtect
**                 ParseCpMvArgs() - msgReqRename
**                 DMMakeDir() - msgReqMakeDir, msgGadCIC
**                 DOSExecute() - msgReqDOSExec
**                 CheckSpace() - msgStatCheckSpace1, msgStatCheckSpace2,
**                                msgStatCheckSpace3, msgErrorCheckSpace
**                 PrintDir() - msgStatPrintDir
**
** 01-09-10 rri - removed reqtags_ContAbortCan
**
** 01-09-15 rri - modified CheckSpace() to use only msgErrorCheckSpace
**                and msgStatCheckSpace
**
** 01-09-18 rri - replaced msgGadCAC from DMRename(), DMProtect(), DMComment()
**                and ParseCpMvArgs() by a MakeBtnString(0, msgGadSkip, 0);
**                initialised g_buttons
**              - replaced msgGadCIC from DMMakeDir() by a
**                MakeBtnString(0, msgGadIcon, 0); initialised g_buttons
**
** 01-09-20 rri - adapted ParseCpMvArgs() and 'Copy' to new button-order with
**                "Cancel" last and "Skip" fourth
**
** 01-09-22 rri - replaced strcmpi() calls in MakeIcon(), DMOpenFont() and
**                InfoReq() by Stricmp() calls
**
** 01-09-23 rri - 'MakeDir' has ICON option now - ID:  03.53
**
** 01-09-29 jjt - Added extern reqtags_OkSkipCan.
**              - Changed DMRename(), DMComment(), DMProtect(), & ParseCpMvArgs() to
**                use reqtags_OkSkipCan.
**
** 01-10-03 rri - 'Move' didn't work anymore with dirs, modified DMMove(),
**                moved MakeDestName(s,dest); from ParseCpMvArgs()
**                to DMCopy()
**
** 01-10-17 rri - added keepselected to ParseCpMvArgs()
**
** 01-10-18 rri - added LONG skip_all for "Skip All" option in ParseCpMvArgs()
**              - prepared ParseCpMvArgs() for "Skip All" option
**              - DMCopy displays the "Copy"/"Move" messages itself now
**
** 01-10-20 rri - changed the gadget-order in ParseCpMvArgs()
**
** 01-10-29 rri - moved parts of DMMove() to DMCopy() to fix a problem
**                with 'Move RENAME' and removed DMMove()
**              - removed CpMvArgTest since ParseCpMvArgs() is only called
**                once now anyways.
**              - modified the prototype for ParseCpMvArgs() to allow
**                DMCopy() call it with "int opt" as "move" parameter
**              - Bugfix: 'Info' works in the DEV/VOL/ASN list now, too.
**                Reported by Stephan Niehues <Nase@NetCologne.de>
**
*/

#include "DM.h"

extern struct DateStamp setStamp; /* 2.5b10 rri */
extern struct DirWindow *DirWin[],*DestWin,*CDWin;
extern struct FileInfoBlock   Fib;
extern struct Library   *AslBase;
extern struct Screen    *Screen,*MyScreen;
extern struct StringHistory PathHistory;  /* 2.5b10 jjt */
extern struct TagItem reqtags_OkSkipCan[];  /* 2.5b13 jjt */

extern UBYTE *ActionArgs[],
             dcPath[],
             DOSPassStr[],
             g_buttons[], /* 2.5b13 rri */
             *Globuff,
             Pattern[],
             sbuff[],
             ScreenTitle[], /* new! 2.5b4 */
             sPath[],
             Version[];

extern int Abort,
           AttrFlag,
           RecurseDepth,
           ColFudge, /* 2.5b9 rri */
           WinTitleFlag, /* new! 2.5b4 */
           TestWarnFlag;  /* 2.5b13 jjt */

extern BPTR StdIO; /* new! 2.4b14 */

extern LONG BlkTotal,
            BPB,
            Globuff_size;

extern ULONG keepselected; /* 2.5b13 rri */

extern APTR NamePool; /* 2.5b10 rri */

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */

struct TextFont *DMFont;
struct TextAttr MAttr;
struct InfoData InfoData; /* new! 2.5b4 */

struct Library *AmigaGuideBase; /* new!2.4 */
struct Library *WorkbenchBase; /* new!2.4 */

UBYTE FontName[32]="topaz",
      ProtBuff[24]="-HSPA +RWED"; /* new! 2.4 */

int FontSize=8; /* new! 2.4 */

LONG skip_all; /* 2.5b13 rri */


void UpdateDlp(struct DirList *dlp,UBYTE *name);
void AddNewDlp(struct DirWindow *dw,UBYTE *name);
ULONG ParseCpMvArgs(UBYTE *s, UBYTE *dest, int move);  /* 2.5b13 jjt */


int DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new) /* new! 2.2b15 */
{
UBYTE  *ptr=name,*ptr2=sbuff+1;

if(*dev==0) return(0);

if(!new)
 {
  if(ptr) while(*ptr&&*ptr!=':') *ptr2++=(*ptr++); /* 2.5b10 rri */
  *ptr2=0;
  sprintf(sbuff+52,msgReqRelabel,dev); /* 2.5b13 rri */
  if(!DMReqTagList(sbuff+52, sbuff+1, 31, 0) || !sbuff[1]) return(0);  /* 2.5b10 jjt */
 }
else strcpy(sbuff+1,new);
sbuff[0]=(UBYTE)strlen(sbuff+1);
return Relabel(dev,sbuff+1);
}


void DMRename(UBYTE *old)
{
UBYTE *ptr,*new=ActionArgs[2];
sFIB  *fib=(&Fib); /* 2.5b10 rri */
BPTR  lock; /* 2.5b5 rri */

if(!old) return;

if(!new)
 {
  strcpy(dcPath,old);
  new=dcPath;
  ptr=new+strlen(new)-1;
  while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
  if (DMReqTagList(msgReqRename, ptr+1, 107, reqtags_OkSkipCan) != 1) return;  /* 2.5b13 jjt */
 }

if(lock=Lock(old,ACCESS_READ)) /* new! 2.4b21 */
 {
  UnLock(lock); /* 2.5b6 rri */
  if(!Rename(old,new)) Abort=1;
  else
   {
    ptr=new+strlen(new)-1; /* place the pointer at the end of the string */
    while(!(lock=Lock(new,ACCESS_READ))&&*ptr!=':') /* 2.5b6 rri */
     {
      *ptr=0; /* Lock() wasn`t sucessfull, shorten string by */
      ptr--;  /* one char and try again */
     }
    if(!lock) /* if Lock() wasn`t sucessfull at all, leave DMRename() */
     {
      Abort=1;
      return;
     }
    while(ptr>new&&*ptr!='/'&&*ptr!=':') ptr--;
    if(Examine(lock,fib)) /* new! 2.4b21 */
     {
      strncpy(ptr+1,fib->fib_FileName,107); /* new! 2.4b21 */
     }
    UnLock(lock); /* new! 2.4b21 */
    if(strncmp(new,old,(size_t)(ptr-new))) /* 2.5b10 rri */
     {
      SmartRemEntry(old);
      SmartAddEntry(new);
     }
    else SmartRename(old,new);
   }
 }
}


void SmartRename(UBYTE *old,UBYTE *new)
{
struct DirWindow *dw;
struct DirList **dl;
UBYTE *ptr;
int len;
LONG i,j,c; /* 2.5b10 rri */

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(strncmp(old,dw->Path,len)) continue;
  if(Stricmp(old,dw->Path)==0) /* 2.5b7 rri */
   {
    strcpy(dw->Path,new);
    RefreshGadgets(&dw->dir_gad,dw->Window,0);
    continue;
   }
  ptr=old+len; dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue; /* rename dev/cmd file */
  if(*ptr=='/')
   {
    ptr++;
    len++;
   }
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=old+len;

  for(j=0;j<dw->FileCount;j++)
   if(Stricmp(ptr,dl[j]->name)==0) /* 2.5b7 rri */
    {
     PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
     dl[j]->name = CloneStr(new+len, NamePool); /* 2.5b10 rri */
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
     dw->Flags|=DWFLAG_RESORT;
     break;
    }
 }
}


void DMComment(UBYTE *name,UBYTE *str,sFIB *fib)
{
if(!name) return;
if(!str)
 {
  str=fib->fib_Comment;
  sprintf(sbuff,msgReqComment,fib->fib_FileName); /* 2.5b13 rri */
  if (DMReqTagList(sbuff, str, 80, reqtags_OkSkipCan) != 1) return;  /* 2.5b13 jjt */
 }
if (Stricmp(str,"##")==0) /* 2.5b7 rri */
 {
  *str=0;
 }

if(!SetComment(name,str)) Abort=1;
else SmartAddEntry(name);
}


void DMProtect(UBYTE *name,UBYTE *str,sFIB *fib)
{
LONG    Attr=fib->fib_Protection;
int     x,incl=(-1); /* 2.5b10 rri */
UBYTE   c;

if(!name) return;
if(!AttrFlag)
 {
  if(str)
   {
    strcpy(ProtBuff,str);
    AttrFlag=1;
   }
  else
   {
    sprintf(sbuff,msgReqProtect,fib->fib_FileName); /* 2.5b13 rri */
    if (DMReqTagList(sbuff, ProtBuff, 22, reqtags_OkSkipCan) != 1) return;  /* 2.5b13 jjt */
   }
 }
str=ProtBuff;
while(c=ToUpper((ULONG)*str++)) /* 2.5b10 rri */
 {
  x=0;
  switch(c)
   {
    case '+': incl=1; break;
    case '-': incl=0; break;
    case 'H': x=128; break;
    case 'S': x=64; break;
    case 'P': x=32; break;
    case 'A': x=16; break;
    case 'R': x=8; break;
    case 'W': x=4; break;
    case 'E': x=2; break;
    case 'D': x=1; break;
    case 'G': AttrFlag=1;
    default : break;
   }
  if(incl<0&&x){Attr=0xf; incl=1;}
  if(x>=16)
   {
    Attr|=x;
    if(!incl) Attr&=~x;
   }
  else if(x)
   {
    Attr&=~x;
    if(!incl) Attr|=x;
   }
 }
if(!SetProtection(name,Attr)) Abort=1;
else SmartAddEntry(name);
}


void DMSetFileDate(UBYTE *dir,sFIB *fib)
{
 SetFileDate(dir,&fib->fib_Date);
 SmartAddEntry(dir);
}


void SmartRemEntry(UBYTE *name)
{
struct DirWindow *dw;
struct DirList **dl,*dlp;
UBYTE  *ptr;
int len;
LONG i,j,c; /* 2.5b10 rri */

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(strncmp(name,dw->Path,len)) continue;
  ptr=name+len;
  dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue;
  if(*ptr==0)
   {
    dw->Path[0]=0;
    InitDir(dw,0);
    continue;
   }
  if(*ptr=='/') ptr++;
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=name+len;
  if(*ptr=='/') ptr++;

  for(j=0;j<dw->FileCount;j++)
   {
    dlp=dl[j];
    if(dlp&&(Stricmp(ptr,dlp->name)==0)) /* 2.5b7 rri */
     {
      dlp->sel=2;
      dlp->dir=(-1); /* 2.5b10 rri */
      dw->Flags|=DWFLAG_RESORT;
      c=dw->Index;
      if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
      break;
     }
   }
 }
}


void SmartAddEntry(UBYTE *name)
{
struct DirWindow *dw;
struct DirList  **dl;
UBYTE           *ptr;
int len;
LONG i,j,c; /* 2.5b10 rri */

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(!dw) continue;
  len=strlen(dw->Path);
  if(strncmp(name,dw->Path,len)) continue;
  ptr=name+len;
  dl=dw->DirList;
  if(dw->FileCount&&dl[0]->dir>1) continue;
  if(len&&dw->Path[len-1]!=':'&&*ptr!='/') continue;
  if(*ptr=='/') ptr++;
  while(*ptr) if(*ptr++=='/') break;
  if(*ptr) continue;
  ptr=name+len;
  if(*ptr=='/') ptr++;
  for(j=0;j<dw->FileCount;j++)
   if(Stricmp(ptr,dl[j]->name)==0) /* 2.5b7 rri */
    {
     PoolFreeVec(dl[j]->name); /* 2.5b10 rri */
     dl[j]->name=0;
     UpdateDlp(dl[j],name);
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows)) dis_name(dw,j,j-c);
     dw->Flags|=DWFLAG_RESORT;
     break;
    }
   if(j==dw->FileCount)
    {
     AddNewDlp(dw,name);
     dw->Flags|=DWFLAG_RESORT;
     Increment(dw,&dw->dn,1);
     SetVert(dw);
     c=dw->Index;
     if(j>=c&&j<(c+dw->Rows))
      {
       len=strlen(dw->DirList[j]->name);
       if(len>dw->ColsName)
        {
         dw->ColsName=len;
         dis_files(dw);
         WinTitle(dw);
        }
       else dis_name(dw,j,j-c);
      }
    }
 }
}


void UpdateDlp(struct DirList *dlp,UBYTE *name)
{
sFIB *fib=(&Fib); /* 2.5b10 rri */
BPTR lock; /* 2.5b5 rri */

if(lock=Lock(name,ACCESS_READ))
 {
  if(Examine(lock,fib))
   {
    Fib2Dlp(dlp,fib);
   }
  UnLock(lock);
 }
}


void AddNewDlp(struct DirWindow *dw,UBYTE *name)
{
 if(AllocDlp(dw)) UpdateDlp(dw->DirList[dw->FileCount++],name);
}


ULONG ParseCpMvArgs(UBYTE *s, UBYTE *dest, int move) /* 2.5b13 jjt */
{
LONG  newer;
BPTR  fIn, fOut;
sFIB  srcfib, destfib, *dfptr;

if (Stricmp(s, dest) == 0) /* Src = Dest?   */
 {
  if (move==3)                /* Move - Exit.  */
   {
    Abort = 1;
    return 0;
   }
  else strcat(dest, ".BAK"); /* Copy - Append ".BAK". */
 }

if (GetActionArg("RENAME", AATYPE_BOOL, 0))
 {
  rename:
  if (DMReqTagList(msgReqRename, FilePart(dest), 107, reqtags_OkSkipCan) != 1) return 0;  /* 2.5b13 jjt */
 }

if (fOut=Lock(dest, ACCESS_READ))  /* Dest exists? */
 {
  dfptr = (Examine(fOut, &destfib)) ? &destfib : (sFIB *) NULL;
  UnLock(fOut);

  if (fIn = Lock(s, ACCESS_READ))
   {
    Examine(fIn, &srcfib);
    UnLock(fIn);
   }

  if (GetActionArg("NEWER", AATYPE_BOOL, 0))
   {
    newer = dfptr ? CompareDates(&destfib.fib_Date, &srcfib.fib_Date) : 0;
    if (newer<=0) return 0;
   }

  else if (skip_all) /* 2.5b13 rri */
   {
    keepselected=1;
    return 0;
   }

  else if (TestWarnFlag && GetActionArg("WARN", AATYPE_BOOL, 0))
   {
    switch(REQ_FileExists(&srcfib, dfptr)) /* 2.5b13 rri */
     {
      case 0: return 0;
      case 2: TestWarnFlag = 0; break;
      case 3: goto rename;
      case 4: skip_all=1; keepselected=1; return 0;
      case 5: keepselected=1; return 0;
     }
   }

  if (GetActionArg("FORCE", AATYPE_BOOL, 0)) SetProtection(dest, 0);
 }

return 1;
}


ULONG DMCopy(UBYTE *s,UBYTE *dest,sFIB *fib,int opt)
{
UBYTE *ptr;
int   status;
LONG  i=NULL, /* 2.5b10 rri */
      cp;     /* 2.5b13 jjt */
BPTR  fIn,fOut; /* 2.5b5 rri */


MakeDestName(s,dest); /* 2.5b13 rri */

cp = ParseCpMvArgs(s, dest, opt); /* 2.5b13 rri */

if(!cp)
 {
  return 0; /* 2.5b13 rri */
 }

if (cp)  /* 2.5b13 jjt */
 {
  if(!Globuff) /* 2.5b7 rri */
   {
    if(!GetGlobuff())
     {
      return 0;
     }
   }
  if(opt==RECURSE_MOVE)
   {
    display(msgStatMoving,sPath); /* 2.5b13 rri */
    if(Rename(s,dest)) /* try to move-by-rename */
     {
      SmartAddEntry(dest);
      SmartRemEntry(s);
      return 0; /* DMRecurse won't need to delete the file */
     }
   }
  else  display(msgStatCopying,sPath); /* 2.5b13 rri */

  /* new! 2.4b21 */

  if(fIn=Open(s,MODE_OLDFILE))
   {
    if(fOut=Open(dest,MODE_NEWFILE))
     {
      status=1;
      while((status>0&&(i=Read(fIn,Globuff,Globuff_size))>0)&&(!Abort))
       {
        CheckAbortKey();
        status=Write(fOut,Globuff,i);

        if(status!=i) /* 2.5b9 rri */
         {
          status=(-1); /* 2.5b10 rri */
         }
       }
      Close(fOut);

      if(status==-1||i==-1||Abort) /* 2.5b9 rri */
       {

/* modified but removed in 2.5b9 - rri

      Fault(IoErr(),NULL,Globuff,FAULT_MAX);
      display(Globuff,0);

Display() is useless here as it will be overwritten instantly
by "Operation Aborted" when Abort=1 is returned...

*/
        DeleteFile(dest);
        Abort=1;
       }

      else
       {
        if(fib->fib_Comment[0]) SetComment(dest,fib->fib_Comment);
        if(fib->fib_Protection) SetProtection(dest,fib->fib_Protection);
        DMSetFileDate(dest,fib);
       }

      ptr = FilePart(dest);
      *ptr=0;
     }
    else /* new! 2.5b2 */
     {
      Abort=1;
     }
    Close(fIn);
   }
  else /* new! 2.5b2 */
   {
    Abort=1;
   }
 }

return (ULONG) (Abort == 0); /* 2.5b13 jjt */
}


void DMMakeDir(UBYTE *name)
{
int n=0,x;
BPTR lock; /* 2.5b5 rri */
UBYTE *ptr;

if(x=GetActionArg("ICON", AATYPE_BOOL, 0)) /* 2.5b13 rri */
 {
  MakeBtnString(0, 0, 0);
  if(x==1) name=0;
 }
else MakeBtnString(0, msgGadIcon, 0);  /* 2.5b13 rri */

if(!name)
 {
  name=sPath;
  if(*name==0) return;
  ptr=name+strlen(name)-1;
  if(*ptr++!=':')
   {
    *ptr++='/';
    *ptr=0;
   }
  n=DMReq(msgReqMakeDir, name, 512, DMREQ_BUTTONS, g_buttons,
                                    DMREQ_HISTORY, (ULONG) &PathHistory,
                                    TAG_END);
  if(!n) return; /* 2.5b10 jjt */
 }

if(lock=Lock(name,ACCESS_READ))
 {
  UnLock(lock);
 }

else if(lock=CreateDir(name))
 {
  UnLock(lock);
  SmartAddEntry(name);
  if(n==2||x)
   {
    MakeIcon(name);
    strcat(name,".info");
    SmartAddEntry(name);
   }
 }
else Abort=1;
}


void MakeIcon(UBYTE *name) /* new! 2.4 */
{
struct DiskObject *dob;
UBYTE  *ptr;

ptr=name+strlen(name);
if(Stricmp((ptr-5),".info")!=0) /* 2.5b13 rri */
 {
  if(dob=GetDiskObjectNew(name))
   {
    PutDiskObject(name,dob);
    FreeDiskObject(dob);
   }
 }
}


void Dupe(void) /* new! 2.4 */
{
UBYTE  *ptr;
struct DirList **Source,**Dest;
int     i=1,c,comment=0,date=0,name=0,size=0,select=1,state;

while(ActionArgs[i])
 {
  ptr=ActionArgs[i];
  switch(*ptr)
   {
    case 'c':
    case 'C': comment=1;
              break;
    case 'd':
    case 'D': date=1;
              break;
    case 'n':
    case 'N': name=1;
              break;
    case 's':
    case 'S': size=1;
              break;
    case '-': select=0;
              break;
   }
  i++;
 }

Source=CDWin->DirList;
Dest=DestWin->DirList;

if (comment||date||name||size)
 {
  for(i=0;i<CDWin->FileCount;i++)
   {
    if (Source[i]->sel!=select)
     {
      for(c=0;c<DestWin->FileCount;c++)
       {
        state=0;

        if(comment)
         {
          if (Source[i]->cmt&&Dest[c]->cmt)
           {
            if (Stricmp(Source[i]->cmt,Dest[c]->cmt)==0) /* 2.5b7 rri */
             {
              state+=comment;
             }
           }
         }
        if (date)
         {
          if (CompareDates(&Source[i]->ds,&Dest[c]->ds)==0)
           {
            state+=date;
           }
         }
        if (name)
         {
          if(Stricmp(Source[i]->name,Dest[c]->name)==0) /* 2.5b7 rri */
           {
            state+=name;
           }
         }
        if (size&&(Source[i]->dir<1)&&(Dest[c]->dir<1))
         {
          if (Source[i]->size==Dest[c]->size)
           {
            state+=size;
           }
         }
        if (state==(comment+date+name+size))
         {
          Source[i]->sel=select;
         }

       } /* endfor (c... */
     } /* endif (Source... */
   } /* endfor (i... */
  } /* endif (comment||date... */
dis_files(CDWin);
WinTitle(CDWin);
}


void SwapSelect(void) /* new! 2.4 */
{
struct DirList **Source;
int     i;

Source=CDWin->DirList;

for(i=0;i<CDWin->FileCount;i++)
 {
  if (Source[i]->sel)
   {
    Source[i]->sel=0;
   }
  else Source[i]->sel=1;
 }
dis_files(CDWin);
WinTitle(CDWin);
}


void DMOpenFont(UBYTE *str,int size)
{
struct FontRequester *FontRequest; /* new! 2.4 */
struct TextFont *oldfont;
struct TextAttr *mat;
struct Screen   *pub_screen;
int    i;
UBYTE  *ptr,*pub_screen_name = "Workbench";

oldfont=DMFont;
mat=(&MAttr); /* 2.5b10 rri */

FontRequest=0;

if (!size||size==0||size>40) size=FontSize; /* new! 2.4 */

if(!str||*str==0)
 {
  if(!AslBase) return; /* new! 2.5b2 */
  str=FontName; /* new! 2.4 */
  FontRequest = AllocAslRequest (ASL_FontRequest, NULL);
  if (FontRequest != NULL)
   {
    if (MyScreen)
     {
      pub_screen=MyScreen;
     }
    else
     {
      pub_screen = LockPubScreen(pub_screen_name);
     }
    if (pub_screen != NULL)
     {
      if (AslRequestTags(FontRequest,
                  ASLFO_Screen, pub_screen,
                  ASLFO_TitleText,  Version,
                  ASLFO_InitialName, str, /* new! 2.4 */
                  ASLFO_InitialSize, size, /* new! 2.4 */
/*                  ASLFO_SleepWindow, TRUE, */
/*                  ASLFO_Window,  */
                  ASLFO_FixedWidthOnly, TRUE,
                  TAG_DONE))
                   {
                    mat=(&FontRequest->fo_Attr); /* 2.5b10 rri */
                    sprintf(str,"%s",mat->ta_Name);
                    size=mat->ta_YSize;
                   }
     } /* if (pub_screen... */
    if (!MyScreen) UnlockPubScreen(pub_screen_name,pub_screen);
   } /* if (FontRequest... */
 } /* if (str... */

ptr=str+strlen(str);
if(Stricmp((ptr-5),".font")!=0) /* 2.5b13 rri */
 {
  strcpy(ptr,".font");
 }

mat->ta_Name=str;
mat->ta_YSize=size;

DMFont=OpenFont(mat);
if(DiskfontBase&&(!DMFont||DMFont->tf_YSize!=size))
 {
  if(oldfont&&DMFont)
   {
    CloseFont(oldfont);
    oldfont=DMFont;
   }
  DMFont=OpenDiskFont(mat);
 }
if(DMFont&&(DMFont->tf_Flags&FPF_PROPORTIONAL))
 {
  display(msgErrorPropFont,0); /* 2.5b13 rri */
  CloseFont(DMFont);
  DMFont=0;
 }

if (DMFont) strcpy(FontName,mat->ta_Name); /* new! 2.4 */

if(!DMFont&&oldfont)
 {
  DMFont=oldfont;
  oldfont=0;
 }
if(oldfont) CloseFont(oldfont);

/* new! 2.3
if (MyScreen)
 {
  SetFont(&MyScreen->RastPort,DMFont);
 }
*/

FontSize=DMFont->tf_YSize; /* new! 2.4 */

for(i=0;i<255;i++)
if(DirWin[i])
 {
  SetFont(DirWin[i]->Window->RPort,DMFont);
  NewSize(DirWin[i]);
 }
if (FontRequest) FreeAslRequest (FontRequest);
}


void View(UBYTE *file) /* new! 2.4 */
{
struct NewAmigaGuide NewGuide = {NULL};

AMIGAGUIDECONTEXT Context;

/*
UBYTE text[]="Wish";
UBYTE *node = text;
LONG line =148;
*/

NewGuide.nag_Name = (STRPTR) file;

if (!LibOpen("amigaguide.library", &AmigaGuideBase, 37)) return;  /* 2.5b6 jjt (18.5.00) */

if (MyScreen)
 {
  NewGuide.nag_Screen = MyScreen;
 }

/*
NewGuide.nag_Node = node;
NewGuide.nag_Line = line;
*/

if ( Context = OpenAmigaGuideA(&NewGuide, NULL)) /* Open the AmigaGuide client */
 {
  CloseAmigaGuide(Context); /* Close the AmigaGuide client */
 }
}


void InfoReq(UBYTE *file) /* new! 2.4 */
{
BPTR lock; /* 2.5b5 rri */
UBYTE  *ptr;

ptr=file+strlen(file);
if(Stricmp((ptr-5),".info")==0) /* 2.5b13 rri */
 {
  ptr[-5]=0;
 }

if (!LibOpen("workbench.library", &WorkbenchBase, 37)) return;  /* 2.5b6 jjt (18.5.00) */

if(CDWin&&CDWin->Path[0])
 {
  if(lock=Lock(CDWin->Path,ACCESS_READ))
   {
    WBInfo(lock, file, Screen);
    UnLock(lock);
   }
 }
else /* 2.5b13 rri */
 {
  if(lock=Lock(file, ACCESS_READ))
   {
    if(ParentDir(lock)) /* entry is ASSIGN ? */
     {
      UnLock(lock);
      GetParent(file,0);
      if(!(lock=Lock(file, ACCESS_READ)))
       {
        return;
       }
     }
    WBInfo(lock,"disk", Screen);
    UnLock(lock);
   }
 }  
}


void DOSExecute(void) /* 2.5b9 rri */
{
UBYTE *ptr=DOSPassStr;
int StackSize=8192,i=1;

if (GetActionArg("s=",AATYPE_BOOL,0)==i) /* if arg "s=" is first arg then */
 {
  StackSize=GetActionArg("s",AATYPE_NUM,8192); /* check if for the stack-option */
  i++;
 }

if (StackSize<8192)
 {
  StackSize=8192;
 }

*ptr=0;

if(DOSParse(ptr,msgReqDOSExec,i))
 {
  DOSStart(StackSize); /* 2.5b9 rri */
 }
}


void DOSStart(int StackSize) /* new! 2.4b15 */
{
BPTR ext_path=NULL;

if(CDWin&&CDWin->Path[0])
 {
  ext_path = Lock(CDWin->Path, ACCESS_READ);
 }

SystemTags(DOSPassStr,
           SYS_Input, StdIO?StdIO:Input(),
           SYS_Output, NULL,
           SYS_UserShell, TRUE, /* new! 2.4b18 */
           NP_CurrentDir, ext_path,
           NP_StackSize, StackSize,
           TAG_END);
}


void CheckSpace(void) /* new! 2.5b4 */
{
BPTR lock; /* new! 2.5b5 hys */
struct BaseConvert checkbase;

if(!CDWin->Path[0])
 {
  if(lock=Lock(ActionArgs[1],ACCESS_READ))
   {
    Info(lock,&InfoData);
    CDWin->BytesPerBlock=InfoData.id_BytesPerBlock;
    UnLock(lock);
   }
 }

if(DestWin&&DestWin->BytesPerBlock)
 {
  BPB=DestWin->BytesPerBlock;
 }
else
 {
  BPB=CDWin->BytesPerBlock;
 }
if(!BPB)
 {
  return;
 }

StartRec(RECURSE_CHECK);

checkbase.BlocksFree=BlkTotal;
checkbase.BytesPerBlock=BPB;
ConvertBase(&checkbase);

strcpy(sbuff,checkbase.String); /* 2.5b13 rri */

if(DestWin)
 {
  if(BlkTotal>DestWin->BlocksFree)
   {
    sprintf(ScreenTitle,msgErrorCheckSpace,sbuff); /* 2.5b13 rri */
   }
  else
   {
    checkbase.BlocksFree=DestWin->BlocksFree-BlkTotal;
    ConvertBase(&checkbase);
    sprintf(ScreenTitle,msgStatCheckSpace,sbuff,checkbase.String); /* 2.5b13 rri */
   }
 }

display(ScreenTitle,0);
WinTitleFlag=1; /* new! 2.5b3 */

}


void PrintDir(void) /* 2.5b9 rri */
{
BPTR PrintFileHandle;
struct DirList **PrintList;
int i;


PrintList=CDWin->DirList;

if(GetGlobuff()) /* we always need a clear buffer so we call the function... */
 {
  if (PrintFileHandle=Open(ActionArgs[2],MODE_NEWFILE))
   {
    sprintf(Globuff,msgStatPrintDir,CDWin->Path); /* 2.5b13 rri */

    for(i=0;i<CDWin->FileCount;i++)
     {
      if (PrintList[i]->sel==1)
       {
        DoFileFormat(PrintList[i],CDWin->ColsName,CDWin->ColsCmt,CDWin->BytesPerBlock);
        sbuff[ColFudge-1]=0;
        strcat(Globuff,sbuff);
        strcat(Globuff,"\n");
        PrintList[i]->sel=0;
       }
     }

    Write(PrintFileHandle,Globuff,(LONG)strlen(Globuff)); /* 2.5b10 rri */
    Close(PrintFileHandle);
   }
 }

dis_files(CDWin);
WinTitle(CDWin);


/*

if(Stricmp(ActionArgs[2],"PRT:")==0)
 {
  sprintf(dcPath,"\x1b[0m%s\x1b[0m\n",sbuff);
  dcPath[2]=WorkDlp->dir?'1':'0';
 }
else sprintf(dcPath,"%s\n",sbuff);

*/

}


void DMSetDate()
{
DateStamp(&setStamp);
StartRec(RECURSE_DATE);
}
