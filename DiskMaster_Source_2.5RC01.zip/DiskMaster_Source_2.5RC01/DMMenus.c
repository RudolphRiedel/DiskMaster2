/* DiskMaster II  Menu module
**
** 00-07-12 rri - changed various stricmp() to Stricmp() calls
**              - replaced all c++ style comments by ANSI ones
**              - removed useless DelMenuItem()
**
** 00-08-19 rri - made the menu use Pens20[BARDETAILPEN] instead
**                of always using pen 1
**
** 2.5b10
**
** 00-12-07 rri - removed two "warning 220"`s and one "warning 317"
**                from AddMenuCmd()
**
** 00-12-22 jjt - Updated DMReq() calls to DMReqTagList().
**
** 00-12-27 rri - removed three "warning 120"`s
**
** 01-01-04 rri - rearranged the code in AddMenuCmd() to remove the goto`s
**              - reworked parts of AddMenu()
**              - reworked parts of AddMenuItem()
**
** 01-01-05 rri - made all allocations pooled
**
** 01-01-07 rri - fixed memory-hole by improving MyFreeMenus()
**              - removed some obsolete vars in file-header
**              - further optimized AddMenu() and AddMenuItem()
**
** 01-01-13 rri - set "g_memattrs" for menu-pool creation
**
** 01-01-27 rri - bugfix: restored the "optimzed" newmenu structures
**                in AddMenu() and AddMenuItem() as these caused
**                crashes on the alpha-testers systems
**                Main tester: Xavier Messersmith
**
** 01-01-28 rri - pooled-allocations use CloneStr() and PoolFreeVec()
**
** 2.5b13
**
** 01-09-09 rri - localisation: 'AddMenuCmd' - msgReqAddMenu
** 
**
*/

#include "DM.h"

extern struct GfxBase *GfxBase;
extern struct IntuitionBase *IntuitionBase;
extern struct Library *GadToolsBase;
extern struct Screen *Screen;
extern struct DirWindow *DirWin[];

extern int  Abort;

extern UBYTE sbuff[],ActionBuf[];
extern UWORD Pens20[]; /* new! 2.2b14 */
extern ULONG g_memattrs; /* 2.5b10 rri */

struct Menu *DMMenu=NULL; /* 2.5b10 rri */

APTR Vi;
APTR MenuPool = NULL; /* 2.5b10 rri */



struct Menu * AddMenu(UBYTE *name)
{
struct Menu *menu, *mptr = DMMenu;
LONG result;

struct NewMenu nm[2] =
 {
  { NM_TITLE, NULL, NULL, 0, 0, NULL },
  { NM_END,   NULL, NULL, 0, 0, NULL }
 };

name = SkipWhite(name);

result = NULL; /* 2.5b10 rri */
menu = NULL; /* 2.5b10 rri */

while(mptr != NULL)
 {
  if(Stricmp(name, mptr->MenuName) == 0) /* 2.5b7 rri */
   {
    return(mptr);
   }
  mptr = mptr->NextMenu;
 }

mptr = DMMenu;

if (nm[0].nm_Label = CloneStr(name, MenuPool)) /* 2.5b10 rri */
 {
  menu = CreateMenus(nm,GTMN_FrontPen,Pens20[BARDETAILPEN],TAG_DONE);

  if(menu != NULL)
   {
    if(DMMenu != NULL)
     {
      while(mptr->NextMenu != NULL) /* add menu to end of list or... */
       {
        mptr = mptr->NextMenu;
       }
      mptr->NextMenu = menu;
     }
    else
     {
      DMMenu = menu; /* set it as first item */
     }

    if(Vi == NULL)
     {
      Vi = GetVisualInfoA(Screen, NULL);
     }

    if(Vi != NULL)
     {
      result = LayoutMenus(DMMenu, Vi, GTMN_NewLookMenus, TRUE,TAG_DONE);
     }

    if (!result)
     {
      FreeMenus(menu);
      menu = NULL;
     }

   }
  if(menu == NULL || !result)
   {
    PoolFreeVec(nm[0].nm_Label); /* 2.5b10 rri */
   }
 }
return(menu);
}


VOID AddMenuItem(struct Menu *menu,UBYTE *name,UBYTE key,UBYTE *cmd) /* 2.5b10 rri */
{
struct NewMenu nm[2] =
 {
  { NM_ITEM,  NULL, NULL, 0, 0, NULL },
  { NM_END,   NULL, NULL, 0, 0, NULL }
 };
struct MenuItem *m;
struct MenuItem *mptr;
STRPTR cmdptr;
LONG len = 0;
LONG result;

result = NULL; /* 2.5b10 rri */

if(Stricmp(name, "BARLABEL") == 0) /* 2.5b7 rri */
 {
  nm[0].nm_Label    = NM_BARLABEL;   /* BARLABELs supported new in */
  nm[0].nm_UserData = NM_BARLABEL;
 }
else
 {
  if (nm[0].nm_Label = CloneStr(name, MenuPool)) /* 2.5b10 rri */
   {
    if(key)
     {
      nm[0].nm_CommKey = &key;
     }

    cmd = SkipWhite(cmd);
    cmdptr = cmd;
    while(*cmdptr > 10)
     {
      cmdptr++;
      len++;
     }

    nm[0].nm_UserData = AsmAllocPooled(MenuPool,len+1,SysBase); /* 2.5b10 rri */
    if(nm[0].nm_UserData != NULL)
     {
      strncpy((STRPTR) nm[0].nm_UserData, cmd, (size_t) len); /* 2.5b10 rri */
     }
    else
     {
      PoolFreeVec(nm[0].nm_Label); /* 2.5b10 rri */
      nm[0].nm_Label = NULL;
     }
   }
 }

if(nm[0].nm_Label != NULL)
 {
  m = (struct MenuItem *) CreateMenus(nm,
       GTMN_FrontPen, Pens20[BARDETAILPEN], /* 2.5b7 rri */
       TAG_DONE);
  if(m != NULL)
   {
    if(menu->FirstItem != NULL)
     {
      mptr = menu->FirstItem;
      while(mptr->NextItem)
       {
        mptr = mptr->NextItem;
       }
      mptr->NextItem = m;
     }
    else
     {
      menu->FirstItem = m;
     }

    if(Vi == NULL)
     {
      Vi = GetVisualInfoA(Screen, NULL);
     }

    if(Vi != NULL)
     {
      result = LayoutMenuItems(menu->FirstItem,   Vi,
                               GTMN_Menu,         menu,
                               GTMN_NewLookMenus, TRUE,
                               TAG_DONE);
     }
    if(!result)
     {
      FreeMenus((struct Menu *) m);
     }
   }
  if(m == NULL || !result)
   {
    if(nm[0].nm_Label != NM_BARLABEL)
     {
      PoolFreeVec(nm[0].nm_Label); /* 2.5b10 rri */
      AsmFreePooled(MenuPool,nm[0].nm_UserData,len+1,SysBase); /* 2.5b10 rri */
     }
   }
 }
}


VOID menu_on(VOID)
{
int i;

if(DMMenu != NULL)
 {
  for(i=0;i<255;i++)
   {
    if(DirWin[i] != NULL)
     {
      SetMenuStrip(DirWin[i]->Window,DMMenu);
     }
   }
 }
}


VOID menu_off(VOID)
{
int i;

for(i=0;i<255;i++)
 {
  if(DirWin[i] != NULL)
   {
    ClearMenuStrip(DirWin[i]->Window);
   }
 }
}


VOID AddMenuCmd(UBYTE *buf) /* 2.5b10 rri */
{
struct Menu *menu;
UBYTE *ptr,k;

if(!MenuPool) /* 2.5b10 rri */
 {
  if(!(MenuPool=AsmCreatePool(g_memattrs,25600,256,SysBase))) /* 2.5b10 rri */
   {
    return;
   }
 }

if(!buf || *buf == 0)
 {
  buf = ActionBuf;
  *buf = 0;
  if(!DMReqTagList(msgReqAddMenu, buf, 256, 0))  /* 2.5b13 rri */
   {
    return;
   }
 }

menu_off();

ptr = sbuff;

while(*buf && *buf != 10 && *buf != ',')
 {
  *ptr++=(*buf++); /* get the name of the menu */ /* 2.5b10 rri */
 }

*ptr = 0;

if(menu = AddMenu(sbuff)) /* continue if menue could be created */
 {
  if(*buf==',') /* continue if it wasn`t the end of the line */
   {
    ptr = sbuff;
    buf++; /* skip "," */

    if(*buf == ' ')
     {
      buf++; /* skip first space in item-name */
     }

    while( *buf && *buf != 10 && *buf != ',')
     {
      *ptr++ = *buf++; /* get the name of the menu-item */
     }

    if(*buf == ',')
     {
      *ptr = 0;
      buf++; /* skip "," */
      k = 0;
      buf = SkipWhite(buf);

      if(*buf && buf[1] == ',') /* buffer valid & argument only 1 char? */
       {
        k = (*buf); /* yes, so this must be a key to press...strange... */ /* 2.5b10 rri */
        buf += 2; /* skip menu shortcut argument */
            /* bug: "test, test, a , " won`t work... */
       }

      buf = SkipWhite(buf);

      if(*buf)
       { /* still not reached the end of the line? */
        AddMenuItem(menu, sbuff, k, buf); /* so take all the rest as menu-command */
       }
     }
   }
 }
menu_on();
}


VOID MyFreeMenus(VOID) /* 2.5b10 rri */
{
struct Menu *mptr,*mptr2;
struct MenuItem *mptr3,*mptr4;

/* this goes down the whole menu-structure freeing each entry individually */

for(mptr = DMMenu; mptr;mptr=mptr2)
 {
  for(mptr3 = mptr->FirstItem;mptr3;mptr3 = mptr4)
   {
    mptr4 = mptr3->NextItem;
    FreeMenus((struct Menu*) mptr3);
   }
  mptr2 = mptr->NextMenu;
  FreeMenus(mptr);
 }

DMMenu = NULL;

if(Vi)
 {
  FreeVisualInfo(Vi);
  Vi = NULL;
 }

if(MenuPool)
 {
  AsmDeletePool(MenuPool,SysBase);
  MenuPool=NULL;
 }
}
