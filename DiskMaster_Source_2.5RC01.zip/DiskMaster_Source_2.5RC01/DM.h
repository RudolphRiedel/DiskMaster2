/* DiskMaster II global definition Module
**
** 00-06-25 rri - replaced all c++ style comments by ANSI ones
**              - added <Dos/notify.h>
**              - added "struct NotifiRequest" and "int Notified"
**                to "struct DirWindow"
**
** 00-06-28 jjt - Added IFFParse includes.
**              - Added DMPack.c's NewXFile().
**              - Added DMClipboard.c's CBRead() & CBWrite().
**              - New prototype for DMRequester.c's EasyReq().
**              - Removed CreateBuffer(), DeleteBuffer(), LhEncode(), & LhDecode()
**                prototypes in DMAsm.a.  Since 2.5b6, these funcs no longer exist.
**
** 00-07-01 rri - removed Devi[32] from struct DirWindow
**
** 00-07-03 jjt - Added CMD_Choose() to DMRequester.c
**              - Removed old, commented-out EasyReq() prototype (DMRequester.c).
**
** 00-07-04 jjt - Removed DMClipboard.c.
**
** 00-07-08 rri - added DMSupport.c
**
** 00-07-07 jjt - Moved GetActionArg() & IsDir() to DMSupport.c.
**              - Added dataisbin flag to the XFile structure.
**
** 00-07-10 rri - removed MyStrUpper(), MyToUpper(), AutoMatch() from DMAsm.a
**
** 00-07-11 rri - added Iconify() to DMConfig.c
**              - modified the headers for SaveConfig`s sub-routines
**
** 00-07-12 rri - moved SkipWhite(), AArg2Str(), Display(), QuoteCar(),
**                NeedQuote() from DMCommand.c to DMSupport.c
**              - removed MTInit(), MTEnd() and CheckDWs()
**                from DMCommand.c for not existing
**
** 00-07-13 rri - replaced DMMatch from DMAsm.a by a C equivalent in DMSupport.c
**              - removed StampTime() and StampDate from DMAsm.c
**
** 00-07-20 rri - removed the "const" atributes from the compare-functions
**                of DMSort.c to get rid of some meaningless warnings
**
** 00-08-04 rri - added prototype for DMSet() to DMCommand.c
**
** 00-08-08 rri - added RefreshWindows() to DMSupport.c
**              - Expanded the string in struct BaseConvert to 15 chars
**
** 00-08-17 rri - replaced StampPort() from DMAsm.a by a C equicalent
**                in DMSupport.c
**
** 00-08-18 rri - added FilterStar() to DMSupport.c
**
** 00-08-25 jjt - Added <Exec/tasks.h>.
**
** 00-08-27 rri - moved GetGlobuff() / FreeGlobuff() from DMDisk.c to
**                DMSupport.c and change GetGlobuff() to (void)
**
** 00-08-29 rri - added FindCmdWin() to DMSupport.c
**
** 00-10-12 rri - added PrintDir() to DMDisk.c
**
** 2.5b9
**
** 00-11-07 rri - added MainLoop() to DM.c
**
** 00-11-08 rri - removed DOSCD() from DMCommand.c
**
** 2.5b10
**
** 00-11-26 rri - moved DOSParse() from DMCommand.c to DMSupport.c
**              - moved DMSetDate() from DMCommand.c to DMDisk.c
**
** 00-11-26 jjt - added StrReq() to DMRequester.c
**
** 00-12-01 rri - splitted DMCommand.c into DMParser.c and DMCommands.c
**
** 00-12-02 jjt - Added CloneStr() prototype to DMRead.c
**
** 00-12-03 jjt - FreeXFile() now typed as void.
**
** 00-12-05 rri - fixed prototype for DoPalette()
**
** 00-12-13 jjt - Added STRHIST_MAX - Maximum number of strings to cache.
**              - Added StringHistory & StringData structs.
**              - DMReq.c - Added prototypes for:  StrData_New(),
**                StrHist_Init(), StrHist_Clear(), StrHist_Add(), & StringHook();
**
**              - Removed StringData struct, & StrData_New().
**              - Commented-out StringHistory's semaphore.
**
** 00-12-19 rri - corrected Prototypes in DMSort.c
**              - added "#include <Hardware/intbits.h>" to name the IRQ in use
**              - added "#define __USE_SYSBASE"
**              - added "#include <Exec/ExecBase.h>"
**              - moved StartTimer() from DMAsm.a to DM.c
**              - moved TimerCode() from DMAsm.a to DM.c
**              - finally removed DMAsm.a from source-tree
**
** 00-12-23 rri - changed the function-header for TimerCode()
**
** 00-12-23 jjt - Removed old DMReq() & EasyReq()
**              - StrReq() new prototype & renamed to DMReqTagList().
**              - Added DMREQ_... tags.
**              - Added MakeBtnString() (DMReq.c).
**
** 00-12-26 rri - corrected prototype for DMOpenScreen()
**              - changed var in GetCmdFile() from int to LONG
**
** 00-12-28 rri - changed struct DirList and struct DirWindow
**              - changed a few function-headers in DMWin.c
**              - changed a few function-headers in DMSort.c
**
** 00-12-29 jjt - Changed XFile & StringHistory structures to use (U)LONGs where possible.
**
** 01-01-03 rri - added memory-pool function prototypes
**
** 01-01-08 rri - added UBYTE *name2 to struct DirList as first step
**
** 01-01-09 jjt - Changed CloneStr() prototype - It now takes a ptr to mempool.
**                Use PoolFreeVec() to free the returned string.
**              - Added PoolAllocVec() & PoolFreeVec() prototypes.
**              - Added mempool field to StringHistory.
**              - Removed StrHist_Clear().
**
** 01-01-10 rri - added AllocComment() / AllocName() to DMWin.c
**
** 01-01-11 rri - removed name[66] from struct DirList
**
** 01-01-12 jjt - Moved PoolAllocVec(), PoolFreeVec(), & CloneStr() from DMRead.c to DMSupport.c
**
** 01-01-28 rri - changed struct dirlist, only *name remains now
**
** 01-02-05 rri - added menu_on() prototype to DMMenu.c
**
** 01-02-18 rri - moved FindDMWin(), SetTitles() and FreeUserJunk() from
**                DM.c to DMSupport.c and added BootBatch() to DMSupport.c
**
** 2.5b11
**
** 01-04-13 jjt - Added RXCMD_GetHistory() prototype to DMRexx.c.
**
** 01-04-22 jjt - Added Char2Nibble() prototype to DMSupport.c.
**
** 2.5b12
**
** 01-07-27 rri - added AllocPens() to DMPalette.c
**
** 01-07-27 jjt - Added - SHOWDEV_... flags.
**                      - CMD_DevList() prototype to DMCommands.c.
**
** 01-07-29 jjt - Added - DEVHIDELST_MAX.
**                      - CMD_HideDev() prototype to DMCommands.c.
**
** 01-08-01 jjt - Added RefreshDevLists() prototype to DMSupport.c.
**
** 2.5b13
**
** 01-08-06 jjt - Added REQ_FileExists() prototype to DMReq.c.
**
** 01-08-07 jjt - Changed DMCopy() prototype from void to ULONG.
**
** 01-08-11 rri - moved DoWindow() from DM.c to DMWindows.c
**              - moved several functions from DMWindows.c to
**                newly created DMWinContent.c
**
** 01-08-24 jjt - Changed REQ_FileExists() prototype (removed "fname" arg).
**
** 01-09-08 rri - added '#include "DM2_cat.h"'�for localisation
**
** 01-09-08 jjt - Changed prototypes for: DMReq() & DMReqTagList() (in DMReq.c) and
**                DOSParse() & CloneStr() (in DMSupport.c) to remove #104 warnings.
**
** 01-09-10 rri - modified prototype MakeBtnString()
**
** 01-09-15 rri - moved and renamed the include for locale
**
** 01-09-16 rri - added WORD zoom[4] and norm[4] to struct DirWindow
**
** 01-09-18 rri - changed prototype for MakeBtnString()
**
** 01-10-18 rri - added "int opt" to DMCopy() to prevent irritating messages
**
** 01-10-20 rri - added prototype for CheckMonth() to DMSupport.c
**
** 01-10-29 rri - removed DMMove() from DMDisk.c
**
*/

#define INTUI_V36_NAMES_ONLY 1

#define __USE_SYSBASE /* 2.5b10 rri */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>     /* 2.5b5 jjt - Reader uses min() & max(). */
#include <Exec/ExecBase.h> /* 2.5b10 rri */
#include <Exec/Types.h>
#include <Exec/Memory.h>
#include <Exec/Interrupts.h>
#include <Hardware/intbits.h> /* 2.5b10 rri */
#include <Exec/ports.h>          /* 2.5b5 jjt */
#include <Exec/tasks.h>          /* 2.5b8 jjt */
#include <devices/inputevent.h>  /* 2.5b5 jjt */
#include <Intuition/IntuitionBase.h>
#include <intuition/intuition.h> /* 2.5b5 jjt */
#include <intuition/gadgetclass.h> /* 2.5b5 jjt */
#include <intuition/imageclass.h>  /* 2.5b5 jjt */
#include <intuition/icclass.h>     /* 2.5b5 jjt */
#include <intuition/screens.h>   /* 2.5b5 */
#include <Intuition/sghooks.h>
#include <Dos/Dos.h>             /* 2.5b5 jjt */
#include <Dos/DateTime.h>
#include <Dos/DosExtens.h>
#include <Dos/DosTags.h>
#include <Dos/FileHandler.h>
#include <Dos/ExAll.h>
#include <Dos/notify.h> /* 2.5b7 rri */
#include <Graphics/GfxBase.h>
#include <graphics/gfxmacros.h>  /* 2.5b5 jjt */
#include <graphics/rastport.h>   /* 2.5b5 jjt */
#include <Graphics/Text.h>
#include <Graphics/DisplayInfo.h> /* new! 2.2b11 */
#include <WorkBench/Startup.h>
#include <Rexx/rxslib.h>         /* 2.5b5 jjt */
#include <Rexx/Storage.h>
#include <workbench/workbench.h>
#include <libraries/gadtools.h>
#include <libraries/iffparse.h> /* 2.5b7 jjt (24.06.00) */
#include <libraries/reqtools.h> /*new! 2.2b10 */
#include <libraries/asl.h> /* new! 2.2b11 */
#include <libraries/amigaguide.h> /* new! 2.4 */
#include <libraries/xfdmaster.h>  /* 2.5b6 jjt */
#include <utility/tagitem.h>     /* 2.5b5 jjt */
#include <xpk/xpk.h>             /* 2.5b6 jjt */

#include <clib/alib_protos.h>    /* 2.2b5 jjt / hys */
#include <clib/RexxSysLib_protos.h>     /* 2.5b5 hys */
#include <Proto/Icon.h>
#include <Proto/Exec.h>
#include <Proto/Dos.h>
#include <Proto/Intuition.h>
#include <Proto/Graphics.h>
#include <Proto/RexxSysLib.h>
#include <Proto/DiskFont.h>
#include <Proto/GadTools.h>
#include <Proto/iffparse.h> /* 2.5b7 jjt (24.06.00) */
#include <proto/reqtools.h> /*new! 2.2b10 */
#include <proto/asl.h> /* new! 2.2b11 */
#include <proto/amigaguide.h> /* new! 2.4 */
#include <proto/wb.h> /* new! 2.4 */
#include <proto/utility.h>  /* 2.5b5 jjt */
#include <proto/xfdmaster.h> /* 2.5b6 jjt */
#include <proto/xpkmaster.h> /* 2.5b6 jjt */

#include "DMLocale.h" /* 2.5b13 rri */

#define sFIB struct FileInfoBlock

#define ACTION(rmp) (rmp->rm_Action)
#define RESULT1(rmp) (rmp->rm_Result1)
#define RESULT2(rmp) (rmp->rm_Result2)

#define DWFLAG_RESORT 1
#define DWFLAG_ADD 2
#define DW_CMD (1<<2)
#define DWFLAG_RELOAD (1<<3)
#define DW_SOURCE (1<<4)
#define DW_DEST (1<<5)

#define RECURSE_DEL   1
#define RECURSE_COPY  2
#define RECURSE_MOVE  3
#define RECURSE_PROT  (1<<2)
#define RECURSE_REN   (1<<3)
#define RECURSE_EXEC  (1<<4)
#define RECURSE_FIND  (1<<5)
#define RECURSE_NOTE  (1<<6)
#define RECURSE_SHOW  (1<<7) /* new! 2.2b12 2.4 */
#define RECURSE_READ  (1<<8)
#define RECURSE_AUTO  (1<<9)
#define RECURSE_REXX  (1<<10)
#define RECURSE_DATE  (1<<11)
/* 2.5b5 rri
#define RECURSE_PRINT (1<<12)
*/
#define RECURSE_CHECK (1<<13)
#define RECURSE_PACK  (1<<14)

/* --- ActionArg Types, passed to GetActionArg() --- */
#define AATYPE_BOOL    1   /* 2.5b5 jjt */
#define AATYPE_STR     2   /* 2.5b5 jjt */
#define AATYPE_NUM     3   /* 2.5b5 jjt */
#define AATYPE_NEXTSTR 4   /* 2.5b6 jjt */

#define STRHIST_MAX 15   /* 2.5b10 jjt */

/* --- Requester Tags (StrReq() & EasyReq()) ---  2.5b10 jjt */
/* (Explained in DMReqTagList() in DMRequester.c )           */
#define DMREQ_TITLE      0x90000001
#define DMREQ_BUTTONS    0x90000002
#define DMREQ_ABORT      0x90000003
#define DMREQ_SCREEN     0x90000004
#define DMREQ_HISTORY    0x90000005

/* --- Flags to filter Device List's Display --- */  /* 2.5b12 jjt */
#define SHOWDEV_DEV  1
#define SHOWDEV_VOL  2
#define SHOWDEV_ASN  4
#define SHOWDEV_ALL  7

#define DEVHIDELIST_MAX 100  /* 2.5b12 jjt */

struct BaseConvert /* new! 2.5b4 */
 {
  LONG  DiskFree,BytesPerBlock,BlocksFree;
  UBYTE String[15]; /* 2.5b7 rri */
 };


struct DirList /* 2.5b10 rri */
 {
  struct DateStamp ds;
  LONG attr,
       dir,
       sel,
       size;
  UBYTE *name, /* 2.5b10 rri */
        *cmt;
};


struct DirWindow /* 2.5b10 rri */
 {
  struct DateStamp PathDate;
  struct DirList **DirList;
  struct FileInfoBlock *Fib;
  struct Gadget dir_gad,v_gad,h_gad,up,dn,lf,rt,parent;
  struct Image v_img,h_img;
  struct NotifyRequest DM2NotifyReq;
  struct PropInfo v_prop,h_prop;
  struct StringInfo dir_str;
  struct StringExtend SExt;
  struct Window *Window;
  LONG   BlocksFree,
         BytesPerBlock,
         ColsCmt,
         ColsName,
         DiskFree,
         Edge,
         FileCount,
         Flags,
         Index,
         MaxFile,
         Notified,
         Rows,
         Sels,
         Sorting;
  UBYTE  *Ptr,Path[516],Title[60],Pattern[32];
  BPTR   DirLock;
  WORD   zoom[4]; /* 2.5b13 rri */
  WORD   norm[4]; /* 2.5b13 rri */
 };


struct XFile {  /* 2.5b6 jjt */
  /* Returned by AutoUnpack.  Use FreeXFile() to dispose. */
  UBYTE                *data;      /* Data buffer */
  ULONG                 len;       /* Amount of data in buffer */
  ULONG                 buflen;    /* Total size of buffer */
  struct xfdBufferInfo *xinfo;     /* May be NULL if XFD lib doesn't exist */
  LONG                  dataisbin; /* TRUE if there's a 0 in the 1st 512 bytes of .data */ /* 2.5b7 jjt (7.7.00) */
};


struct StringHistory {  /* 2.5b10 jjt */
/*   struct SignalSemaphore sema4; */
  APTR                   mempool;
  UBYTE                  *strcache[STRHIST_MAX];
  UWORD                  lencache[STRHIST_MAX];
  ULONG                  total;
  ULONG                  cachepos;
};


/* Prototypes for usage of amiga.lib`s memory-pool functions : */ /* 2.5b10 rri */

void * __asm AsmAllocPooled(register __a0 void *,
                            register __d0 ULONG,
                            register __a6 struct ExecBase *);
void * __asm AsmCreatePool(register __d0 ULONG,
                           register __d1 ULONG,
                           register __d2 ULONG,
                           register __a6 struct ExecBase *);
void __asm AsmDeletePool(register __a0 void *,
                         register __a6 struct ExecBase *);

void __asm AsmFreePooled(register __a0 void *,
                         register __a1 void *,
                         register __d0 ULONG,
                         register __a6 struct ExecBase *);


/* DM.c */

BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver); /* 2.5b6 jjt */
void MainLoop(void); /* 2.5b9 rri */
void StartTimer(int itime); /* 2.5b10 rri */
int __interrupt __saveds TimerCode(void); /* 2.5b10 rri */


/* DMCommands.c */

void DoStdio(UBYTE *str);
void GetParent(UBYTE *path,int parent); /* 2.5b6 rri */
void DMReqPat(void);
void DoSwap(void);
int  UnLockAll(void);
void ResetFlags(void);
void GetCmdFile(struct DirWindow *dw,UBYTE *name,LONG size); /* 2.5b10 rri */
void AutoFiler(struct DirWindow *dw,UBYTE *name);
void EditCmd(struct DirWindow *dw,int ni);
void FreeAutoCmds(void);
void ParseCmd1(struct DirList *dlp,UBYTE *buf);
void DMSet(void); /* 2.5b7 rri */
void CMD_DevList(void);  /* 2.5b12 jjt */
void CMD_HideDev(void);  /* 2.5b12 jjt */
/* new! 2.2b14
void MultiSelect(int i);
void SingleName(int i);
*/


/* DMConfig.c */

void SaveConfig(void);
void SaveMenus(UBYTE *savebuffer);
void SaveScreen(UBYTE *savebuffer);
void SaveWindows(UBYTE *savebuffer);
void SaveWin(struct DirWindow *dw,UBYTE *savebuffer);
void Iconify(void); /* 2.5b7 rri */


/* DMDisk.c */

int  DMRelabel(UBYTE *dev,UBYTE *name,UBYTE *new);
void DMRename(UBYTE *old);
void SmartRename(UBYTE *old,UBYTE *new);
void DMComment(UBYTE *name,UBYTE *str,sFIB *fib);
void DMProtect(UBYTE *name,UBYTE *str,sFIB *fib);
void DMSetFileDate(UBYTE *dir,sFIB *fib);
void SmartRemEntry(UBYTE *name);
void SmartAddEntry(UBYTE *name);
ULONG DMCopy(UBYTE *s,UBYTE *dest,sFIB *fib, int opt); /* 2.5b13 rri */
void DMMakeDir(UBYTE *name);
void MakeIcon(UBYTE *name);
void Dupe(void); /* new! 2.3 */
void SwapSelect(void); /* new! 2.4 */
void DMOpenFont(UBYTE *str,int size); /* new! 2.4 */
void View(UBYTE *file); /* new! 2.4 */
void InfoReq(UBYTE *file); /* new! 2.4 */
void DOSExecute(void);
void DOSStart(int StackSize); /* new! 2.4b15 */
void CheckSpace(void); /* new! 2.5b4 */
void PrintDir(void); /* 2.5b9 rri */
void DMSetDate(void);


/* DMKey.c  new! 2.4b18 */

void AddKeyCmd(UBYTE *str);
void DoKeyCmd(struct DirWindow *dw,UWORD code,UWORD qual,ULONG class); /* new! 2.4b18 */
int  CheckAbortKey(void);
void FreeKeyCmds(void);


/* DMMenus.c */

void AddMenuCmd(UBYTE *);
VOID menu_on(VOID); /* 2.5b10 rri */
void MyFreeMenus(void);


/* DMPack.c */

void           DMPack(UBYTE *name, sFIB *fib, int comp);  /* 2.5b6 jjt */
struct XFile * AutoUnpack(UBYTE *name);      /* 2.5b6 jjt */
struct XFile * NewXFile(void);               /* 2.5b7 jjt */
void           FreeXFile(struct XFile *xf);  /* 2.5b6 jjt */


/* DMPalette.c */

void SetColors(void);
void SetPens(void);
void DoPalette(UWORD code,WORD x,WORD y,ULONG class); /* 2.5b10 rri */
void OpenPalette(void);
void AllocPens(void); /* 2.5b12 rri */


/* DMParser.c */

void AddAutoCmd(UBYTE *str);
void DMArchive(UBYTE *cmd,UBYTE *name);
void DMSetFormat(UBYTE *str,UBYTE *fbuf,int length);
void DMSelect(int sel);
void RefreshCmdWin(struct DirWindow *dw);

void MakeFullName(UBYTE *buf,struct DirWindow *dw,UBYTE *name);
void StartRec(int type); /* new! 2.5b4 */
UBYTE *MakeDestName(UBYTE *s,UBYTE *d);
int  DMRecurse(int lenS,int lenD,int opt);
int  addname(UBYTE *path,UBYTE *name,int len);
void AddCmd(struct DirWindow *dw,UBYTE *buf);
UBYTE *ParseArgs(UBYTE *buf,struct DirWindow *dw);
void ActionCmd(struct DirWindow *dw,UBYTE *buf);


/* DMRead.c */

void   DMRead(UBYTE *file);  /* 2.5b5 jjt */
void   CloseRead(void);


/* DMRequester.c */

void Busy(int i); /* 2.5b7 rri */
void CMD_Choose(void);  /* 2.5b7 jjt (3.7.00) */
LONG REQ_FileExists(sFIB *srcfib, sFIB *destfib);  /* 2.5b13 jjt */
void About(void);
LONG DMReq(CONST_STRPTR body, STRPTR dest, ULONG cmax, ULONG tags, ...);  /* 2.5b10 jjt */
LONG DMReqTagList(CONST_STRPTR body, STRPTR dest, ULONG cmax, struct TagItem *tags);  /* 2.5b10 jjt */
void MakeBtnString(const UBYTE yes[], const UBYTE middle[], const UBYTE no[]); /* 2.5b13 rri */
void StrHist_Init(struct StringHistory *sh);   /* 2.5b10 jjt */
/*void StrHist_Clear(struct StringHistory *sh);*/  /* 2.5b10 jjt */
void StrHist_Add(struct StringHistory *sh, STRPTR str);  /* 2.5b10 jjt */
ULONG __asm StringHook(register __a0 struct Hook *hk, register __a2 struct SGWork *swork, register __a1 ULONG *msg);  /* 2.5b10 jjt */


/* DMRexx.c  new! 2.2b15 */

int  do_rexx_cmd(struct RexxMsg *rm);
struct RexxMsg *MakeRexxMsg(void);
void SendRexx(void);
void doDirList(void); /* new! 2.4 - set to (void) */
void doSetList(UBYTE *var);
void RexxStatus(void); /* new! 2.4 */
int  GetID(void); /* new! 2.4 */
void Filestat(void); /* 2.5b5 rri */
void WinInfo(void); /* 2.5b5 rri */
void RXCMD_GetHistory(void);  /* 2.5b11 jjt */


/* DMScreen.c new! 2.2b13 */

int  CheckScreen(void); /* new! 2.2b13 */
void GetHostScreen(UBYTE *str);
void GetDRI(struct Screen *s);
void InitScreenDefaults(void);
void ParseScreenArgs(); /* 2.5b6 rri - set to (void) */
struct Screen *NewOpenScreen(int n,UBYTE *); /* new! 2.2b12 */

/* 2.5b6 rri
struct Screen *ReadOpenScreen(int n,UBYTE *);
*/

struct Screen *DMOpenScreen(ULONG Width,ULONG Height,ULONG ID,UWORD Depth,UBYTE *name); /* 2,5b10 rri */


/* DMSort.c  new! 2.2b15 */

void DMSortN(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortS(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortD(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
void DMSortC(struct DirList **dl,ULONG count,LONG direction); /* 2.5b10 rri */
int  cmpnameU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpnameD(struct DirList **val1,struct DirList **val2);
int  cmpsizeU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpsizeD(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpdateU(struct DirList **val1,struct DirList **val2); /* 25.08.97 dGN! */
int  cmpdateD(struct DirList **val1,struct DirList **val2);
int  cmpcmtU(struct DirList **val1,struct DirList **val2); /* new! 2.2b15 */
int  cmpcmtD(struct DirList **val1,struct DirList **val2); /* new! 2.2b15 */
void Sort(void); /* new! 2.3 */
void GlobalSort(void); /* new! 2.3 */
void SetSortFlag(struct DirWindow *dw, int c); /* new! 2.3 */
void DMSort(struct DirWindow *dw);
void ReSort(void);
void ResortAll(void);


/* DMSupport.c */

void StrToUpper(UBYTE *str); /* 2.5b7 rri */
LONG GetActionArg(STRPTR keyword, UBYTE type, LONG def); /* 2.5b5 jjt */
BOOL IsDir(STRPTR name); /* 2.5b6 jjt */
UBYTE *SkipWhite(UBYTE *ptr);
BOOL AArg2Str(STRPTR keyword, STRPTR dest, int length, BOOL upper, STRPTR def); /* 2.5b6 jjt */
void display(const UBYTE format[],UBYTE *arg1); /* 2.5b13 rri */
void QuoteCat(UBYTE *ptr,UBYTE *name);
int  NeedQuote(UBYTE *ptr);
int  DMMatch(UBYTE *string,UBYTE *pattern); /* 2.5b7 rri */
void RefreshWindows(void); /* 2.5b7 rri */
void StampProt(UBYTE *str,LONG prot);
void FilterStar(UBYTE *pattern); /* 2.5b7 rri */
int  GetGlobuff(void); /* 2.5b7 rri */
void FreeGlobuff(void);
void FindCmdWin(void); /* 2.5b7 rri */
int  DOSParse(UBYTE *str,const UBYTE *hail,int i);
APTR   PoolAllocVec(APTR mempool, ULONG size); /* 2.5b10 jjt */
void   PoolFreeVec(APTR memptr);               /* 2.5b10 jjt */
STRPTR CloneStr(CONST_STRPTR str, APTR mempool);     /* 2.5b10 jjt */
void FreeUserJunk(void); /* 2.5b10 rri */
void SetTitles(void); /* 2.5b10 rri */
struct DirWindow *FindDMWin(struct Window *win); /* 2.5b10 rri */
int BootBatch(UBYTE *ptr); /* 2.5b10 rri */
ULONG Char2Nibble(ULONG c);  /* 2.5b11 jjt */
void RefreshDevLists(void);  /* 2.5b12 jjt */
int  FindPattern(UBYTE *str);
void Separate(struct DirWindow *dw);
void CheckMonth(void); /* 2.5b13 rri */


/* DMWinContent.c */ /* 2.5b13 rri */

void ConvertBase(struct BaseConvert *basecon);
void ReSize(struct DirWindow *dw);
void MainTitle(void);
void WinTitle(struct DirWindow *dw);
void DoFileFormat(struct DirList *dlp,LONG colsN,LONG colsC,LONG blocksize); /* 2.5b10 rri */
void GetDevList(struct DirWindow *dw);
void InitDir(struct DirWindow *dw,int set);
void GetDirEntry(struct DirWindow *dw);
void Fib2Dlp(struct DirList *dlp,sFIB *fib);
int  AllocDlp(struct DirWindow *dw);
int  GetNewPath(struct DirWindow *dw);
int  DiskShadow(struct DirWindow *dw,sFIB *fib);
void FreeDirTable(struct DirWindow *dw);


/* DMWindows.c */

void DoWindow(void);
void SetHoriz(struct DirWindow *dw);
void SetVert(struct DirWindow *dw);
void dis_name(struct DirWindow *dw,LONG file,LONG pos);
void rdis_files(struct DirWindow *dw);
void dis_files(struct DirWindow *dw);
void Increment(struct DirWindow *dw,struct Gadget *gad,LONG lines); /* 2.5b10 rri */
void HorSlide(struct DirWindow *dw,struct Gadget *gad,LONG lines); /* 2.5b10 rri */
void ShowDirection(struct DirWindow *dw,int n);
void NewSize(struct DirWindow *dw);
void slide_em(struct DirWindow *dw,struct Gadget *gad);
void sel_file(struct DirWindow *dw,int my);
void FindNewDirection(struct DirWindow *dw);
void CloseDirWindow(int num);
int  OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi);
struct Window *OpenSharedWindow(struct NewWindow *nw);
void CloseSharedWindow(struct Window *w);
void RefreshGadget(struct Gadget *,struct Window *);
int  GZZWidth(struct DirWindow *dw);
