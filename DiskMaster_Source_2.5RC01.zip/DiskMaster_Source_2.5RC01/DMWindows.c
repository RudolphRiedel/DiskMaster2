/* DiskMaster II  Windows module  open/close/scroll/select/dislpay
**
** 00-06-12 rri - fixed a bug with Expand on/off that crashed when
** using 'TitleFormat' in a special order of arguments on CD`s.
** Reported by Nils Goers.
**
** 00-06-12 rri - forgot to also move a corresponding UnLock()
**
** 00-06-24 rri - replaced annother "int lock;" by "BPTR lock;"
**              - replaced all c++ style comments by ANSI ones
**              - reduced "Disk not present" system requesters from
**                three to one by better structure of the code in question
**              - fixed a window-not-beeing-updated bug by placing
**                WinTitle(CDWin); in sel_file()
**
** 00-06-25 rri - added filesystem notification
**
** 00-07-01 rri - removed FindRealDev()
**              - removed Devi[] from struct DirWindow
**              - added a refresh for the string-gadget to GetDevList()
**
** 00-07-08 rri - changed MyStrUpper() calls to new StrToUpper() calls
**              - replaced MyToUpper() calls by ToUpper() (utility.library)
**
** 00-07-13 rri - modified DoFileFormat() to use DateToStr()
**              - modified MainTitle() to not use StampDate() anymore
**              - modified DoFileFormat() to use StampDate only for the weekday
**              - removed weekday from DoFileFormat()
**
** 00-08-04 rri - made the length of the number-strings for ConvertBase() user-adjustable
**
** 00-08-07 rri - changed the type of Base_Str_Len from int to ULONG
**                to be 101% it is 32 bit
**
** 00-08-08 rri - increased the string for the sizes to 11 chars in DoFileFormat()
**
** 00-08-13 rri - Remove a misplaced WinTitle(CDWin) from sel_file()
**                'Check' will display it`s result again.
**                Reported by Richard Mattsson <richard@cloudnet.com>
**              - Added WinTitle(DestWin); in sel_file() to fix
**                a window not beeing updated bug
**
** 00-08-13 rri - rewritten and re-integrate DoExAll()
**
** 00-08-18 rri - added dir-filtering to DoExAll()
**
** 00-08-26 jjt - DoExAll() - Added an extra NULL-check.
**
** 00-08-27 rri - modified DoExAll() to use GetGlobuff()
**
** 2.5b9
**
** 00-09-13 rri - added MOUSEMOVE to NewWin
**              - made slide_em() a bit smarter
**
** 00-09-24 rri - removed busy-loop from slide_em()
**
** 00-10-03 rri - added workaround in DoFileFormat() for french locales
**                reported by Jean Marie Boucher <boucher21@caramail.com>
**
** 00-10-04 rri - fixed annother bug that always has been there...
**                with am empty string-gadget the command-window
**                became an ordinary file-window
**
** 00-11-06 rri - Made filesystem-notification user-selectable by adding
**                a check for the var "Notify" to InitDir
**
** 00-11-11-rri - InitDir() filters out all trailing "/"`s now
**
** 2.5b10
** 00-12-13 jjt - Added extern refs to PathHistory, PathStrData, & EditHook.
**              - Added WorkBuf array.
**              - InitDir() - Path is cached (PathHistory).
**              - OpenDirWindow() - Added the EditHook to dir_gad.
**
**              - Removed all StringData references (PathStrData).
**
** 00-12-19 rri - fixed "PBorder" in a way also StormC compiles it
**              - removed 23 of "warning 220"
**              - removed two of "warning 51"
**              - removed eight if "warning 317"
**
** 00-12-23 jjt - InitDir() - String is only cached for dir windows.
**
** 00-12-26 rri - removed four "warning 164"`s
**              - changed argument in AddTstr() from int to ULONG
**              - added type-casting to three ToUpper() calls
**              - removed 43 "warning 220"`s
**              - replaced three unix-style movmem()`s by ANSI-style memmove()`s
**              - removed four "warning 317"`s
**
** 00-12-28 rri - changed struct DWTemplate to new format
**              - changed a few function headers
**
**
** 01-01-03 rri - added new sub-routine AllocComment() to make transition
**                to memory-pools easier
**              - FreeDirTable() does a FreeMem() for commands
**                and a AsmFreePooled() for real comments now
**              - changed comment-allocation to use memory-pool
**
** 01-01-08 rri - started to make name-buffer pooled and dynamic
**
** 01-01-10 rri - added function AllocName()
**
** 01-01-11 rri - set cleared space DoFileFormat() from 200 chars to 300
**
** 01-01-12 rri - removed three enforcer-hits that were caused by
**                not initialized file-name pointers
**
** 01-01-14 rri - set string-pointers to NULL after AsmFreePooled()
**              - added more sanity-checks for "->name2"
**
** 01-01-19 rri - forgot to close a comment - CacheLoad()
**                displayed no file-comments in a cached dir.
**              - changed format of month in dir-list to numeric format
**
** 01-01-28 rri - introduced CloneStr() / PoolFreeVec() for comments
**              - removed AllocComment()
**              - removed a couple of dead lines
**              - introduced CloneStr() / PoolFreeVec() for names
**              - removed AllocName()
**
** 01-01-28 rri - the summing of dir-sizes took a little too much computrons
**                noticed by Dirk Teunis <parcival@yucom.be>
**
** 01-02-05 rri - added BatchFlag
**              - usage of BatchFlag prevents adding of menus to dir-windows
**                in OpenDirWindow() during startup
**
** 01-02-18 rri - bugfix: clicking into the left window-border caused selection
**                reported by Xavier Messersmith
**
** 2.5b11
**
** 01-03-01 jjt - Changed obsolete Intuition flag names to v36 versions:
**                  BOOLGADGET to GTYP_BOOLGADGET,
**                  PROPGADGET to GTYP_PROPGADGET,
**                  STRGADGET to GTYP_STRGADGET,
**                  GADGIMMEDIATE to GACT_IMMEDIATE,
**                  RELVERIFY to GACT_RELVERIFY,
**                  RIGHTBORDER to GACT_RIGHTBORDER,
**                  BOTTOMBORDER to GACT_BOTTOMBORDER,
**                  GRELRIGHT to GFLG_RELRIGHT,
**                  GRELWIDTH to GFLG_RELWIDTH,
**                  GRELHEIGHT to GFLG_RELHEIGHT,
**                  GRELBOTTOM to GFLG_RELBOTTOM,
**                  GADGHCOMP to GFLG_GADGHCOMP,
**                  GADGH_NONE to GFLG_GADGHNONE,
**                  GADGH_IMAGE to GFLG_GADGHIMAGE,
**                  CLOSEWINDOW to IDCMP_CLOSEWINDOW,
**                  DISKINSERTED to IDCMP_DISKINSERTED,
**                  GADGETDOWN to IDCMP_GADGETDOWN,
**                  GADGETUP to IDCMP_GADGETUP,
**                  MENUPICK to IDCMP_MENUPICK,
**                  MOUSEBUTTONS to IDCMP_MOUSEBUTTONS,
**                  MOUSEMOVE to IDCMP_MOUSEMOVE
**                  NEWSIZE to IDCMP_NEWSIZE,
**                  RAWKEY to IDCMP_RAWKEY,
**                  ACTIVATE to WFLG_ACTIVATE,
**                  WINDOWACTIVE TO WFLG_WINDOWACTIVE,
**                  SMART_REFRESH to WFLG_SMART_REFRESH,
**                  NOCAREREFRESH to WFLG_NOCAREREFRESH,
**                  WINDOWCLOSE to WFLG_CLOSEGADGET
**                  WINDOWDEPTH to WFLG_DEPTHGADGET,
**                  WINDOWDRAG to WFLG_DRAGBAR,
**                  WINDOWSIZING to WFLG_SIZEGADGET,
**                - Commented out "zooming" var.
**
** 01-07-15 rri - Changed ReSize() to display upto and no more than 200gig
**              - dis_name() now swaps the command-button colors instead
**                of just inverting the pen-number
**
** 2.5b12
**
** 01-07-27 rri - dis_name() uses the second pen set for
**                the selected command-buttons now
**
** 01-07-29 rri - introduced DirPen, FilePen, BackPen and SelectPen,
**                these four control the listview-content appearance
**                in dis_name()
**
** 01-07-29 jjt - Added - ShowDev var.
**                      - "extern *DevHide_List[]" & DevHide_Count.
**              - GetDevList() - Added ShowDev tests before calls to GetDevListType() to
**                allow filtering the Device List.
**              - GetDevListType() - Now filters out the names in DevHide_List.
**
** 01-07-30 rri - rewritten GetDevList() nearly from scratch
**                - "replaced" GetDevListType() by QueryDosList()
**                - removed NDevice()
**
** 01-08-01 jjt - Added IDCMP_DISKREMOVED flag to NewWin's default values.
**
** 2.5b13
**
** 01-08-11 rri - moved ConvertBase(), ReSize(), AddTStr(), MainTitle(),
**                WinTitle(), DoFileFormat(), QueryDosList(), GetDevList()
**                GetDirEntry(), InitDir(), DoExAll(), AllocDlp(), GetNewPath()
**                DiskShadow(), CacheLoad(), ExDone(), Fib2Dlp() and
**                FreeDirTable() to a new file called DMWinContent.c
**              - moved FindPattern() and Separate() to DMSupport.c
**              - moved DoWindow() from DM.c
**
** 01-08-26 rri - removed a Delay() from sel_file()
**
** 01-09-11 rri - lowered windows minwidth/minheight from 80/70 to 65/65
**
** 01-09-16 rri - modified OpenDirWindow() to init zoom[] and norm[]
**              - replaced IDCMP_NEWSIZE by IDCMP_CHANGEWINDOW
**              - modified DoWindow() to keep track of zoomed dimensions
**              - hot-clicked window is opened with zoom-attributes
**
** 01-09-22 rri - replaced two stricmp()s in OpenDirWindow() by Stricmp()s
**
** 01-10-14 rri - Bugfix: dis_name() issued two enforcer-hits when a new config
**                was loaded by AutoCmd. Unnoticed since 2.1c at least...
**                Reported by: Richard Mattsson <richard@cloudnet.com>
**
*/


#include "DM.h"

#define GADREL    GACT_IMMEDIATE|GACT_RELVERIFY
#define TOPOFFSET 12

extern struct DateStamp setStamp;
extern struct DirList *DClickDir;
extern struct DirWindow *DirWin[],*CDWin,*DestWin,*CmdWin;
extern struct FileInfoBlock     Fib;
extern struct GfxBase *GfxBase;
extern struct InfoData InfoData;
extern struct IntuitionBase *IntuitionBase;
extern struct Menu *DMMenu;
extern struct MsgPort *WinPort,*NotifyPort; /* 2.5b7 rri */
extern struct Process *process;
extern struct Screen *Screen,*MyScreen;
extern struct TextAttr FuckingTopaz;
extern struct TextFont *DMFont,*MyTopaz;
extern struct Window *Palette;


extern UWORD Pens20[];

extern UBYTE dcPath[],
             FontName[], /* new! 2.4 */
             *NextPath,
             PGadStr[],
             sbuff[];

extern int BatchFlag, /* 2.5b10 rri */
           ChgCmd,
           DClick,
           DWNum,
           FontSize, /* new! 2.4 */
           KeepGoing,
           SortType; /* new! 2.3 */

extern APTR NamePool; /* 2.5b10 rri */

extern struct StringHistory PathHistory;  /* 2.5b10 jjt */
extern struct Hook          EditHook;     /* 2.5b10 jjt */

int ColFudge=33,
    LastI,
    LastY;

UBYTE UndoBuff[516],
      WorkBuf[516];  /* 2.5b10 jjt */

WORD VAHVectHi[]={17,0,  0, 0, 0,10},
     VAHVectLo[]={17,1, 17,10, 1,10},
     HAHVectHi[]={15,0,  0,0, 0,9},
     HAHVectLo[]={15,1, 15,9, 1,9},
     UpArrowVectors[]={-4,4, 0,0, 4,4},
     DownArrowVectors[]={-4,-4, 0,0, 4,-4},
     LeftArrowVectors[]={5,-2, 0,0, 5,2},
     RightArrowVectors[]={-5,-2, 0,0, -5,2},
     zooming[4]; /* 2.5b13 rri */

LONG DirPen, FilePen, BackPen, SelectPen; /* 2.5b12 rri */

ULONG  DMicros,
       DSecs;


struct Border
 VAHBorder2   ={0,0,1,0,JAM1,3,VAHVectLo,0},
 VAHBorder    ={0,0,2,0,JAM1,3,VAHVectHi,&VAHBorder2},
 InVAHBorder2 ={0,0,2,0,JAM1,3,VAHVectLo,0},
 InVAHBorder  ={0,0,1,0,JAM1,3,VAHVectHi,&InVAHBorder2},
 HAHBorder2   ={0,0,1,0,JAM1,3,HAHVectLo,0},
 HAHBorder    ={0,0,2,0,JAM1,3,HAHVectHi,&HAHBorder2},
 InHAHBorder2 ={0,0,2,0,JAM1,3,HAHVectLo,0},
 InHAHBorder  ={0,0,1,0,JAM1,3,HAHVectHi,&InHAHBorder2},
 UpArrowBorder ={9,3,1,0,JAM1,3,UpArrowVectors,&VAHBorder},
 DownArrowBorder ={9,7,1,0,JAM1,3,DownArrowVectors,&VAHBorder},
 LeftArrowBorder ={5,4,1,0,JAM1,3,LeftArrowVectors,&HAHBorder},
 RightArrowBorder={11,4,1,0,JAM1,3,RightArrowVectors,&HAHBorder};

struct IntuiText GadSText[4]={
        {1,0,JAM2,2,1,&FuckingTopaz,"S",0},
        {1,0,JAM2,2,1,&FuckingTopaz,"D",0},
        {1,0,JAM2,2,1,&FuckingTopaz,"C",0},
        {1,0,JAM2,2,1,&FuckingTopaz," ",0}
};

WORD PPair1[]={ 0,9, 11,9, 11,0}; /* 2.5b10 rri */
WORD PPair2[]={11,0,  0,0,  0,9}; /* 2.5b10 rri */

struct Border PBorder[]=
 {
  {0,0,2,0,JAM1,3,PPair1,&PBorder[1]}, /* 2.5b10 rri */
  {0,0,1,0,JAM1,3,PPair2,0}, /* 2.5b10 rri */
 };


/* BOOPSI-Gadgets from DMRead.c

struct Gadget        *btnup;
struct Gadget        *btndwn;
struct Image         *uparrow;
struct Image         *dnarrow;
fd->uparrow = NewObject(NULL, "sysiclass", SYSIA_DrawInfo, fd->drwinfo,
                                           SYSIA_Which, UPIMAGE,
                                           SYSIA_Size,  SYSISIZE_MEDRES,
                                           TAG_END);

fd->dnarrow = NewObject(NULL, "sysiclass", SYSIA_DrawInfo, fd->drwinfo,
                                           SYSIA_Which, DOWNIMAGE,
                                           SYSIA_Size,  SYSISIZE_MEDRES,
                                           TAG_END);

fd->btnup = NewObject(NULL, "buttongclass", GA_ID, GID_BTNUP,
                                            GA_RelRight, -17,
                                            GA_RelBottom, -31,
                                            GA_Width, 18,
                                            GA_Height, 11,
                                            GA_RightBorder, TRUE,
                                            GA_Image, fd->uparrow,
                                            GA_Previous, fd->vscroller,
                                            ICA_TARGET, ICTARGET_IDCMP,
                                            TAG_END);

fd->btndwn = NewObject(NULL, "buttongclass", GA_ID, GID_BTNDN,
                                             GA_RelRight, -17,
                                             GA_RelBottom, -20,
                                             GA_Width, 18,
                                             GA_Height, 11,
                                             GA_RightBorder, TRUE,
                                             GA_Image, fd->dnarrow,
                                             GA_Previous, fd->btnup ? fd->btnup : fd->vscroller,
                                             ICA_TARGET, ICTARGET_IDCMP,
                                             TAG_END);
*/

struct DirWindow DWTemplate= /* 2.5b10 */
 {
  {0}, /* struct DateStamp */
  0,   /* struct DirList */
  0,   /* struct FileInfoBlock */

  {0,  3,11,-23,  9,GFLG_RELWIDTH|GFLG_GADGHCOMP,GADREL,GTYP_STRGADGET,0,0,0,0,0,0,0},
  {0,-13,10, 10,-61,GFLG_RELHEIGHT|GFLG_RELRIGHT|GFLG_GADGHNONE,GADREL|GACT_RIGHTBORDER,GTYP_PROPGADGET,0,0,0,0,0,1,0},
  {0,  4,-7,-57,  6,GFLG_RELBOTTOM|GFLG_RELWIDTH|GFLG_GADGHNONE,GADREL|GACT_BOTTOMBORDER,GTYP_PROPGADGET,0,0,0,0,0,2,0},
  {0,-17,-31,18,11,GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE,GADREL|GACT_RIGHTBORDER,GTYP_BOOLGADGET,(APTR)&UpArrowBorder,(APTR)&InVAHBorder,0,0,0,3,0},
  {0,-17,-20,18,11,GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE,GADREL|GACT_RIGHTBORDER,GTYP_BOOLGADGET,(APTR)&DownArrowBorder,(APTR)&InVAHBorder,0,0,0,4,0},
  {0,-49, -9,16,10,GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE,GADREL|GACT_BOTTOMBORDER,GTYP_BOOLGADGET,(APTR)&LeftArrowBorder,(APTR)&InHAHBorder,0,0,0,5,0},
  {0,-33, -9,16,10,GFLG_RELBOTTOM|GFLG_RELRIGHT|GFLG_GADGHIMAGE,GADREL|GACT_BOTTOMBORDER,GTYP_BOOLGADGET,(APTR)&RightArrowBorder,(APTR)&InHAHBorder,0,0,0,6,0},
  {0,-14, 10,12,10,GFLG_RELRIGHT,GADREL|GACT_RIGHTBORDER,GTYP_BOOLGADGET,(APTR)PBorder,0,0,0,0,7,0},

  {0}, /* struct Image v_img */
  {0}, /* struct Image h_img */
  {0}, /* struct NotifyRequest DM2NotifyReq */

  {AUTOKNOB | FREEVERT | PROPNEWLOOK | PROPBORDERLESS,0,0,0,0xFFFF},
  /* struct PropInfo v_prop */
  {AUTOKNOB | FREEHORIZ | PROPNEWLOOK | PROPBORDERLESS,0,0,0xFFFF,0},
  /* struct PropInfo h_prop */
  {0,(UBYTE *)UndoBuff,0,512}, /* struct StringInfo dir_str */
  {0}, /* struct StringExtend SExt */
  0,   /* struct Window */

  0, /* LONG BlocksFree */
  0, /* LONG BytesPerBlock */
  0, /* LONG ColsCmt */
  0, /* LONG ColsName */
  0, /* LONG DiskFree */
  0, /* LONG Edge */
  0, /* LONG FileCount */
  0, /* LONG Flags */
  0, /* LONG Index */
  0, /* LONG MaxFile */
  0, /* Notified */
  0, /* LONG Rows */
  0, /* LONG Sels */
  0, /* Sorting */

  0,  /* UBYTE *Ptr */
  "", /* UBYTE Path[516] */
  "", /* UBYTE Title[60] */
  "", /* UBYTE Pattern[32] */
  0   /* BPTR DirLock */
 };

struct NewWindow NewWin=
 {
  10,30,200,80,0,1,
  IDCMP_ACTIVEWINDOW|
  IDCMP_CHANGEWINDOW| /* 2.5b13 rri */
  IDCMP_CLOSEWINDOW|
  IDCMP_DISKINSERTED|
  IDCMP_DISKREMOVED|  /* 2.5b12 jjt */
  IDCMP_GADGETDOWN|
  IDCMP_GADGETUP|
  IDCMP_MENUPICK|
  IDCMP_MOUSEBUTTONS|
  IDCMP_MOUSEMOVE| /* 2.5b9 rri */
  IDCMP_RAWKEY| /* new! 2.4b18 */
  IDCMP_VANILLAKEY,
  WFLG_ACTIVATE|
  WFLG_CLOSEGADGET|
  WFLG_SIZEGADGET|
  WFLG_DRAGBAR|
  WFLG_DEPTHGADGET|
  WFLG_SMART_REFRESH|
  WFLG_NOCAREREFRESH,
  0,0,0,0,0,
  65, /* minwidth */
  65, /* minheight */
  0xFFFF,0xFFFF,CUSTOMSCREEN
 };



void DoWindow()
{
struct IntuiMessage *msg;
struct DirWindow *dw;
struct Gadget *gad;
static struct Gadget *lastgad; /* 2.5b9 rri */
struct MenuItem *item;
ULONG  class,
       DiskKludge=TRUE;  /* 2.5b12 jjt */
UWORD  code,qual;
WORD   mx,my;
int    id,w,t,hot;

while(msg=(struct IntuiMessage *)GetMsg(WinPort))
 {
  if(RexxSysBase&&do_rexx_cmd((struct RexxMsg *)msg)) continue;
  code=msg->Code;
  qual=msg->Qualifier; /* new! 2.4b18 */
  class=msg->Class;
  mx=msg->MouseX;
  my=msg->MouseY;
  if(Palette&&msg->IDCMPWindow==Palette)
   {
    DoPalette(code,mx,my,class);
    continue;
   }
  dw=FindDMWin(msg->IDCMPWindow);
  DClick=0;
  gad=(struct Gadget *)msg->IAddress;
  hot=0;
  t=(class==IDCMP_MENUPICK);
  w=(class==IDCMP_MOUSEBUTTONS&&code==SELECTDOWN);
  if(w||t)
   {
    if(DoubleClick(DSecs,DMicros,msg->Seconds,msg->Micros)) DClick=1;
    if(w)
     {
      DSecs=msg->Seconds;
      DMicros=msg->Micros;
     }
   }
  if(t&&dw&&(dw->Window->Flags&WFLG_WINDOWACTIVE)&&dw==CDWin&&DClickDir&&DClick)
   if((msg->MouseY+4)>LastY&&(msg->MouseY-4)<LastY) hot=1;
  LastY=msg->MouseY;
  ReplyMsg((struct Message *)msg);

  if(dw) switch(class)
   {
    case IDCMP_DISKINSERTED:
                        Delay(25);
                        ReSort();
    case IDCMP_DISKREMOVED:  /* 2.5b12 jjt */
                        if (DiskKludge) {  /* 2.5b12 jjt */
                          /* Every open window will send a DISKINSERTED/REMOVED,
                             so only act on one. */
                          RefreshDevLists();
                          DiskKludge = FALSE;
                        }
                        break;
    case IDCMP_CHANGEWINDOW: /* 2.5b13 rri */
                        NewSize(dw);
                        if(dw->Window->Flags&WFLG_ZOOMED) /* 2.5b13 rri */
                         {
                          dw->zoom[0]=dw->Window->LeftEdge;
                          dw->zoom[1]=dw->Window->TopEdge;
                          dw->zoom[2]=dw->Window->Width;
                          dw->zoom[3]=dw->Window->Height;
                         }
                        else /* 2.5b13 rri */
                         {
                          dw->norm[0]=dw->Window->LeftEdge;
                          dw->norm[1]=dw->Window->TopEdge;
                          dw->norm[2]=dw->Window->Width;
                          dw->norm[3]=dw->Window->Height;
                         }
                        break;
    case IDCMP_VANILLAKEY:
    case IDCMP_RAWKEY:     /* new! 2.4b18 */
                        DoKeyCmd(dw,code,qual,class);
                        break;
    case IDCMP_MOUSEBUTTONS:
                        if(code==SELECTDOWN)
                         {
                          sel_file(dw,my);
                         }
                        break;
    case IDCMP_GADGETDOWN:
                        if(gad->GadgetID==1||gad->GadgetID==2) /* 2.5b10 rri */
                         {
                          dw->Window->Flags|=WFLG_REPORTMOUSE; /* 2.5b9 rri */
                          lastgad=gad; /* 2.5b9 rri */
                         }
                        slide_em(dw,gad);
                        break;
    case IDCMP_GADGETUP:
                        dw->Window->Flags&=~WFLG_REPORTMOUSE; /* 2.5b9 rri */
                        lastgad=NULL;
                        id=gad->GadgetID;
                        if(id==7&&dw==CDWin)
                         {
                          ParseArgs(PGadStr,CmdWin);
                         }
                        if ((id == 0) && (code != 27))  /* 2.5b10 jjt */
                         {
                          /* if gadget = stringgadget = ID==0
                             and Esc wasn't what triggered the GADGETUP msg.
                          */
                          dw->Pattern[0]=0; /* new! 2.4b14 */
                          if(FindPattern(dw->Path)) /* new! 2.4 */
                           {
                            Separate(dw);
                           }
                          InitDir(dw,0);
                         }
                        break;
    case IDCMP_MOUSEMOVE: /* 2.5b9 rri */
                        if(lastgad) slide_em(dw,lastgad); /* 2.5b10 rri */
                        break;
    case IDCMP_CLOSEWINDOW:
                        CloseDirWindow(DWNum);
                        break;
    case IDCMP_MENUPICK:
                        if(item=ItemAddress(DMMenu,(ULONG) code)) /* 2.5b10 rri */
                         {
                          ActionCmd(CmdWin, GTMENUITEM_USERDATA(item)); /* new! 2.5b5 */
                          break;
                         }
                        if(hot)
                         {
                          /* 2.5b13 rri */
                          zooming[0]=CDWin->zoom[0];
                          zooming[1]=CDWin->zoom[1];
                          zooming[2]=CDWin->zoom[2];
                          zooming[3]=CDWin->zoom[3];
                          
                          OpenDirWindow(0,CDWin->norm[0],
                                          my+CDWin->norm[1]-50,
                                          CDWin->norm[2],
                                          100);
                          WinTitle(DestWin); /* 2.5b6 rri */
                          break;
                         }
    default:            break;
   }
 }
}


void RefreshGadget(struct Gadget *gad,struct Window *win)
{
struct Gadget *gad2=gad->NextGadget;

gad->NextGadget=0;
RefreshGadgets(gad,win,0);
gad->NextGadget=gad2;
}


int GZZWidth(struct DirWindow *dw)
{
return(dw->Window->Width-dw->Window->BorderLeft-dw->Window->BorderRight);
}


void SetHoriz(struct DirWindow *dw)
{
int hbody=dw->h_prop.HorizBody,i,j=ColFudge;

i=GZZWidth(dw)/DMFont->tf_XSize;
ReSize(dw);
dw->h_prop.HorizBody=0xFFFF;
if(j>(i+1))
 {
  dw->h_prop.HorizBody=(i<<16)/(j-1);
  dw->Edge=(dw->h_prop.HorizPot*(j-i))>>16;
 }
else
 {
  dw->Edge=0;
  dw->h_prop.HorizPot=0;
 }
if(j>(i+1)) dw->h_prop.HorizBody=(i<<16)/(j-1);
if(!dw->Edge) dw->h_prop.HorizPot=0;
if(hbody!=dw->h_prop.HorizBody)
 {
  RefreshGadget(&dw->h_gad,dw->Window);
 }
}


void SetVert(struct DirWindow *dw)
{
int vbody=dw->v_prop.VertBody;

dw->v_prop.VertBody=0xFFFF;
if(dw->FileCount>dw->Rows) dw->v_prop.VertBody=((LONG)(dw->Rows-1)<<16)/(dw->FileCount-1);
else dw->Index=0;
if(!dw->Index) dw->v_prop.VertPot=0;
if(vbody!=dw->v_prop.VertBody)
 {
  RefreshGadget(&dw->v_gad,dw->Window);
 }
}


void dis_name(struct DirWindow *dw,LONG file,LONG pos) /* 2.5b0 rri */
{
struct RastPort *rp;
struct DirList **dl,*dlp;
UBYTE *ptr=sbuff;
ULONG Ap=FilePen,Bp=BackPen,cols; /* 2.5b12 rri */

if(!dw||!dw->Window) /* 2.5b13 rri */
 {
  return;
 }

rp=dw->Window->RPort;
dl=dw->DirList;
dlp=dl[file];

if(pos>dw->Rows) return;
memset(ptr,' ',200);

if(file>=0&&file<dw->FileCount&&dlp->sel<2)
 {
  DoFileFormat(dlp,dw->ColsName,dw->ColsCmt,dw->BytesPerBlock); /* 2.5b5 rri */
  if(dlp->dir==3)
   {
    if(!(dlp->sel))
     {
      Ap=dlp->attr&0xF;
      Bp=(dlp->attr>>4)&0xF;
     }
    if(dlp->sel) /* 2.5b12 rri */
     {
      Ap=(dlp->attr>>8)&0xF;
      Bp=(dlp->attr>>12)&0xF;
     }
   }
  else
   {
    if(dlp->sel)
     {
      Bp=SelectPen; /* 2.5b12 rri */
      if (SelectPen==BackPen) Bp++;
     }
    if(dlp->dir&&dlp->dir<3) Ap=DirPen; /* 2.5b12 rri */
   }
 }

if(Ap==Bp) Ap++;

SetAPen(rp,Ap);
SetBPen(rp,Bp);
Move(rp,(LONG)dw->Window->BorderLeft,(LONG)((pos*DMFont->tf_YSize)+dw->Window->BorderTop+TOPOFFSET+DMFont->tf_Baseline));
ptr=sbuff+dw->Edge;
cols=GZZWidth(dw)/DMFont->tf_XSize;
Text(rp,ptr,cols);
}


void rdis_files(struct DirWindow *dw)
{
struct RastPort *rp=dw->Window->RPort;
int pos,VPot;
LONG s,top=dw->Window->BorderTop+TOPOFFSET,h=DMFont->tf_YSize,
     w,maxname=dw->Rows-1; /* 2.5b10 rri */

if(dw->FileCount<maxname) return;
w=GZZWidth(dw);
s=dw->Window->BorderLeft;
while(1)
 {
  VPot=dw->v_prop.VertPot;
  pos=(VPot*(dw->FileCount-maxname))>>16;
  if(pos==dw->Index) return;
  if(pos>dw->Index&&pos<dw->Index+(maxname>>2)) /* new! 2.4 */
   {
    ClipBlit(rp,s,top+h,rp,s,top,w,maxname*h,0xC0);
    dw->Index++;
    dis_name(dw,dw->Index+maxname,maxname);
   }
  else if(pos<dw->Index&&pos>dw->Index-(maxname>>2)) /* new! 2.4 */
    {
     ClipBlit(rp,s,top,rp,s,top+h,w,maxname*h,0xC0);
     dw->Index--;
     dis_name(dw,dw->Index,0);
    }
  else
   {
    dw->Index=pos;
    dis_files(dw);
   }
 }
}


void dis_files(struct DirWindow *dw)
{
LONG i; /* 2.5b10 rri */

if(!dw->FileCount) return; /* test! */

dw->Rows=(dw->Window->Height-dw->Window->BorderTop-TOPOFFSET-10)/DMFont->tf_YSize;
dis_name(dw,dw->Index,0); /* reset completely */
SetHoriz(dw);
SetVert(dw);
for(i=0;i<dw->Rows;i++)
 {
  dis_name(dw,i+dw->Index,i); /* reset again row by row */
 }
}


void Increment(struct DirWindow *dw,struct Gadget *gad,LONG lines) /* 2.5b10 rri */
{
int add,def,ft=0;

if (lines<1) lines=1; /* new! 2.4 */

if(dw->FileCount<=dw->Rows)  return;

def=0xFFFF/(dw->FileCount-dw->Rows);
if(gad->GadgetID==3) add = -def;
else add=def+1;

add=add*lines; /* new! 2.4 */

do
 {
  if((!dw->Index&&add<0)||(dw->Index>(dw->FileCount-dw->Rows-1)&&add>0))
   {
    break;
   }
  def=dw->v_prop.VertPot;
  if(def+add>0xFFFF)
   {
    add=0xFFFF-def;
   }
  else if(def+add<lines) /* new! 2.4b18 */
   {
    add = -def;
   }
  dw->v_prop.VertPot+=add;

  RefreshGadget(&dw->v_gad,dw->Window);
  rdis_files(dw);
  if(!ft&&gad->Flags>0x80)
   {
    ft=1;
   }
 }
while(gad->Flags>0x80);
}


void HorSlide(struct DirWindow *dw,struct Gadget *gad,LONG lines) /* 2.5b10 rri */
{
LONG add,def,cols,clc,ft=0; /* 2.5b10 rri */

if (lines<1) lines=1; /* new! 2.4b18 */

cols=GZZWidth(dw)/DMFont->tf_XSize;
clc=(ColFudge-cols-1);
if(clc<=1) return;
def=0xFFFF/clc;
if(gad->GadgetID==5) add = -def;
else add=def+1;

add=add*lines; /* new! 2.4b18 */

do
 {
  if((!dw->Edge&&add<0)||(dw->Edge>(clc-1)&&add>0)) break;
  def=dw->h_prop.HorizPot;
  if(def+add>0xFFFF)
   {
    add=0xFFFF-def;
   }
  else if(def+add<lines) /* new! 2.4b18 */
   {
    add = -def;
   }
  dw->h_prop.HorizPot+=add;
  RefreshGadget(&dw->h_gad,dw->Window);

  SetHoriz(dw); /* new! 2.4b19 */
  for(clc=0;clc<dw->Rows;clc++) /* new! 2.4b19 */
   {
    dis_name(dw,clc+dw->Index,clc); /* reset again row by row */
   }
  if(!ft)
   {
    ft=1;
   }
 }
while(gad->Flags>0x80);
}


void ShowDirection(struct DirWindow *dw,int n)
{
if(dw)
 {
  if(dw->Flags&DW_SOURCE) n=0;
  if(dw->Flags&DW_DEST) n=1;
  if(dw->Flags&DW_CMD) n=2;
  if(n==4)
   {
    n=1;
    if(dw==CDWin) n=0;
   }
  dw->parent.GadgetText = &GadSText[n];
  RefreshGadget(&dw->parent,dw->Window);
 }
}


void NewSize(struct DirWindow *dw)
{
struct Window *win=dw->Window;
struct RastPort *rp=win->RPort;
LONG tp=dw->v_gad.TopEdge; /* 2.5b10 rri */

dw->dir_str.BufferPos=0;
SetAPen(rp,(ULONG) Pens20[BACKGROUNDPEN]);

RectFill(rp,(LONG) win->BorderLeft, tp-1,
         (LONG) (win->Width-win->BorderRight-1),
         (LONG) (win->Height-win->BorderBottom-1));

SetAPen(rp,(ULONG) Pens20[SHINEPEN]);
Move(rp,2,tp-2);
Draw(rp,(LONG) win->Width-win->BorderRight-1,tp-2);
SetAPen(rp,(ULONG) Pens20[SHADOWPEN]);
Move(rp,2,tp);
Draw(rp,(LONG) win->Width-win->BorderRight-1,tp);
ShowDirection(DestWin,1);
ShowDirection(CDWin,0);
dis_files(dw);
rdis_files(dw);
WinTitle(dw);
}


void slide_em(struct DirWindow *dw,struct Gadget *gad)
{
int r=0,id=gad->GadgetID;

if(id==3||id==4)
 {
  Increment(dw,gad,1); /* new! 2.4 */
  return;
 }

if(id==5||id==6)
 {
  HorSlide(dw,gad,1);
  return;
 }

if(id==2) r=1;
else if(id!=1) return;

if(r) dis_files(dw);
else
 if(!(dw->FileCount<(dw->Rows-1)))
  {
   rdis_files(dw); /* 2.5b9 rri */
  }

}


void sel_file(struct DirWindow *dw,int my)
{
struct DirList **dl=dw->DirList,*dlp;
struct Message *msg;
LONG i,ni,cm; /* 2.5b10 rri */
UBYTE smear=5;
struct Window *win=dw->Window;

cm=(dw->Flags&DW_CMD);

if(my>(win->Height-win->BorderBottom)) return;
if(win->MouseX<win->BorderLeft) return; /* 2.5b10 rri */

if(DClick&&!cm&&NextPath!=dw->Path)
 {
  if(GetNewPath(dw))
   {
    WinTitle(DestWin); /* 2.5b7 rri */
    return;
   }
 }

if(!dw->FileCount) return;
i=(my-win->BorderTop-TOPOFFSET)/DMFont->tf_YSize;
do
 {
  ni=i+dw->Index;
  if(i<0||i>=dw->Rows||ni>=dw->FileCount) goto SK;
  if(win->MouseX>(win->Width-win->BorderRight)) goto SK;
  dlp=dl[ni];
  if(!dlp) goto SK;
  if(smear==5)
   {
    dlp->sel^=1;
    smear=dlp->sel;
   }
  else if(dlp->sel==smear)
        {
         goto SK;
        }
       else dlp->sel=smear;
  if(dlp->dir&&dlp->dir<3)
   {
    if(DClick&&DClickDir==dlp&&!dlp->sel&&LastI==i)
     {
      if(GetNewPath(dw)) return;
     }
    LastI=i;
    DClickDir=dlp;
    NextPath=dw->Path;
    DClick=0;
   }
  else DClickDir=0;
  if(!dlp->dir)
   {
    if(LastI==i&&DClick&&!dlp->sel)
     {
      AutoFiler(dw,dlp->name);
      smear=4;
     }
    else LastI=i;
   }
  if(dlp->dir==3)
   {
    dis_name(dw,ni,i);
    if(ChgCmd)
     {
      EditCmd(dw,(int) ni); /* 2.5b10 rri */
     }
    else
     {
      ActionCmd(dw,dlp->cmt);
      if(CDWin&&CmdWin&&CmdWin->Window->Flags&WFLG_WINDOWACTIVE) /* 2.5b5 rri */
       {
        ActivateWindow(CDWin->Window);
       }
     }
    if(dw!=CmdWin) return;
    dw=CmdWin;
    dlp->sel=0;
    smear=4;
   }
  DClick=0;
  dis_name(dw,ni,ni-dw->Index);
  LastI=i;
  if(smear==4)
   {
    return;
   }

SK:
  ni=(win->MouseY-win->BorderTop-TOPOFFSET)/DMFont->tf_YSize;
  if(ni>i) i++;
  else if(ni<i) i--;
  if(i>=dw->Rows&&i<dw->FileCount)
   {
    i--;
    Increment(dw,&dw->dn,1); /* new! 2.4 */
   }
  if(i<0&&dw->Index)
   {
    i++;
    Increment(dw,&dw->up,1); /* new! 2.4 */
   }
  WaitTOF();
 }
while(!(msg=GetMsg(WinPort)));

if(msg) ReplyMsg(msg);

WinTitle(dw);
}


/* --------------------- Open/Close windows -------------------------------- */

void FindNewDirection(struct DirWindow *dw)
{
struct DirWindow *dw2;
int i=0;

if(dw==CmdWin)
 {
  CmdWin=0;
  if(dw==CDWin) CDWin=0;
  for(i=254;i>=0;i--)
   {
    if(dw2=DirWin[i])
     {
      if(dw2->Flags&DW_CMD)
       {
        CmdWin=dw2;
        DWNum=i;
        return;
       }
     }
        return;
   }
 }

if(dw==DestWin)
 {
  DestWin=0;
  i=1;
 }
if(dw==CDWin)
 {
  CDWin=DestWin;
  i=1;
 }
if(i)
 {
  for(i=254;i>=0;i--)
   {
    if(dw2=DirWin[i])
     {
      if(dw2->Flags&DW_CMD)
       {
        DWNum=i;
        ShowDirection(dw2,2);
       }
      else if(CDWin==dw2) DWNum=i;
      else
       {
        DestWin=dw2;
        break;
       }
     }
   }
  ShowDirection(DestWin,1);
  ShowDirection(CDWin,0);
 }
}


void CloseDirWindow(int num)
{
struct DirWindow *dw=DirWin[num];
int i;

if(!dw) return;
ClearMenuStrip(dw->Window);
CloseSharedWindow(dw->Window);
if(dw->Fib) FreeMem(dw->Fib,sizeof(sFIB));
FreeDirTable(dw);
FreeMem(dw->DirList,(ULONG) (dw->MaxFile<<2)); /* 2.5b10 rri */
FreeMem(dw,sizeof(struct DirWindow));
DirWin[num]=0;
FindNewDirection(dw);
for(i=0;i<255;i++) if(DirWin[i])
 {
  if(!DirWin[DWNum]) DWNum=i;
  process->pr_WindowPtr=(APTR)DirWin[i]->Window;
  break;
 }
 if(i==255)
  {
   process->pr_WindowPtr=(APTR)-1;
   KeepGoing=0;
  }
}


int OpenDirWindow(UBYTE *path,int Left,int Top,int Wid,int Hi)
{
struct DirWindow *dw,*dwt;
struct DirList **dlist;
int dwc=0,maxf=500,w=Screen->Width,h=Screen->Height;

if(Top <0) Top=0;
if(Left<0) Left=0;
if(Wid<=0) Wid=w-Left;
if(Wid<65) Wid=65; /* 2.5b13 rri */
if(Hi<= 0) Hi=h-Top;
if(Hi< 65) Hi=65; /* 2.5b13 rri */

while((Left+Wid)>w)
 {
  if(Wid>80) Wid--;
  else if(Left) Left--;
 }
while((Top+Hi)>h)
 {
  if(Hi>70) Hi--;
  else if(Top) Top--;
 }
NewWin.Screen=Screen;
NewWin.LeftEdge=Left;
NewWin.TopEdge=Top;
NewWin.Width=Wid;
NewWin.Height=Hi;

while(DirWin[dwc]) dwc++;
if(dwc>255) return(0);

DWTemplate.dir_gad.Activation|=0x2000;

if(!(dw=(struct DirWindow *)AllocMem(sizeof(struct DirWindow),MEMF_PUBLIC))) return(0);
if(!(dlist=(struct DirList **)AllocMem((ULONG) (maxf<<2),MEMF_PUBLIC|MEMF_CLEAR))) goto Q1; /* 2.5b10 rri */
dwt = &DWTemplate;
memmove(dw,dwt,(size_t) sizeof(struct DirWindow)); /* 2.5b10 rri */

NewWin.FirstGadget=(struct Gadget *)&dw->up;
NewWin.Title=(UBYTE *)dw->Title; /* 2.5b10 rri */

dw->up.NextGadget = &dw->dn;
dw->dn.NextGadget = &dw->lf;
dw->lf.NextGadget = &dw->rt;
dw->rt.NextGadget = &dw->h_gad;
dw->h_gad.NextGadget = &dw->v_gad;
dw->v_gad.NextGadget = &dw->dir_gad;
dw->dir_gad.NextGadget = &dw->parent;

dw->h_gad.GadgetRender=(APTR)&dw->h_img;
dw->v_gad.GadgetRender=(APTR)&dw->v_img;

dw->h_gad.SpecialInfo=(APTR)&dw->h_prop;
dw->v_gad.SpecialInfo=(APTR)&dw->v_prop;
dw->dir_gad.SpecialInfo=(APTR)&dw->dir_str;

dw->dir_gad.UserData = &PathHistory;  /* 2.5b10 jjt */

dw->dir_str.Buffer=(UBYTE *) dw->Path; /* 2.5b10 rri */

dw->dir_gad.TopEdge=Screen->BarHeight+1;
dw->parent.TopEdge=Screen->BarHeight+1;
dw->v_gad.TopEdge=Screen->BarHeight+12;

dw->v_gad.Height=(-46)-Screen->BarHeight;
dw->parent.GadgetText = &GadSText[0];
dw->dir_str.Extension = &dw->SExt;
dw->SExt.Font=MyTopaz;
dw->SExt.Pens[0]=Pens20[TEXTPEN];
dw->SExt.Pens[1]=Pens20[BACKGROUNDPEN];
dw->SExt.ActivePens[0]=Pens20[HIGHLIGHTTEXTPEN];
dw->SExt.ActivePens[1]=Pens20[BACKGROUNDPEN];
dw->SExt.InitialModes=(1<<2);
dw->SExt.EditHook = &EditHook;   /* 2.5b10 jjt */
dw->SExt.WorkBuffer = WorkBuf;  /* 2.5b10 jjt */
dw->Sorting=SortType; /* new! 2.3 */

/* 2.5b7 rri */
dw->DM2NotifyReq.nr_stuff.nr_Signal.nr_Task = (struct Task *) FindTask(NULL);
dw->DM2NotifyReq.nr_Flags = NRF_SEND_MESSAGE;
dw->DM2NotifyReq.nr_stuff.nr_Msg.nr_Port=NotifyPort;
dw->DM2NotifyReq.nr_UserData = dwc;
dw->Notified=0;

/* 2.5b13 rri */

dw->zoom[0]=zooming[0];
dw->zoom[1]=zooming[1];
dw->zoom[2]=zooming[2];
dw->zoom[3]=zooming[3];
dw->norm[0]=Left;
dw->norm[1]=Top;
dw->norm[2]=Wid;
dw->norm[3]=Hi;

if(!(dw->Window=OpenSharedWindow(&NewWin))) goto Q2;

dw->dir_gad.LeftEdge=dw->Window->BorderLeft;

KeepGoing=1;
if(DMMenu&&(!BatchFlag)) /* 2.5b10 rri */
 {
  SetMenuStrip(dw->Window,DMMenu);
 }
if(DMFont) SetFont(dw->Window->RPort,DMFont);
dw->MaxFile=maxf;
dw->DirList=dlist;
DirWin[DWNum=dwc]=dw;
process->pr_WindowPtr=(APTR)dw->Window;
if(!path||Stricmp(path,"CMD")) /* 2.5b13 rri */
 {
  ShowDirection(DestWin,3);
  DestWin=CDWin;
  CDWin=dw;
  ShowDirection(DestWin,1);
  ShowDirection(CDWin,0);
 }
GetNewPath(dw);
if(!dw->DirLock&&!dw->Path[0])
 {
  h=0;
  if(path)
   {
    strcpy(dw->Path,path);
    if(!Stricmp(path,"CMD")) /* 2.5b13 rri */
     {
      dw->Flags=DW_CMD;
      strcpy(dw->Path,dcPath);
      CmdWin=dw; h=1;
     }
   }
  InitDir(dw,h);
 }
return(1);
Q2: FreeMem(dlist,(ULONG) (maxf<<2)); /* 2.5b10 rri */
Q1: FreeMem(dw,sizeof(struct DirWindow)); return(0);
}


struct Window *OpenSharedWindow(struct NewWindow *nw)
{
ULONG   flags=nw->IDCMPFlags;
struct Window   *w;

nw->IDCMPFlags=0;

/* new! 2.4 */

if(w=OpenWindowTags(nw,
                    WA_NewLookMenus, TRUE,
                    WA_Zoom, zooming, /* 2.5b13 rri */
                    TAG_DONE))

if(flags)
 {
  w->UserPort=WinPort;
  ModifyIDCMP(w,flags);
 }
nw->IDCMPFlags=flags;
return(w);
}


void CloseSharedWindow(struct Window *Window) /* new! 2.2b13 */
{
Forbid();
if(Window->UserPort)
 {
  struct Node *Node,*Next;
  for(Node = Window->UserPort->mp_MsgList.lh_Head ; Next = Node->ln_Succ ; Node = Next)
   {
    if(((struct IntuiMessage *)Node)->IDCMPWindow == Window)
     {
      Remove(Node);
      ReplyMsg((struct Message *)Node);
     }
   }
  Window->UserPort = NULL;
 }
ModifyIDCMP(Window,NULL);
Permit();
CloseWindow(Window);
}
