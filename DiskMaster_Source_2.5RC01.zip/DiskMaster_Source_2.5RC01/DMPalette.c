/* DiskMaster II Palette-Requester
**
** 00-07-10 rri - replaced all c++ style comments by ANSI ones
**              - replaced MyToUpper() calls by ToUpper() (utility.library)
**
** 2.5b10
**
** 00-12-05 rri - fixed prototypes for DoPalette() and PaletteMouse()
**
** 00-12-26 rri - removed nine "warning 120"`s
**              - removed one "warning 164"
**              - replaced five unix-style movmem()`s by ANSI-style memmove()`s
**              - changed UserCols from int to ULONG
**
** 2.5b11
**
** 01-03-01 jjt - Changed obsolete Intuition flag names to v36 versions:
**                  GADGHNONE to GFLG_GADGHNONE,
**                  RAWKEY to IDCMP_RAWKEY,
**                  GADGETDOWN to IDCMP_GADGETDOWN,
**                  CLOSEWINDOW to IDCMP_CLOSEWINDOW,
**                  MOUSEBUTTONS to IDCMP_MOUSEBUTTONS,
**                  GADGIMMEDIATE to GACT_IMMEDIATE,
**                  RELVERIFY to GACT_RELVERIFY,
**                  RMBTRAP to WFLG_RMBTRAP,
**                  SMART_REFRESH to WFLG_SMART_REFRESH,
**                  NOCAREREFRESH to WFLG_NOCAREREFRESH,
**                  WINDOWDRAG to WFLG_DRAGBAR,
**                  WINDOWCLOSE to WFLG_CLOSEGADGET,
**                  WINDOWDEPTH to WFLG_DEPTHGADGET,
**                  PROPGADGET to GTYP_PROPGADGET.
**
** 01-04-23 jjt - Changed SetColors() & SetPens() to use Char2Nibble().
**
** 01-04-29 rri - improved SetColors() with ObtainPen()
**
** 01-07-15 rri - added "Usercolors" to SetColors which is the maximum
**                amount of colors the user wants to be obtained,
**                defaults to 4.
**
** 2.5b12
**
** 01-07-24 rri - improved SetColors() by an ObtainPen() for the last pen
**                in the palette - this should protect the cursor-color
**
** 01-07-25 rri - SetPens() doesn't writes to struct DrawInfo anymore
**                - 'Pens'�has to be called before 'NewScreen' now!
**              - SetPens() dramatically simplified with expanding
**                it's possibilities...
**
** 01-07-26 rri - 'Pens' accepts values 0-28, >28 is set to zero
**              - removed one obsolete line from SetColors()
**
** 01-07-27 rri - SetColors() tries to ObtainPen() the full amount
**                of UserColors now
**              - New sub-routine: AllocPens()
**
** 01-08-03 rri - 'Pens' resets BPen to Pens20[BACKGROUNDPEN]
**              - AllocPens() allocates the real cursor-color now
**              - AllocPens() allocates cursor-over-text pen now
**
** 2.5b13
**
** 01-09-09 rri - sub-routine PenAllocation() saved 24 bytes
**              - AllocPens() allocates the complement of TEXTPEN now
**                Thanks for reporting to Richard Mattsson <richard@cloudnet.com>!
**
*/

#include "DM.h"

extern struct ReqToolsBase      *ReqToolsBase; /*new! 2.2b10 */
extern struct Screen    *Screen,*MyScreen;
extern struct Process   *process;
extern struct MsgPort   *WinPort;
extern struct TextFont  *MyTopaz;
extern struct TextAttr  FuckingTopaz;

extern UBYTE  *ActionArgs[];
extern UBYTE  Version[]; /*new! 2.2b10 */

extern LONG   Use30; /* 2.5b11 rri */
extern LONG   BackPen; /* 2.5b12 rri */

struct Window   *Palette;

int     cursel,pColors;

UWORD   *ColorP,ColMap[32],backup[32],
        Pens20[20];

ULONG UserCols, /* 2.5b10 rri */
      UserColors=4; /* 2.5b11 rri */

struct IntuiText
        pcnl={3,0,JAM2,121,-9,&FuckingTopaz,"Cancel",0},
        rtxt={3,0,JAM2, -9, 1,&FuckingTopaz,"R",&pcnl},
        gtxt={3,0,JAM2, -9, 1,&FuckingTopaz,"G",0},
        btxt={3,0,JAM2, -9, 1,&FuckingTopaz,"B",0};

struct Image    img,r_img,g_img,b_img;
struct PropInfo r_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0},
                g_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0},
                b_prop={FREEHORIZ|AUTOKNOB|0x10,0,0,0x1000,0};

struct Gadget
 blue_gad= {0        ,13,48,169,9,GFLG_GADGHNONE,GACT_IMMEDIATE|GACT_RELVERIFY,
        GTYP_PROPGADGET,(APTR)&b_img,0,&btxt,0,(APTR)&b_prop,80,0},

 green_gad={&blue_gad,13,38,169,9,GFLG_GADGHNONE,GACT_IMMEDIATE|GACT_RELVERIFY,
        GTYP_PROPGADGET,(APTR)&g_img,0,&gtxt,0,(APTR)&g_prop,81,0},

 red_gad= {&green_gad,13,28,169,9,GFLG_GADGHNONE,GACT_IMMEDIATE|GACT_RELVERIFY,
        GTYP_PROPGADGET,(APTR)&r_img,0,&rtxt,0,(APTR)&r_prop,82,0};

struct NewWindow
 NewPal={40,28,187,59,3,2,IDCMP_RAWKEY|IDCMP_GADGETDOWN|IDCMP_CLOSEWINDOW|IDCMP_MOUSEBUTTONS,
        WFLG_RMBTRAP|WFLG_SMART_REFRESH|WFLG_NOCAREREFRESH|WFLG_DRAGBAR|WFLG_CLOSEGADGET|WFLG_DEPTHGADGET,
        &red_gad,0,"Color Palette",0,0,0,0,0,0,CUSTOMSCREEN};


void ColorHex(void);
void set_col(void);
void PaletteGads(void);
void RT_Palette(void);
void PenAllocation(ULONG i); /* 2.5b13 rri */


void ColorHex()
{
struct RastPort *rp=Palette->RPort;
UBYTE buf[8];

sprintf(buf,"%lX-%03lX",cursel,ColorP[cursel]);
Move(rp,136,(LONG) Screen->BarHeight+8);
Text(rp,buf,5);
}


void set_col()
{
UWORD col=ColorP[cursel];

r_prop.HorizPot=(col>>8)*0x1111;
g_prop.HorizPot=((col>>4)&0xF)*0x1111;
b_prop.HorizPot=(col&0xF)*0x1111;
}


void OpenPalette()
{
struct RastPort *rp;
LONG i,n,t=Screen->BarHeight+2; /* 2.5b10 rri */
ULONG I; /* 2.5b10 rri */

if(Palette)
 {
  CloseSharedWindow(Palette);
  Palette=0;
  memmove( (char *)ColMap,(char *)ColorP,(size_t) UserCols<<1); /* 2.5b10 rri */
 }
else
 {
  NewPal.Screen=Screen;
  ColorP=(UWORD *)Screen->ViewPort.ColorMap->ColorTable;
  UserCols=pColors=1<<Screen->BitMap.Depth;
  memmove((char *)backup,(char *)ColorP,(size_t) 64); /* 2.5b10 rri */
  cursel=0;
  set_col();
  red_gad.TopEdge=t+18;
  green_gad.TopEdge=t+28;
  blue_gad.TopEdge=t+38;
  NewPal.Height=t+49;
  if(Palette=OpenSharedWindow(&NewPal))
   {
    SetFont(Palette->RPort,MyTopaz);
    n=130/pColors;
    rp=Palette->RPort;
    for(I=1;I<pColors;I++)
     {
      SetAPen(rp,I);
      i=I*n;
      RectFill(rp,i+4,t,i+n+2,t+14);
     }
    ColorHex();
   }
 }
}


void PaletteMouse(UWORD code,WORD x,WORD y) /* 2.5b10 rri */
{
int newsel,i;
struct Screen *next=Screen->NextScreen;

if(code==105&&next&&Screen)
 {
  i=1<<(next->BitMap.Depth+1);
  if(i>64) i=64;
  memmove((char *)ColorP,(char *)next->ViewPort.ColorMap->ColorTable,(size_t) i);
  LoadRGB4(&Screen->ViewPort,ColorP,32);
 }
else if(y>26||code!=SELECTDOWN) return;
else if(x>130)
 {
  memmove((char *)ColorP,(char *)backup,(size_t) 64); /* 2.5b10 rri */
  LoadRGB4(&Screen->ViewPort,ColorP,32);
  OpenPalette();
  return;
 }
else
 {
  newsel=(x-4)/(130/pColors);
  if(newsel!=cursel)
   {
    cursel=newsel;
    set_col();
    RefreshGadgets(&red_gad,Palette,0);
   }
 }
ColorHex();
}

void PaletteGads()
{
LONG sig=1<<WinPort->mp_SigBit;

do
 {
  Delay(4);
  ColorP[cursel]=((r_prop.HorizPot>>4)&0xF00)+
   ((g_prop.HorizPot>>8)&0xF0)+(b_prop.HorizPot>>12);
  LoadRGB4(&Screen->ViewPort,ColorP,32);
  ColorHex();
 }
while(!(SetSignal(0,sig)&sig));
ColorHex();
}


void DoPalette(UWORD code,WORD x,WORD y,ULONG class) /* 2.5b10 rri */
{
switch(class)
 {
  case IDCMP_CLOSEWINDOW: OpenPalette(); break;
  case IDCMP_GADGETDOWN: PaletteGads(); break;
  case IDCMP_MOUSEBUTTONS: PaletteMouse(code,x,y); break;
 }
}


void SetColors()
{
UBYTE *ptr;
ULONG c,i=1,g=0,x; /* 2.5b11 rri */

if(!ActionArgs[1]) /* new! 2.2b10 */
 {
  if(!ReqToolsBase) OpenPalette();
  else RT_Palette();
  return;
 }
while(ActionArgs[i])
 {
  ptr=ActionArgs[i++];
  ColMap[g]=0;

  while (c = *ptr++) /* 2.5b11 jjt */
   {
    x = Char2Nibble((ULONG) c);  /* 2.5b11 jjt */
    if (x > 15) x = 0;           /* 2.5b11 jjt */
    ColMap[g]<<=4;
    ColMap[g]|=x;
   }
  g++;
 }
UserCols=g;

if(MyScreen)
 {
  LoadRGB4(&MyScreen->ViewPort,ColMap,(ULONG) g); /* 2.5b10 rri */
  if(Use30) /* 2.5b11 rri */
   {
    AllocPens(); /* 2.5b12 */
   }
 }
}


void SetPens()
{
int i=1;

if(MyScreen) /* do nothing when own screen already is open */
 {
  return;
 }

while(ActionArgs[i]&&i<20) /* 2.5b12 rri */
 {
  Pens20[i-1]=0;
  Pens20[i-1]=atoi(ActionArgs[i]);
  if(Pens20[i-1]>28) Pens20[i-1]=0;
  i++;
 }

BackPen=Pens20[BACKGROUNDPEN];

}


void RT_Palette() /*new! 2.2b10 */
{

rtPaletteRequestA( Version, NULL, NULL);

}


void PenAllocation(ULONG i) /* 2.5b13 rri */
{
ObtainPen(Screen->ViewPort.ColorMap,i,0,0,0,PEN_EXCLUSIVE|PEN_NO_SETCOLOR);
}


void AllocPens(void) /* 2.5b13 rri */
{
ULONG i,a;

for(i=0;i<UserColors;i++)
 {
  PenAllocation(i);
 }

a=(1<<MyScreen->BitMap.Depth);

i=a-Pens20[BACKGROUNDPEN]-1;
PenAllocation(i);

i=a-Pens20[TEXTPEN]-1;
PenAllocation(i);

i=a-Pens20[HIGHLIGHTTEXTPEN]-1;
PenAllocation(i);
}
