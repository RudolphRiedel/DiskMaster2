/* DMSupport.c - generic support sub-routines
**
** 00-07-07 rri - created DMSupport.c
**              - added StrToUpper()
**
** 00-07-07 jjt - Added GetActionArg().
**              - Added extern ref to ActionArgs.
**              - Added IsDir().
**
** 00-07-12 rri - added SkipWhite(), AArg2Str(), Display(), QuoteCat()
**
** 00-07-13 rri - added DMMatch()
**
** 00-07-13 jjt - Replaced strnicmp() in GetActioArg() w/ Strnicmp().
**
** 00-08-08 rri - added RefreshWindows()
**
** 00-08-17 rri - added StampProt()
**
** 00-08-18 rri - created FilterStar() out of DMMatch()
**
** 00-08-27 rri - moved GetGlobuff() / FreeGlobuff() in from DMDisk.c
**              - rewritten GetGlobuff() to make it use a static buffer
**
** 00-08-29 rri - added FindCmdWin()
**
** 2.5b10
**
** 00-11-26 rri - moved DOSParse() in from DMCommand.c
**              - removed a little glitch in DOSParse - the resulting
**                string always started with " ".
**
** 00-12-22 jjt - Updated DMReq() call to DMReqTagList().
**
** 00-12-27 rri - removed four "warning 120"`s
**              - removed one "warning 220"
**              - changed two vars in GetActionArg() from UBYTE to LONG
**
** 01-01-12 jjt - Moved PoolAllocVec(), PoolFreeVec(), & CloneStr() from DMRead.c
**
** 01-01-14 jjt - Added safety checks to PoolFreeVec() & CloneStr().
**
** 01-02-18 rri - moved FindDMWin() and SetTitles() in from DM.c
**              - moved BootBatch() and FreeUserJunk() in from DM.c
**
** 2.5b11
**
** 01-03-01 jjt - Changed obsolete Intuition flag names to v36 versions:
**                  WINDOWACTIVE TO WFLG_WINDOWACTIVE.
**
** 01-04-22 jjt - Added Char2Nibble().
**
** 2.5b12
**
** 01-08-01 jjt - Added - RefreshDevLists().
**
** 01-08-03 jjt - RefreshDevLists() - Calls Busy().
**                                  - Replaced call to InitDir() with FreeDirTable() &
**                                    GetDevList().
**
** 2.5b13
**
** 01-08-11 rri - moved FindPattern() and Separate() from DMWindows.c
**
** 01-08-28 rri - reduced Globuff by 4 bytes to meet bug in ATAPI-ZIPs
**                as reported and tested by Alex Basana <ax.riez@biaccabi.com>
**
** 01-09-08 rri - localized visitor-windows warning from FreeUserJunk()
**              - changed header of display() to avoid warnings with
**                localized strings
**              - localized "out of memory" warning from GetGlobuff()
**
** 01-09-08 jjt - Changed DOSParse() & CloneStr() to remove #104 warnings.
**
** 01-09-10 rri - removed reqtags_Ok
**
** 10-09-29 jjt - Added reqtags_Ok.
**              - Changed FreeUserJunk() to use reqtags_Ok.
**
** 01-10-20 rri - new function: CheckMonth()
**
*/

#include "DM.h"

UBYTE DisplayBuffer[256],
      sbuff[512];

LONG Globuff_size,
     long_month=0; /* 2.5b13 rri */

UBYTE *Globuff;

struct Screen *MyScreen;


extern UBYTE *ActionArgs[],ScreenTitle[],ReqStr[];
extern int QuietFlag;
extern struct DirWindow *DirWin[],
                        *CDWin,
                        *CmdWin,
                        *DestWin;
extern struct Window    *Palette;

extern struct MsgPort   *WinPort;

extern int DWNum,
           KeepGloBuff; /* 2.5b8 rri */

extern UBYTE DefStart1[],
             DefStart2[],
             Strap[];

extern LONG  Bar_Height; /* 2.5b10 rri */

extern ULONG Screen_Width,Screen_Height; /* 2.5b9 rri */

extern struct TagItem reqtags_Ok[];  /* 2.5b13 jjt */



void StrToUpper(UBYTE *str) /* 2.5b7 rri */
{
int i=0;

while(str[i])
 {
  str[i]=ToUpper((ULONG) str[i]); /* 2.5b10 rri */
  i++;
 }
}


LONG GetActionArg(STRPTR keyword, UBYTE type, LONG def) {
  UBYTE *akw;
  LONG  idx=1,kwlen,val; /* 2.5b10 rri */

  /*  type = AATYPE_BOOL    - Returns <def> or index of keyword.
             AATYPE_NUM     - Returns <def> or <num>.
             AATYPE_STR     - Returns ptr to <def> or <str>.
             AATYPE_NEXTSTR - Returns ptr to <def> or the next ActionArg after <keyword>).
  */

  val = def;
  kwlen = (LONG) strlen(keyword); /* 2.5b10 ri */
  while ((akw = ActionArgs[idx++])) {
    if (Strnicmp(keyword, akw, kwlen) == 0) {
      if (type == AATYPE_BOOL) val = idx - 1;
      else if (type == AATYPE_NEXTSTR) {
        if ((akw = ActionArgs[idx])) val = (LONG) akw;
      }
      else {
        akw += kwlen;
        if (*akw != 0) {
          akw++;
          val = type == AATYPE_NUM ? atol(akw) : (LONG) akw;
        }
      }
      break;
    }
  }

  return val;
}


BOOL IsDir(STRPTR name) {
  BOOL dir=FALSE;
  BPTR l;
  struct FileInfoBlock fi;

  if ((l = Lock(name, ACCESS_READ))) {
    if (Examine(l, &fi)) dir = (fi.fib_DirEntryType > 0);
    UnLock(l);
  }

  return dir;
}


UBYTE *SkipWhite(UBYTE *ptr)
{
while(*ptr==' '||*ptr==9) ptr++;
return(ptr);
}


BOOL AArg2Str(STRPTR keyword, STRPTR dest, int length, BOOL upper, STRPTR def) {  /* 2.5b6 jjt */
  strncpy(dest, (STRPTR) GetActionArg(keyword, AATYPE_NEXTSTR, (LONG) def), length);
  if (upper) StrToUpper(dest); /* 2.5b7 rri */
  return (BOOL) (*dest != 0);
}


void display(const UBYTE format[],UBYTE *arg1)
{
sprintf(DisplayBuffer,format,arg1); /* new! 2.5b4 */

if(QuietFlag) return; /* 2.5b5 rri */

strcpy(ScreenTitle,DisplayBuffer); /* 2.5b5 rri */

SetTitles();

}


void QuoteCat(UBYTE *ptr,UBYTE *name)
{
int q=NeedQuote(name);

if(q) strcat(ptr,"\"");
strcat(ptr,name);
if(q) strcat(ptr,"\"");
}


int NeedQuote(UBYTE *ptr)
{

while(*ptr)
 {
  if(*ptr==' ') return(1);
  if(*ptr=='\\') return(0);
  ptr++;
 }
return(0);
}


int DMMatch(UBYTE *string,UBYTE *pattern) /* 2.5b7 rri */
{
UBYTE buffer[100];

strcpy(buffer,pattern);
FilterStar(buffer);
ParsePatternNoCase(buffer,ReqStr,300);
return(MatchPatternNoCase(ReqStr,string));

}


void RefreshWindows(void) /* 2.5b7 rri */
{
int i;
struct DirWindow *dw;

for(i=0;i<255;i++)
 {
  if(dw=DirWin[i])
   {
    dis_files(dw);
    WinTitle(dw);
   }
 }
}


void StampProt(UBYTE *str,LONG prot) /* 2.5b7 rri */
{
int a;

sprintf(str,"HSPARWED");

for (a=7;a>=4;a--)
 {
  if (!(prot&(1<<a)))
   {
    str[7-a]='-';
   }
 }
for (a=3;a>=0;a--)
 {
  if (prot&(1<<a))
   {
    str[7-a]='-';
   }
 }
}


void FilterStar(UBYTE *pattern) /* 2.5b7 rri */
{
UBYTE buffer[100];
int x,i;

x=i=0;

while(pattern[i]&&i<100) /* filter out stars */
{
 if (pattern[i]!='*')
  {
   buffer[x++]=pattern[i++];
  }
 else
  {
   buffer[x++]='#';
   buffer[x++]='?';
   i++;
   }
 }
buffer[x]=0;

strcpy(pattern,buffer);
}


int GetGlobuff() /* 2.5b7 rri */
{

if(Globuff)
 {
  memset(Globuff,0,(size_t) Globuff_size); /* 2.5b10 rri */
  return(1);
 }

Globuff_size=(1<<17)-4; /* allocate 128K-4bytes - ATAPI-ZIP bug... 2.5b13 rri */

if(!(Globuff=(UBYTE *)AllocMem(Globuff_size,MEMF_PUBLIC|MEMF_CLEAR)))
 {
  Globuff_size=(1<<16)-4; /* second try with 64K-4bytes  2.5b13 rri  */
  if(!(Globuff=(UBYTE *)AllocMem(Globuff_size,MEMF_PUBLIC|MEMF_CLEAR)))
   {
    display(msgErrorNoMemory,0); /* 2.5b13 rri */
    return(0);
   }
 }

return(1);
}


void FreeGlobuff()
{
if(Globuff)
 {
  FreeMem(Globuff,Globuff_size);
  Globuff=0;
 }
}


void FindCmdWin(void) /* 2.5b7 rri */
{
int i;

i=0;

while(i<255)
 {
  if (DirWin[i])
   {
    if(DirWin[i]->Flags&DW_CMD)
     {
      CmdWin=DirWin[i];
     }
   }
  i++;
 }
}


int DOSParse(UBYTE *str,const UBYTE *hail,int i) /* new! 2.2b14 */
{
UBYTE   *ptr=str,*ptr2;
int     q,s;

s=i; /* 2.5b10 */

while(ActionArgs[i])
 {
  ptr2=ActionArgs[i];
  if (i!=s) /* 2.5b10 rri */
   {
    *ptr++=' ';
   }
  q=NeedQuote(ptr2);
  if(q) *ptr++='"';

  while(*ptr2)
   {
    if(*ptr2=='\\')
     {
      if(q) *ptr++='"';
      ptr2++;
      *ptr++='\n';
      q=NeedQuote(ptr2);
     }
    *ptr++ = *ptr2++;
   }
  if(q) *ptr++='"';
  *ptr=0;
  i++;
 }
if(i<2&&!DMReqTagList(hail, str, 200, 0)) return(0); /* 2.5b10 jjt */
return(1);
}


APTR PoolAllocVec(APTR mempool, ULONG size) {  /* 2.5b10 jjt */
  ULONG *mem;

  size += 8;
  if ((mem = AsmAllocPooled(mempool, size, SysBase))) {
    *mem++ = (ULONG) mempool;  /* Store mem-pool addr. (will be ptr - 8 bytes) */
    *mem++ = size;             /* Store string len.    (will be ptr - 4 bytes) */
  }

  return (APTR) mem;
}


void PoolFreeVec(APTR memptr) {  /* 2.5b10 jjt */
  ULONG *mem;

  /*
     memptr - 8 bytes = actual start of mem block.
     *(memptr - 8 bytes) = mem-pool addr.
     *(memptr - 4 bytes) = mem length.
  */

  if (memptr) {
    mem = (ULONG *) memptr;
    AsmFreePooled((APTR) (*(mem - 2)), mem - 2, *(mem - 1), SysBase);
  }
}


STRPTR CloneStr(CONST_STRPTR str, APTR mempool) {  /* 2.5b10 jjt */
  STRPTR newstr=NULL;

  if ((str) && (*str)) {
    if ((newstr = PoolAllocVec(mempool, (ULONG) (strlen(str) + 1)))) strcpy(newstr, str);
  }
  return newstr;
}


struct DirWindow *FindDMWin(struct Window *win)
{
struct DirWindow *olddw=CDWin,*dmw=NULL;
int i;

for(i=0;i<255;i++)
 {
  if(DirWin[i])
   {
    dmw=DirWin[i];
    if(win==dmw->Window)
     {
      if(dmw->Flags&DW_CMD)
       {
        CmdWin=dmw;
        DWNum=i;
        ShowDirection(dmw,2);
        return(dmw);
       }
      break;
     }
   }
 }

if(dmw&&(dmw->Window->Flags&WFLG_WINDOWACTIVE))
 {
  DWNum=i;
  CDWin=dmw;
  if(CDWin!=olddw)
   {
    if(!(olddw->Flags&DW_SOURCE))
     {
      ShowDirection(DestWin,3);
      DestWin=olddw;
     }
    ShowDirection(DestWin,1);
    ShowDirection(CDWin,0);
   }
 }

return(dmw);
}


void SetTitles()
{
struct DirWindow *dw;
UBYTE *ptr=ScreenTitle;
int     i;

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(dw&&(dw->Window->Flags&WFLG_WINDOWACTIVE))
   {
    SetWindowTitles(dw->Window,dw->Title,ptr);
    break;
   }
 }
}


void FreeUserJunk()
{
struct IntuiMessage *msg;
int i;

CloseRead();  /* 2.5b7 jjt */

if(Palette) OpenPalette();
for(i=0;i<255;i++) if(DirWin[i])
 {
  CloseDirWindow(i);
  DirWin[i]=0;
  while(msg=(struct IntuiMessage *)GetMsg(WinPort))
   {
    ReplyMsg((struct Message *)msg);
   }
 }

CDWin=DestWin=CmdWin=0;
MyFreeMenus();
FreeAutoCmds();
FreeKeyCmds();
DoStdio("CLOSE");

if(!KeepGloBuff) /* 2.5b8 rri */
 {
  FreeGlobuff(); /* 2.5b7 rri */
 }

GetHostScreen(0);
if(MyScreen)
 {
  while (CheckScreen()) /* new! 2.4 */
   {
    DMReqTagList(msgErrorVisitorWindows, 0, 0, reqtags_Ok);  /* 2.5b13 jjt */
   }
  CloseScreen(MyScreen);
  InitScreenDefaults(); /* new! 2.5b5 */
  MyScreen=0;
 }
}


int BootBatch(UBYTE *ptr)
{
struct WBArg *argptr;
UBYTE *ptr2;
BPTR lock; /* 2.5b6 rri */
int inq=0;

if(*ptr==0)
 {
  argptr=_WBenchMsg->sm_ArgList;
  argptr++;
  if(_WBenchMsg->sm_NumArgs>1)
   {
    CurrentDir(argptr->wa_Lock);
    strcpy(Strap+4,argptr->wa_Name);
   }
 }
else
 {
  if(*ptr=='"')
   {
    inq=1;
    ptr++;
   }
  if(inq)
   {
    while(*ptr!='"')
     {
      ptr++;
     }
    *ptr++=0;
   }
  else
   {
     while(*ptr!=' ')
      {
       ptr++;
      }
    }
  while(*ptr==' ')
   {
    ptr++;
   }
  ptr2=ptr;
  while(*ptr2!='\n')
   {
    ptr2++;
   }
  *ptr2=0;
  if(*ptr)
   {
    strcpy(Strap+4,ptr);
   }
 }

if(lock=Lock(Strap+4,ACCESS_READ))
 {
  UnLock(lock);
  GetCmdFile(0,Strap+4,0); /* 2.5b7 rri */
 }
else
 {
  if(lock=Lock(Strap+2,ACCESS_READ))
   {
    UnLock(lock);
    GetCmdFile(0,Strap+2,0); /* 2.5b7 rri */
   }
  else
   {
    if(*ptr=='"')
     {
      ActionCmd(0,ptr+1);
     }
    else
     {

 /* 2.5b9 rri */

      ActionCmd(0,DefStart1);
      if (!GetGlobuff()) return(0);
      inq=Screen_Width/5;
      sprintf(Globuff,"OpenW %ld %ld %ld %ld CMD\n",inq*2,Bar_Height+1,inq,Screen_Height);
      sprintf(sbuff,"OpenW %ld %ld %ld %ld\n",0,Bar_Height+1,inq*2,Screen_Height);
      strcat(Globuff,sbuff);
      sprintf(sbuff,"OpenW %ld %ld %ld %ld\n",inq*3,Bar_Height+1,inq*2,Screen_Height);
      strcat(Globuff,sbuff);
      strcat(Globuff,DefStart2);
      ActionCmd(0,Globuff);
      About();
     }
   }
 }

if(DirWin[0])
 {
  FindCmdWin(); /* 2.5b7 rri */
  return(1);
 }
}


ULONG Char2Nibble(ULONG c) {  /* 2.5b11 jjt */

  /* Returns 0 - 15, or 255 if <c> isn't a hex digit. */

  if (isxdigit(c)) {
    c |= 32;  /* Letters to lowercase; no effect on numbers. */
    c -= c < 'a' ? '0' : 87;
  }

  return c;
}


void RefreshDevLists(void) {  /* 2.5b12 jjt */
  ULONG i;
  struct DirWindow *dw;

  Busy(1);
  for (i=0; i<255; i++) {
    if (dw=DirWin[i]) {
      if (((dw->Flags & DW_CMD) == 0) && (dw->Path[0] == 0)) {
        FreeDirTable(dw);
        GetDevList(dw);
      }
    }
  }
  Busy(0);
}


int FindPattern(UBYTE *str)
{
while(*str)
 {
  if(*str=='*'||*str=='?'||*str=='#') return(1);
  str++;
 }
return(0);
}


void Separate(struct DirWindow *dw)
{
UBYTE *mark,*str=dw->Path;
int len=strlen(str);

mark=str; /* 2.5b10 rri */
dw->Pattern[0]=0; /* new! 2.4 */

while(len)
 {
  if(str[len]==':')
   {
    mark=str+len+1;
    break;
   }
 if(str[len]=='/')
  {
   mark=str+len;
   *mark=0;
   mark++;
   break;
  }
  len--;
 }
strcpy(dw->Pattern,mark);
*mark=0;
StrToUpper(dw->Pattern); /* 2.5b7 rri */
}


void CheckMonth() /* 2.5b13 rri */
{
struct DateTime DateTime;
UBYTE  Date[16];

DateTime.dat_Stamp.ds_Days = 160; /* 78-Jun-10 */
DateTime.dat_Stamp.ds_Minute = 0;
DateTime.dat_Stamp.ds_Tick = 20;

DateTime.dat_Format  = FORMAT_INT; /* yy-mmm-dd e.g. 00-Jul-13 */
DateTime.dat_Flags   = 0;
DateTime.dat_StrDay  = 0;
DateTime.dat_StrDate = Date;
DateTime.dat_StrTime = 0;

DateToStr(&DateTime);

if(Date[6]!='-') long_month = 1;
}
