/* DiskMaster II  Config Module    SaveConfig
**
** 2.5b6 - 2000-06-08: SaveMenu code adapted to BARLABELs. - hys
**
** 00-06-05 rri -reworked the internal Startup.DM
**
** 00-06-22 jjt
** - Changed the internal Startup.DM:
**   - Restored the "Pack" & "Unpack" items in the "Archive" menu.
**   - Removed the "AddA TEXT..." line.
**   - Removed the "HEX" arg from the "AddA DEFAULT..." line.
**     (Otherwise crunched texts were forced into hex mode.)
**   - Typo in the "AddC Delete..." line - "file3" instead of "files".
**   - Added "AddC Find Text..." line.
**
** 00-07-11 rri - changed internal Startup.DM to new autocmd style
**              - replaced all c++ style comments by ANSI ones
**              - changed various stricmp() to Stricmp() calls
**              - added Iconfy()
**              - replaced DiskMaster Icon
**              - modified SaveConfig() to use an allocated buffer
**
** 00-08-27 rri - modified Iconfy() to use GetGlobuff(),
**                new global var "iconify" to signal FreeUserJunk()
**                not to call FreeGlobuff()
**              - modified SaveConfig() to use GetGlobuff()
**              - new sub-routine FillSaveBuffer() to have less code double
**              - fixed a bug with Iconify() that caused a confused
**                command-window
**
** 00-08-29 rri - Added a FindCmdWin() call to Iconify() to fix an enforcer-hit
**                with not initialized var "CmdWin"
**
** 2.5b8
**
** 00-09-07 rri - changed var "iconify" to "KeepGloBuff"
**
** 2.5b9
**
** 00-10-04 rri - removed some flagged-out lines from internal startup.dm
**              - removed some lines from internal startup.dm`s
**                "Project" menu to simplify things for newbies a bit
**              - added IFF recognition to auto-command
**              - splitted internal startup.dm into two parts to make
**                screen-relative windows possible
**
** 00-10-06 rri - added configureable icon position to Iconify()
**              - 'SetX' is now a member of the startup.dm
**
** 00-11-21 rri - added 'Quit' and 'Wake' ARexx-commands to Iconify()
**
** 00-11-22 rri - fixed a silly last-minute bug in Iconify()
**
** 00-12-22 jjt - Updated a DMReq() call to the new format.
**
** 2.5b10
**
** 00-12-26 rri - remove one "warning 120"
**
** 01-01-10 rri - change one "->name" to "->name2" in SaveWin()
**
** 01-01-28 rri - changed ->name2 reference in SaveWin() back to ->name
**
** 01-02-04 rri - made default menu-structure more style-guide friendly
**                suggested by Gerd Frank <Gerd.Frank@gmx.de>
**
** 01-02-05 rri - added BatchFlag
**              - with BatchFlag the menus are disabled untill all windows
**                are opened now
**              - added deactivation of windows message-port during
**                restart after iconification
**
** 2.5b11
**
** 01-03-01 jjt - Changed obsolete Intuition flag names to v36 versions:
**                  GADGIMMEDIATE to GACT_IMMEDIATE,
**                  RELVERIFY to GACT_RELVERIFY.
**
** 01-07-15 rri - 'SaveConfig' won't save more than (UserColors)
**
** 2.5b12
**
** 01-07-25 rri - usage of GetRGB4() to print out the colors instead
**                of peeking into the color-table directly
**              - SetX()'s UserColors are saved, too
**
** 01-07-26 rri - simplified SaveScreen()s pen-saving
**              - adds "Notify" to 'SetX' when set
**              - modified SaveWin() to save 'AddCmd' lines either
**                with hex-values and with the second pen-set
**
** 01-07-29 rri - adds BPen, DPen, FPen and SPen to 'SetX'
**
** 2.5b13
**
** 01-08-14 rri - fixed an enforcer hit with 'Iconify' beeing called
**                directly from the Startup.DM
**
** 01-08-15 rri - Bugfix: freeing a message to early may cause mungwall-hits...
**                Reported by Ed Vishoot.
**
**
** 01-08-25 rri - Bugfix: IconY did not get saved correctly
**                Reported by Ed Vishoot.
**              - Bugfix: The "Icon" button from the 'SaveConfig' requester
**                had no effect since 2.5b10...
**              - 'Iconify' uses the alternative icon provided
**                with 'SetX appicon=<file>'
**
** 01-08-26 rri - "AddIcon=<file>" added to 'SetX' in 'SaveConfig'
**
** 01-09-09 rri - localisation: 'SaveConfig' - msgReqSave, msgGadCIC
**
** 01-09-16 rri - SaveWin() - norm[] and zoom[] are used for the dimensions now
**
** 01-09-18 rri - replaced msgGadCIC from SaveConfig()
**                by a MakeBtnString(0, msgGadIcon, 0); initialised g_buttons
**
** 01-09-22 rri - added "Zoomed" option to SaveWin()
**
** 01-10-14 rri - Bugfix: without CMD-window 'Iconify' issued an enforcer-hit
**
*/

#include "DM.h"

extern int Abort,
           BatchFlag,
           digits,  /* 2.5b9 rri */
           FontSize,
           KeepGoing, /* 2.5b9 rri */
           Notify; /* 2.5b12 */

extern UBYTE 
             *_ProgramName,
             *ActionArgs[],
             *AppIconPath, /* 2.5b13 rri */
             *AutoCmdStr[],
             BarFormat[],
             dcPath[],
             DispFormat[],
             DMname[], /* 2.5b7 rri */
             FontName[],
             g_buttons[], /* 2.5b13 rri */
             *Globuff, /* 2.5b7 rri */
             *KeyCmdStr[],
             PGadStr[],
             sbuff[],
             Strap[],
             TitleFormat[];

extern UWORD Pens20[],Screen_Depth;

extern ULONG Screen_Width,Screen_Height,Screen_ID,
             UserColors; /* 2.5b11 rri */

extern LONG Globuff_size; /* 2.5b7 rri */

extern LONG DirPen, FilePen, BackPen, SelectPen; /* 2.5b12 rri */

extern struct DirWindow *DirWin[],*CmdWin;
extern struct Menu *DMMenu;
extern struct Screen *MyScreen;

extern struct TextFont *DMFont;
extern struct MsgPort *WinPort; /* 2.5b7 rri */

int KeepGloBuff; /* 2.5b8 rri */

LONG IconX=NO_ICON_POSITION,IconY=NO_ICON_POSITION; /* 2.5b9 rri */

UBYTE DefStart1[]= /* 2.5b10 rri */
   "NewS\n"

   "AddM Project,Iconify,I,Iconify\n"
   "AddM Project,Barlabel,\n"
   "AddM Project,About,?,About\n"
   "AddM Project,Barlabel,\n"
   "AddM Project,Quit,Q,Confirm \"Really quit now?\" Yes No;Quit\n"

   "AddM Options,Display Format,F,SetFormat\n"
   "AddM Options,Change Font,Font\n"
   "AddM Options,Palette,Color\n"
   "AddM Options,Barlabel,\n"
   "AddM Options,Load Config,L,Batch S:Startup.DM\n"
   "AddM Options,Save Config,S,SaveConfig\n"
   "AddM Options,Edit S:Startup.DM,E,ScrBack;Extern Ed S:Startup.DM;ScrFront\n"

   "AddM Tools,Execute Command...,Extern\n"
   "AddM Tools,Run Selected,Single;Extern run %s\n"
   "AddM Tools,Print Dir,PrintDir %s prt:\n"

   "AddM Archives,Lha Add,StdIO \"CON:0/12/640/100/Add\";Archive \"Lha -r a\";StdIO CLOSE\n"
   "AddM Archives,Lha Extract,StdIO \"CON:0/12/640/100/Extract\";Extern Lha x %s;StdIO CLOSE\n"
   "AddM Archives,Lha X >Dest,StdIO \"CON:0/12/640/100/Extract\";Extern Lha x %s %d;StdIO CLOSE\n" /* 2.5b6 rri */
   "AddM Archives,Lha X Req,Confirm \"Enter destination path\" Continue Cancel %P;StdIO \"CON:0/12/640/100/Extract\";Extern Lha x %s %r;StdIO CLOSE\n" /* 2.5b6 rri */
   "AddM Archives,Lha List,StdIO \"CON:0/12/640/160/List\";Extern Lha v %s;Wait;StdIO CLOSE\n"
   "AddM Archives,Pack,Pack %s TO %d SUFFIX KEEPORIG\n" /* 2.5b6 jjt */
   "AddM Archives,Unpack,Unpack %s TO %d KEEPORIG\n"    /* 2.5b6 jjt */

   "AddM Control,Sort by Name,Sort N g\n"
   "AddM Control,Sort by Comment,Sort C g\n"
   "AddM Control,Sort by Date,Sort D g\n"
   "AddM Control,Sort by Size,Sort S g\n";


UBYTE DefStart2[]= /* 2.5b9 rri */
   "AddC Root,10, Root\n"
   "AddC Parent,10,Parent\n"
   "AddC All,30,Select *\n"
   "AddC Clear,30,Deselect *\n"
   "AddC Select,30,Select\n"
   "AddC Exclude,30,DeSelect\n"
   "AddC Copy,20,ReqPattern;Copy %s %d\n"
   "AddC Move,20,ReqPattern;Move %s %d\n"
   "AddC Delete,30,ReqPattern;Confirm \"All selected files will be lost!\";Delete %s\n"
   "AddC Rename,20,Recurse OFF;Rename %s\n"
   "AddC Protect,20,Recurse OFF;Protect %s\n"
   "AddC Comment,20,Recurse OFF;Comment %s\n"
   "AddC Find File,20,ReqPattern \"Please enter a search pattern:\";Find %s\n"
   "AddC Find Text,20,Read %s SEARCH\n"  /* 2.5b6 jjt (22.6.00) */
   "AddC Read,20,Read %s wait\n"
   "AddC HexRead,20,Read %s HEX wait\n"
   "AddC MakeDir,20,MakeDir\n"
   "AddC Size Check,20,UnMark OFF;Check %s\n"

   "AddA ??-lh#?,StdIO \"CON:0/12/640/100/Extract\";Extern Lha x %s;StdIO CLOSE\n"
   "AddA PK#?,StdIO \"CON:0/12/640/100/DM II\";Extern UnZIP %s;StdIO CLOSE\n"
   "AddA (FORM????ILBM#?|@database#?),View %s\n" /* 2.5b9 rri */
   "AddA DEFAULT,Read %s wait\n"  /* 2.5b6 jjt (22.6.00) */
   "\x0";


UWORD RenderImageData[] =
{
  0xffff,0xffff,0xffff,0xffff,0xffff,0xf81f,0xffff,0xffff,
  0xe007,0xffff,0xffff,0xe007,0xffff,0xffff,0xc183,0xffff,
  0xffff,0xc3c3,0xffff,0xffff,0xc3c3,0xffff,0xffff,0xff83,
  0xffff,0xffff,0xff87,0xffff,0xffff,0xff07,0xffff,0xffff,
  0xfe0f,0xffff,0xffff,0xfc1f,0xffff,0xffff,0xf83f,0xffff,
  0xffff,0xf001,0xffff,0xffff,0xe001,0xffff,0xffff,0xc001,
  0xffff,0xffff,0xffff,0x0000,0x0000,0x0000,0x0000,0x7c7c,
  0x07e0,0x0000,0x7c7c,0x1ff8,0x0000,0x7c7c,0x1ff8,0x0000,
  0x7c7c,0x3e7c,0x0000,0xfefe,0x3c3c,0x0000,0xfefe,0x3c3c,
  0x0000,0xfefe,0x007c,0x0000,0xeeee,0x0078,0x0001,0xefef,
  0x00f8,0x0001,0xefef,0x01f0,0x0001,0xefef,0x03e0,0x0001,
  0xc7c7,0x07c0,0x0003,0xc7c7,0x8ffe,0x0003,0xc7c7,0x9ffe,
  0x0003,0xc7c7,0xbffe,0x0000,0x0000,0x0000,0x0000,0x0000,
  0x0000,0x7fc0,0x7c7c,0x0000,0x7ff0,0x7c7c,0x0000,0x7ff8,
  0x7c7c,0x0000,0x7878,0x7c7c,0x0000,0x783c,0xfefe,0x0000,
  0x783c,0xfefe,0x0000,0x783c,0xfefe,0x0000,0x783c,0xeeee,
  0x0000,0x783d,0xefef,0x0000,0x783d,0xefef,0x0000,0x783d,
  0xefef,0x0000,0x7879,0xc7c7,0x0000,0x7ffb,0xc7c7,0x8000,
  0x7ff3,0xc7c7,0x8000,0x7fc3,0xc7c7,0x8000,0x0000,0x0000,
  0x0000,
};

struct Image RenderImage=
{
 0,0,   /* Top Corner */
 48,17, /* Width, Height */
 3,     /* Depth */
 &RenderImageData[0], /* Image Data */
 7, 0,  /* PlanePick,PlaneOnOff */
 NULL   /* Next Image */
};

UWORD SelectRenderData[] =
{
  0xffff,0xc007,0xffff,0xffff,0x0000,0x707f,0xfffe,0x0000,
  0x707f,0xfffe,0x07c0,0x707f,0xfffe,0x07c0,0x707f,0xffff,
  0x7fc0,0x203f,0xffff,0x7f81,0x203f,0xffff,0xff01,0x203f,
  0xffff,0xfe02,0x223f,0xffff,0xfc06,0x021f,0xffff,0xf80e,
  0x021f,0xffff,0xf01a,0x021f,0xffff,0xe037,0x071f,0xffff,
  0xc000,0x070f,0xffff,0x8000,0x070f,0xffff,0x0000,0x070f,
  0xfffe,0x0000,0x7fff,0x0000,0x3ff8,0x0000,0x0000,0xfffe,
  0x0f80,0x0001,0xffff,0x0f80,0x0001,0xf83f,0x0f80,0x0001,
  0xf83f,0x0f80,0x0000,0x703f,0x1fc0,0x0000,0x707f,0x1fc0,
  0x0000,0x00ff,0x1fc0,0x0000,0x01fc,0x5dc0,0x0000,0x03fc,
  0x7de0,0x0000,0x07fc,0xfde0,0x0000,0x0ff9,0xfde0,0x0000,
  0x1ff0,0xf8e0,0x0000,0x3fff,0xf8f0,0x0000,0x7fff,0xf8f0,
  0x0000,0xffff,0x98f0,0x0001,0xffff,0x8000,0x0000,0x0000,
  0x0000,0x01ff,0x0001,0x8f80,0x01fe,0x0000,0x8f80,0x01fe,
  0x0000,0x8f80,0x01e0,0x0000,0x8f80,0x01e0,0x8000,0xdfc0,
  0x01e0,0x8000,0xdfc0,0x01e0,0xf000,0xdfc0,0x01e0,0xf001,
  0xddc0,0x01e0,0xf001,0xfde0,0x01e0,0xf001,0xfde0,0x01e0,
  0xf005,0xfde0,0x01e1,0xe008,0xf8e0,0x01ff,0xc000,0x78f0,
  0x01ff,0x8000,0x78f0,0x01ff,0x0000,0x78f0,0x0000,0x0000,
  0x0000,
};

struct Image SelectRender=
{
 0,0,
 48,17,
 3,
 &SelectRenderData[0],
 7,0,
 NULL
};



struct DiskObject do_dm_config=
 {
  WB_DISKMAGIC,
  WB_DISKVERSION,
   { /* Embedded Gadget Structure */
    NULL, /* Next Gadget Pointer */
    0,    /* LeftEdge */
    0,    /* TopEdge */
    48,   /* Width */
    17,   /* Height */
    GFLG_GADGHIMAGE|GFLG_GADGIMAGE, /* Flags */
    GACT_IMMEDIATE|GACT_RELVERIFY, /* Activation */
    GTYP_BOOLGADGET, /* GadgetType */
    (APTR)&RenderImage, /* GadgetRender */
    (APTR)&SelectRender, /* SelectRender */
    NULL, /* *GadgetText */
    NULL, /* MutualExclude */
    NULL, /* SpecialInfo */
    0, /* GadgetID */
    NULL /* UserData */
   },
  WBPROJECT, /* Icon Type */
  "", /* Default Tool */
  NULL, /* Tool Type Array */
  NO_ICON_POSITION, /* Current X */
  NO_ICON_POSITION, /* Current Y */
  NULL, /* Drawer Structure */
  NULL, /* Tool Window */
  4096 /* Stack Size */
 };



void FillSaveBuffer(UBYTE *savebuffer) /* 2.5b7 rri */
{
 sprintf(savebuffer,"Reset\n");
 SaveScreen(savebuffer);
 SaveMenus(savebuffer);
 SaveWindows(savebuffer);
}


void SaveConfig() /* new! 2.2b15 */
{
UBYTE *buf=ActionArgs[1];
BPTR fh;
int icon,n=1;

icon=GetActionArg("ICON",AATYPE_BOOL,0); /* 2.5b7 rri */

if(!buf||*buf==0||(Stricmp(buf,"ICON")==0))
 {
  buf=Strap+4;
  MakeBtnString(0, msgGadIcon, 0);  /* 2.5b13 rri */
  n=DMReq(msgReqSave, buf, 128, DMREQ_BUTTONS,g_buttons, TAG_END);  /* 2.5b13 rri */
 }

if(n)
 {
  if (!GetGlobuff()) return; /* 2.5b7 rri */
  if(fh=Open(buf,MODE_NEWFILE))
   {
    FillSaveBuffer(Globuff); /* 2.5b7 rri */
    Write(fh,Globuff,(ULONG) strlen(Globuff)); /* 2.5b10 rri */
    Close(fh);
    SmartAddEntry(buf);
    if(icon||n==2) /* 2.5b13 rri */
     {
      strcpy(sbuff,_ProgramName);
      do_dm_config.do_DefaultTool=sbuff;
      PutDiskObject(buf,&do_dm_config);
      sprintf(sbuff,"%s.info",buf);
      SmartAddEntry(sbuff);
     } /* if (Icon)... */
   } /* if (fh=... */
 } /* if(n)... */
}




void SaveScreen(UBYTE *savebuffer)
{
UBYTE *ptr; /* new! 2.4b21 */

LONG i,cols; /* 2.5b12 rri */
struct DrawInfo *dri; /* new! 2.4 */

ptr=sbuff;

if(MyScreen)
 {
  strcat(savebuffer,"Pens ");
  if(dri=GetScreenDrawInfo(MyScreen)) /* new! 2.4 */
   {
    for(i=0;i<(dri->dri_NumPens);i++)
     {
      sprintf(ptr,"%ld ",dri->dri_Pens[i]); /* 2.5b12 rri */
      ptr+=strlen(ptr); /* 2.5b12 rri */
     }
    FreeScreenDrawInfo(MyScreen,dri);
    sprintf(ptr,"\n"); /* 2.5b12 rri */
    strcat(savebuffer,sbuff);
   }

  sprintf(sbuff,"NewScreen ID=%ld D=%ld W=%ld H=%ld\n",
          Screen_ID,Screen_Depth,Screen_Width,Screen_Height); /* new! 2.2b11 */
  strcat(savebuffer,sbuff);

  strcpy(sbuff,"Color ");
  ptr=sbuff+6;
  cols=1<<MyScreen->BitMap.Depth;
  if(UserColors<cols) cols=UserColors; /* 2.5b11 rri */
  if(cols>29) cols=29; /* 2.5b12 rri */

  for(i=0;i<cols;i++)
   {
    sprintf(ptr,"%03.3lx ",GetRGB4(MyScreen->ViewPort.ColorMap,i)); /* 2.5b12 rri */
    ptr+=4;
   }
  ptr--;
  *ptr++=10;
  *ptr=0;
  strcat(savebuffer,sbuff);
 }

if(DMFont)
 {
  sprintf(sbuff,"Font %s %ld\n",FontName,FontSize); /* new! 2.4 */
  strcat(savebuffer,sbuff);
 }

sprintf(sbuff,"SetX digits=%ld BPen=%ld DPen=%ld FPen=%ld SPen=%ld",
                    digits,BackPen,DirPen,FilePen,SelectPen);  /* 2.5b12 rri */

if(Notify) /* 2.5b12 rri */
 {
  strcat(sbuff," Notify");
 }

if(IconX!=NO_ICON_POSITION)
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," IconX=%ld",IconX);
 }

if(IconY!=NO_ICON_POSITION)
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," IconY=%ld",IconY);
 }

if(AppIconPath) /* 2.5b13 rri */
 {
  strcat(sbuff," AppIcon=");
  strcat(sbuff,AppIconPath);
 }

if(UserColors>4) /* 2.5b12 rri */
 {
  ptr=sbuff+strlen(sbuff);
  sprintf(ptr," UserColors=%ld",UserColors);
 }

strcat(sbuff,"\n\n");
strcat(savebuffer,sbuff);
}


void SaveMenus(UBYTE *savebuffer)
{
struct Menu *menu=DMMenu;
struct MenuItem *item;
struct IntuiText *itext;
UBYTE *ptr,*ptr2,*ptr3,cmd[4],c;

while(menu)
 {
  item=menu->FirstItem;
  ptr=menu->MenuName;
  while(item)
   {
    itext=(struct IntuiText *)item->ItemFill;
    ptr2=itext->IText;

    ptr3 = GTMENUITEM_USERDATA(item); /* 2.5b5 hys */
    if(ptr3 == NM_BARLABEL)
     {
      sprintf(sbuff, "AddMenu %s, BARLABEL,\n", ptr);
     }
    else
     {
      c=item->Command;
      cmd[0]=cmd[3]=0;
      cmd[1]=',';
      cmd[2]=' ';
      if(c) cmd[0]=c;
      sprintf(sbuff,"AddMenu %s, %s, %s%s\n",ptr,ptr2,cmd,ptr3);
     }
    strcat(savebuffer,sbuff);
    item=item->NextItem;
   }
  menu=menu->NextMenu;
  strcat(savebuffer,"\n");
 }
}


void SaveWindows(UBYTE *savebuffer)
{
struct DirWindow *dw;
UBYTE *ptr;
int i;

sprintf(sbuff,"Button \"%s\"\nSetFormat \"%s\"\nBarFormat \"%s\"\nTitleFormat \"%s\"\n\n",
        PGadStr,DispFormat,BarFormat,TitleFormat);
strcat(savebuffer,sbuff);

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(dw) SaveWin(dw,savebuffer);
 }
for(i=0;i<255;i++)
if(ptr=AutoCmdStr[i])
 {
  sprintf(sbuff,"AddAutoCmd %s\n",ptr);
  strcat(savebuffer,sbuff);
 }
strcat(savebuffer,"\n");
for(i=0;i<100;i++)
if(ptr=KeyCmdStr[i])
 {
  sprintf(sbuff,"AddKeyCmd %s\n",ptr);
  strcat(savebuffer,sbuff);
 }
}


void SaveWin(struct DirWindow *dw,UBYTE *savebuffer)
{
struct DirList **dl,*dlp;
UBYTE *ptr=dw->Path,*ptr2="\n";
int ct=0,j;

if(dw->Flags&DW_CMD)
 {
  ct=1;
  ptr="CMD";
 }
if(dw->Flags&DW_SOURCE) ptr2="Lock S\n";
if(dw->Flags&DW_DEST  ) ptr2="Lock D\n";

sprintf(sbuff,"OpenWindow %ld %ld %ld %ld \"%s\" "
              "ZoomL=%ld ZoomT=%ld ZoomW=%ld ZoomH=%ld", /* 2.5b13 rri */
               dw->norm[0],dw->norm[1],dw->norm[2],dw->norm[3],ptr, /* 2.5b13 rri */
               dw->zoom[0],dw->zoom[1],dw->zoom[2],dw->zoom[3]); /* 2.5b13 rri */

if(dw->Window->Flags&WFLG_ZOOMED) /* 2.5b13 rri */
 {
  strcat(sbuff," Zoomed\n");
 }
else strcat(sbuff,"\n");

strcat(sbuff,ptr2);
strcat(savebuffer,sbuff);

if(ct)
 {
  dl=dw->DirList;
  for(j=0;j<dw->FileCount;j++)
   {
    dlp=dl[j];
    /* 2.5b12 rri */
    sprintf(sbuff,"AddCmd %s, %lx%lx, %lx%lx, %s\n",dlp->name,
    dlp->attr&0xf,(dlp->attr>>4)&0xf,(dlp->attr>>8)&0xf,(dlp->attr>>12)&0xf,
    dlp->cmt);
    strcat(savebuffer,sbuff);
   }
  strcat(savebuffer,"\n");
 }
}


void Iconify(void) /* 2.5b7 rri */
{
struct AppIcon *appicon;
struct AppMessage *appmsg;
struct RexxMsg *rexxmsg;
struct IntuiMessage *msg;
int loop=1;
struct DiskObject *diskobj=0; /* 2.5b13 rri */
struct Gadget do_dm_config_gadget; /* 2.5b13 rri */


if(BatchFlag)
 {
  return; /* 2.5b13 rri */
 }

KeepGloBuff=1;

do_dm_config_gadget=do_dm_config.do_Gadget; /* 2.5b13 rri */

do_dm_config.do_Type=NULL;
do_dm_config.do_CurrentX = IconX; /* 2.5b9 rri */
do_dm_config.do_CurrentY = IconY; /* 2.5b9 rri */

if (LibOpen("workbench.library", &WorkbenchBase, 37))
 {
  if (!GetGlobuff()) return;
  FillSaveBuffer(Globuff);

  if(!CmdWin) /* 2.5b13 rri */
   {
    FindCmdWin();
   }
  if(CmdWin) /* 2.5b13 rri */
   {
    strcpy(dcPath,CmdWin->Path);
   }

  FreeUserJunk();

  if(AppIconPath) /* 2.5b13 rri */
   {
    if(IconBase->lib_Version >= 44)
     {
      diskobj=GetIconTagList(AppIconPath,TAG_DONE);
     }
    else
     {
      diskobj=GetDiskObject(AppIconPath);
     }

    if(diskobj)
     {
      do_dm_config.do_Gadget=diskobj->do_Gadget;
     }
   }

  appicon=AddAppIconA(NULL,NULL,DMname,WinPort,NULL,&do_dm_config,NULL);

  while(loop) /* 2.5b9 rri */
   {
    WaitPort(WinPort);

    while(appmsg=(struct AppMessage *)GetMsg(WinPort))
     {
      if(IsRexxMsg((struct RexxMsg *)appmsg)) /* 2.5b9 rri  */
       {
        rexxmsg=(struct RexxMsg *)appmsg;
        if(strncmp("QUIT",rexxmsg->rm_Args[0],4)==0)
         {
          KeepGoing=0;
          loop=2;
         }
        else if(strncmp("WAKE",rexxmsg->rm_Args[0],4)!=0)
         {
          ReplyMsg((struct Message *)appmsg); /* 2.5b13 rri */
          continue;
         }
       }

      ReplyMsg((struct Message *)appmsg); /* 2.5b13 rri */

      while(appmsg=(struct AppMessage *)GetMsg(WinPort))
       {
        ReplyMsg((struct Message *)appmsg);
       }

      RemoveAppIcon(appicon);

      if(loop==1)
       {
        BatchFlag=1; /* 2.5b10 rri */

        while(msg=(struct IntuiMessage *)GetMsg(WinPort))
         {
          ReplyMsg((struct Message *)msg);
         }
        RemPort(WinPort); /* test! */

        ActionCmd(0,Globuff);

        AddPort(WinPort); /* test! */

        menu_on(); /* 2.5b10 rri */
        BatchFlag=0; /* 2.5b10 rri */
        FindCmdWin();
       }
      loop=0;
     }
   }

 }

do_dm_config.do_Type=WBPROJECT;

do_dm_config.do_CurrentX = NO_ICON_POSITION; /* 2.5b9 rri */
do_dm_config.do_CurrentY = NO_ICON_POSITION; /* 2.5b9 rri */

if(diskobj) /* 2.5b13 rri */
 {
  do_dm_config.do_Gadget=do_dm_config_gadget;
  FreeDiskObject(diskobj);
 }


KeepGloBuff=0;
}
