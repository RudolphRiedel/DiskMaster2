/* DiskMaster II Screen Module
**
** 00-06-05 rri -rewritten ParseScreenArgs() to make use of GetActionArg()
**              -removed ReadOpenScreen() from the active source
** 00-06-07 rri -corrected ParseScreenArgs()
**
** 2.5b9
**
** 00-10-04 rri - added Bar_Height to InitScreenDefaults()
**
** 2.5b10
**
** 00-12-26 rri - replaced all c++ style comments by ANSI ones
**              - replaced one unix-style movmem() by an ANSI-style memmove()
**              - removed five "warning 120"`s
**              - changed UserCols from int to ULONG
**
** 00-12-27 rri - made Bar_Height a LONG
**
** 2.5b11
**
** 01-07-15 rri - Set minimum screen-depth to two planes
**
** 2.5b12
**
** 01-07-25 rri - added init of Pens20[] to InitScreenDefaults()
**
** 01-07-29 rri - added init of DirPen, FilePen, BackPen and SelectPen
**                to GetDRI()
**
*/

#include "DM.h"
#define AA      ActionArgs

extern struct IntuitionBase *IntuitionBase;
extern struct Library       *AslBase;
extern struct Screen        *Screen,*MyScreen;
extern struct MsgPort       *WinPort;
extern struct TextFont      *DMFont; /* new! 2.3 */

extern UBYTE DMname[],Version[],*ActionArgs[],HostID[];

extern UWORD Pens20[],ColMap[];

extern LONG  DirPen, FilePen, BackPen, SelectPen; /* 2.5b12 rri */

extern ULONG UserCols; /* 2.5b10 rri */

LONG   Bar_Height; /* 2.5b10 rri */
UWORD  Screen_Depth;
ULONG  Screen_Width,Screen_Height,Screen_ID;



int CheckScreen()
{
struct Window *win;

win=MyScreen->FirstWindow;
while(win)
 {
  if(win->UserPort!=WinPort) return(1);
  win=win->NextWindow;
 }
 return(0);
}


void GetDRI(struct Screen *s)
{
struct DrawInfo *dri;

if(!s) return;
if(dri=GetScreenDrawInfo(s))
 {
  memmove((UBYTE *)Pens20,(UBYTE *)dri->dri_Pens,(size_t) (dri->dri_NumPens*2));
  FreeScreenDrawInfo(s,dri);
 }

BackPen=Pens20[BACKGROUNDPEN]; /* 2.5b12 rri */
DirPen=Pens20[HIGHLIGHTTEXTPEN]; /* 2.5b12 rri */
FilePen=Pens20[TEXTPEN]; /* 2.5b12 rri */
SelectPen=Pens20[FILLPEN]; /* 2.5b12 rri */

}


void GetHostScreen(UBYTE *str)
{
struct Screen *s;

if(MyScreen) return;
if(HostID[0])
 {
  UnlockPubScreen(HostID,Screen);
  HostID[0]=0;
  InitScreenDefaults(); /* new! 2.5b5 */
 }
if(!str||*str==0) return;
s=LockPubScreen(str);
if(s)
 {
  Screen=s;
  strcpy(HostID,str);
  GetDRI(s);
 }
}


void InitScreenDefaults()	/* new! 2.2b14 */
{
UBYTE pub_screen_name[MAXPUBSCREENNAME+1]; /* new! 2.5b5 */
struct Screen   *pub_screen; /* new! 2.2b13 */
struct DrawInfo *screen_drawinfo; /* new! 2.2b13 */

GetDefaultPubScreen(pub_screen_name);
if(pub_screen_name[0])
 {
  pub_screen = LockPubScreen(pub_screen_name);	/* new! 2.2b12 */
  if (pub_screen != NULL) /* new! 2.2b12 */
   {
    Screen = pub_screen; /* new! 2.5b5 */
    screen_drawinfo = GetScreenDrawInfo(pub_screen); /* new! 2.2b12 */
    if (screen_drawinfo != NULL)	/* new! 2.2b12 */
     {
      Screen_ID = GetVPModeID(&(pub_screen->ViewPort));
      if(Screen_ID != INVALID_ID )
       {
        Screen_Width = pub_screen->Width;
        Screen_Height = pub_screen->Height;
        Screen_Depth = screen_drawinfo->dri_Depth;
        Bar_Height = pub_screen->BarHeight; /* 2.5b9 rri */
        GetDRI(pub_screen); /* 2.5b12 rri */
       }
     }
    FreeScreenDrawInfo(pub_screen,screen_drawinfo);	/* new! 2.2b12 */
   }
  UnlockPubScreen(pub_screen_name,pub_screen);	/* new! 2.2b12 */
 }
else
 {
  Screen_ID = NULL;
  Screen_Width = NULL;
  Screen_Height = NULL;
  Screen_Depth = NULL;
  Bar_Height = NULL; /* 2.5b9 rri */
 }
}


void ParseScreenArgs(void) /* 2.5b6 rri */
{

Screen_Depth = (UWORD) GetActionArg("D", AATYPE_NUM, (LONG) Screen_Depth); /* 2.5b10 rri */
if (Screen_Depth<2) Screen_Depth=2; /* 2.5b11 rri */

Screen_Height= GetActionArg("H", AATYPE_NUM, Screen_Height);
if (Screen_Height < 200) Screen_Height = 200;
Screen_Width = GetActionArg("W", AATYPE_NUM, Screen_Width);
if (Screen_Width < 320) Screen_Width=320;


Screen_ID = GetActionArg("ID", AATYPE_NUM, Screen_ID);

if (!FindDisplayInfo (Screen_ID))
 {
  Screen_ID = NULL;
 }
}


/* New OpenScreen-Routine, finished in 2.2b11 */

struct Screen *NewOpenScreen(int n,UBYTE *name)	/* new! 2.2b12 */
{
struct	Screen *s;

struct ScreenModeRequester *ModeRequest;

if(AslBase) /* new! 2.5b2 */
 {
  if(!ActionArgs[n])
   {
	ModeRequest = AllocAslRequest (ASL_ScreenModeRequest, NULL); /* new! 2.2b12 */
     if (ModeRequest != NULL)	/* new! 2.2b12 */
      {
       if (AslRequestTags (ModeRequest,
           ASLSM_TitleText, Version,
           ASLSM_InitialDisplayID, Screen_ID,
           ASLSM_InitialDisplayWidth, Screen_Width,
           ASLSM_InitialDisplayHeight, Screen_Height,
           ASLSM_InitialDisplayDepth, Screen_Depth,
           ASLSM_DoWidth, TRUE,
           ASLSM_DoHeight, TRUE,
           ASLSM_DoDepth, TRUE,
           ASLSM_MinWidth, 320,
           ASLSM_MinHeight, 200,
           TAG_DONE))
        {
         Screen_ID=ModeRequest->sm_DisplayID;
         Screen_Depth=ModeRequest->sm_DisplayDepth;
         Screen_Width=ModeRequest->sm_DisplayWidth;
         Screen_Height=ModeRequest->sm_DisplayHeight;
        } /* endif AslRequestTags... */
      } /* endif ModeRequest... */
    if (ModeRequest) FreeAslRequest (ModeRequest);	/* new! 2.2b12 */
   } /* endif !ActionArgs... */
  else
   {
    ParseScreenArgs(); /* 2.5b6 rri */
   } /* endif else... */
 } /* endif AslBase... */

s=DMOpenScreen(Screen_Width,Screen_Height,Screen_ID,Screen_Depth,name);

return(s);
}


/* Reader OpenScreen-Routine new! 2.2b12 */
/* removed from active source in 2.5b6
struct Screen *ReadOpenScreen(int n,UBYTE *name)
{
struct  Screen *s;

UWORD Depth;
ULONG Height,Width,ID;

Depth=Screen_Depth;
Screen_Depth=2;
Height=Screen_Height;
Width=Screen_Width;
ID=Screen_ID;

ParseScreenArgs();
s=DMOpenScreen(Screen_Width,Screen_Height,Screen_ID,Screen_Depth,name);

Screen_Height=Height;
Screen_Width=Width;
Screen_ID=ID;
Screen_Depth=Depth;

return(s);
}
*/

struct Screen *DMOpenScreen(ULONG Width,ULONG Height,ULONG ID,UWORD Depth,UBYTE *name)
{
struct	Screen *s;

s =(struct Screen *)OpenScreenTags(NULL,
                        SA_Width,		Width,
                        SA_Height,		Height,
                        SA_Depth,		Depth,
                        SA_Overscan,	OSCAN_TEXT,
                        SA_AutoScroll,	TRUE,
                        SA_Pens,		Pens20,
                        SA_SharePens,   TRUE, /* new! 2.3 */
                        SA_DisplayID,	ID,
                        SA_Title,		name,
                        SA_PubName,		name,
                        TAG_DONE);

if(s)
 {
  if(UserCols) LoadRGB4(&s->ViewPort,ColMap,UserCols);
  PubScreenStatus(s,0);
/*
  if (DMFont)
   {
    SetFont(&s->RastPort,DMFont);
   }
*/
 }

return(s);
}
