/* DiskMaster II  general commands module
**
** 2.5b10
**
** 00-12-01 rri - file created
**
** 00-12-05 rri - removed one "warning 220" from GetCmdFile(), two from
**                AutoFiler() and two from ParseCmd1()
**
** 00-12-23 jjt - Updated DMReq() calls to either DMReq() or DMReqTagList().
**              - Added extern ref. to g_buttons.
**
** 00-12-26 rri - removed seven "warning 120"`s
**              - replaced four unix-style movmem()`s by ANSI-style memmove()`s
**              - changed var in GetCmdFile() header from int to LONG
**
** 01-01-08 rri - changed ParseCmd1() to init dlp->name2, too
**
** 01-01-16 rri - enabled BatchFlag
**
** 01-01-28 rri - introduced CloneStr() / PoolFreeVec() for comments
**              - changed ->name2 referencies to ->name
**              - introduced CloneStr() for names
**
** 01-02-05 rri - added menu-enabling to GetCmdFile()
**
** 2.5b11
**
** 01-03-01 rri - rewritten mainpart of DoSwap() after bug-report
**                from Richard Mattsson <richard@cloudnet.com>
**
** 01-03-11 jjt - DoSwap() - Added lines to update the Window-structure's FirstGadget
**                & Title fields.
**
** 01-03-14 jjt - DoSwap() - Trying to fix my previous fix. :-)
**
** 01-04-01 jjt - GetCmdFile() - Bug fix:  Removed an "if (!Globuff)..." test that
**                bracketed the call to GetGlobuff().  Allows Globuff, if it already
**                exists, to be reinitialized to all 0's.
**                Reported by Richard Mattsson <richard@cloudnet.com> ()
**
** 01-04-22 jjt - ParseCmd1() - Changed part that sets a button's FG & BG colors.  Now uses
**                Char2Nibble(), & accepts values from 0-F.
**                Suggested (ID 09.08) by Fredrik Ismyren <myrn@tjohoo.se>
**
** 01-07-15 rri - Added "UserColors" to DMSet()
**
** 2.5b12
**
** 01-07-27 rri - Changing "UserColors" with DMSet() will call
**                ObtainPen() or ReleasePen() now
**              - ParseCmd1() checks for two pen sets now
**
** 01-07-28 rri - changed requester in AddCmd()
**              - modified EditCmd() to match new AddCmd()
**
** 01-07-29 rri - Added BPen/DPen/FPen/SPen to 'SetX'
**
** 01-07-29 jjt - Added - "extern ShowDev" & "StringPool".
**                      - DevHide_List & DevHide_Count vars.
**                      - CMD_DevList() - Sets Device List filtering.
**                      - CMD_HideDev() - Filters specific dev names.
**
** 01-07-30 jjt - CMD_DevList() & CMD_HideDev() now call RefreshDevLists(),
**
** 01-08-03 rri - 'SetX' protects the real cursor-color now...
**              - 'SetX' also protects cursor-over-text pen now...
**
** 2.5b13
**
** 01-08-08 jjt - Added TestWarnFlag to ResetFlags().
**
** 01-08-25 rri - Added "AppIcon" option to 'SetX'
**
** 01-09-09 rri - localisation:
**                 'Archive' - msgReqArchive
**                 'Select' - msgReqSelect
**                 'ReqPatttern' - msgReqPattern
**                 'SetFormat' - msgReqFormat
**                 'AddAutoCmd' - msgReqAddAuto
**                 'AddCmd' - msgReqCmd
**                 'EditCmd' - msgReqCmd
**
** 01-09-11 rri - AddCmd() opens a screen-relative CMD window on demand now
**
** 01-09-16 rri - AddCmd() uses the zooming-option, too
**
** 01-09-18 rri - corrected localisation of DMReqPat()
**
** 01-09-22 rri - replaced a strcmpi() in DMSet() by Stricmp()
**
** 01-09-23 rri - added option "Comment" to 'Select'
**
** 01-10-05 rri - Bugfix: 'Parent' on removed disks showed the
**                "No disk present..." requester forever - thanks for
**                reporting to Richard Mattsson <richard@cloudnet.com>
**
*/


#include "DM.h"

extern struct DirWindow  *CDWin,*CmdWin,*DestWin,*DirWin[];
extern struct DirList    *WorkDlp;
extern struct Screen     *Screen,*MyScreen;

extern UBYTE
             *ActionArgs[],
             ActionBuf[],
             DispFormat[],
             DMname[],
             *Globuff,
             g_buttons[], /* 2.5b10 jjt */
             PGadStr[],
             sbuff[],
             sPath[];

extern WORD  zooming[]; /* 2.5b13 rri */

extern UWORD Pens20[20]; /* 2.5b12 rri */

extern LONG  BackPen, /* 2.5b12 rri */
             Bar_Height, /* 2.5b13 rri */
             DirPen, /* 2.5b12 rri */
             FilePen, /* 2.5b12 rri */
             IconX,
             IconY,
             SelectPen, /* 2.5b12 rri */
             Use30; /* 2.5b12 rri */

extern int   Abort,
             KeepGloBuff,
             RecFlag;

extern ULONG Base_Str_Len,
             Screen_Height, /* 2.5b13 rri */
             Screen_Width, /* 2.5b13 rri */
             ShowDev, /* 2.5b12 jjt */
             UserColors; /* 2.5b11 rri */

extern APTR CommentPool; /* 2.5b10 rri */
extern APTR NamePool; /* 2.5b10 rri */
extern APTR StringPool; /* 2.5b12 jjt */



BPTR StdIO;

int   AutoFiling,
      AttrFlag,
      BatchFlag,
      ChgCmd,
      ConfirmFlag,
      digits=5,
      LoopFlag,
      Notify=0,
      PatReqFlag,
      QuietFlag,
      ReSortFlag,
      SingleFlag,
      unMark,
      WinTitleFlag,
      TestWarnFlag;  /* 2.5b13 jjt */

UBYTE
      *AppIconPath, /* 2.5b13 rri */
      *AutoCmdStr[256],
      dcPath[512],
      DOSPassStr[1024],
      Pattern[32],
      ReqStr[700],
      *DevHide_List[DEVHIDELIST_MAX];  /* 2.5b12 jjt*/

ULONG DevHide_Count = 0;  /* 2.5b12 jjt */

sFIB Fib;


void DoStdio(UBYTE *str)
{

if(StdIO)
 {
  Close(StdIO);
  StdIO=0;
 }

if(Stricmp(str,"CLOSE")==0) return; /* 2.5b7 rri */

if(MyScreen) /* new! 2.2b12 */
 {
  strcat(str,"/SCREEN");
  strcat(str,DMname);
 }

StdIO=Open(str,MODE_OLDFILE);
}


void GetParent(UBYTE *path,int parent) /* 2.5b6 rri */
{
BPTR lockcurrent,lockresult;
UBYTE *ptr=path+strlen(path);

for(;ptr>=path;ptr--)
 {
  if(*ptr==':')
   {
    ptr++;
    if(*ptr) /*  path was root+1 dir */
     {
      *ptr=0;
      break;
     }
    else /* path already was root */
     {
      if (lockcurrent=Lock(path,ACCESS_READ))
       {
        lockresult=ParentDir(lockcurrent);
        UnLock(lockcurrent);
        if (lockresult)
         {
          NameFromLock(lockresult,path,512);
          UnLock(lockresult);
          ptr=path+strlen(path)-1; /* 2.5b7 rri */
          if((*ptr==':')||parent) /* 2.5b9 rri */
           {
            break;
           }
         }
        else if (!lockresult&&(IoErr()==0))
         {
          path[0]=0;
          break;
         }
       }
      else /* path not valid anymore */ /* 2.5b13 rri */
       {
        path[0]=0;
        break;
       }
     }
   }
  if(parent&&*ptr=='/') /* if !parent the loop will run `till root */
   {
    *ptr=0;
    break;
   }
 }
}


void DMArchive(UBYTE *cmd,UBYTE *name)
{
struct DirList **dl,*dlp;
UBYTE   *ptr=DOSPassStr; /* 2.5b9 rri */
BPTR lock; /* 2.5b5 rri */
int     i=0,cnt=0,q;

if(!CDWin) return;
if(!name||*name==0)
 {
  name=dcPath;
  strcpy(name,CDWin->Path);
  if(*(name+strlen(name)-1)!=':' && *(name+strlen(name)-1)!='/') strcat(name,"/"); /* new! 2.2b15 RB */
  if(!DMReqTagList(msgReqArchive, name, 512, 0)) return;  /* 2.5b13 rri */
 }
dl=CDWin->DirList;

NEXT:

DOSPassStr[0]=0;
*ptr=0; /* 2.5b9 rri */
strcpy(ptr,cmd); /* 2.5b9 rri */
strcat(ptr," ");
QuoteCat(ptr,name);

while(i<CDWin->FileCount)
 {
  dlp=dl[i++];
  if(dlp&&dlp->sel==1)
   {
    dlp->sel=0;
    cnt++;
    strcat(ptr," ");
    q=NeedQuote(dlp->name);
    if(q) strcat(ptr,"\"");
    strcat(ptr,dlp->name);
    if(q) strcat(ptr,"\"");
    if(strlen(ptr)>=224||cnt>=30)
     {
      dis_files(CDWin);
      WinTitle(CDWin);
      DOSStart(4000); /* new! 2.4b15 */
      cnt=0;
      goto NEXT;
     }
   }
 }
if(cnt)
 {
  dis_files(CDWin);
  WinTitle(CDWin);
  DOSStart(4000); /* new! 2.4b15 */
 }
if(lock=Lock(name,ACCESS_READ))
 {
  UnLock(lock);
  SmartAddEntry(name);
 }
}


void DMSelect(int sel)
{
struct DirList **dl,*dlp;
int i,c=1,comment;

PatReqFlag=1;

if (comment=GetActionArg("COMMENT", AATYPE_BOOL, 0)) /* 2.5b13 rri */
 {
  ActionArgs[comment]=0;
 }

if(!ActionArgs[1])
 {
  ActionArgs[1]=sbuff;
  sbuff[0]='*';
  sbuff[1]=0;
  if(!DMReqTagList(msgReqSelect, sbuff, 31, 0)) return;  /* 2.5b13 rri */
 }
if(!CDWin) return;

while (ActionArgs[c])
 {
  dl=CDWin->DirList;
  for(i=0;i<CDWin->FileCount;i++)
   {
    dlp=dl[i];
    if(comment) /* 2.5b13 rri */
     {
      if(DMMatch(dlp->cmt,ActionArgs[c])) dlp->sel=sel;
     }
    else if(DMMatch(dlp->name,ActionArgs[c])) dlp->sel=sel;
   }
  c++;
 }
dis_files(CDWin);
WinTitle(CDWin);
}


void DMReqPat()
{
if(PatReqFlag) return;
if(WorkDlp&&!WorkDlp->dir) return;
if(ActionArgs[2]) strcpy(Pattern,ActionArgs[2]);

if(!ActionArgs[1]) /* 2.5b13 rri */
 {
  strcpy(ReqStr,msgReqPattern);
  ActionArgs[1]=ReqStr;
 }
if(!ActionArgs[5]) /* 2.5b13 rri */
 {
  strcpy(sbuff,msgGadSkip);
  ActionArgs[5]=sbuff;
 }

MakeBtnString(ActionArgs[3], ActionArgs[5], ActionArgs[4]);  /* 2.5b10 jjt */
if(DMReq(ActionArgs[1], Pattern, 31, DMREQ_BUTTONS, g_buttons,
                                     DMREQ_ABORT, 0, /* 2.5b13 rri */
                                     TAG_END) == 1)
 {
  PatReqFlag=1;
 }
}


void DMSetFormat(UBYTE *str,UBYTE *fbuf,int length) /* new! 2.4b19 */
{

if(str&&*str) strcpy(fbuf,str);
else if(!DMReqTagList(msgReqFormat, fbuf, (ULONG) length, 0)) return;  /* 2.5b13 rri */
if(fbuf==DispFormat)
 {
  RefreshWindows(); /* 2.5b7 rri */
 }
}


void AddAutoCmd(UBYTE *str)
{
int i=0;
ULONG len=0;
UBYTE *ptr;

if(*str==0)
 {
  sbuff[0]=0;
  if(!DMReqTagList(msgReqAddAuto, sbuff, 512, 0)) return;  /* 2.5b13 rri */
  str=sbuff;
 }
ptr=str;

while(*ptr&&*ptr!=10)
 {
  ptr++;
  len++;
 }

while(AutoCmdStr[i]) i++; /* find next free autocmd */

if(Strnicmp(str,"TEXT",4)==0) i=253; /* 2.5b7 rri */
if(Strnicmp(str,"DEFAULT",7)==0) i=254; /* 2.5b7 rri */

if(ptr=AutoCmdStr[i])
 {
  FreeMem(ptr,(ULONG) (strlen(ptr)+1)); /* 2.5b10 rri */
  AutoCmdStr[i]=0;
 }

if(i<256&&!AutoCmdStr[i])
 {
  if(AutoCmdStr[i]=AllocMem(len+1,MEMF_PUBLIC|MEMF_CLEAR))
   {
    memmove(AutoCmdStr[i], str, (size_t) len); /* 2.5b10 rri */
   }
 }
}


void RefreshCmdWin(struct DirWindow *dw)
{

if(dw&&(dw->Flags&DW_CMD)&&(dw->Flags&DWFLAG_ADD))
 {
  CmdWin=dw;
  ReSize(dw);
  NewSize(dw);
  FindNewDirection(dw);
  ShowDirection(dw,2);
  dw->Flags&=~DWFLAG_ADD;
 }
}


void AddCmd(struct DirWindow *dw,UBYTE *buf)
{
struct DirList **dl,*dlp;
int x; /* 2.5b13 rri */

if(!dw)
 {
 /* 2.5b13 rri */
  x=Screen_Width/5;
  zooming[0]=x*2;
  zooming[1]=Bar_Height+1;
  zooming[2]=65;
  zooming[3]=65;
  OpenDirWindow("CMD",x*2,(int) Bar_Height+1,x,(int) Screen_Height);

  dw=CmdWin;
 }
if(!dw) return;

if(!buf||*buf==0)
 {
  buf=ActionBuf;
  *buf=0;
  if(!DMReqTagList(msgReqCmd, buf, 512, 0)) return; /* 2.5b13 rri */
 }
if(!(dw->Flags&(DWFLAG_ADD|DW_CMD))) FreeDirTable(dw);
if(!AllocDlp(dw)) return;
dw->Flags=DW_CMD;
dl=dw->DirList;
dlp=dl[dw->FileCount++];
ParseCmd1(dlp,buf);
dw->Flags|=DWFLAG_ADD;
}


void EditCmd(struct DirWindow *dw,int ni)
{
struct DirList **dl=dw->DirList,*dlp=dl[ni];
UBYTE *ptr=dlp->cmt;

ChgCmd=0;

sprintf(ActionBuf,"%s, %lx%lx, %lx%lx, %s",dlp->name,
dlp->attr&0xf,(dlp->attr>>4)&0xf,(dlp->attr>>8)&0xf,(dlp->attr>>12)&0xf,ptr); /* 2.5b12 rri */

if(!DMReqTagList(msgReqCmd, ActionBuf, 512, 0)) return;  /* 2.5b13 rri */
if(ptr)
 {
  PoolFreeVec(dlp->cmt); /* 2.5b10 rri */
 }
dlp->cmt=0;
ParseCmd1(dlp,ActionBuf);
}


void DoSwap()
{
UBYTE   wincounter; /* new! 2.4 */
struct DirWindow *dwsource=CDWin;
struct DirWindow *dwdest=DestWin; /* new! 2.4 */
struct Window *Window; /* 2.5b11 */

if(!dwsource||!dwdest) return;

if (ActionArgs[1])
 {
  wincounter=atoi(ActionArgs[1]); /* new! 2.4 */
  if(DirWin[wincounter]&&!(DirWin[wincounter]->Flags&DW_CMD)&&!(DirWin[wincounter]==CDWin))
  {
   dwdest=DirWin[wincounter];
  }
 }

/* 2.5b11 */

Window = dwsource->Window;         /* swap around window-structures */
dwsource->Window = dwdest->Window;
dwdest->Window = Window;

/* 2.5b11 jjt
   After window-structures are swapped, swap the window's FirstGadget & Title fields.
*/
Window = (struct Window *) dwsource->Window->FirstGadget;
dwsource->Window->FirstGadget = dwdest->Window->FirstGadget;
dwdest->Window->FirstGadget = (struct Gadget *) Window;
dwsource->Window->Title = dwsource->Title;
dwdest->Window->Title = dwdest->Title;

dwsource->Flags|=DWFLAG_RESORT;    /* set re-sort flag */
dwdest->Flags|=DWFLAG_RESORT;

RefreshGadget(&dwsource->dir_gad,dwsource->Window);
RefreshGadget(&dwdest->dir_gad,dwdest->Window);

ReSort();
}


int UnLockAll()
{
struct DirWindow *dw;
int i;

for(i=0;i<255;i++)
 {
  dw=DirWin[i];
  if(dw&&(dw->Flags&(DW_DEST|DW_SOURCE)))
   {
    dw->Flags&=~(DW_DEST|DW_SOURCE);
    ShowDirection(dw,4);
   }
 }
ShowDirection(CDWin,0);
ShowDirection(DestWin,1);
return(0);
}


void ResetFlags()
{
 Abort=PatReqFlag=ConfirmFlag=AttrFlag=RecFlag=SingleFlag=0; /* 2.5b6 jjt (17.4.00) - Removed "NoteFlag" from DMPack. */
 AutoFiling=0; /* 2.5b6 rri */
 QuietFlag=0; /* 2.5b5 rri */
 unMark=0;
 LoopFlag=ReSortFlag=WinTitleFlag=0;
 Pattern[0]='*';
 Pattern[1]=0;
 TestWarnFlag=1;  /* 2.5b13 jjt */
}


void GetCmdFile(struct DirWindow *dw,UBYTE *name,LONG size)
{
sFIB *fib=(&Fib); /* 2.5b10 rri */
BPTR lock,fh; /* 2.5b5 rri */

if(size<=0)
 {
  if(!(lock=Lock(name,ACCESS_READ))) return;
  if(Examine(lock,fib)) size=fib->fib_Size;
  UnLock(lock);
 }
if(size<=0) return;

if(!GetGlobuff()) return;

KeepGloBuff=1; /* 2.5b8 rri */

if(fh=Open(name,MODE_OLDFILE))
 {
  if(dw) CmdWin=dw;
  strcpy(dcPath,name);
  if(Read(fh,Globuff,size)>0)
   {
    BatchFlag=1; /* 2.5b10 rri */
    ActionCmd(dw,Globuff);
    menu_on(); /* 2.5b10 rri */
    BatchFlag=0;
   }
  Close(fh);
 }
KeepGloBuff=0; /* 2.5b8 rri */
}


void AutoFiler(struct DirWindow *dw,UBYTE *name)
{
BPTR fh; /* 2.5b5 rri */
int i,len2,j,k,lenB; /* 2.5b7 rri */
UBYTE *ptr,*ptr2,*ptr3;

MakeFullName(sPath,CDWin,name);
ResetFlags();

AutoFiling=1; /* 2.5b6 rri */

if(!(fh=Open(sPath,MODE_OLDFILE))) return;
lenB=Read(fh,sbuff,500); /* 2.5b7 rri */
Close(fh);

for(i=0;i<lenB;i++) /* 2.5b7 rri */
 {
  if (sbuff[i]==0)
   {
    sbuff[i]=1;
   }
 }

for(i=0;i<256;i++)
 if(ptr=AutoCmdStr[i])
  {
   ptr2=dcPath;
   len2=0;
   *ptr2=0;

   while(*ptr&&*ptr!=',')
    {
     *ptr2++ = *ptr++;
     len2++;
    }

   ptr++;
   ptr2--;

   while(len2>0&&*ptr2<=' ') /* cut-off spaces and control-chars from the end */
    {                        /* of the pattern-string */
     ptr2--;
     len2--;
    }

   ptr2++;
   *ptr2=0;

   if(len2<=0) j=1;
   else
    {
     ParsePatternNoCase(dcPath,ReqStr,500); /* 2.5b8 rri */
     if (!(j=MatchPatternNoCase(ReqStr,sbuff))) /* 2.5b8 rri */
      {
       if(Stricmp(dcPath,"TEXT")==0) /* 2.5b7 rri */
        {
         k=lenB-1; /* 2.5b7 rri */
         while(k) if(sbuff[k--]==1) break; /* 2.5b7 rri */
         if(!k) j=1;
        }
       else if(Stricmp(dcPath,"DEFAULT")==0) j=1; /* 2.5b7 rri */
      }
    }
   ptr2=dcPath;
   len2=0;
   *ptr2=0;
   ptr3=ptr;
   while(*ptr3&&*ptr3!=',') /* 2.5b9 rri */
    {
     *ptr2++ = *ptr3++;
     len2++;
    }
   if(*ptr3==',')
    {
     ptr2--;
     ptr=ptr3+1;
     while(len2>0&&*ptr2<=' ')
      {
       ptr2--;
       len2--;
      }
     ptr2++;
     *ptr2=0;
     if(len2>0&&j)
      {
       ParsePatternNoCase(dcPath,ReqStr,500); /* 2.5b9 rri */
       j=MatchPatternNoCase(ReqStr,name);
      }
    }
   if(j)
    {
     ParseArgs(ptr,dw);
     break;
    }
  }

/*
if(ReSortFlag==1)
 {
  InitDir(dw,0);
  dw->Flags|=DWFLAG_RESORT;
  ReSort();
 }
*/

/* CloseRead(); */ /* 2.5b8 jjt */
ReSort();
WinTitle(CDWin);
ResetFlags();
}


void FreeAutoCmds()
{
UBYTE *ptr;
int i;

for(i=0;i<256;i++)
 {
  if(ptr=AutoCmdStr[i])
   {
    FreeMem(ptr,(ULONG) (strlen(ptr)+1)); /* 2.5b10 rri */
    AutoCmdStr[i]=0;
   }
 }
}


void ParseCmd1(struct DirList *dlp,UBYTE *buf)
{
UBYTE cmdnamebuffer[31]; /* 2.5b10 rri */
UBYTE *ptr=cmdnamebuffer; /* 2.5b10 rri */
int i=30, c;

/*
dlp->name = name of command
dlp->dir  = 3 - special cookie
dlp->attr = colors
dlp->cmt  = command-line itself
*/

dlp->dir=3;

while(*buf&&*buf!=10&&*buf!=','&&i--) *ptr++ = *buf++; /* copy 30 chars max */

*ptr-- = 0;

while(*ptr==' '||*ptr==9) *ptr--=0; /* eliminate SPACE`s/TAB`s at the end */

dlp->attr=0x2002; /* 2.5b12  rri */

if(*buf==',')
 {
  buf++;

  buf=SkipWhite(buf);

/* 2.5b12 rri */
  if(buf[2]==','||buf[2]==' ') /* if only two charaters follow */
   {
    c = Char2Nibble((ULONG) *buf);
    if(c>16) c=0;
    dlp->attr=c;
    buf++;
    c = Char2Nibble((ULONG) *buf);
    if(c>16) c=0;
    dlp->attr = (c << 4) | dlp->attr;
    buf++;
   }

  buf=SkipWhite(buf);

  if(*buf==',')
   {
    buf++;
    buf=SkipWhite(buf);
   }

  if(buf[2]==','||buf[2]==' ') /* if only two charaters follow */
   {
    c = Char2Nibble((ULONG) *buf);
    if(c>16) c=0;
    dlp->attr= (c << 8) | dlp->attr;
    buf++;
    c = Char2Nibble((ULONG) *buf);
    if(c>16) c=0;
    dlp->attr = (c << 12) | dlp->attr;
    buf++;
   }
  else
   {
    dlp->attr=((dlp->attr&0x0f)<<12)|((dlp->attr&0x0f0)<<4)|dlp->attr; /* 0010 -> 0110 */
   }
/* 2.5b12 rri */


  buf=SkipWhite(buf);


  if(*buf==',')
   {
    buf++;
    buf=SkipWhite(buf);
   }

  ptr=sbuff;

  i=0;

  while(*buf>10&&i<512)
   {
    *ptr++ = *buf++;
    i++;
   }
  *ptr=0;
  dlp->name = CloneStr(cmdnamebuffer, NamePool); /* 2.5b10 rri */
  if(i)
   {
    dlp->cmt = CloneStr(sbuff, CommentPool); /* 2.5b10 rri */
   }
 }
}


void DMSet() /* 2.5b7 rri */
{
ULONG i,c,x; /* 2.5b12 */

if (GetActionArg("digits",AATYPE_BOOL,0))
 {
  Base_Str_Len=10; /* 2.5b9 rri */
  digits = GetActionArg("digits", AATYPE_NUM, 5);
  if (digits<5) digits=5;
  if (digits>9) digits=9;

  for (i=1;i<digits;i++)
   {
    Base_Str_Len*=10;
   }

  Base_Str_Len--;
  RefreshWindows();
 }

IconX = GetActionArg("IconX", AATYPE_NUM, NO_ICON_POSITION); /* 2.5b9 rri */
IconY = GetActionArg("IconY", AATYPE_NUM, NO_ICON_POSITION); /* 2.5b9 rri */

if (GetActionArg("notify",AATYPE_BOOL,0)) /* 2.5b9 rri */
 {
  Notify=1;
 }

if (GetActionArg("UserColors",AATYPE_BOOL,0)) /* 2.5b11 rri */
 {
  i=UserColors;
  UserColors = GetActionArg("UserColors", AATYPE_NUM, 4);
  if (UserColors<4) UserColors=4; /* 2.5b11 rri */

  if(MyScreen&&Use30) /* 2.5b12 rri */
   {
    if(UserColors>i)
     {
      AllocPens();
     }
    if(UserColors<i)
     {
      for(c=UserColors;c<i;c++)
       {
        if(c==17||c==18||c==19||                          /* protect pointer */
           c==(1<<MyScreen->BitMap.Depth)-Pens20[BACKGROUNDPEN]-1|| /* cursor */
           c==(1<<MyScreen->BitMap.Depth)-Pens20[HIGHLIGHTTEXTPEN]-1) /* and cursor over text*/
         {
          continue;
         }
        /* protect the GUI-pens: */
        for(x=0;x<20;x++)
         {
          if(c==Pens20[x])
           {
            x=42;
            break;
           }
         }
        if(x==42)
         {
          continue;
         }

        ReleasePen(Screen->ViewPort.ColorMap,c);
       }
     }

   }
 }

i=0;

if (GetActionArg("BPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  BackPen = GetActionArg("BPen", AATYPE_NUM, (LONG) Pens20[BACKGROUNDPEN]);
  if (BackPen>28) BackPen=Pens20[BACKGROUNDPEN];
  i=1;
 }
if (GetActionArg("DPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  DirPen = GetActionArg("DPen", AATYPE_NUM, (LONG) Pens20[HIGHLIGHTTEXTPEN]);
  if (DirPen>28) DirPen=Pens20[HIGHLIGHTTEXTPEN];
  i=1;
 }
if (GetActionArg("FPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  FilePen = GetActionArg("FPen", AATYPE_NUM, (LONG) Pens20[TEXTPEN]);
  if (FilePen>28) FilePen=Pens20[TEXTPEN];
  i=1;
 }
if (GetActionArg("SPen",AATYPE_BOOL,0)) /* 2.5b12 rri */
 {
  SelectPen = GetActionArg("SPen", AATYPE_NUM, (LONG) Pens20[FILLPEN]);
  if (SelectPen>28) SelectPen=Pens20[FILLPEN];
  i=1;
 }

if(i==1) /* 2.5b12 rri */
 {
  for(i=0;i<255;i++)
   {
    if(!(DirWin[i])) continue;
    dis_files(DirWin[i]);
   }
 }


if (GetActionArg("AppIcon",AATYPE_BOOL,0)) /* 2.5b13 rri */
 {
  i=(ULONG) GetActionArg("AppIcon", AATYPE_STR, 0);
  if(i)
   {
    if(AppIconPath)
     {
      PoolFreeVec(AppIconPath);
      AppIconPath=0;
     }
    AppIconPath=CloneStr((UBYTE *)i, StringPool);
    if(strlen(AppIconPath)>5 &&
       Stricmp(AppIconPath+(strlen(AppIconPath)-5),".info")==0) /* 2.5b13 rri */
        {
         AppIconPath[strlen(AppIconPath)-5]=0;
        }
   }
 }

}


void CMD_DevList(void) {  /* 2.5b12 jjt */
  ShowDev = 0;
  if (GetActionArg("DEV", AATYPE_BOOL, 0)) ShowDev = SHOWDEV_DEV;
  if (GetActionArg("VOL", AATYPE_BOOL, 0)) ShowDev |= SHOWDEV_VOL;
  if (GetActionArg("ASN", AATYPE_BOOL, 0)) ShowDev |= SHOWDEV_ASN;
  if (ShowDev == 0) ShowDev = SHOWDEV_ALL;
  RefreshDevLists();
}


void CMD_HideDev(void) {  /* 2.5b12 jjt */
  STRPTR sptr;
  ULONG  append, i, l;

  append = GetActionArg("ADD", AATYPE_BOOL, 0);
  if (append == 0) {
    /* --- Clear the list. --- */
    for (i=0; i < DevHide_Count; i++) PoolFreeVec(DevHide_List[i]);
    DevHide_Count = 0;
  }

  for (i=1; (DevHide_Count < DEVHIDELIST_MAX) && ActionArgs[i]; i++) {
    if (i != append) {
      sptr = CloneStr(ActionArgs[i], StringPool);
      if (sptr) {
        for (l = strlen(sptr) - 1; l > 0; l--) {
          /* --- Remove/end at ":" --- */
          if (sptr[l] == ':') {
            sptr[l] = 0;
            break;
          }
        }

        DevHide_List[DevHide_Count] = sptr;
        DevHide_Count++;
      }
    }
  }

  RefreshDevLists();
}


/*
void MultiSelect(int p)
{struct DirList **dl,*dlp;
 int    i=0,c=0;

 dl=CDWin->DirList;
 while(c<30||i<CDWin->FileCount){
        dlp=dl[i++];
        if(dlp&&dlp->sel==1)
        {
                dlp->sel=0;
                c++;
                ActionArgs[p++] = dlp->name;
        }
 }
 if(c)
 {
        dis_files(CDWin);
        WinTitle(CDWin);
 }
}
*/
