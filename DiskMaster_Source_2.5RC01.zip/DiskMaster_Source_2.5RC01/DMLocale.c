/* DiskMaster II  Locale Module
**
** This file was created automatically by `FlexCat 2.4'
** from "DM2.cd".
**
** Do NOT edit by hand!
**
*/

#include "DM.h"

#include <libraries/locale.h>
#include <proto/locale.h>

struct FC_String DM2_Strings[59] = {
    { (STRPTR) "Close all visitor windows!", 0 },
    { (STRPTR) "Out of memory!", 1 },
    { (STRPTR) "File move error!", 2 },
    { (STRPTR) "Font is proportional!", 3 },
    { (STRPTR) "Total: %s - Not enough room!", 4 },
    { (STRPTR) "Delete Failed!", 5 },
    { (STRPTR) "Can`t Quit! %ld Arexx-Script(s) still running!", 6 },
    { (STRPTR) "Unable to compress %s !", 7 },
    { (STRPTR) "Unable to decompress %s !", 8 },
    { (STRPTR) "Unable to open: %s !", 9 },
    { (STRPTR) "Error initializing reader!", 10 },
    { (STRPTR) "Error viewing file: %s !", 11 },
    { (STRPTR) "Enter new name for %s:", 12 },
    { (STRPTR) "Enter new filename:", 13 },
    { (STRPTR) "Enter comment for %s:", 14 },
    { (STRPTR) "Enter protection mask for %s:", 15 },
    { (STRPTR) "Enter new directory name:", 16 },
    { (STRPTR) "Enter command string:", 17 },
    { (STRPTR) "Enter ARexx string:", 18 },
    { (STRPTR) "Enter new archive name:", 19 },
    { (STRPTR) "Enter select-pattern:", 20 },
    { (STRPTR) "Directories selected. Specify pattern:", 21 },
    { (STRPTR) "Enter new display-format:", 22 },
    { (STRPTR) "Auto Command: data,pattern,<command string>", 23 },
    { (STRPTR) "Command template: Title,##,##,<command string>", 24 },
    { (STRPTR) "Enter filename to save:", 25 },
    { (STRPTR) "Key Command: C,<command string>", 26 },
    { (STRPTR) "Command template: Menu,Title,A,<command string>", 27 },
    { (STRPTR) "Enter destination path:", 28 },
    { (STRPTR) "Found: %s\nOpen New Window?", 29 },
    { (STRPTR) "Enter new button command string:", 30 },
    { (STRPTR) "%s exists:\n"\
	"  Source: %ld bytes - %s %s\n"\
	"  Dest:   %ld bytes - %s %s\n"\
	"Okay to overwrite?", 31 },
    { (STRPTR) "Go to line:", 32 },
    { (STRPTR) "Enter search pattern:", 33 },
    { (STRPTR) "Built-in english catalog in use.", 34 },
    { (STRPTR) "Okay", 35 },
    { (STRPTR) "Cancel", 36 },
    { (STRPTR) "Skip", 37 },
    { (STRPTR) "Icon", 38 },
    { (STRPTR) "Yes|All|Rename...|None|No|Cancel", 39 },
    { (STRPTR) "Okay|Skip|Cancel", 40 },
    { (STRPTR) "Moving %s", 41 },
    { (STRPTR) "Copying %s", 42 },
    { (STRPTR) "Total: %s - Leaving %s free.", 43 },
    { (STRPTR) "Listing of %s\n\n", 44 },
    { (STRPTR) "Deleted %s", 45 },
    { (STRPTR) "File Protected", 46 },
    { (STRPTR) "File in use", 47 },
    { (STRPTR) "Select Command to Edit", 48 },
    { (STRPTR) "Press RETURN to continue...\n", 49 },
    { (STRPTR) "Operation canceled", 50 },
    { (STRPTR) "compressed", 51 },
    { (STRPTR) "decompressed", 52 },
    { (STRPTR) "Pattern Not Found", 53 },
    { (STRPTR) "No Search Pattern", 54 },
    { (STRPTR) "Searching %s...", 55 },
    { (STRPTR) "B", 56 },
    { (STRPTR) "K", 57 },
    { (STRPTR) "M", 58 }
};

STATIC struct Catalog *DM2Catalog = NULL;


VOID CloseDM2Catalog(VOID)
{
if (DM2Catalog)
 {
  CloseCatalog(DM2Catalog);
 }
}

VOID OpenDM2Catalog(VOID)
{
if (LocaleBase)
 {
  if ((DM2Catalog = OpenCatalog(NULL, (STRPTR) "DM2.catalog",
                               OC_BuiltInLanguage, "english",
                               OC_Version, 1,
                               TAG_DONE)))
   {
    struct FC_String *fc;
    int i;

    for (i = 0, fc = DM2_Strings;  i < 59;  i++, fc++)
     {
      fc->msg = GetCatalogStr(DM2Catalog, fc->id, (STRPTR) fc->msg);
     }
   }
 }
}
