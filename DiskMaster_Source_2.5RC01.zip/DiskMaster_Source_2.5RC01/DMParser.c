/* DiskMaster II  command-parser
**
** 2.5b10
**
** 00-12-01 rri - file created from parts of DMCommand.c
**
**
** 00-12-22 jjt - Updated DMReq() calls to either DMReq() or DMReqTagList().
**              - Added extern refs to g_buttons, reqtags_ContAbortCan, & reqtags_Ok.
**
** 00-12-26 rri - added flag B - amount of selected entries
**              - removed five "warning 220"`s by reformating the source
**              - removed ten "warning 120"`s by typecasting
**                ToUpper() needs an ULONG as parameter - stupid includes
**              - removed three "warning 120"`s by typecasting
**              - removed a "warning 164" by removing the adress-operator
**                from the argument in a Read() line
**              - replaced one unix-style movmem() by an ANSI-style memmove()
**
** 00-12-28 rri - changed a var in ActionCmd() from int to LONG
**
** 01-01-10 rri - changed three "->name"s into "->name2"s
**
** 01-01-14 rri - corrected requester-line for 'Find'
**
** 01-01-28 rri - changed back three "->name2"s into "->name"s
**              - removed some dead lines
**              - removed 'Priority' command
**
** 2.5b11
**
** 01-04-13 jjt - Added GetHistory command to DoCmd().
**
** 2.5b12
**
** 01-07-27 jjt - Added DevList command to DoCmd().
**
** 01-07-29 jjt - Added HideDev command to DoCmd().
**
** 2.5b13
**
** 01-08-07 jjt - Bug Fix:  Added "cpyok" var to DMRecurse().  This should (maybe?)
**                prevent Move WARN from deleting a file and Move RENAME from moving
**                a file even if the req. was cancelled,
**
** 01-08-12 rri - new sub-routine CheckDestPath() that let 'Copy' and
**                'Move' share some additional lines of code
**
** 01-09-09 rri - localise: CheckDestPath() - msgReqDestPath
**                          DMRecurse() - msgStatMoving, msgStatDeleted,
**                          msgStatCopying, msgStatProtected, msgStatInUse,
**                          msgErrorDelete, msgReqFind, msgGadCOA
**                          DoCmd() - msgReqButton, msgStatChgCmd,
**                          msgReqDestPath, msgErrorArexx, msgStatWait
**                          ActionCmd() - msgStatAborted
**
** 01-09-10 rri - removed reqtags_ContAbortCan
**              - removed reqtags_Ok
**
** 01-09-11 rri - improved 'Find' by making the new window open more
**                relative to the current dir-window
**
** 01-09-13 rri - fixed a terrible bug with the localisation of 'Wait'
**
** 01-09-16 rri - added zoom-options to 'OpenWindow' in DoCmd()
**              - 'Find' clones zoom-options, too
**
** 01-09-18 rri - replaced msgGadCAC from CheckDestPath() and DoCmd()
**                by a MakeBtnString(0, msgGadSkip, 0);
**                initialised g_buttons
**              - replaced msgGadCOA from 'Find' by a
**                MakeBtnString(0, msgGadOpen, 0); initialised g_buttons
**
** 01-09-22 rri - added option "zoomed" to 'OpenWin'
**
** 01-09-23 rri - 'Find' uses a "Okay|Skip|Cancel" requester now
**
** 01-09-29 jjt - Added externs for reqtags_Ok & reqtags_OkSkipCan.
**              - Changed CheckDestPath(), DMRecurse(), & DoCmd() (Unpack & Quit)
**                to use reqtags_...
**
** 01-10-03 jjt - Changed DoCmd() "Last" to use reqtags_Ok.
**
** 01-10-17 rri - new var: keepselected - for all "Skip" operations
**
** 01-10-18 rri - added var skip_all
**              - moved display of 'Copy'/'Move' message to DMCopy() itself
**
** 01-10-29 rri - moved RecurseDepth=0; from 'Copy' and 'Move' to CheckDestPath()
**              - eliminated DMMove() call from DoCmd()
**
*/

#include "DM.h"

extern struct DirWindow *CDWin,*CmdWin,*DestWin,*DirWin[];
extern struct MsgPort *WinPort;
extern struct RexxMsg *rxMsg;
extern struct Screen *Screen,*MyScreen;
extern struct StringHistory PathHistory;
extern struct TagItem reqtags_Ok[], reqtags_OkSkipCan[];  /* 2.5b13 jjt */

extern BPTR StdIO;

extern int   Abort,
             AutoFiling,
             ChgCmd,
             ConfirmFlag,
             DWNum,
             KeepGoing,
             LoopFlag,
             PatReqFlag,
             QuietFlag,
             ReSortFlag,
             rexxErr,
             SingleFlag,
             unMark,
             WinTitleFlag;


extern UBYTE BarFormat[],
             dcPath[],
             DispFormat[],
             DisplayBuffer[],
             DMname[],
             g_readsearchpat[],
             Pattern[],
             PGadStr[],
             ReqStr[],
             *rexxStr,
             sbuff[],
             TitleFormat[],
             g_buttons[];  /* 2.5b10 jjt */

extern WORD  zooming[]; /* 2.5b13 rri */

extern LONG  Bar_Height, /* 2.5b13 rri */
             RexxOutstanding,
             skip_all; /* 2.5b13 rri */


UBYTE *ActionArgs[32],
      ActionBuf[1024],
      sPath[512];

int
/*   BatchFlag, */
     expandflag=0,
     ForceFlag,
     PackOpt,
     RecFlag,
     RecurseDepth;

LONG BlkTotal,
     BPB,
     DirTotal;

ULONG keepselected; /* 2.5b13 rri */

struct DateStamp setStamp;
struct DirList   *WorkDlp;



int CheckDestPath(void) /* 2.5b13 rri */
{
int i;

if(!ActionArgs[1]) return(0);
if(!ActionArgs[2])
 {
  ActionArgs[2]=dcPath;
  dcPath[0]=0;
  if(DestWin) strcpy(dcPath,DestWin->Path);
  if(ActionArgs[1]==ActionArgs[2])
   {
    return(0);
   }
  i=(DMReq(msgReqDestPath, dcPath, 512, DMREQ_HISTORY, (ULONG) &PathHistory,
                                        TAG_MORE, reqtags_OkSkipCan));  /* 2.5b13 jjt */
  if (!i||i==2||!ActionArgs[2][0]) return(0); /* 2.5b13 rri */
 }

RecurseDepth=0; /* 2.5b13 rri */

return(1);
}


UBYTE *MakeDestName(UBYTE *s,UBYTE *d)
{
UBYTE *dptr=d+strlen(d)-1,*sptr=s+strlen(s)-1,*dptrR; /* new! 2.5b5 */

while(sptr>s&&*sptr!='/'&&*sptr!=':') sptr--;
sptr++;
if(*dptr++!=':')
 {
  dptrR=dptr;
  *dptr++='/';
 }
else dptrR=dptr;
strcpy(dptr,sptr);
return(dptrR);
}


int addname(UBYTE *path,UBYTE *name,int len)
{
UBYTE *pt=path+len,ch;
int i=0;

if(len!=0&&(ch=path[len-1])!='/'&&ch!=':')
 {
  *pt++='/';
  ++i;
 }
 for( ; *pt++ = *name++ ; ++i );
 *pt=0;
 return len+i;
}


LONG get_blocks(long size,LONG bpb)
{
LONG data_blk,list_blk;

data_blk=(size+bpb-1)/bpb;   /* number of data blocks */
list_blk=(data_blk-1)/72;    /* number of file list blocks */
return(1+list_blk+data_blk); /* file header + list + data blocks */
}


int DMRecurse(int lenS,int lenD,int opt)
{
sFIB *info;
BPTR lock; /* 2.5b5 rri */
int  dir=0,reEx=0,i=0,
     cpyok=1; /* 2.5b13 jjt */

if(!lenS) return(0);

if(!(lock=Lock(sPath,ACCESS_READ))) return(0);

keepselected=0; /* 2.5b13 rri */

if(!(info=(sFIB *)AllocMem(sizeof(sFIB),MEMF_PUBLIC)))
 {
  Abort=1;
  goto RECERR;
 }

if(!Examine(lock,info))
 {
  Abort=1;
  goto RECERR;
 }

/* 2.5b9 rri */
if (!CDWin->Path[0]) /* is window showing DEVS/VOL/ASN list? */
 {
  Abort=1;
  goto RECERR;
 }

if(info->fib_DirEntryType>0&&!RecFlag&&!SingleFlag)
 {

/* Little loop to delete hard-links without destroying the files
   they are pointing at:  */

  if(opt==RECURSE_DEL) /* new! 2.4 */
   {
    if(DeleteFile(sPath)) /* when this is a success, the dir was a hard-linked */
     {                    /* or empty anyways */
      SmartRemEntry(sPath); /* remove entry from list */
      display(msgStatDeleted,sPath); /* inform user - 2.5b13 rri */
      UnLock(lock); /* free lock */
      sPath[lenS]=0;
      goto EX; /* exit */
     }
   }

  if(lenD)
   {
    if (Stricmp(sPath,dcPath)!=0) /* new! 2.4 */
     {
      i=addname(dcPath,info->fib_FileName,lenD);
      DMMakeDir(dcPath);
     }
   }
  if(opt==RECURSE_CHECK)
   {
    BlkTotal++;
    DirTotal++;
   }
  while(ExNext(lock,info))
   {
    RecurseDepth++;
    if(DMRecurse(addname(sPath,info->fib_FileName,lenS),i,opt))
    Examine(lock,info);
    RecurseDepth--;
    if(CheckAbortKey()) goto RECERR;
   }
  dir=1;
 }

RECERR:

UnLock(lock);
sPath[lenS]=0;

if(Abort) goto EX;

if(!(opt&3)) display(sPath,0);

if(!RecurseDepth||dir||DMMatch(info->fib_FileName,Pattern))
 {

  if(!dir&&(opt&RECURSE_COPY))
   {
    cpyok=DMCopy(sPath,dcPath,info,opt); /* 2.5b13 rri */
   }

  if((opt&RECURSE_DEL)&&!Abort&&cpyok) /* added cpyok test 2.5b13 jjt */
   {

    if(ForceFlag)  /* new! 2.4 */
     {
      SetProtection(sPath,0);
     }

    if(!(DeleteFile(sPath)))
     {
      reEx=IoErr();
      if(reEx==222) display(msgStatProtected,0); /* 2.5b13 rri */
      else
       {
        if(reEx==202) display(msgStatInUse,0); /* 2.5b13 rri */
         else display(msgErrorDelete,0); /* 2.5b13 rri */
        if(ForceFlag) SetProtection(sPath,info->fib_Protection); /* new! 2.4 */
       }
      reEx=0;
      goto EX;
     }
    else reEx=1;
    if(opt==RECURSE_DEL)
     {
      display(msgStatDeleted,sPath); /* 2.5b13 rri */
     }
    SmartRemEntry(sPath);
   }

  if(RecFlag||!dir) switch(opt)
   {
    case RECURSE_PROT: DMProtect(sPath,ActionArgs[2],info); break;
    case RECURSE_NOTE: DMComment(sPath,ActionArgs[2],info); break;
    case RECURSE_AUTO: AutoFiler(CmdWin,info->fib_FileName); break;
    case RECURSE_REN : DMRename(sPath); break;
    case RECURSE_EXEC: DOSExecute(); break;
    case RECURSE_PACK: DMPack(sPath, info, PackOpt); break; /*2.5b6 jjt */
    case RECURSE_READ: DMRead(sPath); break;  /* 2.5b6 jjt */
    case RECURSE_SHOW: View(sPath); break; /* new! 2.4 */
    case RECURSE_DATE: info->fib_Date.ds_Days=setStamp.ds_Days;
                       info->fib_Date.ds_Minute=setStamp.ds_Minute;
                       info->fib_Date.ds_Tick=0;
                       DMSetFileDate(sPath,info); break;
    case RECURSE_FIND:
         sprintf(sbuff,msgReqFind,info->fib_FileName); /* 2.5b13 rri */
         if (DMReqTagList(sbuff, 0, 0, reqtags_OkSkipCan) == 1)  /* 2.5b13 jjt */
          {
           GetParent(sPath,1);
           zooming[0]=CDWin->zoom[0];
           zooming[1]=CDWin->zoom[1];
           zooming[2]=CDWin->zoom[2];
           zooming[3]=CDWin->zoom[3];

           OpenDirWindow(sPath,CDWin->norm[0], /* 2.5b13 rri */
                               CDWin->norm[1]+20,
                               CDWin->norm[2],
                               120);
           Abort=1;
          }

         break;
    case RECURSE_CHECK: BlkTotal+=get_blocks(info->fib_Size,BPB);
                        DirTotal+=get_blocks(info->fib_Size,CDWin->BytesPerBlock); /* 2.5b5 rri */
    default: break;
   }
 }
EX:
 if(lenD) dcPath[lenD]=0;
 sPath[lenS]=0;
 if(info) FreeMem(info,sizeof(sFIB));
 return(reEx);
}


void StartRec(int type)
{
RecurseDepth=0;
if(ActionArgs[1]) /* new! 2.4 */
 {
  DMRecurse(addname(sPath,ActionArgs[1],0),0,type);
 }
}


void DoCmd(struct DirWindow *dw)
{
struct Window *win;
UBYTE temp[4],*ptr; /* new! 2.4 */
ULONG *CmdL=(ULONG *)temp;
int   h,l,t,w,i=0; /* new! 2.5b5 */

if(!ActionArgs[0]) return;

StrToUpper(ActionArgs[0]); /* 2.5b7 rri */
memmove(temp,ActionArgs[0],4); /* 2.5b10 rri */

switch(*CmdL)
 {
  case 0x41424f55: /* About */
                  About();
                  break;
  case 0x41444441: /* AddAutoCommand */
                  AddAutoCmd(ActionArgs[1]);
                  break;
  case 0x41444443: /* AddCommand */
                  AddCmd(dw,ActionArgs[1]);
                  break;
  case 0x4144444b: /* AddKeyCommand */
                  AddKeyCmd(ActionArgs[1]);
                  break;
  case 0x4144444d: /* AddMenuCommand */
                  AddMenuCmd(ActionArgs[1]);
                  break;
  case 0x41524348: /* Archiv */
                  DMArchive(ActionArgs[1],ActionArgs[2]);
                  ReSortFlag=1; /* new! 2.5b4a5 */
                  break;
  case 0x4155544F: /* Auto */
                  if (!AutoFiling)
                   {
                    StartRec(RECURSE_AUTO);
                   }
                  break;
  case 0x42415246: /* BarFormat */
                  DMSetFormat(ActionArgs[1],BarFormat,190);
                  break;

  case 0x4c4f4144: /* Batch */
  case 0x42415443: /* LoadConfig - Alias added in 2.5b1 */
                  GetCmdFile(dw,ActionArgs[1],0);
                  break;
  case 0x42555454:  /* Button */
                  if(!ActionArgs[1][0])
                   {
                    DMReqTagList(msgReqButton, PGadStr, 250, 0);  /* 2.5b13 rri */
                   }
                  else
                   {
                    strcpy(PGadStr,ActionArgs[1]);
                   }
                  break;
  case 0x43484543: /* Check */
                  CheckSpace(); /* new! 2.5b4a3 */
                  break;
  case 0x43484743: /* ChgCmd */
                  ChgCmd=1;
                  display(msgStatChgCmd,0); /* 2.5b13 rri */
                  break;
  case 0x43484F4F: /* Choose - 2.5b7 jjt (11.6.00) */
                   CMD_Choose(); /* 2.5b7 jjt (3.7.00) */
                   break;
  case 0x434c4f53: /* CloseWindow */
                  if (ActionArgs[1]) DWNum = atoi(ActionArgs[1]);
                  CloseDirWindow(DWNum);
                  break;
  case 0x434f4c4f: /* Color */
                  SetColors();
                  break;
  case 0x434f4d4d: /* Comment */
                  StartRec(RECURSE_NOTE);
                   if(CDWin) /* new! 2.5b3 */
                    {
                     if(CDWin->Sorting==2||CDWin->Sorting==3)
                      {
                       ReSortFlag=1;
                      }
                    }
                  break;
  case 0x434f4e46: /* Confirm */
                  if(!ConfirmFlag&&!PatReqFlag)
                   {
                    h=0;
                    if(ActionArgs[4])
                     {
                      strcpy(ReqStr,ActionArgs[4]);
                      h=512;
                      rexxStr=ReqStr;
                     }
                    else rexxStr = 0; /* 2.5b10 jjt */
                    MakeBtnString(ActionArgs[2], 0, ActionArgs[3]);  /* 2.5b10 jjt */
                    DMReq(ActionArgs[1], rexxStr,(ULONG) h, DMREQ_BUTTONS, g_buttons,
                                                    DMREQ_ABORT,   0,
                                                    TAG_END); /* 2.5b10 jjt */
                    if(!ActionArgs[4])
                     {
                      ConfirmFlag=1;
                      }
                   }
                  break;
  case 0x434f5059: /* Copy */
                  if(!CheckDestPath()) break; /* 2.5b13 rri */
                  DMRecurse(addname(sPath,ActionArgs[1],0),addname(dcPath,ActionArgs[2],0),RECURSE_COPY);
                  ReSortFlag=1; /* new! 2.5b2 */
                  WinTitleFlag=1; /* new! 2.5b4a5 */
                  break;
  case 0x44454c45: /* Delete */
                  if(WorkDlp->attr==DLT_DIRECTORY) /* 2.5b9 rri */
                   {
                    strcpy(sbuff,sPath);
                    sbuff[strlen(sbuff)-1]=0;
                    AssignLock(sbuff,0);
                    InitDir(CDWin,0);
                    break;
                   }
                  ForceFlag=0;
                  if(ActionArgs[2]&&(Stricmp(ActionArgs[2],"FORCE")==0)) /* 2.5b7 rri */
                   {
                    ForceFlag=1;
                   }
                  StartRec(RECURSE_DEL);
                  ReSortFlag=1; /* new! 2.5b2 */
                  break;
  case 0x44455345:  /* Deselect */
                  DMSelect(0);
                  break;
  case 0x4445564C:  /* DevList*/  /* 2.5b12 jjt*/
                  CMD_DevList();
                  break;
  case 0x4449524c: /* DirList */
                  if(rxMsg&&CDWin)
                   {
                    doDirList();
                   }
                  break;
  case 0x44495350: /* Display */
                  StartRec(0);
                  break;
  case 0x44555045: /* Dupe */
                  if(CDWin&&DestWin&&CDWin->Path[0]&&DestWin->Path[0])
                   {
                    Dupe();
                   }
                  break;
  case 0x45585041: /* Expand */ /* re-integrated with 2.5b6 rri */
                  if(ActionArgs[1])
                   {
                    expandflag=(ToUpper((ULONG)ActionArgs[1][1])!='F'); /* 2.5b10 rri */
                   }
                  else expandflag^=1;
                  break;
  case 0x45585445: /* Extern */
                  if(LoopFlag)
                   {
                    RecurseDepth=0;
                    DMRecurse(strlen(sPath),0,RECURSE_EXEC);
                   }
                  else DOSExecute();
                  ReSort();
                  break;
  case 0x46494c45: /* Filestat */  /* 2.5b5 rri */
                  if (rxMsg)
                   {
                    Filestat();
                   }
                  break;
  case 0x46494e44: /* Find */
                 if(WorkDlp->dir)
                  {
                   StartRec(RECURSE_FIND);
                  }
                 break;
  case 0x464f4e54: /* Font */
                  if (!ActionArgs[2]) /* new! 2.4 */
                   {
                    if (ActionArgs[1]) /* new! 2.4 */
                     {
                      ptr=ActionArgs[1]+strlen(ActionArgs[1]);
                      while(ptr>ActionArgs[1]&&*ptr!='/') ptr--;
                      ptr++;
                      if(isdigit(*ptr))
                       {
                        i=atoi(ptr--);
                        *ptr=0;
                       }
                     }
                   }
                  else if(isdigit(*ActionArgs[2]))
                   {
                    i=atoi(ActionArgs[2]); /* new! 2.4 */
                   }
                  DMOpenFont(ActionArgs[1],i);
                  break;
  case 0x47455448: /* GetHistory */  /* 2.5b11 jjt */
                  if (rxMsg) RXCMD_GetHistory();
                  break;
  case 0x47554900: /* GUI 2.5b7 rri */
                  if(ActionArgs[1])
                   {
                    Busy(1);
                   }
                  else
                   {
                    Busy(0);
                   }
                  break;
  case 0x48494445: /* HideDev */  /* 2.5b12*/
                   CMD_HideDev();
                   break;
  case 0x484f5354: /* Host */
                   GetHostScreen(ActionArgs[1]);
                   break;
  case 0x49434f4e:  /* Icon */  /* new! 2.4 */
                   if(ActionArgs[0][4]=='I') /* 2.5b7 rri */
                    {
                     Iconify();
                    }
                   else if(ActionArgs[1])
                         {
                          MakeIcon(ActionArgs[1]);
                         }
                    break;
  case 0x494e464f: /* Info */ /* new! 2.4 */
                   if(ActionArgs[1]) InfoReq(ActionArgs[1]);
                   break;
  case 0x4c415354: /* Last */ /* new! 2.5b4 */
                   if(DisplayBuffer[0])
                    {
                     DMReqTagList(DisplayBuffer, 0, 0, reqtags_Ok); /* 2.5b13 jjt */
                    }
                   break;
  case 0x4c4f434b:  /* Lock */
                    if(!CDWin) break;
                    switch(ToUpper((ULONG)ActionArgs[1][0])) /* 2.5b10 rri */
                     {
                      case 'S': CDWin->Flags|=DW_SOURCE;
                                CDWin->Flags&=~DW_DEST;
                                ShowDirection(CDWin,0);
                                break;
                      case 'D': CDWin->Flags|=DW_DEST;
                                CDWin->Flags&=~DW_SOURCE;
                                ShowDirection(CDWin,1);
                                break;
                     }
                    break;
  case 0x4d414b45: /* MakeDir */
                   DMMakeDir(ActionArgs[1]);
                   ReSortFlag=1; /* new! 2.5b2 */
                   break;
  case 0x4d4f5645: /* Move */
                   if(!CheckDestPath()) break; /* 2.5b13 rri */
                   DMRecurse(addname(sPath,ActionArgs[1],0),addname(dcPath,ActionArgs[2],0),RECURSE_MOVE);
                   ReSortFlag=1; /* new! 2.5b2 */
                   break;
  case 0x4d534700: /* Msg */
                   display(ActionArgs[1],ActionArgs[2]);
                   break;

  case 0x4e455744: /* NewDir */
                   if(CDWin)
                    {
                     if(ActionArgs[1])
                      {
                       strcpy(CDWin->Path,ActionArgs[1]);
                       CDWin->Pattern[0]=0; /* new! 2.4b22 */
                       if(FindPattern(CDWin->Path)) /* new! 2.4 */
                        {
                         Separate(CDWin); /* new! 2.4 */
                        }
                      }
                     else CDWin->Path[0]=0;
                     InitDir(CDWin,0);
                    }
                   break;
  case 0x4e455753: /* NewScreen */
                   if(!MyScreen) MyScreen=NewOpenScreen(1,DMname); /* new! 2.2b12 */
                   if(MyScreen) Screen=MyScreen;
                   break;
  case 0x4f50454e: /* OpenWindow */
                   RefreshCmdWin(dw);
                   if(ActionArgs[0][4]=='W')
                    {
                     l=atoi(ActionArgs[1]);
                     t=atoi(ActionArgs[2]);
                     w=atoi(ActionArgs[3]);
                     h=atoi(ActionArgs[4]);

                     /* 2.5b13 rri */
                     zooming[0]=GetActionArg("zooml", AATYPE_NUM, (LONG) l);
                     zooming[1]=GetActionArg("zoomt", AATYPE_NUM, (LONG) t);
                     zooming[2]=GetActionArg("zoomw", AATYPE_NUM, 65);
                     zooming[3]=GetActionArg("zoomh", AATYPE_NUM, 65);
                     if(GetActionArg("zoomed",AATYPE_BOOL,0))
                      {
                       PackOpt=42; /* magic cookie */
                      }
                     if (i=GetActionArg("zoom",AATYPE_BOOL,0))
                      {
                       if(i==5 && (ActionArgs[i][5]=='='||(Stricmp(ActionArgs[i],"zoomed")==0)))
                        {
                         ActionArgs[5]=0;
                        }
                      }
                     OpenDirWindow(ActionArgs[5],l,t,w,h);

                     if(PackOpt==42) /* 2.5b13 rri */
                      {
                       ZipWindow(CDWin->Window);
                       PackOpt=0;
                      }
                    }
                   break;
  case 0x5041434B: /* PACK */
                   PackOpt=1;
  case 0x554E5041: /* UNPACK */
                   if(!ActionArgs[1]) break;
                   RecurseDepth=0;
                   if (!AArg2Str("TO", dcPath, 512, FALSE, sPath)) /* 2.5b6 jjt */
                    {
                     if (DMReqTagList(msgReqDestPath, dcPath, 512, reqtags_OkSkipCan) != 1) break;  /* 2.5b13 jjt */
                    }                                                                               /* 2.5b6 jjt */
                   DMRecurse(addname(sPath, ActionArgs[1], 0), 0, RECURSE_PACK);  /* 2.5b6 jjt */
                   PackOpt=0;
                   break;
  case 0x50415245: /* Parent */
                   if(CDWin&&CDWin->Path[0])
                    {
                     GetParent(CDWin->Path,1);
                     InitDir(CDWin,0);
                    }
                   break;
  case 0x50454e53: /* Pens */
                   SetPens();
                   break;
  case 0x5052494e: /* PrintDir */
                   if(ToUpper((ULONG)ActionArgs[0][5])=='D') /* 2.5b10 rri */
                    {
                     if(!ActionArgs[1]||!ActionArgs[2]||!CDWin)
                      {
                       Abort=1;
                       break;
                      }
                     PrintDir(); /* 2.5b9 rri */
                    }
                   break;
  case 0x50524f54: /* Protect */
                   StartRec(RECURSE_PROT);
                   break;
  case 0x51554945: /* Quiet */ /* 2.5b5 rri */
                   QuietFlag=1;
                   break;
  case 0x51554954: /* Quit */
                   if(RexxOutstanding) /* new! 2.5b1 */
                    {
                     sprintf(sbuff,msgErrorArexx,RexxOutstanding);
                     DMReqTagList(sbuff, 0, 0, reqtags_Ok); /* 2.5b13 jjt */
                    }
                   else
                    {
                     KeepGoing=0; /* new! 2.4 CheckScreen(); */
                    }
                   break;
  case 0x52454144: /* Read */
                   StartRec(RECURSE_READ);
                   break;
  case 0x52454355: /* Recurse */
                   RecFlag=(ToUpper((ULONG)ActionArgs[1][1])=='F'); /* 2.5b10 rri */
                   break;
  case 0x52454e41: /* Rename */
                   if (RecFlag&&WorkDlp->dir==2&&WorkDlp->attr==DLT_VOLUME) /* 2.5b9 rri */
                    {
                     if (DMRelabel(WorkDlp->name,ActionArgs[1],ActionArgs[2]))
                      {
                       InitDir(CDWin,0);
                      } /* if (DMRelabel... */
                    } /* if (WorkDlp... */
                   else StartRec(RECURSE_REN);
                   ReSortFlag=1; /* new! 2.5b2 */
                   break;
  case 0x52455150: /* ReqPattern */
                   DMReqPat();
                   break;
  case 0x52455345: /* RESET */
                   FreeUserJunk();
                   break;
  case 0x52455858: /* REXX */
                   SendRexx();
                   break;
  case 0x524f4f54: /* Root */
                   if(CDWin&&CDWin->Path[0])
                    {
                     GetParent(CDWin->Path,0);
                     InitDir(CDWin,0);
                    }
                   break;
  case 0x53415645: /* Save */
                   SaveConfig();
                   break;
  case 0x53435242: /* Screen2Back */
                   WBenchToFront();
                   break;
  case 0x53435246: /* Screen2Front */
                   ScreenToFront(Screen);
                   break;
  case 0x53454c45: /* Select */
                   DMSelect(1);
                   break;
  case 0x53455444: /* SetDate */
                   DMSetDate();
                   break;
  case 0x5345544c: /* SetList */
                   if(rxMsg&&CDWin) doSetList(ActionArgs[1]);
                   break;
  case 0x53455446: /* SetFormat */
                   DMSetFormat(ActionArgs[1],DispFormat,50); /* new! 2.4b19 */
                   break;
  case 0x53455450: /* SetPattern */
                   PatReqFlag=1;
                   strcpy(Pattern,ActionArgs[1]);
                   break;
  case 0x53455458: /* SetX */ /* 2.5b7 rri */
                   DMSet();
                   break;
  case 0x53494e47: /* Single */
                   SingleFlag=1;
                   break;
  case 0x534f5254: /* Sort */
                   if (ActionArgs[1]) Sort();
                   break;
  case 0x53544154: /* Status */
                   RexxStatus(); /* new! 2.4 */
                   break;
  case 0x53544449: /* Stdio */
                   DoStdio(ActionArgs[1]);
                   break;
  case 0x53574150: /* Swap */ /* 2.4 rri */
                   if(ActionArgs[0][4]=='S')
                    {
                     if (CDWin&&CDWin->Path[0]) SwapSelect();
                    }
                   else DoSwap();
                   break;
  case 0x5449544C: /* TitleFormat */
                   DMSetFormat(ActionArgs[1],TitleFormat,50); /* 2.4b19 rri */
                   break;
  case 0x554e4c4f: /* UnLock */
                   if(ActionArgs[1][0]) UnLockAll();
                   else if(CDWin)
                         {
                          CDWin->Flags&=~(DW_DEST|DW_SOURCE);
                          ShowDirection(CDWin,0);
                         }
                   break;
  case 0x554e4d41: /* UnMark */
                   if(ActionArgs[1]&&(Stricmp(ActionArgs[1],"OFF")==0)) unMark=1; /* 2.5b7 rri */
                   else unMark=0;
                   break;
  case 0x56494557: /* View */ /* 2.4 rri */
                   StartRec(RECURSE_SHOW);
                   break;
  case 0x57414954: /* Wait */
                   if(t=atoi(ActionArgs[1]))
                    {
                     Delay((LONG)t*50); /* 2.5b10 rri */
                    }
                   else if(StdIO)
                         {
                          if(!ActionArgs[1])
                           {
                            strcpy(sbuff,msgStatWait); /* 2.5b13 rri */
                            ActionArgs[1]=sbuff;  /* 2.5b13 rri */
                           }
                          Write(StdIO,ActionArgs[1],(LONG)strlen(ActionArgs[1])); /* 2.5b10 rri */
                          Read(StdIO,sbuff,1); /* 2.5b10 rri */
                         }
                        else WaitPort(WinPort);
                   break;
  case 0x57494e44: /* Window */
                   win=0;
                   if(!ActionArgs[1])
                    {
                     rexxErr=1;
                     break;
                    }
                   if(Stricmp(ActionArgs[1],"DEST")==0) /* 2.5b7 rri */
                    {
                     win=DestWin->Window;
                    }
                   else if(Stricmp(ActionArgs[1],"NEXT")==0) /* 2.5b7 rri */
                    {
                     t=DWNum+1;
                     while(t!=DWNum)
                      {
                       if(DirWin[t]&&!(DirWin[t]->Flags&DW_CMD))
                        {
                         win=DirWin[t]->Window;
                         break;
                        }
                       t++;
                       if(t>=255) t=0; /* new! 2.4 */
                      }
                    }
                   else for(t=0;t<255;t++)
                    {
                     if(DirWin[t]) if(Stricmp(DirWin[t]->Path,ActionArgs[1])==0) /* 2.5b7 rri */
                      {
                       win=DirWin[t]->Window;
                       break;
                      }
                    }
                   if(win)
                    {
                     ActivateWindow(win);
                     FindDMWin(win); /* 2.5b6 rri */
                    }
                   else rexxErr=1;
                   break;
  case 0x57494e49: /* WinInfo */ /* 2.5b5 rri */
                   if (rxMsg)
                    {
                     WinInfo();
                    }
                   break;
 }
}


UBYTE *ParseArgs(UBYTE *buf,struct DirWindow *dw)
{
UBYTE *ptr,q;
int i,inq;

NXTCMD:

ptr=ActionBuf;

i=inq=0;
while(*buf==' '||*buf==9) buf++;
while(*buf>10)
 {
  if(*buf=='"'||*buf==39) inq^=1;
  if(!inq&&*buf==';') break;
  *ptr++ = *buf++;
 }
*ptr=0;
ptr=ActionBuf;

while(i<30)
 {
  while(*ptr&&(*ptr<=' '||*ptr==',')) ptr++;
  if(*ptr=='"'||*ptr==39)
   {
    q = *ptr++;
    ActionArgs[i]=ptr;
    while(*ptr&&*ptr!=q) ptr++;
    if(ActionArgs[i]==ptr) ActionArgs[i]=0;
   }
  else
   {
    ActionArgs[i]=ptr;
    while(*ptr&&*ptr!=' '&&*ptr!=',') ptr++;
    if(ActionArgs[i]==ptr) ActionArgs[i]=0;
   }
  i++;
  if(*ptr) *ptr++=0;
  else break;
 }
while(i<30) ActionArgs[i++]=0;
i=0;

while(ActionArgs[i])
 {
  ptr=ActionArgs[i];
  if(*ptr=='%') switch(ToUpper((ULONG)ptr[1])) /* 2.5b10 rri */
   {
    case 'A': ActionArgs[i]=DMname; /* new! 2.2b8 */
              break;
    case 'B': if(CDWin) /* 2.5b10 rri */
               {
                sprintf(ActionArgs[i],"%ld",CDWin->Sels);
               }
              break;
    case 'D': ActionArgs[i]=dcPath;
              if(DestWin) strcpy(dcPath,DestWin->Path);
              else
               {
                ActionArgs[i]=0;
                Abort=1;
               }
              if(ActionArgs[i]&&*ActionArgs[i]==0) ActionArgs[i]=0;
              break;
    case 'N': ActionArgs[i]=FilePart(sPath);  /* new! 2.4 */
              LoopFlag=1;
              if(!CDWin)
               {
                ActionArgs[i]=0;
                Abort=1;
               }
              break;
/*
    case 'M': MultiSelect(i);
              break;

  UBYTE buffer[100];
        strcpy(buffer, FilePart(dcPath));
        if (Stricmp(
        FilePart(dcPath)),info->fib_FileName)!=0)
*/

    case 'P': if(!CDWin)
               {
                ActionArgs[i]=0;
                Abort=1;
               }
              else ActionArgs[i]=CDWin->Path;
              break;

    case 'R': ActionArgs[i]=ReqStr;
              break;

    case 'S': ActionArgs[i]=sPath; LoopFlag=1;
              if(!CDWin)
               {
                ActionArgs[i]=0;
                Abort=1;
               }
              break;
   }
  i++;
 }

if(!Abort)
 {
  DoCmd(dw);
  dw=CmdWin;
 }
if(*buf==';'&&!Abort)
 {
  buf++;
  goto NXTCMD;
 }
return(buf);
}


void MakeFullName(UBYTE *buf,struct DirWindow *dw,UBYTE *name)
{
if(!dw) dw=CDWin;
if(!dw)
 {
  *buf=0;
  return;
 }
strcpy(buf,dw->Path);

AddPart(buf, name, 512); /* 2.5b5 hys */
}


void ActionCmd(struct DirWindow *dw,UBYTE *buf)
{
struct DirWindow *dw2;
struct DirList **dl,*dlp=0;
UBYTE *ptr,*BufS;
int c,k,loop,dloop,destlocked,j;
LONG item; /* 2.5b10 rri */

if(!buf) return;

ResetFlags();
rexxStr=0;
ReqStr[0]=0;

keepselected=0; /* 2.5b13 rri */
skip_all=0; /* 2.5b13 rri */

while(*buf)
 {
  NXTLIN:

  while(*buf&&*buf<=' ') buf++;
  if(*buf==0) break;
  k=(*buf==';');
  if(ToUpper((ULONG)*buf)=='A'&&ToUpper((ULONG)buf[1])=='D') k=(-1); /* 2.5b10 rri */
  if(k)
   {
    if(k<0)
     {
      ActionArgs[0]=ptr=ActionBuf;
      while(*buf>' ') *ptr++ = *buf++;
      *ptr=0;
      if(*buf==' '||*buf==9) buf++;
      ActionArgs[1]=buf;
      DoCmd(dw);
      dw=CmdWin;
     }
    while(*buf&&*buf!=10) buf++;
   }
  else
   {
    loop=dloop=0;
    BufS=buf;
    destlocked=0;
    BlkTotal=0;
    item=0;
    while(*BufS&&*BufS!=10)
     {
      if(*BufS=='%'&&ToUpper((ULONG)BufS[1])=='S') loop=1; /* 2.5b7 rri */
      if(*BufS=='%'&&ToUpper((ULONG)BufS[1])=='D') dloop=1; /* 2.5b7 rri */
      if(*BufS=='%'&&ToUpper((ULONG)BufS[1])=='N') loop=1; /* 2.5b7 rri */
      BufS++;
     }
    if(loop) for(j=0;j<255;j++)
     {
      dw2=DirWin[j];
      if(dw2&&(dw2->Flags&DW_SOURCE)&&dw2->Sels)
       {
        CDWin=dw2;
        break;
       }
     }
    BufS=buf;
    sPath[0]=0;

    NXTLOOP:

    if(CDWin) strcpy(sPath,CDWin->Path);
    DirTotal=0;
    if(loop)
     {
      if(!CDWin)
       {
        return;
       }
      dl=CDWin->DirList;
      while(item<CDWin->FileCount)
       {
        dlp=dl[item];
        if(dlp->sel==1)
         {
          while(item>(CDWin->Index+CDWin->Rows-1)) /* new! 2.4 */
           {
            Increment(CDWin,&CDWin->dn,(item-CDWin->Rows-CDWin->Index));
           }
          MakeFullName(sPath,CDWin,dlp->name);
          break;
         }
        item++;
       }
      if(item>=CDWin->FileCount)
       {
        CDWin->Sels=0;
        for(j=0;j<255;j++)
         {
          dw2=DirWin[j];
          if(dw2&&(dw2->Flags&DW_SOURCE)&&dw2->Sels)
           {
            CDWin=dw2;
            item=0;
            goto NXTLOOP;
           }
         }
        while(*buf&&*buf!=10) buf++;
        goto NXTLIN;
       }
      if(CDWin->Flags&DW_DEST)
       {
        return;
       }
     }
    WorkDlp=dlp;
    if(dloop) for(j=0;j<255;j++)
     {
      dw2=DirWin[j];
      if(dw2&&(dw2->Flags&DW_DEST))
       {
        DestWin=dw2;
        destlocked=1;
        ParseArgs(buf,dw);
        dw=CmdWin;
        if(CheckAbortKey())
         {
          rexxErr=1;
          Abort=0;
          display(msgStatAborted,0); /* 2.5b13 rri */
          goto DIE;
         }
        if(CDWin&&dlp->sel==1) MakeFullName(sPath,CDWin,dlp->name);
        buf=BufS;
       }
     }
    if(!destlocked)
     {
      buf=ParseArgs(buf,dw);
      dw=CmdWin;
      if(CheckAbortKey())
       {
        rexxErr=1;
        Abort=0;
        display(msgStatAborted,0); /* 2.5b13 rri */
        goto DIE;
       }
     }
    if(loop&&CDWin&&dlp)
     {
      if(DirTotal&&dlp->dir==1)
       {
        dlp->size=DirTotal;
       }
      if(item<CDWin->FileCount&&dlp->sel<2&&!unMark&&!keepselected) /* 2.5b13 rri */
       {
        dlp->sel=0;
       }
      c=CDWin->Index;
      if(item>=c&&item<(c+CDWin->Rows)) dis_name(CDWin,item,item-c);
      dlp=0;
      if(!SingleFlag)
       {
        buf=BufS;
        item++;
        goto NXTLOOP;
       }
     }
   }
 }

DIE:

/* CloseRead(); */ /* 2.5b8 jjt */
*g_readsearchpat = 0;
RefreshCmdWin(dw);

if(ReSortFlag==1) /* new! 2.5b2 */
 {
  ReSort();
 }

if(WinTitleFlag==1) /* new! 2.5b3 */
 {
  WinTitle(CDWin);
 }

ResetFlags();
}
