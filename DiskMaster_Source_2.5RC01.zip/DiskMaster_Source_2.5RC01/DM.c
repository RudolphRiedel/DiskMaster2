/* DiskMaster II  Main Module  Startup/Exit, S/D control
**
** 00-05-31 rri
**
** Inserted "WinTitle(DestWin);" two times in DoWindow().
** The first fixes the glitch with "select dir - click nextwin".
** The second fixes the glitch with "select dir - click right".
** In both cases the dest-win title kept showing 1 entry selected.
**
** 00-06-11 jjt
** - Bug fix (?):  main() - Replaced line "wincount=1000;" w/ "break";
**
** 00-06-22 jjt - LibOpen() - Removed "retry" loop & req.
**
** 00-06-24 rri - replaced annother "int lock;" by "BPTR lock;"
**              - replaced all c++ style comments by ANSI ones
**          jjt - Moved XpkBase & xfdMasterBase defs to DMPack.
**
** 00-06-25 rri - added filesystem notification
**
** 00-07-01 rri - removed notifcation requester
**
** 00-07-06 rri - removed a GOTO from BootBatch()
**              - notifcation triggers windowupdate now
**
** 00-07-07 rri - changed visitor-window warning to call EasyReq()
**              - increased itime from 1 to 2 for lesser Lock`s
**
** 00-08-13 rri - removed a misplaced WinTitle(DestWin); from DoWindow()
**
** 00-08-25 jjt - FreeUserJunk() calls CloseRead().
**
** 00-08-27 rri - Added FreeGlobuff() to FreeUserJunk()
**
** 00-08-29 rri - replaced some lines in BootBatch() by a call to FindCmdWin()
**
** 00-09-03 rri - set the release-date of 2.5b7 to 00-09-03
**
** 2.5b8
**
** 00-09-04 rri - set the version to 2.5b8
**
** 00-09-07 rri - changed var "iconify" to "KeepGloBuff"
**              - set the release-date of 2.5b8 to 00-09-07
**
** 2.5b9
**
** 00-09-08 rri - set the version to 2.5b9
**
** 00-09-24 rri - changed DoWindow to scroll on IDCMP_MOUSEMOVE events
**
** 00-10-04 rri - set default display-format to "NS C" to make things
**                more simple for newbies
**              - changed BootBatch() to handle the two-parted internal startup.dm
**              - removed all date-info from the overcrowded
**                default screentitle
**              - added screen sensitive windows to BootBatch()
**
** 00-11-07 rri - content of "Notify" is now added to "itime" to have lesser
**                Lock()`s when filesystem-notification is active
**              - Made the main-loop a sub-function called MainLoop() to
**                replace the copy in DMRexx.c of this loop
**
** 00-11-23 rri - set the release-date of 2.5b9 to 00-11-23
**              - increased stack to 8K - just for more headroom
**
** 2.5b10
**
** 00-11-26 rri - set version to 2.5b10
**
** 00-11-28 rri - squashed an enforcer-hit with slide_em() in DoWindow()
**                reported by Xavier Messersmith <xcaliber@xav.to>
**
** 00-12-05 rri - removed a "warning 220" from MainLoop()
**              - removed a "warning 317" from FindDMWin()
**
** 00-12-06 rri - Bugfix: activation of the string-gadget started mouse-move events
**                that prevented further click-drag selection
**                Reported by Jostein Klemmetsrud <klemmetj@c2i.net>
**
** 00-12-09 rri - Bugfix: only clicking on sliders will start
**                mouse-movement events
**                Reported by Dirk Teunis (parcival@yucom.be)
**
** 00-12-13 jjt - Added PathHistory, ReqHistory, PathStrData, & EditHook.
**              - main() - Initialized the above, and free them at the end.
**
**              - Removed PathStrData, & all StringData references.
**              - Added ReadHistory.
**
** 00-12-19 rri - replaced StartTimer() and TimerCode() from DMAsm.a
**
** 00-12-23 rri - changed the function-header for TimerCode()
**              - added this cast: "TimerInt.is_Code=(void (*)()) TimerCode;"
**                to get rid of one "warning 225"
**              - added this cast: "ItemAddress(DMMenu,(ULONG) code))"
**                to get rid of one "warning 120"
**              - moved "TimerSignal" into Main() and made it LONG
**                to get rid of one "warning 120"
**
** 00-12-23 jjt - Added extern ref. to reqtags_Ok.
**              - DoWindow() - Esc now cancels dir window string gadget.
**              - Replaced a call to EasyReq() w/ DMReqTagList().
**
** 00-12-27 rri - made Bar_Height a LONG
**              - removed global-var "i" - must`ve been an accident
**              - sorted vars and removed unused vars
**
** 01-01-03 rri - added creation of comments memory-pool to main()
**
** 01-01-08 rri - added creation of names memory-pool to main()
**
** 01-01-09 jjt - Added StringPool & ReaderPool creation & destruction to main().
**              - Removed StrHist_Clear() calls.  Deleting StringPool does the job.
**
** 01-01-28 rri - increased puddle-sizes for NamePool and CommentPool
**                to meet requirements of PoolAllocVec()
**
** 01-02-18 rri - moved FindDMWin(), SetTitles(), BootBatch() and FreeUserJunk()
**                to DMSupport.c to shorten compile-time for DM.c
**              - removed a few obsolete vars
**
** 01-02-24 rri - set release date
**
** 2.5b11
**
** 01-03-01 rri - set version to 2.5b11
**
** 01-03-01 jjt - Changed obsolete Intuition flag names to v36 versions:
**                  MENUPICK to IDCMP_MENUPICK,
**                  MOUSEBUTTONS to IDCMP_MOUSEBUTTONS,
**                  SELECTED to GFLG_SELECTED,
**                  WINDOWACTIVE to WFLG_WINDOWACTIVE.
**
** 01-07-20 rri - set release date
**
** 2.5b12
**
** 01-07-23 rri - set version to 2.5b12
**
** 01-08-01 jjt - Added IDCMP_DISKREMOVED handling to DoWindow().
**              - IDCMP_DISKINSERTED & IDCMP_DISKREMOVED call RefreshDevLists().
**              - Added DiskKludge var to DoWindow(), a quick-fix so only one
**                DISKINSERTED/REMOVED msg gets acted upon.
**
** 01-08-05 rri - increased the puddle-size of StringPool by 1000
**              - set release date
**
** 2.5b13
**
** 01-08-08 rri - set version to 2.5b13
**
** 01-08-11 rri - moved DoWindow() to DMWindows.c
**
** 01-09-15 rri - added calls for locale-functions instead of leaving
**                them auto-init
**
** 01-09-29 jjt - main() initializes the reqtags_... strings.
**              - Added externs for reqtags_Ok & reqtags_OkSkipCan.
**
** 01-10-20 rri - added call to CheckMonth() to main()
**
** 01-10-30 rri - set release-date and version to 2.5RC1
**
*/

#include "DM.h"

extern struct Menu      *DMMenu;
extern struct WBStartup *_WBenchMsg;
extern struct RexxMsg   *WaitRX;
extern struct TextFont  *DMFont;

extern struct Library *AmigaGuideBase; /* new! 2.4 */
extern struct Library *WorkbenchBase; /* new! 2.4 */

extern UBYTE FontName[],
             *Globuff; /* 2.5b9 rri */

extern int  FontSize, /* new! 2.4 */
            LastI,
            Notify; /* 2.5b9 rri */

extern ULONG g_memattrs; /* 2.5b10 jjt */

extern struct TagItem reqtags_Ok[],         /* 2.5b13 jjt */
                      reqtags_OkSkipCan[];  /* 2.5b13 jjt */

struct RxsLib       *RexxSysBase; /* new! 2.5b5 jjt */
struct ReqToolsBase *ReqToolsBase; /* new! 2.2b10 */
struct Library      *DiskfontBase; /* new! 2.4 */
struct Library      *AslBase; /* new! 2.5b2 */
struct Library      *LocaleBase; /* 2.5b13 rri */

struct Library      *LibBasePtrs[20];  /* 2.5b6 jjt (18.5.00) */

struct Screen    *Screen;
struct Process   *process;
struct MsgPort   *WinPort,*NotifyPort; /* 2.5b7 rri */
struct DirWindow *DirWin[255],*CDWin,*DestWin,*CmdWin;
struct DirList   *DClickDir;
struct TextFont  *MyTopaz;
struct TextAttr  FuckingTopaz={"topaz.font",8,0,0};
struct Interrupt TimerInt;

struct TDat /* 2.5b10 rri */
 {
  ULONG TSignalMask;
  LONG TData;
  struct Task *TTask;
 };

struct TDat TimerData= /* 2.5b10 rri */
 {
  0,
  0,
  0,
 };

struct StringHistory ReqHistory, PathHistory, ReadHistory;  /* 2.5b10 jjt */
struct Hook EditHook;  /* 2.5b10 jjt */

APTR CommentPool, /* 2.5b10 rri */
     NamePool, /* 2.5b10 rri */
     StringPool, /* 2.5b10 jjt */
     ReaderPool; /* 2.5b10 jjt */

LONG   __oslibversion=37,
       __stack=8192,
       __priority=0,
       LibBaseTotal=0; /* 2.5b6 jjt (18.5.00) */

int    Abort,
       DClick,
       DMnumber=2,
       DWNum,
       KeepGoing=1,
       lockcount,
       Use30;

UBYTE  BarFormat[200],
       DispFormat[60],
       DMname[7]="DM.1",
       *NextPath,
       ScreenTitle[256],PGadStr[256],
       Strap[256],
       TitleFormat[60],
       Version[]="DiskMaster 2.5RC1",
       VerstrA[]="$VER: DiskMaster 2.5RC1 (01-10-30) R.Riedel";
       /* VerstrA[]="$VER: DiskMaster 2.5"__AMIGADATE__" R.Riedel", */



void __stdargs __main(char *line)
{
int i;
LONG TimerSignal; /* 2.5b10 rri */

process=(struct Process *)FindTask(0);
process->pr_WindowPtr=(APTR)-1;
if(IntuitionBase->LibNode.lib_Version>38) Use30=1;

LibOpen("reqtools.library", (struct Library **) &ReqToolsBase, 0);   /* 2.5b6 jjt (18.5.00) */
LibOpen("rexxsyslib.library", (struct Library **) &RexxSysBase, 0);  /* 2.5b6 jjt (18.5.00) */
LibOpen("diskfont.library", &DiskfontBase, 0);                       /* 2.5b6 jjt (18.5.00) */
LibOpen("asl.library", &AslBase, 37);                                /* 2.5b6 jjt (18.5.00) */

if (LibOpen("locale.library", &LocaleBase, 38)) /* 2.5b13 rri */
 {
  OpenDM2Catalog();
 }

/* --- Initialize reqtags_... strings --- */
reqtags_Ok[0].ti_Data = (ULONG) msgGadOkay;             /* 2.5b13 jjt */
reqtags_OkSkipCan[0].ti_Data = (ULONG) msgGadOkSkipCan; /* 2.5b13 jjt */

Forbid(); /* new! 2.4 */
while(FindPort(DMname))
 { /* new! 2.2b12 */
  sprintf (DMname,"DM.%ld", DMnumber++);
 }
Permit(); /* new! 2.4 */

if(!(WinPort=CreatePort(DMname,0))) goto Q2;

if(!(NotifyPort=CreatePort(0,0))) goto Q2; /* 2.5b7 rri */

if(!(TimerSignal=AllocSignal(-1))) goto Q2; /* 2.5b10 rri */

if (!(CommentPool= AsmCreatePool(g_memattrs,  8100,  100, SysBase))) goto Q2; /* 2.5b10 rri */
if (!(NamePool   = AsmCreatePool(g_memattrs, 16384,  256, SysBase))) goto Q2; /* 2.5b10 rri */
if (!(StringPool = AsmCreatePool(g_memattrs,  4000, 2000, SysBase))) goto Q2; /* 2.5b12 rri */
if (!(ReaderPool = AsmCreatePool(g_memattrs,  1200, 1000, SysBase))) goto Q2; /* 2.5b10 jjt */

DMnumber--; /* new! 2.2b15 */
process->pr_Task.tc_Node.ln_Name=DMname; /* new! 2.2b14 */

InitScreenDefaults();   /* new! 2.2b14 */
DMOpenFont(FontName,FontSize); /* new! 2.4 */
strcpy(PGadStr,"Parent");
MyTopaz=OpenFont(&FuckingTopaz);

/* var ini on startup - new! 2.2b12 */

sprintf (Strap,"DMS:Startup.DM");
sprintf (DispFormat,"NS C"); /* 2.5b9 rri */
sprintf (TitleFormat,"%%B/%%F %%I/%%C"); /* new! 2.2b14 */
sprintf (BarFormat,"DiskMaster %%V  %%T   C:%%C  F:%%F  Total:%%P"); /* 2.5b9 rri */

StrHist_Init(&ReqHistory);         /* 2.5b10 jjt */
StrHist_Init(&PathHistory);        /* 2.5b10 jjt */
StrHist_Init(&ReadHistory);        /* 2.5b10 jjt */
ReadHistory.mempool = ReaderPool;  /* 2.5b10 jjt */
EditHook.h_Entry = (ULONG (*)()) StringHook;  /* 2.5b10 jjt */

CheckMonth(); /* 2.5b13 rri */

if(!BootBatch(line)) goto DIE;

TimerInt.is_Node.ln_Type=2;
TimerInt.is_Node.ln_Name="DMTimer";
TimerData.TSignalMask = 1L << TimerSignal; /* 2.5b10 rri */
TimerData.TTask = FindTask(0); /* 2.5b10 rri */
TimerInt.is_Code=(void (*)()) TimerCode; /* 2.5b10 rri */

AddIntServer(INTB_VERTB,&TimerInt); /* 2.5b10 rri */

DoWindow();

while(KeepGoing)
 {
  MainLoop(); /* 2.5b9 rri */
 }

RemIntServer(INTB_VERTB,&TimerInt); /* 2.5b10 rri */

DIE:

FreeUserJunk();
KeepGoing=0;

DeletePort(WinPort);
DeletePort(NotifyPort); /* 2.5b7 rri */

FreeSignal(TimerSignal); /* 2.5b10 rri */

AsmDeletePool(CommentPool, SysBase); /* 2.5b10 rri */
AsmDeletePool(NamePool,    SysBase); /* 2.5b10 rri */
AsmDeletePool(StringPool,  SysBase); /* 2.5b10 jjt */
AsmDeletePool(ReaderPool,  SysBase); /* 2.5b10 jjt */

if(MyTopaz) CloseFont(MyTopaz);
if(DMFont) CloseFont(DMFont);

Q2:

CloseDM2Catalog(); /* 2.5b13 rri */

for (i=0; i < LibBaseTotal; i++)
 {
  CloseLibrary(LibBasePtrs[i]);  /* 2.5b6 jjt (18.5.00) */
 }
}


BOOL LibOpen(STRPTR name, struct Library **base, ULONG ver) /* 2.5b6 jjt */
{
if (*base == 0)
 {
  if ((*base = OpenLibrary(name, ver)) == 0) return FALSE;
  LibBasePtrs[LibBaseTotal++] = *base;
 }
return TRUE;
}


void MainLoop(void) /* 2.5b9 rri */
{
struct DirWindow *dw;
int t,i;
ULONG sig;

ULONG notifymask = 1L << NotifyPort->mp_SigBit; /* 2.5b7 rri */
struct NotifyMessage *note; /* 2.5b7 rri */

int wincount;

struct DateStamp now; /* new! 2.5b3 */
static LONG Minutes=0; /* new! 2.5b3 */
static int itime=1;

if(lockcount)
 {
  t=0;
  for(i=0;i<255;i++)
   {
    dw=DirWin[i];
    if (dw) GetDirEntry(dw); /* new! 2.4b19 */
    if(dw&&dw->DirLock) t=1;
   }
  if(!t)
   {
    lockcount=0;
    if(WaitRX)
     {
      ReplyMsg((struct Message *)WaitRX);
      WaitRX=0;
     }
   }
  DoWindow();
 }
else
 {
  StartTimer(itime); /* 2.5b3 rri */
  sig=Wait((1<<WinPort->mp_SigBit)|notifymask|TimerData.TSignalMask); /* 2.5b10 rri */
  TimerData.TData=0; /* 2.5b10 rri */

  if (sig & notifymask) /* 2.5b7 rri */
   {
    while (note=(struct NotifyMessage *)GetMsg(NotifyPort))
     {
      ReplyMsg((struct Message *)note);
     }
    ReSort(); /* 2.5b7 rri */
   }

  if(sig != TimerData.TSignalMask) /* 2.5b10 rri */
   {
    MainTitle();
    DoWindow();
   }
  else /* 2.5b2 rri */
   {
    wincount=0; /* 2.5b3 rri */
    while(DirWin[wincount])
     {
      if(DirWin[wincount]->Window->Flags&WFLG_WINDOWACTIVE)
       {
        itime=1+Notify; /* 2.5b9 rri */
        break;   /* 2.5b6 jjt (11.6.00) */
       }
      else
       {
        itime=4;
        wincount++;
       }
      }

    DClickDir=0;
    LastI=(-1); /* 2.5b10 rri */

    if(CDWin) /* 2.5b3 rri */
     {
      DateStamp(&now); /* get current system time */
      if (now.ds_Minute>Minutes) /* check if a new minute began */
       {
        Minutes=now.ds_Minute; /* update the minute-counter var */
        MainTitle(); /* 2.5b2 rri */
        SetTitles(); /* 2.5b2 rri */
       }
      if(!(CDWin->dir_gad.Flags&GFLG_SELECTED))
       {
        ReSort();
       }
     }
   }
 }
}


void StartTimer(int itime) /* 2.5b10 rri */
{

SetSignal(0L,TimerData.TSignalMask);

TimerData.TData=SysBase->VBlankFrequency*itime;
}


int __interrupt __saveds TimerCode() /* 2.5b10 rri */
{

if (TimerData.TData)
 {
  if (!--TimerData.TData)
   {
    Signal(TimerData.TTask,TimerData.TSignalMask);
   }
 }

return 0;
}
