/* DiskMaster II ARexx-Module */
/*
** Last changes:
**
** 00-06-12 rri - SendRexx() : replaced "wincount=1000;" by "break" as Jody
**                already did in DM.c
**
** 00-07-01 rri - removed dw->Devi[0]=0 from doSetList()
**              - replaced all c++ style comments by ANSI ones
**              - removed some flagged-out code
**
** 00-07-08 rri - changed MyStrUpper() calls to new StrToUpper() calls
**              - added filesystem-notification to SendRexx()
**              - increased itime from 1 to 2 for lesser Lock`s
**              - replaced MyToUpper() calls by ToUpper() (utility.library)
**
** 00-07-12 rri - changed various stricmp() to Stricmp() calls
**              - bugfix in dosetlist() - still used 30 chars for the name
**
** 00-10-15 rri - optimized var-header
**              - removed several "#pragma msg 88 ignore" lines
**
** 2.5b9
**
** 00-11-07 rri - replaced the copy of the main loop from DM.c in SendRexx()
**                by a call to the new function MainLoop()
**
** 2.5b10
**
** 00-12-27 rri - removed 23 "warning 120"`s mostly by adding
**                this type-cast: "(ULONG) strlen()"
**              - removed one "warning 220"
**              - removed two "warning 317"`s
**              - set "ID" in RexxStatus() from UBYTE to LONG
**              - removed a couple of obsolete vars
**
** 01-01-11 rri - changed doSetList() to make use of pooled names
**
** 01-01-28 rri - changed ->name2 referencies to ->name
**              - introduced CloneStr() for names
**
** 2.5b11
**
** 01-04-13 jjt - Added RXCMD_GetHistory().
**
** 2.5b13
**
** 01-09-05 rri - added var.path to DoDirList() - Jody Tierney, ID: 01.18
**              - added new sub-routine outputRexxVar(), replacing several
**                SetRexxVar(rxMsg,var,cont,strlen(cont)); by more simple
**                outputRexxVar(var,cont); calls saved about 350 bytes
**
** 01-09-08 rri - two more sub-routines: RexxPrint() and RexxPrintDec()
**                this saved 196 bytes again
**              - making outputRexxVar() simpler saved 104 bytes again
**              - localize: SendRexx() - msgReqSendRexx
**
** 01-09-09 rri - RexxPrintDec_sbuff() this final sub-routine saved 80 bytes
**                  
**
*/

#include "DM.h"

extern struct RxsLib *RexxSysBase; /* 2.5b5 jjt */
extern struct DirWindow *DirWin[],*CDWin,*CmdWin,*DestWin;

extern struct MsgPort *WinPort;

extern struct StringHistory ReqHistory, PathHistory, ReadHistory;  /* 2.5b11 jjt */


extern APTR NamePool; /* 2.5b10 rri */

extern int KeepGoing,
           lockcount,
           Abort,
           DWNum,
           LoopFlag;

extern UBYTE sbuff[],
             dcPath[],
             DMname[],
             *ActionArgs[],
             DispFormat[],
             Version[];

extern BPTR StdIO;  /* 2.5b5 jjt (Experiment) */


struct RexxMsg *WaitRX,*rxMsg;

UBYTE RexxPassStr[1024],
      *rexxStr,
      RexxReturn[12], /* new! 2.4b20 */
      HostID[32]; /* 2.5b9 rri */

UBYTE 
      dlbase[32],
      dlcomm[]="COMMENT",
      dldate[]="DATE",
      dldir[]="DIR",
      dlid[]="ID",
      dlname[]="NAME", /* 2.5b5 rri */
      dlpath[]="PATH",
      dlprot[]="PROTECT",
      dlsel[]="SEL",
      dlsize[]="SIZE",
      dlstatus[]="STATUS",
      dlvar[]="VAR";

LONG RexxOutstanding,rexxErr;

void outputRexxVar(UBYTE *cont); /* 2.5b13 rri */
void RexxPrint(UBYTE *string); /* 2.5b13 rri */
void RexxPrintDec(UBYTE *string,LONG i); /* 2.5b13 rri */
void RexxPrintDec_sbuff(LONG i); /* 2.5b13 rri */


void outputRexxVar(UBYTE *cont) /* 2.5b13 rri */
{
SetRexxVar(rxMsg,dcPath,cont,(ULONG) strlen(cont));
}


void RexxPrint(UBYTE *string) /* 2.5b13 rri */
{
sprintf(dcPath,"%s.%s",dlbase,string);
}


void RexxPrintDec(UBYTE *string,LONG i) /* 2.5b13 rri */
{
sprintf(dcPath,"%s.%s.%ld",dlbase,string,i);
}

void RexxPrintDec_sbuff(LONG i) /* 2.5b13 rri */
{
sprintf(sbuff,"%ld",i);
}


int do_rexx_cmd(struct RexxMsg *rm)
{
int ret;

ret=1;

if(rm->rm_LibBase==(APTR)RexxSysBase)
 {
  rexxErr=0;
  RESULT1(rm)=0;
  RESULT2(rm)=0;
  rxMsg=rm;
  ActionCmd(CmdWin,ARG0(rm));
  rxMsg=0;
  if(lockcount&&!WaitRX)
   {
    WaitRX=rm;
   }
  else
   {
    if(rexxErr) RESULT1(rm)=1;
    else if(rexxStr&&(rm->rm_Action&=RXFF_RESULT))
     {
      RESULT2(rm)=(LONG)CreateArgstring(rexxStr,(ULONG) strlen(rexxStr)); /* 2.5b10 rri */
     }
    ReplyMsg((struct Message *)rm);
   }
 }
else if(rm->rm_Node.mn_Node.ln_Type==NT_REPLYMSG)
 {
  DeleteArgstring(rm->rm_Args[0]);
  DeleteRexxMsg(rm);
  if(RexxOutstanding) RexxOutstanding--;
  if(rm->rm_Result1) /* new! 2.4b20 */
   {
    DoStdio("CLOSE");
    Abort=1;
   }
 }
else ret=0;
return(ret);
}

struct RexxMsg *MakeRexxMsg()
{
return(CreateRexxMsg(WinPort,"dm",DMname));
}


void SendRexx()
{
UBYTE *arg;
struct RexxMsg *rmsg;
struct MsgPort *port;
int fail=0,ro;

if(!RexxSysBase) return;
if(!DOSParse(RexxPassStr,msgReqSendRexx,1)) return; /* 2.5b13 rri */
if(!(arg=CreateArgstring(RexxPassStr,(ULONG) strlen(RexxPassStr)))) return; /* 2.5b10 rri */
if(rmsg=MakeRexxMsg())
 {
  ACTION(rmsg)=RXCOMM;
  ARG0(rmsg)=(STRPTR)arg;
  rmsg->rm_Stdout = StdIO;  /* 2.5b5 jjt (Experiment) */
  Forbid();
  if(port=FindPort("REXX"))
   {
    PutMsg(port,(struct Message *)rmsg);
    RexxOutstanding++;
   }
  else fail=1;
  Permit();
  if(fail) DeleteRexxMsg(rmsg);
 }
ro=RexxOutstanding;
if(fail) DeleteArgstring(arg);
else if(LoopFlag) while(KeepGoing&&!Abort&&RexxOutstanding==ro)
 {
  MainLoop(); /* 2.5b9 rri */
 }
}


void doDirList(void)
{
struct DirList **dl=CDWin->DirList;
UBYTE *ptr=dcPath+100;
int lsize,lcomm,lprot,ldate,lsel,ldir,list_item; /* 2.5b5 rri */

ULONG stem_item,items;

AArg2Str(dlvar, dlbase, 31, TRUE, "LIST");  /* 2.5b6 jjt (30.5.00) */

lsel=ldir=0;

lsize=GetActionArg(dlsize, AATYPE_BOOL, 0); /* 2.5b5 rri */
lcomm=GetActionArg(dlcomm, AATYPE_BOOL, 0); /* 2.5b5 rri */
lprot=GetActionArg(dlprot, AATYPE_BOOL, 0); /* 2.5b5 rri */
ldate=GetActionArg(dldate, AATYPE_BOOL, 0); /* 2.5b5 rri */

if(GetActionArg(dlsel, AATYPE_BOOL, 0)) /* 2.5b5 rri */
 {
  lsel=1;
 }
if(GetActionArg("unsel", AATYPE_BOOL, 0)) /* 2.5b5 rri */
 {
  lsel=2;
 }
if(GetActionArg(dldir, AATYPE_BOOL, 0)) /* 2.5b5 rri */
 {
  ldir=1;
 }
if(GetActionArg("file", AATYPE_BOOL, 0)) /* 2.5b5 rri */
 {
  ldir=2;
 }

RexxPrint(dlpath); /* 2.5b13 rri */
outputRexxVar(CDWin->Path); /* 2.5b13 rri */

if(!CDWin->FileCount) /* new! 2.4b16 */
 {
  RexxPrintDec(dlname,0); /* 2.5b13 rri */
  sprintf(ptr,"0");
  outputRexxVar(ptr); /* 2.5b13 rri */
  dcPath[0]=0;
  return;
 }

/*
 Types for fib_DirEntryType.  NOTE that both USERDIR and ROOT are
 directories, and that directory/file checks should use <0 and >=0.
 This is not necessarily exhaustive!  Some handlers may use other
 values as needed, though <0 and >=0 should remain as supported as possible.

#define ST_ROOT         1
#define ST_USERDIR      2
#define ST_SOFTLINK     3       // looks like dir, but may point to a file!
#define ST_LINKDIR      4       // hard link to dir
#define ST_FILE         -3      // must be negative for FIB!
#define ST_LINKFILE     -4      // hard link to file
#define ST_PIPEFILE     -5      // for pipes that support ExamineFH

*/


stem_item=1;
items=0;

for(list_item=0;list_item<CDWin->FileCount;list_item++)
 {
  if (!ldir) /* new! 2.4b16 */
   {
    RexxPrintDec(dldir,stem_item); /* 2.5b13 rri */
    RexxPrintDec_sbuff(dl[list_item]->dir); /* 2.5b13 rri */
    outputRexxVar(sbuff); /* 2.5b13 rri */
   }
  else if (ldir==1)
   {
    if (!dl[list_item]->dir)
     {
      continue;
     }
   }
  else if (ldir==2)
   {
    if (dl[list_item]->dir)
     {
      continue;
     }
   }
  if (!lsel) /* new! 2.4b16 */
   {
    RexxPrintDec(dlsel,stem_item); /* 2.5b13 rri */
    RexxPrintDec_sbuff(dl[list_item]->sel); /* 2.5b13 rri */
    outputRexxVar(sbuff); /* 2.5b13 rri */
   }
  else if(lsel==1)
   {
    if(!dl[list_item]->sel)
     {
      continue;
     }
   }
  else if(lsel==2)
   {
    if(dl[list_item]->sel)
     {
      continue;
     }
   }
  RexxPrintDec(dlname,stem_item); /* 2.5b13 rri */
  outputRexxVar(dl[list_item]->name); /* 2.5b13 rri */
  items++;

  if(lsize)
   {
    RexxPrintDec(dlsize,stem_item); /* 2.5b13 rri */
    RexxPrintDec_sbuff(dl[list_item]->size); /* 2.5b13 rri */
    outputRexxVar(sbuff); /* 2.5b13 rri */
   }
  if(lcomm&&dl[list_item]->cmt) /* new! 2.4b14 */
   {
    RexxPrintDec(dlcomm,stem_item); /* 2.5b13 rri */
    outputRexxVar(dl[list_item]->cmt); /* 2.5b13 rri */
   }
  if(lprot)
   {
    RexxPrintDec(dlprot,stem_item); /* 2.5b13 rri */
    StampProt(sbuff,dl[list_item]->attr);
    sbuff[8]=0;
    outputRexxVar(sbuff); /* 2.5b13 rri */
   }
  if(ldate) /* new! 2.4b14 */
   {
    RexxPrintDec(dldate,stem_item); /* 2.5b13 rri */
    RexxPrintDec_sbuff(dl[list_item]->ds.ds_Days); /* 2.5b13 rri */
    outputRexxVar(sbuff); /* 2.5b13 rri */
   }
  stem_item++;
 }

if(!lsel)
 {
  RexxPrintDec(dlsel,0); /* 2.5b13 rri */
  sprintf(ptr,"%ld",CDWin->Sels);
  outputRexxVar(ptr); /* 2.5b13 rri */
 }
RexxPrintDec(dlname,0); /* 2.5b13 rri */
sprintf(ptr,"%ld",items);
outputRexxVar(ptr); /* 2.5b13 rri */
dcPath[0]=0;
}


void doSetList(UBYTE *var)
{
struct DirWindow *dw=CDWin;
struct DirList *dlp;
UBYTE *ptr;

if(!var) return;
StrToUpper(var); /* 2.5b7 rri */
FreeDirTable(dw);
dw->Path[0]=0; /* 2.5b7 rri */
dw->ColsCmt=dw->ColsName=0;
sprintf(dcPath,"%s.0",var);
if (GetRexxVar(rxMsg,dcPath,&ptr)==0&&(*ptr)) strcpy(dw->Path,ptr); /* new! 2.4 */
for(;;)
 {
  sprintf(dcPath,"%s.%ld",var,dw->FileCount+1);
  if(GetRexxVar(rxMsg,dcPath,&ptr)>0||!AllocDlp(dw)||!ptr||*ptr==0) break; /* new! 2.4 */
  dlp=dw->DirList[dw->FileCount++];
  dlp->dir=4;
  dlp->name = CloneStr(ptr, NamePool); /* 2.5b10 rri */
 }
dcPath[0]=0;
ReSize(dw);
NewSize(dw);
}


void RexxStatus(void) /* new! 2.4 */
{
LONG ID; /* 2.5b10 rri */

ID=GetID();

switch(ToUpper((ULONG)ActionArgs[1][0])) /* 2.5b10 rri */
 {
  case 'D': if(DestWin) rexxStr=DestWin->Path;
            break;
  case 'E': if(DirWin[ID]) /* new! 2.4 */
             {
              sprintf(RexxReturn,"%ld",DirWin[ID]->FileCount);
              rexxStr=RexxReturn;
             }
            break;
  case 'F': rexxStr=DispFormat;
            break;
  case 'H': if(HostID[0]) rexxStr=HostID;
            else rexxStr=DMname;
            break;
  case 'P': if (DirWin[ID]&&DirWin[ID]->Path[0]) rexxStr=DirWin[ID]->Path; /* new! 2.3 */
            break;
  case 'S': if(DirWin[ID]) /* new! 2.4 */
             {
              sprintf(RexxReturn,"%ld",DirWin[ID]->Sels);
              rexxStr=RexxReturn;
             }
            break;
  case 'V': rexxStr=Version;
            break;
  case 'W': sprintf(RexxReturn,"%ld",DWNum);
            rexxStr=RexxReturn;
 }
}


int GetID(void) /* new! 2.4 */
{
int i,id=0; /* 2.5b10 rri */

for(i=0;i<255;i++)
 {
  if(CDWin==DirWin[i])
   {
    id=i;
   }
 }
return (id);
}


void Filestat(void) /* 2.5b5 rri */
{
struct FileInfoBlock *StatFib;
BPTR lock;
long result=0; /* 2.5b10 rri */

if(!ActionArgs[1])
 {
  return;
 }

AArg2Str(dlvar, dlbase, 31, TRUE, "LIST");  /* 2.5b6 jjt (30.5.00) */

if(lock=Lock(ActionArgs[1],ACCESS_READ))
 {
  if(StatFib=AllocMem(sizeof(sFIB),MEMF_PUBLIC))
   {
    if(Examine(lock,StatFib))
     {
      RexxPrint(dlsize); /* 2.5b13 rri */
      RexxPrintDec_sbuff(StatFib->fib_Size); /* 2.5b13 rri */
      outputRexxVar(sbuff); /* 2.5b13 rri */
      RexxPrint(dlcomm); /* 2.5b13 rri */
      outputRexxVar(StatFib->fib_Comment); /* 2.5b13 rri */
      RexxPrint(dlprot); /* 2.5b13 rri */
      StampProt(sbuff,StatFib->fib_Protection);
      sbuff[8]=0;
      outputRexxVar(sbuff); /* 2.5b13 rri */
      RexxPrint(dldate); /* 2.5b13 rri */
      RexxPrintDec_sbuff(StatFib->fib_Date.ds_Days); /* 2.5b13 rri */
      outputRexxVar(sbuff); /* 2.5b13 rri */
      if(StatFib->fib_DirEntryType<0)
       {
        result=0;
       }
      else
       {
        result=1;
       }
     }
    FreeMem(StatFib,sizeof(sFIB));
   }
  UnLock(lock);
 }
else
 {
  result=(-1); /* 2.5b10 rri */
 }
RexxPrintDec_sbuff(result); /* 2.5b13 rri */
rxMsg->rm_Result2=(LONG)CreateArgstring(sbuff,(ULONG) strlen(sbuff)); /* 2.5b10 rri */

SetRexxVar(rxMsg,dlbase,sbuff,(ULONG) strlen(sbuff));
}


void WinInfo(void) /* 2.5b5 rri */
{
struct DirWindow *dw;
int id,path,status;
LONG n,list_item; /* 2.5b13 rri */

AArg2Str(dlvar, dlbase, 31, TRUE, "LIST");  /* 2.5b6 jjt (30.5.00) */

id=GetActionArg(dlid, AATYPE_BOOL, 0);
path=GetActionArg(dlpath, AATYPE_BOOL, 0);
status=GetActionArg(dlstatus, AATYPE_BOOL, 0);

n=1;

for(list_item=0;list_item<255;list_item++)
 {
  dw=DirWin[list_item];
  if(dw)
   {
    if (id)
     {
      RexxPrintDec(dlid,n); /* 2.5b13 rri */
      RexxPrintDec_sbuff(list_item); /* 2.5b13 rri */
      outputRexxVar(sbuff); /* 2.5b13 rri */
     }
    if (path)
     {
      RexxPrintDec(dlpath,n); /* 2.5b13 rri */
      outputRexxVar(dw->Path); /* 2.5b13 rri */
     }
    if (status)
     {
      RexxPrintDec(dlstatus,n); /* 2.5b13 rri */
      if(dw->Flags&DW_CMD)
       {
        sprintf(sbuff,"%s","CMD");
       }
      else
       {
        if(dw->parent.GadgetText->IText[0]=='S') /* 2.5b13 rri */
         {
          sprintf(sbuff,"%s","SOURCE");
         }
        else
         {
          if(dw->parent.GadgetText->IText[0]=='D') /* 2.5b13 rri */
           {
            sprintf(sbuff,"%s","DEST");
           }
          else
           {
            sprintf(sbuff,"%s","OFF");
           }
         }
       }
      outputRexxVar(sbuff); /* 2.5b13 rri */
     }
    n++;
   }
  sprintf(dcPath,"%s",dlbase);
  RexxPrintDec_sbuff(n-1); /* 2.5b13 rri */
  outputRexxVar(sbuff); /* 2.5b13 rri */
 }
}


void RXCMD_GetHistory(void) {   /* 2.5b11 jjt */
  UBYTE                *stem;
  ULONG                i;
  struct StringHistory *sh;

  /* [P]ath (default), [R]eader, or [M]isc string history. */
  stem = (STRPTR) GetActionArg("HISTORY", AATYPE_STR, (LONG) "P");
  *stem |= 32;  /* To lowercase */
  sh = (*stem == 'm') ? &ReqHistory : (*stem == 'r') ? &ReadHistory : &PathHistory;

  stem = (STRPTR) GetActionArg("VAR", AATYPE_STR, (LONG) "LIST");
  StrToUpper(stem);

  for (i=0; i < sh->total; i++) {
    sprintf(dcPath, "%s.%ld", stem, i);
    outputRexxVar(sh->strcache[i]); /* 2.5b13 rri */
  }

  sprintf(dcPath, "%s.COUNT", stem);
  i = stcl_d(sbuff, i);
  SetRexxVar(rxMsg, dcPath, sbuff, i);
}
